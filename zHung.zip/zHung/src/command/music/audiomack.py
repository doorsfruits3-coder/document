import threading
import time
import asyncio
import os
from src.services.browserAPI.audiomackApi import *
from app.module.utils import MediaCache

Platf = "audiomack"
Timeout = 120

def HandleAudiomackSend(self, Data, Song, ThreadId, ThreadType):
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    Sid = Song["id"]
    Cache = self.MediaCache.get(Platf, Sid)

    if Cache:
        FileUrl = Cache.get("fileUrl")
        if FileUrl and self.MediaCache.isAlive(FileUrl):
            try:
                self.sendReaction(Data, "", ThreadId, ThreadType, -1)
                self.sendRemoteVoice(FileUrl, ThreadId, ThreadType)
                self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
                return
            except Exception:
                self.MediaCache.remove(Platf, Sid)

    Path = download(Song)
    if not Path:
        self.sendMentionStyle("Failed download", None, ThreadId, ThreadType)
        return

    Upload = asyncio.run(self._uploadAttachmentAsync(Path, ThreadId, ThreadType))
    FileUrl = Upload.get("fileUrl")

    if FileUrl:
        self.sendReaction(Data, "", ThreadId, ThreadType, -1)
        self.sendRemoteVoice(FileUrl, ThreadId, ThreadType)
        self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
        self.MediaCache.set(
            Platf,
            Sid,
            {"title": Song.get("title"), "artist": Song.get("artist")},
            FileUrl,
        )

    try:
        os.remove(Path)
    except Exception:
        pass


def FormatAudiomackList(self, Songs):
    Lines = ["Chọn số để phát bài:\n"]
    for i, s in enumerate(Songs, 1):
        Lines.append(
            f"{i}. {s.get('title','Unknown')} - {s.get('artist','Unknown')}"
        )
    Lines.append("\n0. Huỷ")
    return "\n".join(Lines)


def StartAudiomackCooldown(self, MsgObj, ThreadId, ThreadType):
    if not hasattr(self, "_audiomackCooldown"):
        self._audiomackCooldown = {}

    key = MsgObj.msgId
    self._audiomackCooldown[key] = True

    msg = MessageObject(
        msgId=MsgObj.msgId,
        cliMsgId=MsgObj.clientId,
        msgType="webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not self._audiomackCooldown.get(key):
                break
            self.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            self.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        self._audiomackCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()


def AudiomackCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    Parts = MessageObj.text.strip().split()
    if len(Parts) < 2:
        return self.sendMentionStyle(
            f"📍Please enter the keyword for the song you want to search for on AudioMack.",
            UserId,
            ThreadId,
            ThreadType,
        )

    Arg = Parts[1]
    State = self.audiomackStates.get(UserId)

    if Arg.isdigit() and State:
        if time.time() - State["time"] > Timeout:
            self.audiomackStates.pop(UserId, None)
            return self.sendMentionStyle("Selection expired", UserId, ThreadId, ThreadType)

        Num = int(Arg)
        if Num == 0:
            self.audiomackStates.pop(UserId, None)
            return

        Songs = State["songs"]
        if Num < 1 or Num > len(Songs):
            return

        key = State.get("msgId")
        if hasattr(self, "_audiomackCooldown") and key:
            self._audiomackCooldown[key] = False

        Song = Songs[Num - 1]
        self.audiomackStates.pop(UserId, None)
        self.sendReaction(Data, "🕑", ThreadId, ThreadType, 1000000023)
        threading.Thread(
            target=lambda: HandleAudiomackSend(self, Data, Song, ThreadId, ThreadType),
            daemon=True,
        ).start()
        return

    Songs = search_song(Arg)
    if not Songs:
        return self.sendMentionStyle("No result", UserId, ThreadId, ThreadType)

    Msg = self.sendMentionStyle(
        FormatAudiomackList(self, Songs),
        UserId,
        ThreadId,
        ThreadType,
    )

    self.audiomackStates[UserId] = {
        "songs": Songs,
        "time": time.time(),
        "msgId": getattr(Msg, "msgId", None),
        "cliMsgId": getattr(Msg, "clientId", None),
        "threadId": ThreadId,
        "typeGr": ThreadType,
    }

    StartAudiomackCooldown(self, Msg, ThreadId, ThreadType)


def InitTimeoutAudiomack(self, Interval=1):
    def Loop():
        while True:
            Now = time.time()
            for Uid, State in list(self.audiomackStates.items()):
                if Now - State["time"] > Timeout:
                    self.audiomackStates.pop(Uid, None)
                    try:
                        self.deleteMessage(
                            State["msgId"],
                            self.uid,
                            State["cliMsgId"],
                            State["threadId"],
                        )
                    except Exception:
                        pass
                    self.sendMentionStyle(
                        "Timed out, please search again",
                        Uid,
                        State["threadId"],
                        State["typeGr"],
                    )
            time.sleep(Interval)

    threading.Thread(target=Loop, daemon=True).start()


def AudiomackReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    State = self.audiomackStates.get(UserId)
    if not State:
        return

    Msg = MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)
    Msg = Msg.strip()
    if not Msg.isdigit() or not Data.quote:
        return

    MsgId = State.get("msgId")
    CliMsgId = State.get("cliMsgId")

    NumMessage = Message(text=f"{self.prefix}audiomack {Msg}")
    AudiomackCommand(self, NumMessage, Data, UserId, ThreadId, ThreadType)

    if MsgId and CliMsgId:
        try:
            self.deleteMessage(MsgId, self.uid, CliMsgId, ThreadId)
        except Exception:
            pass


dependencies = {
    "name": "audiomack",
    "permission": 0,
    "cooldown": 5,
    "description": "Songs on Audiomack",
    "main": AudiomackCommand,
}