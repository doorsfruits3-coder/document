import os
import re
import uuid
import time
import asyncio
import threading

from src.services.browserAPI.nhaccuatuiApi import (
    nct_search,
    nct_download,
    nct_resolve,
    nct_get_lyric,
)
from src.services.pillow.soundcloudCard import draw_soundcloud_card
from src.services.pillow.soundcloudListCard import draw_soundcloud_list
from app.module.utils import MediaCache
from app.core.index import *

Platf   = "nhaccuatui"
Timeout = 120

MUSIC_CAPTIONS = [
    "Âm nhạc là ngôn ngữ mà linh hồn dùng để nói chuyện với trái tim. 🎵",
    "Mỗi bài hát là một cuốn nhật ký không cần chữ viết. 🎶",
    "Có những điều không thể nói bằng lời, nhưng âm nhạc thì có thể. 🎼",
    "Âm nhạc chữa lành những vết thương mà lời nói không chạm tới được. 🎸",
    "Cuộc đời không có nhạc nền sẽ chỉ là một bộ phim câm. 🎹",
    "Hãy để âm thanh dẫn đường khi con tim lạc lối. 🎷",
    "Một giai điệu đúng lúc có thể thay đổi cả một ngày dài. 🎺",
    "Âm nhạc là khi ngôn ngữ kết thúc, cảm xúc bắt đầu. 🎻",
]
_caption_index = 0

def _next_caption():
    global _caption_index
    cap = MUSIC_CAPTIONS[_caption_index % len(MUSIC_CAPTIONS)]
    _caption_index += 1
    return cap

def _extract_number(text):
    cleaned = re.sub(r'@\S+', '', text)
    match   = re.search(r'\b(\d+)\b', cleaned)
    return match.group(1) if match else None

def _fmt(t):
    t = int(t or 0)
    if t > 24 * 3600:
        t //= 1000
    h, t = divmod(t, 3600)
    m, s = divmod(t, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


# ── Send handler ─────────────────────────────────────────────────────────────

def HandleNctSend(self, Data, Song, ThreadId, ThreadType,
                  UserId=None, LoadingMsgId=None, LoadingCliMsgId=None,
                  WantLyric=False):
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    Sid   = Song.get("id") or Song.get("key") or str(int(time.time() * 1000))
    Cache = self.MediaCache.get(Platf, Sid)

    def _delete_loading():
        if LoadingMsgId and LoadingCliMsgId:
            try:
                self.deleteMessage(LoadingMsgId, self.uid, LoadingCliMsgId, ThreadId)
            except Exception:
                pass

    def _send_card_caption_and_voice(file_url):
        card_path = None
        image_url = None
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_soundcloud_card(
                {
                    "cover":    Song.get("cover") or Song.get("image") or "",
                    "title":    Song.get("title",  "Unknown"),
                    "artist":   Song.get("artist", "Unknown"),
                    "duration": Song.get("duration", 0),
                },
                card_path,
            )
            image_res = self._uploadImage(card_path, ThreadId, ThreadType)
            if isinstance(image_res, dict):
                image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
            elif isinstance(image_res, str) and image_res.startswith("http"):
                image_url = image_res
        except Exception as e:
            print(f"[NctCard] draw/upload error: {e}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        _delete_loading()

        caption_line = _next_caption()

        if image_url:
            try:
                name         = self.userName(UserId) or str(UserId)
                mention_text = f"@{name}"
                caption      = f"🎵 {mention_text} {caption_line}"
                self.sendRemoteImage(
                    image_url,
                    ThreadId,
                    ThreadType,
                    width=2048,
                    height=622,
                    message=Message(
                        text=caption,
                        mention=Mention(UserId, length=len(mention_text), offset=3),
                    ),
                )
            except Exception as e:
                print(f"[NctCard] sendRemoteImage error: {e}")
        else:
            self.sendMentionStyle(caption_line, UserId, ThreadId, ThreadType)

        self.sendRemoteVoice(file_url if file_url.endswith(".aac") else file_url + ".aac", ThreadId, ThreadType)

        # ── Gửi lyric riêng sau voice (chỉ khi user yêu cầu) ─────────────────
        if WantLyric:
            try:
                song_key   = Song.get("key") or Song.get("id")
                link_share = Song.get("linkShare") or Song.get("link") or ""
                if song_key:
                    lyric = nct_get_lyric(song_key, link_share=link_share)
                    if lyric:
                        self.sendMessage(
                            Message(text=lyric),
                            ThreadId,
                            ThreadType,
                        )
            except Exception as e:
                print(f"[NctLyric] send error: {e}")

    # ── Try cache first ───────────────────────────────────────────────────────
    if Cache:
        FileUrl = Cache.get("fileUrl")
        if FileUrl and self.MediaCache.isAlive(FileUrl):
            try:
                self.sendReaction(Data, "", ThreadId, ThreadType, -1)
                _send_card_caption_and_voice(FileUrl)
                self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
                return
            except Exception:
                self.MediaCache.remove(Platf, Sid)

    # ── Download ──────────────────────────────────────────────────────────────
    filePath = None
    try:
        filePath = nct_download(Song)
        if not filePath:
            _delete_loading()
            self.sendMentionStyle("Không tải được bài hát", UserId, ThreadId, ThreadType)
            return

        upload  = asyncio.run(
            self._uploadAttachmentAsync(filePath, ThreadId, ThreadType)
        )
    finally:
        if filePath and os.path.exists(filePath):
            try:
                os.remove(filePath)
            except Exception:
                pass

    FileUrl = upload.get("fileUrl") if upload else None
    if not FileUrl:
        _delete_loading()
        self.sendMentionStyle("Upload thất bại", UserId, ThreadId, ThreadType)
        return

    self.sendReaction(Data, "", ThreadId, ThreadType, -1)
    _send_card_caption_and_voice(FileUrl)
    self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)

    self.MediaCache.set(
        Platf,
        Sid,
        {
            "title":  Song.get("title"),
            "artist": Song.get("artist"),
            "cover":  Song.get("cover") or Song.get("image"),
        },
        FileUrl,
    )


# ── Cooldown reaction loop ────────────────────────────────────────────────────

def StartNctCooldown(self, MsgObj, ThreadId, ThreadType):
    if not hasattr(self, "_nctCooldown"):
        self._nctCooldown = {}

    key = getattr(MsgObj, "msgId", None)
    if not key:
        return
    self._nctCooldown[key] = True

    msg = MessageObject(
        msgId=key,
        cliMsgId=getattr(MsgObj, "clientId", None),
        msgType="webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not self._nctCooldown.get(key):
                break
            self.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            self.sendMultiReaction(msg, "",   ThreadId, ThreadType, -1,      numreact=i)
        self._nctCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()


# ── Main command ─────────────────────────────────────────────────────────────

def NctCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    from api.util.Enum import ThreadType as _TT
    if ThreadType == _TT.USER:
        return self.sendMentionStyle(
            "Tính năng nghe nhạc chỉ dùng được trong nhóm. 🎵",
            UserId, ThreadId, ThreadType,
        )

    if not hasattr(self, "nctStates"):
        self.nctStates = {}
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    Parts = MessageObj.text.strip().split()
    if len(Parts) < 2:
        return self.sendMentionStyle(
            "📍 Nhập tên bài hát muốn tìm trên NhacCuaTui.",
            UserId, ThreadId, ThreadType,
        )

    Arg   = " ".join(Parts[1:])
    State = self.nctStates.get(UserId)

    # ── User picking a number ─────────────────────────────────────────────────
    if Arg.strip().isdigit() and State:
        if time.time() - State["time"] > Timeout:
            self.nctStates.pop(UserId, None)
            return self.sendMentionStyle("Đã hết giờ chọn", UserId, ThreadId, ThreadType)

        Num = int(Arg.strip())

        if Num == 0:
            key = State.get("msgId")
            if hasattr(self, "_nctCooldown") and key:
                self._nctCooldown[key] = False
            self.nctStates.pop(UserId, None)
            return

        Songs = State["songs"]
        if Num < 1 or Num > len(Songs):
            return

        key = State.get("msgId")
        if hasattr(self, "_nctCooldown") and key:
            self._nctCooldown[key] = False

        Song = Songs[Num - 1]
        WantLyric = State.get("wantLyric", False)
        self.nctStates.pop(UserId, None)

        LoadingMsg = self.sendMentionStyle(
            "⏳ Đợi mình tải nhạc chút nhé...",
            UserId, ThreadId, ThreadType,
        )
        LoadingMsgId = getattr(LoadingMsg, "msgId",    None)
        LoadingCliId = getattr(LoadingMsg, "clientId", None)

        self.sendReaction(Data, "🕑", ThreadId, ThreadType, 1000000023)
        threading.Thread(
            target=lambda: HandleNctSend(
                self, Data, Song, ThreadId, ThreadType,
                UserId=UserId,
                LoadingMsgId=LoadingMsgId,
                LoadingCliMsgId=LoadingCliId,
                WantLyric=WantLyric,
            ),
            daemon=True,
        ).start()
        return

    # ── Search ────────────────────────────────────────────────────────────────
    Songs = nct_search(Arg, limit=10)
    if not Songs:
        return self.sendMentionStyle("Không tìm thấy bài hát", UserId, ThreadId, ThreadType)

    list_path = None
    list_url  = None
    try:
        os.makedirs("data/assets/cache/cards", exist_ok=True)
        list_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
        draw_soundcloud_list(
            [
                {
                    "title":    s.get("title",  "Unknown"),
                    "artist":   s.get("artist", "Unknown"),
                    "duration": _fmt(s.get("duration")),
                    "cover":    s.get("cover") or s.get("image") or "",
                }
                for s in Songs
            ],
            list_path,
            keyword=Arg,
        )
        image_res = self._uploadImage(list_path, ThreadId, ThreadType)
        if isinstance(image_res, dict):
            list_url = image_res.get("normalUrl") or image_res.get("hdUrl")
        elif isinstance(image_res, str) and image_res.startswith("http"):
            list_url = image_res
    except Exception as e:
        print(f"[NctList] error: {e}")
    finally:
        if list_path and os.path.exists(list_path):
            try:
                os.remove(list_path)
            except Exception:
                pass

    if list_url:
        name         = self.userName(UserId) or str(UserId)
        mention_text = f"@{name}"
        caption      = f"🎵 {mention_text} Reply và chọn số để phát, 0 để huỷ thêm lyric để lấy lời."
        Msg = self.sendRemoteImage(
            list_url,
            ThreadId,
            ThreadType,
            width=2560,
            height=1440,
            message=Message(
                text=caption,
                mention=Mention(UserId, length=len(mention_text), offset=3),
            ),
        )
    else:
        lines = ["Chọn số để phát bài:\n"]
        for i, s in enumerate(Songs, 1):
            lines.append(f"{i}. {s['title']} - {s['artist']} - {_fmt(s['duration'])}")
        lines.append("\n0. Huỷ")
        Msg = self.sendMentionStyle("\n".join(lines), UserId, ThreadId, ThreadType)

    self.nctStates[UserId] = {
        "songs":    Songs,
        "time":     time.time(),
        "msgId":    getattr(Msg, "msgId",    None),
        "cliMsgId": getattr(Msg, "clientId", None),
        "threadId": ThreadId,
        "typeGr":   ThreadType,
    }

    StartNctCooldown(self, Msg, ThreadId, ThreadType)


# ── Reply handler (quote) ─────────────────────────────────────────────────────

def NctReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    State = self.nctStates.get(UserId) if hasattr(self, "nctStates") else None
    if not State:
        return

    RawText = MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)
    if not Data.quote:
        return

    # Detect "1 lyric" hoặc "lyric 1"
    WantLyric = bool(re.search(r'\blyric\b', RawText, re.I))
    NumStr    = _extract_number(RawText)
    if not NumStr:
        return

    # Gọi NctCommand với số, rồi truyền WantLyric vào HandleNctSend
    State["wantLyric"] = WantLyric
    NumMsg = Message(text=f"{self.prefix}nct {NumStr}")
    NctCommand(self, NumMsg, Data, UserId, ThreadId, ThreadType)

    try:
        self.deleteMessage(
            State["msgId"],
            self.uid,
            State["cliMsgId"],
            ThreadId,
        )
    except Exception:
        pass


# ── Timeout loop ──────────────────────────────────────────────────────────────

def InitTimeoutNct(self, Interval=1):
    if not hasattr(self, "nctStates"):
        self.nctStates = {}

    def Loop():
        while True:
            Now = time.time()
            for Uid, State in list(self.nctStates.items()):
                if Now - State["time"] > Timeout:
                    self.nctStates.pop(Uid, None)
                    try:
                        self.deleteMessage(
                            State["msgId"],
                            self.uid,
                            State["cliMsgId"],
                            State["threadId"],
                        )
                    except Exception:
                        pass
                    self.sendMentionStyle(
                        "Đã hết giờ, hãy tìm lại nhé",
                        Uid,
                        State["threadId"],
                        State["typeGr"],
                    )
            time.sleep(Interval)

    threading.Thread(target=Loop, daemon=True).start()

dependencies = {
    "name":        "nhaccuatui",
    "permission":  0,
    "cooldown":    5,
    "description": "Songs on NhacCuaTui",
    "main":        NctCommand,
}