import os
import uuid
import time
import asyncio
import threading

from src.services.browserAPI.soundcloudApi import *
from src.services.pillow.soundcloudCard import draw_soundcloud_card
from src.services.pillow.soundcloudListCard import draw_soundcloud_list
from app.module.utils import MediaCache
from app.core.index import *

Platf   = "soundcloud"
Timeout = 120

MUSIC_CAPTIONS = [
    "Âm nhạc là ngôn ngữ mà linh hồn dùng để nói chuyện với trái tim. 🎵",
    "Mỗi bài hát là một cuốn nhật ký không cần chữ viết. 🎶",
    "Có những điều không thể nói bằng lời, nhưng âm nhạc thì có thể. 🎼",
    "Âm nhạc chữa lành những vết thương mà lời nói không chạm tới được. 🎸",
    "Cuộc đời không có nhạc nền sẽ chỉ là một bộ phim câm. 🎹",
    "Hãy để âm thanh dẫn đường khi con tim lạc lối. 🎷",
    "Một giai điệu đúng lúc có thể thay đổi cả một ngày dài. 🎺",
    "Âm nhạc là khi ngôn ngữ kết thúc, cảm xúc bắt đầu. 🎻",
]
_caption_index = 0

def _next_caption():
    global _caption_index
    cap = MUSIC_CAPTIONS[_caption_index % len(MUSIC_CAPTIONS)]
    _caption_index += 1
    return cap

def _extract_number(text):
    import re
    cleaned = re.sub(r'@\S+', '', text)
    match = re.search(r'\b(\d+)\b', cleaned)
    if match:
        return match.group(1)
    return None

def _fmt(t):
    t = int(t or 0)
    if t > 24 * 3600:
        t //= 1000
    h, t = divmod(t, 3600)
    m, s = divmod(t, 60)
    return f"{h:02d}:{m:02d}:{s:02d}"


def HandleSCSend(self, Data, Song, ThreadId, ThreadType, UserId=None, LoadingMsgId=None, LoadingCliMsgId=None):
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()

    Sid   = Song["id"]
    Cache = self.MediaCache.get(Platf, Sid)

    def _delete_loading():
        if LoadingMsgId and LoadingCliMsgId:
            try:
                self.deleteMessage(LoadingMsgId, self.uid, LoadingCliMsgId, ThreadId)
            except Exception:
                pass

    def _send_card_caption_and_voice(file_url):
        card_path = None
        image_url = None
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_soundcloud_card(
                {
                    "cover":    Song.get("thumb") or Song.get("thumb2") or "",
                    "title":    Song.get("title",  "Unknown"),
                    "artist":   Song.get("artist", "Unknown"),
                    "duration": Song.get("duration", 0),
                },
                card_path,
            )
            image_res = self._uploadImage(card_path, ThreadId, ThreadType)
            if isinstance(image_res, dict):
                image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
            elif isinstance(image_res, str) and image_res.startswith("http"):
                image_url = image_res
        except Exception as e:
            print(f"[SCCard] draw/upload error: {e}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        _delete_loading()

        caption_line = _next_caption()
        if image_url:
            try:
                name         = self.userName(UserId) or str(UserId)
                mention_text = f"@{name}"
                caption      = f"🎵 {mention_text} {caption_line}"
                self.sendRemoteImage(
                    image_url,
                    ThreadId,
                    ThreadType,
                    width=2048,
                    height=622,
                    message=Message(
                        text=caption,
                        mention=Mention(UserId, length=len(mention_text), offset=3)
                    )
                )
            except Exception as e:
                print(f"[SCCard] sendRemoteImage error: {e}")
        else:
            self.sendMentionStyle(caption_line, UserId, ThreadId, ThreadType)

        self.sendRemoteVoice(file_url, ThreadId, ThreadType)

    if Cache:
        FileUrl = Cache.get("fileUrl")
        if FileUrl and self.MediaCache.isAlive(FileUrl):
            try:
                self.sendReaction(Data, "", ThreadId, ThreadType, -1)
                _send_card_caption_and_voice(FileUrl)
                self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)
                return
            except Exception:
                self.MediaCache.remove(Platf, Sid)

    path = None
    try:
        path = download(Song)
        if not path:
            _delete_loading()
            self.sendMentionStyle("Không tải được bài hát", UserId, ThreadId, ThreadType)
            return

        upload = asyncio.run(self._uploadAttachmentAsync(path, ThreadId, ThreadType))
    finally:
        if path and os.path.exists(path):
            try:
                os.remove(path)
            except Exception:
                pass

    FileUrl = upload.get("fileUrl")
    if not FileUrl:
        _delete_loading()
        self.sendMentionStyle("Upload thất bại", UserId, ThreadId, ThreadType)
        return

    self.sendReaction(Data, "", ThreadId, ThreadType, -1)
    _send_card_caption_and_voice(FileUrl)
    self.sendReaction(Data, "/-ok", ThreadId, ThreadType, 100000000)

    self.MediaCache.set(
        Platf,
        Sid,
        {
            "title":  Song.get("title"),
            "artist": Song.get("artist"),
            "cover":  Song.get("thumb") or Song.get("thumb2") or "",
        },
        FileUrl,
    )


def StartSCCooldown(self, MsgObj, ThreadId, ThreadType):
    if not hasattr(self, "_scCooldown"):
        self._scCooldown = {}

    key = getattr(MsgObj, "msgId", None)
    if not key:
        return
    self._scCooldown[key] = True

    msg = MessageObject(
        msgId    = getattr(MsgObj, "msgId",    ""),
        cliMsgId = getattr(MsgObj, "clientId", ""),
        msgType  = "webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not self._scCooldown.get(key):
                break
            self.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            self.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        self._scCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()


def SoundCloudCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    Parts = MessageObj.text.strip().split()
    if len(Parts) < 2:
        return self.sendMentionStyle(
            "📍 Nhập keyword để tìm bài hát trên SoundCloud.",
            UserId, ThreadId, ThreadType,
        )

    if not hasattr(self, "scStates"):
        self.scStates = {}

    Arg   = " ".join(Parts[1:])
    State = self.scStates.get(UserId)

    if Arg.strip().isdigit() and State:
        if time.time() - State["time"] > Timeout:
            self.scStates.pop(UserId, None)
            return self.sendMentionStyle("Selection expired", UserId, ThreadId, ThreadType)

        Num = int(Arg.strip())
        if Num == 0:
            key = State.get("msgId")
            if hasattr(self, "_scCooldown") and key:
                self._scCooldown[key] = False
            self.scStates.pop(UserId, None)
            return

        Songs = State["songs"]
        if Num < 1 or Num > len(Songs):
            return

        key = State.get("msgId")
        if hasattr(self, "_scCooldown") and key:
            self._scCooldown[key] = False

        Song = Songs[Num - 1]
        self.scStates.pop(UserId, None)

        LoadingMsg = self.sendMentionStyle(
            "⏳ Wait, im trying to download...",
            UserId, ThreadId, ThreadType,
        )
        LoadingMsgId = getattr(LoadingMsg, "msgId",    None)
        LoadingCliId = getattr(LoadingMsg, "clientId", None)

        self.sendReaction(Data, "🕑", ThreadId, ThreadType, 1000000023)
        threading.Thread(
            target=lambda: HandleSCSend(
                self, Data, Song, ThreadId, ThreadType,
                UserId=UserId,
                LoadingMsgId=LoadingMsgId,
                LoadingCliMsgId=LoadingCliId,
            ),
            daemon=True,
        ).start()
        return

    try:
        Songs = search_song(Arg)
    except Exception as e:
        return self.sendMentionStyle(f"Lỗi tìm kiếm: {e}", UserId, ThreadId, ThreadType)

    if not Songs:
        return self.sendMentionStyle("Không tìm thấy kết quả", UserId, ThreadId, ThreadType)

    list_path = None
    list_url  = None
    try:
        os.makedirs("data/assets/cache/cards", exist_ok=True)
        list_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
        draw_soundcloud_list(Songs, list_path)
        image_res = self._uploadImage(list_path, ThreadId, ThreadType)
        if isinstance(image_res, dict):
            list_url = image_res.get("normalUrl") or image_res.get("hdUrl")
        elif isinstance(image_res, str) and image_res.startswith("http"):
            list_url = image_res
    except Exception as e:
        print(f"[SCList] canvas error: {e}")
    finally:
        if list_path and os.path.exists(list_path):
            try:
                os.remove(list_path)
            except Exception:
                pass

    if list_url:
        name         = self.userName(UserId) or str(UserId)
        mention_text = f"@{name}"
        caption      = f"🎵 {mention_text} Chọn số để phát • reply 0 để huỷ"
        Msg = self.sendRemoteImage(
            list_url,
            ThreadId,
            ThreadType,
            width=2560,
            height=1440,
            message=Message(
                text=caption,
                mention=Mention(UserId, length=len(mention_text), offset=3)
            )
        )
    else:
        lines = ["Chọn số để phát bài:\n"]
        for i, s in enumerate(Songs, 1):
            lines.append(f"{i}. {s.get('title','?')} - {s.get('artist','?')} - {_fmt(s.get('duration'))}")
        lines.append("\n0. Huỷ")
        Msg = self.sendMentionStyle("\n".join(lines), UserId, ThreadId, ThreadType)

    self.scStates[UserId] = {
        "songs":    Songs,
        "time":     time.time(),
        "msgId":    getattr(Msg, "msgId",    None),
        "cliMsgId": getattr(Msg, "clientId", None),
        "threadId": ThreadId,
        "typeGr":   ThreadType,
    }

    StartSCCooldown(self, Msg, ThreadId, ThreadType)


def SoundcloudReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    if not hasattr(self, "scStates"):
        self.scStates = {}
    State = self.scStates.get(UserId)
    if not State:
        return

    RawText = MessageObj.text if isinstance(MessageObj, Message) else str(MessageObj)
    NumStr  = _extract_number(RawText)
    if not NumStr or not Data.quote:
        return

    NumMessage = Message(text=f"{self.prefix}soundcloud {NumStr}")
    SoundCloudCommand(self, NumMessage, Data, UserId, ThreadId, ThreadType)

    try:
        self.deleteMessage(
            State["msgId"],
            self.uid,
            State["cliMsgId"],
            ThreadId,
        )
    except Exception:
        pass


def InitTimeoutSoundCloud(self, Interval=1):
    if not hasattr(self, "scStates"):
        self.scStates = {}

    def Loop():
        while True:
            Now = time.time()
            for Uid, State in list(self.scStates.items()):
                if Now - State["time"] > Timeout:
                    self.scStates.pop(Uid, None)
                    try:
                        self.deleteMessage(
                            State["msgId"],
                            self.uid,
                            State["cliMsgId"],
                            State["threadId"],
                        )
                    except Exception:
                        pass
                    self.sendMentionStyle(
                        "Timed out, please search again",
                        Uid,
                        State["threadId"],
                        State["typeGr"],
                    )
            time.sleep(Interval)

    threading.Thread(target=Loop, daemon=True).start()


dependencies = {
    "name":        "soundcloud",
    "permission":  0,
    "cooldown":    5,
    "description": "Songs on SoundCloud",
    "main":        SoundCloudCommand,
}