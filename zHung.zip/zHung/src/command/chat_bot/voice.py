import os
import uuid
import asyncio
import threading
from app.core.index import *

try:
    from gtts import gTTS
    GTTS_AVAILABLE = True
except ImportError:
    GTTS_AVAILABLE = False

LANG_MAP: dict[str, str] = {
    "vi": "vi", "vn": "vi",
    "en": "en", "us": "en",
    "zh": "zh-CN", "cn": "zh-CN",
    "zh-TW": "zh-TW", "tw": "zh-TW",
    "ja": "ja", "jp": "ja",
    "ko": "ko", "kr": "ko",
    "fr": "fr",
    "de": "de",
    "th": "th",
    "es": "es",
    "it": "it",
    "ru": "ru",
    "pt": "pt",
    "ar": "ar",
    "hi": "hi",
    "id": "id",
    "ms": "ms",
}

_CACHE_DIR = "data/assets/cache/voice"


class VoiceCommand:
    def __init__(self, ctx):
        self._ctx   = ctx
        self.prefix = getattr(ctx, "prefix", "/")
        self.cmd    = getattr(ctx, "commandName", "voice")

    def _reply(self, text: str, data, threadId, type, *, color: str, title: str, userId):
        return self._ctx.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title, userId=userId,
        )

    @staticmethod
    def _extract_text_from_quote(quote) -> str | None:
        msg = (getattr(quote, "msg", None) or "").strip()
        return msg if msg else None

    @staticmethod
    def _synthesize(text: str, lang: str) -> str:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        path = f"{_CACHE_DIR}/voice_{uuid.uuid4().hex}.mp3"
        gTTS(text=text, lang=lang, slow=False).save(path)
        return path

    @staticmethod
    def _cleanup(path: str):
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception:
            pass

    def _process(self, text: str, lang: str, data, threadId, type, userId):
        path = None
        try:
            path   = self._synthesize(text, lang)
            upload = asyncio.run(self._ctx._uploadAttachmentAsync(path, threadId, type))
            file_url = upload.get("fileUrl") if upload else None

            if not file_url:
                self._reply(
                    "Upload thất bại, thử lại sau.",
                    data, threadId, type,
                    color="r", title="ERROR", userId=userId,
                )
                return

            self._reply(
                f"✅ Đã chuyển văn bản sang giọng nói!\n🌐 Ngôn ngữ: {lang}",
                data, threadId, type,
                color="gr", title="COMPLETE", userId=userId,
            )
            self._ctx.sendRemoteVoice(file_url, threadId, type)

        except Exception as e:
            self._reply(
                f"Lỗi xử lý: {e}", data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        finally:
            if path:
                self._cleanup(path)

    def run(self, message, data, userId, threadId, type):
        if not GTTS_AVAILABLE:
            return self._reply(
                "Thiếu thư viện gTTS.\nCài đặt: pip install gtts",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

        text_raw  = (getattr(message, "text", "") or "").strip()
        cmd_token = f"{self.prefix}{self.cmd}"
        args_raw  = text_raw[len(cmd_token):].strip() if text_raw.lower().startswith(cmd_token.lower()) else text_raw

        if args_raw.lower().startswith("help=lang"):
            lines = [f"{'Mã':<8} {'Ngôn Ngữ'}", "─" * 28]
            lines += [f"{code:<8} {lang}" for code, lang in sorted(LANG_MAP.items())]
            return self._reply(
                "\n".join(lines), data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

        lang, text_to_speak = "vi", ""

        tokens = args_raw.split(maxsplit=1)
        if tokens and tokens[0].lower() in LANG_MAP:
            lang          = LANG_MAP[tokens[0].lower()]
            text_to_speak = tokens[1].strip() if len(tokens) > 1 else ""
        else:
            text_to_speak = args_raw

        if not text_to_speak:
            quote     = getattr(data, "quote", None)
            quote_msg = self._extract_text_from_quote(quote) if quote else None
            if quote_msg:
                text_to_speak = quote_msg
            else:
                guide = (
                    f"Nhập Nội Dung Cần Chuyển Sang Giọng Nói\n\n"
                    f"Ví Dụ:\n"
                    f"  📍 {self.prefix}{self.cmd} Hello Kefl.\n"
                    f"  📍 {self.prefix}{self.cmd} ja Xin chào từ tiếng Nhật.\n"
                    f"  📍 {self.prefix}{self.cmd} help=lang Xem các ngôn ngữ hỗ trợ."
                )
                return self._reply(
                    guide, data, threadId, type,
                    color="or", title="CAUTION", userId=userId,
                )

        self._reply(
            f"🎙️ Đang tạo giọng nói...\n🌐 Ngôn ngữ: {lang}",
            data, threadId, type,
            color="or", title="PROCESSING", userId=userId,
        )

        threading.Thread(
            target=self._process,
            args=(text_to_speak, lang, data, threadId, type, userId),
            daemon=True,
        ).start()


def voiceCommand(self, message, data, userId, threadId, type):
    VoiceCommand(self).run(message, data, userId, threadId, type)


dependencies = {
    "name":        "voice",
    "permission":  0,
    "cooldown":    10,
    "description": "Chuyển văn bản sang giọng nói",
    "main":        voiceCommand,
}