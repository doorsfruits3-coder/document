"""
capcut.py  –  Lệnh tìm kiếm template CapCut cho zBot
Đặt file tại:  zBot/src/command/chat_bot/capcut.py

Tính năng:
  /capcut <từ khoá>      → tìm kiếm, hiển thị danh sách template (card ảnh)
  /capcut <từ khoá> → reply <số>  → xem chi tiết + link template
  /capcut <url CapCut>   → xem chi tiết template từ link trực tiếp
"""

import os
import re
import time
import uuid
import threading

import requests

from app.core.index import *
from src.services.pillow.capcutListCard import draw_capcut_list
from src.services.pillow.capcutCard import draw_capcut_card

# ── Hằng số ──────────────────────────────────────────────────────────────────
Platf          = "capcut"
SEARCH_TIMEOUT = 60   # giây chờ user chọn

CAPCUT_SEARCH_URL = "https://edit-api-sg.capcut.com/lv/v1/cc_web/replicate/search_templates"
CAPCUT_HEADERS    = {
    "accept":           "application/json, text/plain, */*",
    "accept-language":  "en-US,en;q=0.9,vi;q=0.8",
    "app-sdk-version":  "48.0.0",
    "appvr":            "5.8.0",
    "content-type":     "application/json",
    "device-time":      "1734146729",
    "lan":              "vi-VN",
    "loc":              "va",
    "origin":           "https://www.capcut.com",
    "pf":               "7",
    "referer":          "https://www.capcut.com/",
    "sign":             "8c69245fb9e23bbe2401518a277ef9d4",
    "sign-ver":         "1",
    "user-agent":       (
        "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/131.0.0.0 Mobile Safari/537.36"
    ),
}

des = {
    "version":     "1.0.0",
    "credits":     "zBot",
    "description": "Tìm kiếm template video CapCut",
    "power":       "Thành viên",
}


# ── Tìm kiếm CapCut ───────────────────────────────────────────────────────────
def _search_capcut(query: str, limit: int = 10) -> list:
    """Gọi API CapCut, trả về list template."""
    try:
        payload = {
            "cc_web_version": 0,
            "count":          limit,
            "cursor":         "0",
            "enter_from":     "workspace",
            "query":          query,
            "scene":          1,
            "sdk_version":    "86.0.0",
            "search_version": 2,
        }
        r = requests.post(
            CAPCUT_SEARCH_URL,
            json=payload,
            headers=CAPCUT_HEADERS,
            timeout=10,
        )
        r.raise_for_status()
        data = r.json().get("data", {}) or {}
        return data.get("video_templates") or []
    except Exception as e:
        print(f"[CapCut] search error: {e}")
        return []


def _extract_number(text: str):
    cleaned = re.sub(r"@\S+", "", text or "")
    m = re.search(r"\b(\d+)\b", cleaned)
    return m.group(1) if m else None


def _is_capcut_url(text: str) -> bool:
    return bool(re.search(
        r"https?://(www\.)?capcut\.com/\S+",
        text or "",
        re.IGNORECASE,
    ))


def _fmt_num(n) -> str:
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


# ── State management ──────────────────────────────────────────────────────────
def _ensure_state(self):
    if not hasattr(self, "capcutStates"):
        self.capcutStates = {}


def _init_timeout_cleaner(self):
    def _loop():
        while True:
            now = time.time()
            for uid, state in list(self.capcutStates.items()):
                if now - state["time"] > SEARCH_TIMEOUT:
                    self.capcutStates.pop(uid, None)
                    try:
                        self.deleteMessage(
                            state["msgId"], self.uid,
                            state["cliMsgId"], state["threadId"]
                        )
                    except Exception:
                        pass
                    try:
                        self.sendMentionStyle(
                            "Hết thời gian, hãy tìm kiếm lại!",
                            uid, state["threadId"], state["typeGr"]
                        )
                    except Exception:
                        pass
            time.sleep(5)

    threading.Thread(target=_loop, daemon=True).start()


def _start_timeout_loop(self, key, msg_id, cli_id, thread_id, thread_type):
    """Đếm ngược reaction trên message danh sách."""
    if not hasattr(self, "_capcutCooldown"):
        self._capcutCooldown = {}
    self._capcutCooldown[key] = True

    def _loop():
        for i in range(SEARCH_TIMEOUT, 0, -1):
            if not self._capcutCooldown.get(key):
                break
            try:
                self.sendMultiReaction(
                    MessageObject(msgId=msg_id, cliMsgId=cli_id, msgType="webchat"),
                    "🕑", thread_id, thread_type, 102229, numreact=i
                )
                time.sleep(1)
                self.sendMultiReaction(
                    MessageObject(msgId=msg_id, cliMsgId=cli_id, msgType="webchat"),
                    "", thread_id, thread_type, -1, numreact=i
                )
            except Exception:
                break
        self._capcutCooldown.pop(key, None)

    threading.Thread(target=_loop, daemon=True).start()


def _stop_timeout(self, key):
    if hasattr(self, "_capcutCooldown"):
        self._capcutCooldown[key] = False


# ── Gửi chi tiết template ─────────────────────────────────────────────────────
def _send_template_detail(
    self, data, template, thread_id, thread_type, user_id,
    loading_msg_id=None, loading_cli_id=None
):
    """Vẽ card chi tiết và gửi link template."""

    def _delete_loading():
        if loading_msg_id and loading_cli_id:
            try:
                self.deleteMessage(loading_msg_id, self.uid, loading_cli_id, thread_id)
            except Exception:
                pass

    cache_dir = "data/assets/cache/capcut"
    os.makedirs(cache_dir, exist_ok=True)
    card_path = f"{cache_dir}/{uuid.uuid4().hex}.jpg"

    image_url = None
    try:
        draw_capcut_card(template, card_path)
        res = self._uploadImage(card_path, thread_id, thread_type)
        if isinstance(res, dict):
            image_url = res.get("normalUrl") or res.get("hdUrl")
        elif isinstance(res, str) and res.startswith("http"):
            image_url = res
    except Exception as e:
        print(f"[CapCut] card error: {e}")
    finally:
        if card_path and os.path.exists(card_path):
            try:
                os.remove(card_path)
            except Exception:
                pass

    _delete_loading()

    title      = template.get("title", "CapCut Template")
    plays      = _fmt_num(template.get("play_amount", 0))
    likes      = _fmt_num(template.get("like_count", 0))
    tpl_id     = template.get("template_id") or template.get("id") or ""
    link       = (
        f"https://www.capcut.com/template-detail/{tpl_id}"
        if tpl_id else "https://www.capcut.com"
    )

    name         = self.userName(user_id) or str(user_id)
    mention_text = f"@{name}"
    caption = (
        f"🎬 {mention_text}\n"
        f"▶ {plays}  ♥ {likes}\n"
        f"🔗 {link}"
    )

    if image_url:
        try:
            self.sendRemoteImage(
                image_url, thread_id, thread_type,
                width=2048, height=622,
                message=Message(
                    text=caption,
                    mention=Mention(user_id, length=len(mention_text), offset=3)
                )
            )
            return
        except Exception:
            pass

    # Fallback text
    self.sendMentionStyle(
        f"🎬 Template: {title}\n▶ {plays}  ♥ {likes}\n🔗 {link}",
        user_id, thread_id, thread_type
    )


# ── Main command ──────────────────────────────────────────────────────────────
def CapCutCommand(self, message_obj, data, user_id, thread_id, thread_type):
    _ensure_state(self)

    text     = (getattr(message_obj, "text", "") or "").strip()
    prefix   = getattr(self, "prefix", "/")
    cmd_name = getattr(self, "commandName", "capcut")

    cmd_tok = f"{prefix}{cmd_name}"
    if text.lower().startswith(cmd_tok.lower()):
        arg = text[len(cmd_tok):].strip()
    else:
        parts = text.split(maxsplit=1)
        arg   = parts[1].strip() if len(parts) > 1 else ""

    if not arg:
        guide = (
            f"🎬 Tìm kiếm template CapCut!\n\n"
            f"📍 {prefix}{cmd_name} <từ khoá>   – Tìm template\n"
            f"📍 Reply <số>             – Xem chi tiết + link\n"
            f"📍 {prefix}{cmd_name} <url CapCut> – Xem từ link\n\n"
            f"Ví dụ: {prefix}{cmd_name} wedding cinematic"
        )
        return self.replyMessageStyle(
            guide, data, thread_id, thread_type,
            color="or", title="CAPCUT", userId=user_id
        )

    # ── Chọn số từ danh sách ──────────────────────────────────────────────────
    state   = self.capcutStates.get(user_id)
    num_str = _extract_number(arg)

    if num_str and state:
        if time.time() - state["time"] > SEARCH_TIMEOUT:
            self.capcutStates.pop(user_id, None)
            return self.sendMentionStyle(
                "Hết thời gian, hãy tìm kiếm lại!",
                user_id, thread_id, thread_type
            )

        num = int(num_str)
        if num == 0:
            _stop_timeout(self, state.get("msgId"))
            self.capcutStates.pop(user_id, None)
            return

        items = state["items"]
        if num < 1 or num > len(items):
            return self.sendMentionStyle(
                f"Số không hợp lệ! Nhập từ 1 đến {len(items)}",
                user_id, thread_id, thread_type
            )

        _stop_timeout(self, state.get("msgId"))
        template = items[num - 1]
        self.capcutStates.pop(user_id, None)

        try:
            self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], thread_id)
        except Exception:
            pass

        loading = self.sendMentionStyle(
            "⏳ Đang tải thông tin template...", user_id, thread_id, thread_type
        )
        self.sendReaction(data, "🕑", thread_id, thread_type, 1000000023)

        threading.Thread(
            target=_send_template_detail,
            args=(self, data, template, thread_id, thread_type, user_id),
            kwargs={
                "loading_msg_id": getattr(loading, "msgId", None),
                "loading_cli_id": getattr(loading, "clientId", None),
            },
            daemon=True,
        ).start()
        return

    # ── URL trực tiếp ─────────────────────────────────────────────────────────
    if _is_capcut_url(arg):
        # Trích template_id từ URL nếu có
        m = re.search(r"/template-detail/([^/?#]+)", arg)
        tpl_id = m.group(1) if m else ""
        fake_tpl = {
            "template_id": tpl_id,
            "title":       "CapCut Template",
            "cover_url":   "",
            "play_amount": 0,
            "like_count":  0,
        }
        self.sendReaction(data, "🔗", thread_id, thread_type, 100000000)
        self.sendMentionStyle(f"🎬 Link CapCut:\n{arg}", user_id, thread_id, thread_type)
        return

    # ── Tìm kiếm theo từ khoá ─────────────────────────────────────────────────
    keyword = arg
    self.sendReaction(data, "🔍", thread_id, thread_type, 100000000)

    def _do_search():
        items = _search_capcut(keyword, limit=10)

        if not items:
            self.sendReaction(data, "❌", thread_id, thread_type, 100000000)
            self.replyMessageStyle(
                f"Không tìm thấy template CapCut với từ khoá: \"{keyword}\"",
                data, thread_id, thread_type,
                color="r", title="CAPCUT", userId=user_id
            )
            return

        # Vẽ card danh sách
        card_path = None
        list_url  = None
        try:
            os.makedirs("data/assets/cache/capcut", exist_ok=True)
            card_path = f"data/assets/cache/capcut/{uuid.uuid4().hex}.jpg"
            draw_capcut_list(items, card_path, keyword=keyword)
            res = self._uploadImage(card_path, thread_id, thread_type)
            if isinstance(res, dict):
                list_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                list_url = res
        except Exception as ce:
            print(f"[CapCut] list card error: {ce}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        name         = self.userName(user_id) or str(user_id)
        mention_text = f"@{name}"
        caption      = f"🎬 {mention_text} Chọn số để xem chi tiết • reply 0 để huỷ"

        if list_url:
            msg = self.sendRemoteImage(
                list_url, thread_id, thread_type,
                width=2560, height=1440,
                message=Message(
                    text=caption,
                    mention=Mention(user_id, length=len(mention_text), offset=3)
                )
            )
        else:
            lines = [f"🎬 CapCut: \"{keyword}\"\nChọn số để xem • reply 0 để huỷ\n"]
            for i, t in enumerate(items, 1):
                title = (t.get("title") or "Template")[:40]
                plays = _fmt_num(t.get("play_amount", 0))
                likes = _fmt_num(t.get("like_count", 0))
                lines.append(f"{i}. {title}  ▶{plays} ♥{likes}")
            lines.append("\n0. Huỷ")
            msg = self.sendMentionStyle("\n".join(lines), user_id, thread_id, thread_type)

        self.capcutStates[user_id] = {
            "items":    items,
            "time":     time.time(),
            "msgId":    getattr(msg, "msgId",    None),
            "cliMsgId": getattr(msg, "clientId", None),
            "threadId": thread_id,
            "typeGr":   thread_type,
        }

        _start_timeout_loop(
            self,
            key=getattr(msg, "msgId", str(user_id)),
            msg_id=getattr(msg, "msgId",    None),
            cli_id=getattr(msg, "clientId", None),
            thread_id=thread_id,
            thread_type=thread_type,
        )

    threading.Thread(target=_do_search, daemon=True).start()


# ── Reply handler ─────────────────────────────────────────────────────────────
def CapCutReply(self, message_obj, data, user_id, thread_id, thread_type):
    """Xử lý reply chọn số từ danh sách CapCut."""
    if not hasattr(self, "capcutStates"):
        return
    state = self.capcutStates.get(user_id)
    if not state:
        return

    quoted = getattr(data, "quote", None)
    if not quoted:
        return

    raw     = getattr(message_obj, "text", "") or ""
    num_str = _extract_number(raw)
    if not num_str:
        return

    prefix   = getattr(self, "prefix", "/")
    old_cmd  = getattr(self, "commandName", "capcut")
    self.commandName = "capcut"
    fake_msg = Message(text=f"{prefix}capcut {num_str}")
    CapCutCommand(self, fake_msg, data, user_id, thread_id, thread_type)
    self.commandName = old_cmd

    try:
        self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], thread_id)
    except Exception:
        pass


# ── onLoad hook ───────────────────────────────────────────────────────────────
def _on_load(self):
    _ensure_state(self)
    _init_timeout_cleaner(self)


# ── dependencies ──────────────────────────────────────────────────────────────
dependencies = {
    "name":        "capcut",
    "permission":  0,
    "cooldown":    5,
    "description": "Tìm kiếm template video CapCut",
    "onLoad":      _on_load,
    "main":        CapCutCommand,
}
