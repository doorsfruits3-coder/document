from app.core.index import *
from src.command.chat_bot.devtool import agentMemory
from src.command.chat_bot.devtool.apiModels import ApiModels, GeminiContent, redactSecrets

def _bot_uid(this) -> str:
    return str(getattr(this, "uid", "") or "").strip()

def _thread_key(threadId, data) -> str:
    s = str(threadId or "").strip()
    if s:
        return s
    for attr in ("groupId", "gid", "threadId"):
        v = data.get(attr) if isinstance(data, dict) else getattr(data, attr, None)
        if v:
            return str(v).strip()
    return ""

def _get_memory_text(this, threadId, data, limit: int = 12) -> str:
    b = _bot_uid(this); t = _thread_key(threadId, data)
    if not b or not t:
        return ""
    return agentMemory.GetText(b, t, limit=limit)

def _get_memory_items(this, threadId, data, limit: int = 50):
    b = _bot_uid(this); t = _thread_key(threadId, data)
    if not b or not t:
        return []
    return agentMemory.GetItems(b, t, limit=limit)

def _append_memory(this, threadId, data, userId, q, a, meta=None) -> bool:
    b = _bot_uid(this); t = _thread_key(threadId, data)
    if not b or not t:
        return False
    return agentMemory.Write(b, str(userId), t, str(q), str(a),
                             meta=meta or {}, ts=int(time.time()))

def _build_prompt(this, ask: str, threadId, data, userId) -> str:
    cmd_list = []
    if hasattr(this, "commands"):
        for name, cmd in this.commands.items():
            if isinstance(cmd, dict):
                desc = cmd.get("description", "")
                cmd_list.append(f"Command '{name}': {desc}")

    memory_text = _get_memory_text(this, threadId, data) or "No memory"
    asker       = this.userName(userId)

    return f"""Bạn là trợ lý AI mang tên zAgent, bạn có khả năng suy nghĩ và đưa ra câu trả lời đúng.

+ Trả lời ngắn gọn, không quá dài khi đang hội thoại
+ Suy nghĩ, phân tích rồi đưa ra câu trả lời
+ Nếu không biết thì nói không biết, không bịa

Bạn có thể điều khiển các lệnh trong hệ thống nếu người dùng yêu cầu.
Danh sách lệnh hiện có:
{chr(10).join(cmd_list) or "(không có)"}

Bộ nhớ gần đây (ngữ cảnh, không bịa thêm):
{memory_text}

Nếu người dùng yêu cầu thực thi lệnh, trả lời đúng định dạng:
CMD: tên_lệnh tham_số

Câu hỏi của {asker}: {ask}"""

def AgentCommand(this, message, data, userId, threadId, type):
    parts = (getattr(message, "text", "") or "").strip().split()
    if len(parts) < 2:
        return this.replyMessageStyle(
            "Bạn chưa nhập câu hỏi cho AI.",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )

    ask = " ".join(parts[1:]).strip()
    low = ask.lower()

    if any(k in low for k in ("lịch sử", "xem lại", "tất cả")):
        items = _get_memory_items(this, threadId, data, limit=30)
        if not items:
            return this.replyMessageStyle(
                "Chưa có lịch sử trong cuộc trò chuyện này.",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        lines = [f"- User: {it['q']}\n  Agent: {it['a']}" for it in items if it.get("q") or it.get("a")]
        return this.replyMessageStyle(
            "\n".join(lines) or "Chưa có lịch sử.",
            data, threadId, type,
            color="gr", title="HISTORY", userId=userId,
        )

    api = ApiModels()
    m   = GeminiContent(api)
    m.prompt = _build_prompt(this, ask, threadId, data, userId)

    try:
        text = m.getText()
    except Exception as e:
        return this.replyMessageStyle(
            f"Lỗi gọi AI: {redactSecrets(str(e))}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

    if not text:
        return this.replyMessageStyle(
            "Không có câu trả lời.",
            data, threadId, type,
            color="yl", title="AGENT", userId=userId,
        )

    import re
    cmd_match = re.search(r"CMD:\s*(.+)", text, re.IGNORECASE)
    if cmd_match:
        cmd_content = cmd_match.group(1).strip()
        try:
            new_data = dict(data) if isinstance(data, dict) else {}
            new_data["content"]  = f"{getattr(this, 'prefix', '/')}{cmd_content}"
            new_data["mentions"] = []
            this.LoadCommands(message, new_data, userId, threadId, type)
        except Exception:
            this.replyMessageStyle(
                "Lỗi thực thi lệnh AI.",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        return

    _append_memory(this, threadId, data, userId, ask, text,
                   meta={"chat_type": str(type or "")})

    this.replyMessageStyle(
        text, data, threadId, type,
        color="gr", title="zAgent", userId=userId,
    )

dependencies = {
    "name":        "agent",
    "permission":  0,
    "cooldown":    5,
    "description": "AI Agent (Gemini / GPT)",
    "main":        AgentCommand,
}