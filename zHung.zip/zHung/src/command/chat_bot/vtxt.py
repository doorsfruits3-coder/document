import os
import json
import uuid
import threading
import requests
from app.core.index import *

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except ImportError:
    SR_AVAILABLE = False

try:
    from pydub import AudioSegment
    PYDUB_AVAILABLE = True
except ImportError:
    PYDUB_AVAILABLE = False

LANG_MAP: dict[str, str] = {
    "vi": "vi-VN", "vn": "vi-VN",
    "en": "en-US", "us": "en-US",
    "zh": "zh-CN", "cn": "zh-CN",
    "ja": "ja-JP", "jp": "ja-JP",
    "ko": "ko-KR", "kr": "ko-KR",
    "fr": "fr-FR",
    "de": "de-DE",
    "th": "th-TH",
}

_CACHE_DIR = "data/assets/cache/voice"
_SESSION   = requests.Session()
_SESSION.headers.update({"User-Agent": "Mozilla/5.0"})


class VtxtCommand:
    def __init__(self, ctx):
        self._ctx    = ctx
        self.prefix  = getattr(ctx, "prefix", "/")
        self.cmd     = getattr(ctx, "commandName", "vtxt")

    def _reply(self, text: str, data, threadId, type, *, color: str, title: str, userId):
        return self._ctx.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title, userId=userId,
        )

    @staticmethod
    def _extract_voice_url(data) -> str | None:
        if getattr(data, "msgType", "") == "chat.voice":
            content = getattr(data, "content", None)
            if content:
                return getattr(content, "href", None) or (
                    content.get("href") if isinstance(content, dict) else None
                )

        quote = getattr(data, "quote", None)
        if not quote:
            return None

        if getattr(quote, "msgType", "") == "chat.voice":
            qcontent = getattr(quote, "attach", None) or getattr(quote, "content", None)
            if qcontent:
                return qcontent.get("href") if isinstance(qcontent, dict) else getattr(qcontent, "href", None)

        raw = getattr(quote, "attach", None)
        if raw and isinstance(raw, str):
            try:
                obj = json.loads(raw)
                return obj.get("href") or obj.get("fileUrl") or obj.get("url")
            except Exception:
                pass

        return None

    @staticmethod
    def _ext_from_url(url: str) -> str:
        for ext in ("mp3", "m4a", "wav", "ogg"):
            if f".{ext}" in url:
                return ext
        return "aac"

    @staticmethod
    def _download(url: str) -> str:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        ext  = VtxtCommand._ext_from_url(url)
        path = f"{_CACHE_DIR}/vtxt_{uuid.uuid4().hex}.{ext}"
        with _SESSION.get(url, stream=True, timeout=20) as r:
            r.raise_for_status()
            with open(path, "wb") as f:
                for chunk in r.iter_content(16384):
                    if chunk:
                        f.write(chunk)
        return path

    @staticmethod
    def _to_wav(src: str) -> str:
        wav = src.rsplit(".", 1)[0] + "_cvt.wav"
        AudioSegment.from_file(src) \
            .set_channels(1) \
            .set_frame_rate(16000) \
            .export(wav, format="wav", parameters=["-q:a", "0"])
        return wav

    @staticmethod
    def _recognize(wav: str, lang: str) -> str:
        rec = sr.Recognizer()
        rec.energy_threshold         = 200
        rec.dynamic_energy_threshold = False
        with sr.AudioFile(wav) as src:
            audio = rec.record(src)
        return rec.recognize_google(audio, language=lang)

    @staticmethod
    def _cleanup(*paths: str):
        for p in paths:
            try:
                if p and os.path.exists(p):
                    os.remove(p)
            except Exception:
                pass

    def _check_deps(self, data, threadId, type, userId) -> bool:
        if SR_AVAILABLE and PYDUB_AVAILABLE:
            return True
        missing = []
        if not SR_AVAILABLE:    missing.append("SpeechRecognition")
        if not PYDUB_AVAILABLE: missing.append("pydub")
        self._reply(
            f"Thiếu thư viện: {', '.join(missing)}\n"
            f"Cài đặt: pip install {' '.join(missing)}\n"
            f"Và cần có ffmpeg trên hệ thống.",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
        return False

    def _process(self, voice_url: str, lang_code: str, data, threadId, type, userId):
        src = wav = None
        try:
            src    = self._download(voice_url)
            wav    = self._to_wav(src)
            result = self._recognize(wav, lang_code).strip()

            if not result:
                self._reply(
                    "Không nhận diện được nội dung.\n"
                    "Thử lại với ngôn ngữ khác hoặc kiểm tra chất lượng audio.",
                    data, threadId, type,
                    color="yl", title="WARNING", userId=userId,
                )
            else:
                self._reply(
                    result, data, threadId, type,
                    color="gr", title="TRANSCRIPT", userId=userId,
                )

        except sr.UnknownValueError:
            self._reply(
                "Không nhận dạng được giọng nói.\n"
                "Audio có thể quá nhỏ, nhiễu, hoặc không đúng ngôn ngữ.",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        except sr.RequestError as e:
            self._reply(
                f"Lỗi kết nối Google STT API:\n{e}",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        except Exception as e:
            self._reply(
                f"Lỗi xử lý: {e}", data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )
        finally:
            self._cleanup(src, wav)

    def run(self, message, data, userId, threadId, type):
        if not self._check_deps(data, threadId, type, userId):
            return

        text_raw  = (getattr(message, "text", "") or "").strip()
        cmd_token = f"{self.prefix}{self.cmd}"
        arg       = text_raw[len(cmd_token):].strip().lower() if text_raw.lower().startswith(cmd_token.lower()) else ""
        lang_code = LANG_MAP.get(arg, "vi-VN")

        voice_url = self._extract_voice_url(data)
        if not voice_url:
            return self._reply(
                f"Không tìm thấy tin nhắn voice.\n\n"
                f"Cách dùng:\n"
                f"  📍 Reply vào tin nhắn voice rồi gõ {self.prefix}{self.cmd}\n"
                f"  📍 Thêm mã ngôn ngữ: {self.prefix}{self.cmd} en  (mặc định: vi)\n\n"
                f"Ngôn ngữ hỗ trợ: vi · en · zh · ja · ko · fr · de · th",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

        self._reply(
            f"🎙️ Đang nhận diện giọng nói...\n🌐 Ngôn ngữ: {lang_code}",
            data, threadId, type,
            color="or", title="PROCESSING", userId=userId,
        )

        threading.Thread(
            target=self._process,
            args=(voice_url, lang_code, data, threadId, type, userId),
            daemon=True,
        ).start()

def vtxtCommand(self, message, data, userId, threadId, type):
    VtxtCommand(self).run(message, data, userId, threadId, type)

dependencies = {
    "name":        "vtxt",
    "permission":  0,
    "cooldown":    30,
    "description": "Chuyển tin nhắn voice sang văn bản",
    "main":        vtxtCommand,
}