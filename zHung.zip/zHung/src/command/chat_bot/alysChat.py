from app.core.index import *
from src.services.pillow.drawTopChat import draw_top_chat
from src.services.data.chatCounter   import (
    get_top_group, get_top_global, reset_data,
)
import os, time

CACHE_DIR = "data/assets/cache/image"


# ══════════════════════════════════════════════════════════════════════════════
#  LIVE FETCH HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _fetch_user_info(self, uid: str) -> tuple:
    """Trả về (name, avatar_url) của user, fetch live."""
    try:
        info     = self.fetchUserInfo(str(uid))
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        name     = profile.get("displayName") or profile.get("name") or ""
        url      = profile.get("avatar") or ""
        if url:
            import re
            url = re.sub(r'[?&]w=\d+',    '', url)
            url = re.sub(r'[?&]h=\d+',    '', url)
            url = re.sub(r'[?&]s=\d+',    '', url)
            url = re.sub(r'[?&]size=\d+', '', url)
            url = re.sub(r'/w\d+/',        '/w2048/', url)
            url = url.rstrip('?&')
        return name or uid, url
    except Exception:
        return uid, ""


def _fetch_group_info(self, thread_id: str) -> tuple:
    """Trả về (name, avatar_url) của group, fetch live."""
    try:
        info  = self.fetchGroupInfo(str(thread_id))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g     = gdata.get(str(thread_id)) or {}
        name  = g.get("name") or ""
        avatar = (
            g.get("avt")       or
            g.get("avatar")    or
            g.get("fullAvt")   or
            g.get("avatarUrl") or
            ""
        )
        if avatar:
            import re
            avatar = re.sub(r'[?&]w=\d+',    '', avatar)
            avatar = re.sub(r'[?&]h=\d+',    '', avatar)
            avatar = re.sub(r'[?&]s=\d+',    '', avatar)
            avatar = re.sub(r'[?&]size=\d+', '', avatar)
            avatar = re.sub(r'/w\d+/',        '/w2048/', avatar)
            avatar = avatar.rstrip('?&')
        return name, avatar
    except Exception:
        return "", ""


# ══════════════════════════════════════════════════════════════════════════════
#  SEND HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _send_card(self, entries, title, data, userId, threadId, type):
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        out = os.path.join(CACHE_DIR, f"topchat_{threadId}_{int(time.time())}.jpg")
        w, h = draw_top_chat(entries, out, title=title)

        name    = self.userName(userId)
        mention = Mention(userId, offset=0, length=len(name))
        caption = Message(
            text=f"{name}\n{title}",
            mention=mention,
        )
        self.sendLocalImage(out, threadId, type, width=w, height=h, message=caption)

        try:
            os.remove(out)
        except Exception:
            pass

    except Exception as e:
        logger.errorw(f"topchat draw error: {e}")
        self.replyMessageStyle(
            f"Lỗi vẽ card: {e}", data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


def _format_text(entries: list, title: str) -> str:
    lines  = [f"🏆 {title}\n"]
    medals = {1: "🥇", 2: "🥈", 3: "🥉"}
    for e in entries:
        icon = medals.get(e["rank"], f"#{e['rank']}")
        lines.append(f"{icon} {e['name']}  —  {e['count']:,} tin nhắn")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  ENRICH entries với name/avatar từ live fetch
# ══════════════════════════════════════════════════════════════════════════════

def _enrich_user_entries(self, entries: list) -> list:
    """Thêm name, avatar vào mỗi entry user bằng live fetch."""
    out = []
    for e in entries:
        uid = e.get("userId", "")
        name, avatar = _fetch_user_info(self, uid)
        out.append({**e, "name": name, "avatar": avatar})
    return out


def _enrich_group_entries(self, entries: list) -> list:
    """Thêm name, avatar vào mỗi entry group bằng live fetch."""
    out = []
    for e in entries:
        gid = e.get("groupId", "")
        name, avatar = _fetch_group_info(self, gid)
        out.append({**e, "name": name or gid, "avatar": avatar})
    return out


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

def topChatCommand(self, message, data, userId, threadId, type):
    msg_text = (getattr(message, "text", None) or str(message) or "").strip().lower()
    tokens   = msg_text.split()

    is_global = "global" in tokens
    is_text   = "text"   in tokens

    if is_global:
        raw     = get_top_global(self.uid, n=15)
        entries = _enrich_group_entries(self, raw)
        title   = "TOP NHÓM NHẮN TIN NHIỀU NHẤT"
    else:
        raw     = get_top_group(self.uid, threadId, n=15)
        entries = _enrich_user_entries(self, raw)
        title   = "TOP CHAT NHÓM"

    if not entries:
        return self.replyMessageStyle(
            "Chưa có dữ liệu tin nhắn nào được ghi nhận.",
            data, threadId, type,
            color="yl", title="THÔNG BÁO", userId=userId,
        )

    if is_text:
        self.replyMessageStyle(
            _format_text(entries, title),
            data, threadId, type,
            color="gr", title=title, userId=userId,
        )
    else:
        _send_card(self, entries, title, data, userId, threadId, type)

    self.sendReaction(data, "👌", threadId, type, 100000000)


def resetDataCommand(self, message, data, userId, threadId, type):
    """
    alys reset data                  → xoá data chat của chính bot này
    alys reset data @bot1 @bot2      → xoá data của các bot được mention
    alys reset data all              → xoá toàn bộ data tất cả bot
    Yêu cầu quyền DEVELOPER (level 4).
    """
    from app.module.commandLoader import PermissionLevel
    settings = read_settings(self.uid)
    dev_list = settings.get("developerAdmin", [])
    if str(userId) not in dev_list:
        return self.replyMessageStyle(
            "Lệnh này chỉ dành cho Developer.",
            data, threadId, type,
            color="r", title="PERMISSION DENIED", userId=userId,
        )

    msg_text = (getattr(message, "text", None) or "").strip()
    tokens   = msg_text.split()
    # tokens: ["alys", "reset", "data", ...]
    rest     = tokens[3:] if len(tokens) > 3 else []

    # Lấy danh sách bot uid được mention
    from app.helpers.methods import extractUids
    mentioned_uids = extractUids(data)

    # --- alys reset data all ---
    if rest and rest[0].lower() == "all":
        deleted = reset_data(bot_uid=None)
        return self.replyMessageStyle(
            f"Đã xoá toàn bộ data chat của tất cả bot.\n"
            f"Tổng file đã xoá: {deleted}",
            data, threadId, type,
            color="r", title="RESET ALL", userId=userId,
        )

    # --- alys reset data @bot1 @bot2 ---
    if mentioned_uids:
        lines = []
        for uid in mentioned_uids:
            deleted = reset_data(bot_uid=str(uid))
            name    = self.userName(uid)
            lines.append(f"Bot {name} ({uid}): đã xoá {deleted} file")
        return self.replyMessageStyle(
            "\n".join(lines),
            data, threadId, type,
            color="yl", title="RESET BOT", userId=userId,
        )

    # --- alys reset data (không mention) → reset chính bot này ---
    deleted = reset_data(bot_uid=str(self.uid))
    return self.replyMessageStyle(
        f"Đã xoá data chat của bot này ({self.uid}).\n"
        f"Tổng file đã xoá: {deleted}",
        data, threadId, type,
        color="yl", title="RESET SELF", userId=userId,
    )


def alysCommand(self, message, data, userId, threadId, type):
    msg_text = (getattr(message, "text", None) or "").strip().lower()
    tokens   = msg_text.split()

    # alys reset data ...
    if len(tokens) >= 3 and tokens[1] == "reset" and tokens[2] == "data":
        return resetDataCommand(self, message, data, userId, threadId, type)

    # alys [global] [text]  → top chat
    return topChatCommand(self, message, data, userId, threadId, type)


dependencies = {
    "name":        "alys",
    "permission":  0,
    "cooldown":    10,
    "description": "Xem top nhắn tin nhiều nhất. alys reset data để xoá data (Developer only).",
    "main":        alysCommand,
}
