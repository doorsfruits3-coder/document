from app.core.index import *
from src.services.pillow.qrDraw import QRDrawer
import os
import traceback
import threading
from collections import defaultdict, deque


class QRCommand:
    def __init__(self):
        self.qr     = QRDrawer()
        self.queues = defaultdict(deque)
        self.locks  = defaultdict(threading.Lock)

    def _process_queue(self, threadId):
        lock = self.locks[threadId]
        if not lock.acquire(blocking=False):
            return
        try:
            while self.queues[threadId]:
                bot, message, data, userId, type, waitMsg = self.queues[threadId].popleft()
                img_path = None
                try:
                    content = message.text.strip().split(maxsplit=1)
                    if len(content) < 2:
                        bot.replyMessageStyle(
                            "Nhập nội dung để tạo qr đi trời.",
                            data, threadId, type,
                            color="yl", title="WARNING", userId=userId,
                        )
                        continue

                    text = content[1]

                    # Lấy avatar của user gọi lệnh (học theo info.py)
                    try:
                        _info     = bot.fetchUserInfo(userId)
                        _profiles = getattr(_info, "changed_profiles", {}) or {}
                        _profile  = _profiles.get(str(userId)) or {}
                        avatar_url = _profile.get("avatar", "") or None
                    except Exception:
                        avatar_url = None

                    try:
                        if isinstance(waitMsg, dict):
                            msg_id = waitMsg.get("globalMsgId")
                            cli_id = waitMsg.get("cliMsgId")
                        else:
                            msg_id = getattr(waitMsg, "globalMsgId", None)
                            cli_id = getattr(waitMsg, "cliMsgId", None)
                        if msg_id and cli_id:
                            bot.deleteMessage(str(msg_id), str(bot.uid), str(cli_id), threadId)
                    except Exception:
                        pass

                    img_path = self.qr.create_gradient_qr(text, avatar_url=avatar_url)

                    if not img_path or not os.path.isfile(img_path):
                        raise Exception(f"File không tồn tại: {img_path}")
                    if os.path.getsize(img_path) == 0:
                        raise Exception("File QR rỗng")

                    image_res = bot._uploadImage(img_path, threadId, type)

                    if not image_res:
                        raise Exception("Upload trả về None")
                    if isinstance(image_res, dict):
                        image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
                        if not image_url:
                            raise Exception(f"Dict không có url hợp lệ: {image_res}")
                    elif isinstance(image_res, str):
                        image_url = image_res.strip()
                    else:
                        raise Exception(f"Upload sai kiểu: {type(image_res)}")

                    if not image_url.startswith("http"):
                        raise Exception(f"Link không hợp lệ: {image_url}")

                    name = bot.userName(userId) or str(userId)
                    # "📍 " = 2 ký tự (emoji + space), mention bắt đầu tại offset 2
                    mention_text = f"@{name}"
                    caption = f"📍 {mention_text} QR của bạn đây!"
                    bot.sendRemoteImage(
                        image_url,
                        threadId,
                        type,
                        width=2560,
                        height=2560,
                        ttl=0,
                        message=Message(
                            text=caption,
                            mention=Mention(userId, length=len(mention_text), offset=3)
                        )
                    )

                except Exception as e:
                    bot.replyMessageStyle(
                        f"Lỗi tạo QR\n{str(e)}",
                        data, threadId, type,
                        color="r", title="ERROR", userId=userId,
                    )
                finally:
                    if img_path and os.path.isfile(img_path):
                        try:
                            os.remove(img_path)
                            print(f"[QR] Đã xoá file: {img_path}")
                        except Exception as e:
                            print(f"[QR] Không xoá được file: {img_path} | Lỗi: {e}")
                    elif img_path:
                        print(f"[QR] File không tồn tại để xoá (đã bị xoá trước?): {img_path}")
        finally:
            lock.release()

    def createQr(self, bot, message, data, userId, threadId, type):
        content = message.text.strip().split(maxsplit=1)

        if len(content) < 2:
            return bot.replyMessageStyle(
                "Nhập nội dung để tạo qr đi trời.",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

        waitMsg = bot.replyMessageStyle(
            "Đang tạo QR, vui lòng chờ...",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        ) or data

        self.queues[threadId].append((bot, message, data, userId, type, waitMsg))
        threading.Thread(target=self._process_queue, args=(threadId,)).start()


qr_cmd = QRCommand()


def createQr(self, message, data, userId, threadId, type):
    return qr_cmd.createQr(self, message, data, userId, threadId, type)


dependencies = {
    "name":        "qr",
    "permission":  0,
    "description": "Tạo mã QR từ nội dung",
    "cooldown":    0,
    "main":        createQr,
}
