"""
imageCore.py  –  Lệnh image / img

Sub-commands:
  {p}{c}                          – help
  {p}{c} get          (reply ảnh) – gửi lại chất lượng cao nhất
  {p}{c} caption="…"  (reply ảnh) – thêm header caption trắng lên đầu ảnh
  {p}{c} tb           (reply ảnh) – chuyển ảnh sang trắng đen
  {p}{c} r=90         (reply ảnh) – xoay 90° (1–360), viết tắt: r=<góc>
  {p}{c} resize=50%   (reply ảnh) – thu/phóng 50%
  {p}{c} resize=800x600(reply ảnh)– resize về đúng 800×600 px
  {p}{c} resize=800   (reply ảnh) – chiều rộng 800px, giữ tỷ lệ
"""

import os
import re
import json
import uuid
import urllib.parse

from app.core.index import *
from src.services.pillow.drawCaptionImage import (
    draw_caption_image,
    draw_caption_image_grayscale,
    draw_rotate_image,
    draw_resize_image,
)

_CACHE_DIR = "data/assets/cache/image"

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _extract_image_url(data) -> str | None:
    """Lấy URL ảnh HD nhất từ tin nhắn quote (chat.photo)."""
    try:
        quote = getattr(data, "quote", None)
        if not quote:
            return None

        raw = getattr(quote, "attach", None)
        if raw:
            attach = json.loads(raw) if isinstance(raw, str) else raw
            url = (
                attach.get("hdUrl")
                or attach.get("normalUrl")
                or attach.get("href")
            )
            if url:
                url = urllib.parse.unquote(url.replace("\\/", "/"))
                url = url.replace("/jxl", "/jpg").replace(".jxl", ".jpg")
                return url

        # fallback: msg text chứa URL ảnh trực tiếp
        msg = getattr(quote, "msg", "") or ""
        if msg.startswith("http") and any(
            e in msg.lower() for e in (".jpg", ".jpeg", ".png", ".webp")
        ):
            return msg

    except Exception as e:
        logger.errorw(f"[image] extract url error: {e}")
    return None


def _extract_attach_size(data) -> tuple[int, int]:
    try:
        raw    = getattr(data.quote, "attach", "{}") or "{}"
        attach = json.loads(raw) if isinstance(raw, str) else raw
        return int(attach.get("width", 2560) or 2560), int(attach.get("height", 2560) or 2560)
    except Exception:
        return 2560, 2560


def _tmp(ext: str = "png") -> str:
    os.makedirs(_CACHE_DIR, exist_ok=True)
    return os.path.join(_CACHE_DIR, f"{uuid.uuid4().hex}.{ext}")


# ─────────────────────────────────────────────────────────────────────────────
# Handler
# ─────────────────────────────────────────────────────────────────────────────

class ImageHandler:

    _HELP = (
        "📷 Các lệnh xử lý ảnh\n"
        "   (reply vào ảnh rồi gõ lệnh)\n"
        "\n"
        "  📌 Lấy ảnh chất lượng cao\n"
        "     {cmd} get\n"
        "\n"
        "  📌 Thêm caption lên đầu ảnh\n"
        "     {cmd} caption=\"Nội dung muốn ghi\"\n"
        "\n"
        "  📌 Chuyển trắng đen\n"
        "     {cmd} tb\n"
        "\n"
        "  📌 Xoay ảnh (1–360°)\n"
        "     {cmd} r=90\n"
        "     {cmd} r=45\n"
        "\n"
        "  📌 Đổi kích thước\n"
        "     {cmd} resize=50%      — thu nhỏ còn 50%%\n"
        "     {cmd} resize=800      — rộng 800px, giữ tỷ lệ\n"
        "     {cmd} resize=800x600  — ép về đúng 800×600px"
    )

    def __init__(self, ctx, message, data, userId, threadId, threadType):
        self._ctx       = ctx
        self._msg       = message
        self._data      = data
        self.userId     = str(userId)
        self.threadId   = threadId
        self.threadType = threadType
        self.cmd        = f"{ctx.prefix}{ctx.commandName}"

    # ── reply shortcuts ────────────────────────────────────────────────────────
    def _reply(self, text: str, *, color: str, title: str):
        return self._ctx.replyMessageStyle(
            text, self._data, self.threadId, self.threadType,
            color=color, title=title, userId=self.userId,
        )
    def _warn(self, t): return self._reply(t, color="yl", title="WARNING")
    def _err(self,  t): return self._reply(t, color="r",  title="ERROR")
    def _ok(self,   t): return self._reply(t, color="gr", title="SUCCESS")

    def _help(self): return self._HELP.format(cmd=self.cmd)

    # ── send ──────────────────────────────────────────────────────────────────
    def _send(self, path: str, w: int, h: int):
        try:
            res = self._ctx._uploadImage(path, self.threadId, self.threadType)
            url = (res.get("hdUrl") or res.get("normalUrl")) if isinstance(res, dict) else None
            if url:
                self._ctx.sendRemoteImage(url, self.threadId, self.threadType, width=w, height=h)
            else:
                self._ctx.sendLocalImage(path, self.threadId, self.threadType, width=w, height=h)
        except Exception as e:
            raise RuntimeError(f"Gửi ảnh thất bại: {e}")

    # ── need-quote guard ──────────────────────────────────────────────────────
    def _require_image(self) -> str | None:
        url = _extract_image_url(self._data)
        if not url:
            self._warn("Vui lòng reply vào một tin nhắn chứa ảnh tĩnh.")
        return url

    # ── sub-commands ──────────────────────────────────────────────────────────
    def _do_get(self):
        url = self._require_image()
        if not url:
            return
        w, h = _extract_attach_size(self._data)
        try:
            self._ctx.sendRemoteImage(url, self.threadId, self.threadType, width=w, height=h)
        except Exception as e:
            self._err(f"Lỗi: {e}")

    def _do_tb(self):
        url = self._require_image()
        if not url:
            return
        out = _tmp()
        try:
            self._ok("⏳ Đang chuyển trắng đen...")
            w, h = draw_caption_image_grayscale(url, out, is_url=True)
            self._send(out, w, h)
        except Exception as e:
            logger.errorw(f"[image tb] {e}")
            self._err(f"Xử lý thất bại: {e}")
        finally:
            try: os.remove(out)
            except Exception: pass

    def _do_caption(self, caption_text: str):
        if not caption_text.strip():
            return self._warn("caption không được để trống.\nVí dụ: caption=\"Nội dung muốn ghi\"")
        url = self._require_image()
        if not url:
            return
        out = _tmp()
        try:
            self._ok("⏳ Đang ghép caption...")
            w, h = draw_caption_image(caption_text, url, out, is_url=True)
            self._send(out, w, h)
        except Exception as e:
            logger.errorw(f"[image caption] {e}")
            self._err(f"Xử lý thất bại: {e}")
        finally:
            try: os.remove(out)
            except Exception: pass

    def _do_rotate(self, degrees: float):
        url = self._require_image()
        if not url:
            return
        out = _tmp()
        try:
            self._ok(f"⏳ Đang xoay ảnh {degrees}°...")
            w, h = draw_rotate_image(degrees, url, out, is_url=True)
            self._send(out, w, h)
        except Exception as e:
            logger.errorw(f"[image rotate] {e}")
            self._err(f"Xử lý thất bại: {e}")
        finally:
            try: os.remove(out)
            except Exception: pass

    def _do_resize(self, arg_val: str):
        """
        Phân tích giá trị resize:
          "50%"    → percent=50
          "800x600"→ width=800, height=600
          "800"    → width=800
        """
        url = self._require_image()
        if not url:
            return

        kw: dict = {}
        arg_val = arg_val.strip().lower()

        if arg_val.endswith("%"):
            try:
                pct = float(arg_val[:-1])
                if not (1 <= pct <= 500):
                    return self._warn("Phần trăm resize hợp lệ: 1%–500%.")
                kw["percent"] = pct
            except ValueError:
                return self._warn(f"Giá trị resize không hợp lệ: {arg_val}")

        elif "x" in arg_val:
            parts = arg_val.split("x", 1)
            try:
                kw["width"]  = int(parts[0])
                kw["height"] = int(parts[1])
                if kw["width"] < 1 or kw["height"] < 1:
                    raise ValueError
            except ValueError:
                return self._warn(f"Định dạng resize: WxH (ví dụ: 800x600).")

        else:
            try:
                kw["width"] = int(arg_val)
                if kw["width"] < 1:
                    raise ValueError
            except ValueError:
                return self._warn(f"Giá trị resize không hợp lệ: {arg_val}")

        # Thông báo kích thước
        if "percent" in kw:
            label = f"{kw['percent']:g}%"
        elif "height" in kw:
            label = f"{kw['width']}×{kw['height']}px"
        else:
            label = f"rộng {kw['width']}px"

        out = _tmp()
        try:
            self._ok(f"⏳ Đang resize ({label})...")
            w, h = draw_resize_image(url, out, is_url=True, **kw)
            self._send(out, w, h)
        except Exception as e:
            logger.errorw(f"[image resize] {e}")
            self._err(f"Xử lý thất bại: {e}")
        finally:
            try: os.remove(out)
            except Exception: pass

    # ── router ────────────────────────────────────────────────────────────────
    def run(self):
        raw     = (self._msg.text or "").strip()
        tokens  = raw.split()
        args    = tokens[1:]
        arg_str = " ".join(args).strip()

        if not arg_str:
            return self._warn(self._help())

        sub = args[0].lower()

        # get
        if sub == "get":
            return self._do_get()

        # tb
        if sub == "tb":
            return self._do_tb()

        # r=<degrees>  hoặc  rotate=<degrees>
        m = re.fullmatch(r"r(?:otate)?=(\d+(?:\.\d+)?)", sub)
        if m:
            deg = float(m.group(1)) % 360
            if deg == 0:
                return self._warn("Góc xoay phải từ 1 đến 359°.")
            return self._do_rotate(deg)

        # resize=<value>
        m = re.fullmatch(r"resize=(.+)", sub, re.IGNORECASE)
        if m:
            return self._do_resize(m.group(1))

        # caption="..."  /  caption=...
        m = re.search(r'caption\s*=\s*["\']?(.+?)["\']?\s*$', arg_str, re.IGNORECASE)
        if m:
            return self._do_caption(m.group(1).strip().strip("\"'"))

        return self._warn(self._help())


# ─────────────────────────────────────────────────────────────────────────────
# Entry
# ─────────────────────────────────────────────────────────────────────────────

def ImageCommand(self, message, data, userId, threadId, threadType):
    ImageHandler(self, message, data, userId, threadId, threadType).run()


dependencies = {
    "name":        "image",
    "alias":       ["img"],
    "permission":  0,
    "cooldown":    5,
    "description": "Xử lý ảnh: HD / caption / trắng đen / xoay / resize",
    "main":        ImageCommand,
}
