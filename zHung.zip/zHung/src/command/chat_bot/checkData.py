from app.core.index import *
import json

def checkLink(self, message, data, userId, threadId, type):
    if not getattr(data, "quote", None):
        return self.replyMessageStyle(
            "Vui lòng reply 1 attachment để lấy link!",
            data,
            threadId,
            type,
            color="yl",
            title="WARNING",
            userId=userId,
        )

    # Kiểm tra flag -la
    args = (getattr(message, "text", "") or "").strip().split()
    show_all = "-la" in args

    try:
        quoteda = data.quote.attach
        dataA = json.loads(quoteda)
        href = dataA.get("href")

        if not href:
            raise Exception("No link")

        if not show_all:
            return self.replyMessageStyle(
                f"Link: {href}",
                data,
                threadId,
                type,
                color="gr",
                title="SUCCESS",
                userId=userId,
            )
        else:
            lines = []

            href     = dataA.get("href", "")
            thumb    = dataA.get("thumb", "")
            webp_url = ""
            params   = dataA.get("params")
            if isinstance(params, dict):
                webp = params.get("webp")
                if isinstance(webp, dict):
                    webp_url = webp.get("url", "")

            if href:
                lines.append(f"[attach.href]: {href}")
            if thumb:
                lines.append(f"[attach.thumb]: {thumb}")
            if webp_url:
                lines.append(f"[attach.params.webp.url]: {webp_url}")

            result = "\n".join(lines) if lines else "Không tìm thấy thông tin attach"

            return self.replyMessageStyle(
                result,
                data,
                threadId,
                type,
                color="gr",
                title="SUCCESS",
                userId=userId,
            )

    except:
        return self.replyMessageStyle(
            "Không lấy được link",
            data,
            threadId,
            type,
            color="r",
            title="ERROR",
            userId=userId,
        )


dependencies = {
    "name": "getlink",
    "permission": 0,
    "description": "Attachment getlink",
    "cooldown": 5,
    "main": checkLink
}
