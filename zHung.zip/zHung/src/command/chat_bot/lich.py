from app.core.index import *
from datetime import date
import os, re


# ── helpers ───────────────────────────────────────────────────────────────────

def _reply_err(self, text, data, threadId, type, userId):
    self.sendReaction(data, "❌", threadId, type, 100000000)
    self.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)

def _reply_warn(self, text, data, threadId, type, userId):
    self.sendReaction(data, "⚠️", threadId, type, 100000000)
    self.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)

def _reply_info(self, title, text, data, threadId, type, userId):
    self.replyMessageStyle(text, data, threadId, type, color="or", title=title, userId=userId)


def _parse_args(parts: list[str]) -> tuple[int, int] | None:
    """
    Nhận list token sau prefix+command.
    Hỗ trợ:
      (trống)          → tháng/năm hiện tại
      <month>          → tháng đó, năm hiện tại
      <month> <year>   → tháng + năm
      <month>/<year>   → 6/2025
      <month>-<year>   → 6-2025
    Trả về (month, year) hoặc None nếu không hợp lệ.
    """
    today = date.today()

    if not parts:
        return today.month, today.year

    raw = " ".join(parts).strip()

    # dạng mm/yyyy hoặc mm-yyyy
    m = re.fullmatch(r"(\d{1,2})[/\-](\d{4})", raw)
    if m:
        return int(m.group(1)), int(m.group(2))

    tokens = raw.split()

    if len(tokens) == 1:
        try:
            mo = int(tokens[0])
            return mo, today.year
        except ValueError:
            return None

    if len(tokens) == 2:
        try:
            mo = int(tokens[0])
            yr = int(tokens[1])
            return mo, yr
        except ValueError:
            return None

    return None


# ── main command ──────────────────────────────────────────────────────────────

def lichCommand(self, message, data, userId, threadId, type) -> None:
    p    = self.prefix
    c    = self.rawCommand
    text = (getattr(message, "text", None) or "").strip()

    raw_parts = text.split()
    parts     = [x for x in raw_parts[1:] if not x.startswith("@")]
    sub       = parts[0].lower() if parts else ""

    # ── help ─────────────────────────────────────────────────────────────────
    if sub in ("help", ":help"):
        help_text = (
            f"Xem Lịch Tháng\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c}\n"
            f"      Xem lịch tháng hiện tại.\n\n"
            f"  📍 {p}{c} 8\n"
            f"      Xem lịch tháng 8 năm nay.\n\n"
            f"  📍 {p}{c} 8 2026\n"
            f"      Xem lịch tháng 8 năm 2026.\n\n"
            f"  📍 {p}{c} 8/2026\n"
            f"      Cú pháp rút gọn tháng/năm."
        )
        return _reply_info(self, "LỊCH", help_text, data, threadId, type, userId)

    # ── parse tháng/năm ───────────────────────────────────────────────────────
    parsed = _parse_args(parts)
    if parsed is None:
        return _reply_warn(
            self,
            f"Không nhận ra tháng/năm.\nVí dụ: {p}{c} 8  hoặc  {p}{c} 8/2026",
            data, threadId, type, userId,
        )

    month, year = parsed

    if not (1 <= month <= 12):
        return _reply_warn(self, "Tháng phải từ 1 đến 12.", data, threadId, type, userId)
    if not (1900 <= year <= 2100):
        return _reply_warn(self, "Năm phải từ 1900 đến 2100.", data, threadId, type, userId)

    # ── render ────────────────────────────────────────────────────────────────
    try:
        from src.services.pillow.calendarDraw import draw_calendar
    except ImportError as e:
        return _reply_err(self, f"Thiếu module PIL: {e}", data, threadId, type, userId)

    out_path = f"assets/cache/calendar_{year}_{month:02d}.png"
    try:
        draw_calendar(month, year, out_path)
    except Exception as e:
        return _reply_err(self, f"Lỗi render lịch: {e}", data, threadId, type, userId)

    try:
        name     = self.userName(userId) or str(userId)
        msg_text = f"@{name} Lịch tháng {month}/{year}"
        mention  = Mention(userId, length=len(name) + 1, offset=0)
        self.sendLocalImage(
            out_path,
            threadId,
            type,
            message=Message(text=msg_text, mention=mention),
        )
        self.sendReaction(data, "✅", threadId, type, 100000000)
    except Exception as e:
        _reply_err(self, f"Không gửi được ảnh: {e}", data, threadId, type, userId)
    finally:
        try:
            os.remove(out_path)
        except Exception:
            pass


dependencies = {
    "name":        "lich",
    "permission":  0,
    "description": "Xem lịch tháng dạng ảnh",
    "cooldown":    5,
    "main":        lichCommand,
}
