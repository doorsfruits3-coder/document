"""
tiktok.py  –  Lệnh tìm kiếm & tải video TikTok cho zBot
Đặt file này vào:  zBot/src/command/chat_bot/tiktok.py

Tính năng:
  /tiktok <từ khoá>         → tìm kiếm, hiện danh sách (card ảnh)
  /tiktok <từ khoá> → reply <số>   → tải video (no watermark)
  /tiktok <từ khoá> → reply <số> audio → tải audio mp3
  /tiktok <url>             → tải trực tiếp từ URL TikTok
"""
import os
import re
import time
import uuid
import threading
import subprocess

import httpx
import requests

from app.core.index import *
from app.module.utils import MediaCache
from src.services.pillow.tiktokListCard import draw_tiktok_list
from src.services.pillow.tiktokCard import draw_tiktok_card

# ── Hằng số ──────────────────────────────────────────────────────────────────
Platf       = "tiktok"
Timeout     = 120          # giây – thời gian chờ user chọn
TikwmBase   = "https://tikwm.com"

TIKTOK_CAPTIONS = [
    "Video hay nhất TikTok gửi đến bạn! 🎵",
    "Nội dung chất lượng từ TikTok! 🎬",
    "Enjoy your TikTok video! 🎶",
    "Khoảnh khắc thú vị từ TikTok! ✨",
    "TikTok brings the vibe! 🔥",
]
_cap_idx = 0


def _next_caption():
    global _cap_idx
    cap = TIKTOK_CAPTIONS[_cap_idx % len(TIKTOK_CAPTIONS)]
    _cap_idx += 1
    return cap


# ── Tikwm client ──────────────────────────────────────────────────────────────
def _tikwm_client(timeout=25):
    return httpx.Client(
        timeout=timeout,
        headers={
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/122.0.0.0 Safari/537.36"
            ),
            "Accept":  "application/json, text/plain, */*",
            "Referer": TikwmBase + "/",
            "Origin":  TikwmBase,
        },
        follow_redirects=True,
    )


# ── Helpers ───────────────────────────────────────────────────────────────────
def _pick(d, *keys, default=None):
    cur = d
    for k in keys:
        if isinstance(cur, dict) and k in cur:
            cur = cur[k]
        else:
            return default
    return cur


def _fmt_ms(ms):
    ms  = int(ms or 0)
    sec = ms // 1000
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


def _fmt_num(n):
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def _extract_number(text):
    cleaned = re.sub(r"@\S+", "", text or "")
    m = re.search(r"\b(\d+)\b", cleaned)
    return m.group(1) if m else None


def _is_tiktok_url(text):
    return bool(re.search(r"https?://(www\.|vm\.|vt\.)?tiktok\.com/\S+", text or ""))


# ── Tikwm API ─────────────────────────────────────────────────────────────────
def _normalize_item(x):
    return {
        "id": str(x.get("video_id") or x.get("id") or ""),
        "desc": x.get("title") or x.get("desc") or "",
        "stat": {
            "playCount": int(x.get("play_count") or x.get("playCount") or 0),
            "diggCount": int(x.get("digg_count") or x.get("diggCount") or 0),
            "commentCount": int(x.get("comment_count") or x.get("commentCount") or 0),
            "shareCount": int(x.get("share_count") or x.get("shareCount") or 0),
        },
        "video": {
            "url": x.get("play") or x.get("video_url") or x.get("wmplay") or "",
            "cover": x.get("cover") or x.get("origin_cover") or "",
            "duration": int((x.get("duration") or 0) * 1000) or 1000,
        },
        "author": x.get("author") or {},
        "music": {
            "title": _pick(x, "music_info", "title", default="") or "",
            "author": _pick(x, "music_info", "author", default="") or "",
            "url": _pick(x, "music_info", "play", default="") or "",
            "cover": _pick(x, "music_info", "cover", default="") or "",
        },
    }


def _search_tiktok(keywords, limit=9):
    try:
        with _tikwm_client() as c:
            r = c.post(f"{TikwmBase}/api/feed/search",
                       data={"keywords": keywords, "count": int(limit)})
            if r.status_code != 200:
                return []
            j = r.json()
        items = _pick(j, "data", "videos", default=None) or _pick(j, "data", default=[]) or []
        out = []
        for it in items:
            v = _normalize_item(it)
            if v["id"]:
                out.append(v)
            if len(out) >= limit:
                break
        return out
    except Exception as e:
        logger.errorw(f"[TikTok] search error: {e}")
        return []


def _get_video_info(tiktok_url):
    try:
        with _tikwm_client(timeout=30) as c:
            r = c.post(f"{TikwmBase}/api/", data={"url": tiktok_url})
            if r.status_code != 200:
                return None
            j = r.json()
        data = j.get("data") or {}
        if not data:
            return None
        return {
            "id":   str(data.get("id") or ""),
            "desc": data.get("title") or data.get("desc") or "",
            "author": {
                "unique_id": _pick(data, "author", "unique_id", default=""),
                "nickname":  _pick(data, "author", "nickname",  default=""),
            },
            "music": {
                "title":  _pick(data, "music_info", "title",  default=""),
                "author": _pick(data, "music_info", "author", default=""),
                "url":    _pick(data, "music_info", "play",   default=""),
                "cover":  _pick(data, "music_info", "cover",  default=""),
            },
            "stat": {
                "playCount":    int(data.get("play_count") or 0),
                "diggCount":    int(data.get("digg_count") or 0),
                "commentCount": int(data.get("comment_count") or 0),
                "shareCount":   int(data.get("share_count") or 0),
            },
            "video": {
                "url":   data.get("play")   or "",
                "noWatermarkUrl": data.get("hdplay") or data.get("play") or "",
                "cover": data.get("cover")  or "",
                "duration": int((data.get("duration") or 0) * 1000) or 1000,
            },
        }
    except Exception as e:
        logger.errorw(f"[TikTok] get_video_info error: {e}")
        return None


def _download_file(url, out_path):
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    with httpx.Client(timeout=120, follow_redirects=True,
                      headers={"User-Agent": "Mozilla/5.0"}) as c:
        with c.stream("GET", url) as r:
            r.raise_for_status()
            with open(out_path, "wb") as f:
                for chunk in r.iter_bytes():
                    if chunk:
                        f.write(chunk)
    return out_path


def _extract_audio(video_path, audio_path):
    """Dùng ffmpeg để trích audio mp3 từ video."""
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", video_path,
             "-vn", "-acodec", "libmp3lame", "-q:a", "2", audio_path],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=60,
        )
        return os.path.exists(audio_path)
    except Exception as e:
        logger.errorw(f"[TikTok] ffmpeg error: {e}")
        return False


# ── Ensure state attrs ────────────────────────────────────────────────────────
def _ensure_state(self):
    if not hasattr(self, "tiktokStates"):
        self.tiktokStates = {}
    if not hasattr(self, "MediaCache"):
        self.MediaCache = MediaCache()


# ── Cooldown timer ────────────────────────────────────────────────────────────
def _start_timeout_loop(self, key, msg_id, cli_id, thread_id, thread_type):
    """Hiện đồng hồ đếm ngược trên message danh sách."""
    if not hasattr(self, "_tiktokCooldown"):
        self._tiktokCooldown = {}
    self._tiktokCooldown[key] = True

    def _loop():
        for i in range(Timeout, 0, -1):
            if not self._tiktokCooldown.get(key):
                break
            try:
                self.sendMultiReaction(
                    MessageObject(msgId=msg_id, cliMsgId=cli_id, msgType="webchat"),
                    "🕑", thread_id, thread_type, 102229, numreact=i
                )
                time.sleep(1)
                self.sendMultiReaction(
                    MessageObject(msgId=msg_id, cliMsgId=cli_id, msgType="webchat"),
                    "", thread_id, thread_type, -1, numreact=i
                )
            except Exception:
                break
        self._tiktokCooldown.pop(key, None)

    threading.Thread(target=_loop, daemon=True).start()


def _stop_timeout(self, key):
    if hasattr(self, "_tiktokCooldown"):
        self._tiktokCooldown[key] = False


# ── Timeout cleanup ───────────────────────────────────────────────────────────
def _init_timeout_cleaner(self):
    def _loop():
        while True:
            now = time.time()
            for uid, state in list(self.tiktokStates.items()):
                if now - state["time"] > Timeout:
                    self.tiktokStates.pop(uid, None)
                    try:
                        self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], state["threadId"])
                    except Exception:
                        pass
                    try:
                        self.sendMentionStyle("Hết thời gian, hãy tìm kiếm lại!", uid,
                                              state["threadId"], state["typeGr"])
                    except Exception:
                        pass
            time.sleep(5)

    threading.Thread(target=_loop, daemon=True).start()


# ── Send video ────────────────────────────────────────────────────────────────
def _send_video(self, data_obj, item, thread_id, thread_type, user_id,
                is_audio=False, loading_msg_id=None, loading_cli_id=None):
    """Tải và gửi video (hoặc audio) cho user."""
    _ensure_state(self)

    def _delete_loading():
        if loading_msg_id and loading_cli_id:
            try:
                self.deleteMessage(loading_msg_id, self.uid, loading_cli_id, thread_id)
            except Exception:
                pass

    vid   = item.get("video") or {}
    vid_url = vid.get("noWatermarkUrl") or vid.get("url") or ""
    if not vid_url:
        _delete_loading()
        self.sendMentionStyle("Không lấy được link video!", user_id, thread_id, thread_type)
        return

    # Tải video
    cache_dir = "data/assets/cache/tiktok"
    os.makedirs(cache_dir, exist_ok=True)
    vid_path = f"{cache_dir}/{uuid.uuid4().hex}.mp4"

    try:
        _download_file(vid_url, vid_path)
    except Exception as e:
        _delete_loading()
        logger.errorw(f"[TikTok] download error: {e}")
        self.sendMentionStyle("Tải video thất bại!", user_id, thread_id, thread_type)
        return

    try:
        # ── Gửi card ảnh ──────────────────────────────────────────────────
        card_path = f"{cache_dir}/{uuid.uuid4().hex}.jpg"
        image_url = None
        try:
            draw_tiktok_card(item, card_path)
            res = self._uploadImage(card_path, thread_id, thread_type)
            if isinstance(res, dict):
                image_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                image_url = res
        except Exception as ce:
            logger.errorw(f"[TikTok] card error: {ce}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        _delete_loading()

        # ── Gửi caption + card ────────────────────────────────────────────
        name         = self.userName(user_id) or str(user_id)
        mention_text = f"@{name}"
        caption      = f"{'🎵' if is_audio else '🎬'} {mention_text} {_next_caption()}"

        if image_url:
            try:
                self.sendRemoteImage(
                    image_url, thread_id, thread_type,
                    width=2048, height=622,
                    message=Message(
                        text=caption,
                        mention=Mention(user_id, length=len(mention_text), offset=3)
                    )
                )
            except Exception:
                self.sendMentionStyle(_next_caption(), user_id, thread_id, thread_type)
        else:
            self.sendMentionStyle(_next_caption(), user_id, thread_id, thread_type)

        # ── Audio hoặc Video ──────────────────────────────────────────────
        if is_audio:
            audio_path = f"{cache_dir}/{uuid.uuid4().hex}.mp3"
            ok = _extract_audio(vid_path, audio_path)
            if ok:
                try:
                    import asyncio
                    upload = asyncio.run(
                        self._uploadAttachmentAsync(audio_path, thread_id, thread_type)
                    )
                    file_url = (upload or {}).get("fileUrl")
                    if file_url:
                        self.sendRemoteVoice(file_url, thread_id, thread_type)
                    else:
                        self.sendMentionStyle("Upload audio thất bại!", user_id, thread_id, thread_type)
                finally:
                    if os.path.exists(audio_path):
                        try:
                            os.remove(audio_path)
                        except Exception:
                            pass
            else:
                self.sendMentionStyle("Trích xuất audio thất bại!", user_id, thread_id, thread_type)
        else:
            # Upload & gửi video
            try:
                import asyncio
                upload = asyncio.run(
                    self._uploadAttachmentAsync(vid_path, thread_id, thread_type)
                )
                file_url = (upload or {}).get("fileUrl")
                if file_url:
                    thumb_url = vid.get("cover") or ""
                    dur_ms    = int(vid.get("duration") or 1000)
                    self.sendRemoteVideo(
                        file_url, thumb_url, dur_ms,
                        thread_id, thread_type,
                        width=1080, height=1920,
                    )
                else:
                    self.sendMentionStyle("Upload video thất bại!", user_id, thread_id, thread_type)
            except Exception as ue:
                logger.errorw(f"[TikTok] upload error: {ue}")
                self.sendMentionStyle("Upload video thất bại!", user_id, thread_id, thread_type)

        self.sendReaction(data_obj, "/-ok", thread_id, thread_type, 100000000)

    finally:
        if os.path.exists(vid_path):
            try:
                os.remove(vid_path)
            except Exception:
                pass


# ── Main command ──────────────────────────────────────────────────────────────
def TikTokCommand(self, message_obj, data, user_id, thread_id, thread_type):
    _ensure_state(self)

    text = (getattr(message_obj, "text", "") or "").strip()
    prefix   = getattr(self, "prefix", "/")
    cmd_name = getattr(self, "commandName", "tiktok")

    # Bỏ prefix + tên lệnh
    cmd_tok = f"{prefix}{cmd_name}"
    if text.lower().startswith(cmd_tok.lower()):
        arg = text[len(cmd_tok):].strip()
    else:
        parts = text.split(maxsplit=1)
        arg   = parts[1].strip() if len(parts) > 1 else ""

    if not arg:
        guide = (
            f"🎵 Tìm kiếm & tải video TikTok!\n\n"
            f"📍 {prefix}{cmd_name} <từ khoá>   – Tìm kiếm video\n"
            f"📍 Reply <số>             – Tải video (không watermark)\n"
            f"📍 Reply <số> audio       – Tải âm thanh mp3\n"
            f"📍 {prefix}{cmd_name} <url TikTok> – Tải trực tiếp từ link\n\n"
            f"Ví dụ: {prefix}{cmd_name} mèo cute"
        )
        return self.replyMessageStyle(
            guide, data, thread_id, thread_type,
            color="or", title="TIKTOK", userId=user_id
        )

    # ── Trường hợp nhập số (chọn từ danh sách) ───────────────────────────────
    state = self.tiktokStates.get(user_id)
    is_audio = "audio" in arg.lower()
    num_str  = _extract_number(arg)

    if num_str and state:
        if time.time() - state["time"] > Timeout:
            self.tiktokStates.pop(user_id, None)
            return self.sendMentionStyle("Hết thời gian, hãy tìm kiếm lại!", user_id, thread_id, thread_type)

        num = int(num_str)
        if num == 0:
            _stop_timeout(self, state.get("msgId"))
            self.tiktokStates.pop(user_id, None)
            return

        items = state["items"]
        if num < 1 or num > len(items):
            return self.sendMentionStyle(
                f"Số không hợp lệ! Nhập từ 1 đến {len(items)}",
                user_id, thread_id, thread_type
            )

        _stop_timeout(self, state.get("msgId"))
        item = items[num - 1]
        self.tiktokStates.pop(user_id, None)

        # Xoá list card
        try:
            self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], thread_id)
        except Exception:
            pass

        loading = self.sendMentionStyle("⏳ Đang tải video TikTok...", user_id, thread_id, thread_type)
        self.sendReaction(data, "🕑", thread_id, thread_type, 1000000023)

        threading.Thread(
            target=_send_video,
            args=(self, data, item, thread_id, thread_type, user_id),
            kwargs={
                "is_audio": is_audio,
                "loading_msg_id": getattr(loading, "msgId", None),
                "loading_cli_id": getattr(loading, "clientId", None),
            },
            daemon=True,
        ).start()
        return

    # ── Tải trực tiếp từ URL ─────────────────────────────────────────────────
    if _is_tiktok_url(arg):
        self.sendReaction(data, "🔍", thread_id, thread_type, 100000000)
        loading = self.sendMentionStyle("⏳ Đang lấy thông tin video...", user_id, thread_id, thread_type)

        def _direct_dl():
            info = _get_video_info(arg)
            if not info:
                try:
                    self.deleteMessage(
                        getattr(loading, "msgId", None),
                        self.uid,
                        getattr(loading, "clientId", None),
                        thread_id,
                    )
                except Exception:
                    pass
                self.sendMentionStyle("Không lấy được thông tin video!", user_id, thread_id, thread_type)
                return
            _send_video(
                self, data, info, thread_id, thread_type, user_id,
                is_audio=False,
                loading_msg_id=getattr(loading, "msgId", None),
                loading_cli_id=getattr(loading, "clientId", None),
            )

        threading.Thread(target=_direct_dl, daemon=True).start()
        return

    # ── Tìm kiếm theo từ khoá ────────────────────────────────────────────────
    keyword = arg
    self.sendReaction(data, "🔍", thread_id, thread_type, 100000000)

    def _do_search():
        items = _search_tiktok(keyword, limit=9)

        if not items:
            self.sendReaction(data, "❌", thread_id, thread_type, 100000000)
            self.replyMessageStyle(
                f"Không tìm thấy video TikTok với từ khoá: \"{keyword}\"",
                data, thread_id, thread_type,
                color="r", title="TIKTOK", userId=user_id
            )
            return

        # Vẽ card danh sách
        card_path = None
        list_url  = None
        try:
            os.makedirs("data/assets/cache/tiktok", exist_ok=True)
            card_path = f"data/assets/cache/tiktok/{uuid.uuid4().hex}.jpg"
            draw_tiktok_list(items, card_path, keyword=keyword)
            res = self._uploadImage(card_path, thread_id, thread_type)
            if isinstance(res, dict):
                list_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                list_url = res
        except Exception as ce:
            logger.errorw(f"[TikTok] list card error: {ce}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        name         = self.userName(user_id) or str(user_id)
        mention_text = f"@{name}"
        caption      = f"🎵 {mention_text} Chọn số để tải • reply 0 để huỷ"

        if list_url:
            msg = self.sendRemoteImage(
                list_url, thread_id, thread_type,
                width=2560, height=1440,
                message=Message(
                    text=caption,
                    mention=Mention(user_id, length=len(mention_text), offset=3)
                )
            )
        else:
            # Fallback text
            lines = [f"🎵 TikTok: \"{keyword}\"\nChọn số để tải • reply 0 để huỷ\n"]
            for i, it in enumerate(items, 1):
                desc  = (it.get("desc") or "TikTok")[:40]
                auth  = (
                    it.get("author", {}).get("unique_id")
                    or it.get("author", {}).get("nickname")
                    or "TikTok"
                )
                dur   = _fmt_ms(it.get("video", {}).get("duration") or 0)
                plays = _fmt_num(it.get("stat", {}).get("playCount") or 0)
                lines.append(f"{i}. {desc}\n   @{auth} • {dur} • ▶{plays}")
            lines.append("\n0. Huỷ")
            msg = self.sendMentionStyle("\n".join(lines), user_id, thread_id, thread_type)

        self.tiktokStates[user_id] = {
            "items":    items,
            "time":     time.time(),
            "msgId":    getattr(msg, "msgId",    None),
            "cliMsgId": getattr(msg, "clientId", None),
            "threadId": thread_id,
            "typeGr":   thread_type,
        }

        _start_timeout_loop(
            self,
            key=getattr(msg, "msgId", str(user_id)),
            msg_id=getattr(msg, "msgId",    None),
            cli_id=getattr(msg, "clientId", None),
            thread_id=thread_id,
            thread_type=thread_type,
        )

    threading.Thread(target=_do_search, daemon=True).start()


# ── Reply handler (gọi từ utils.py) ──────────────────────────────────────────
def TikTokReply(self, message_obj, data, user_id, thread_id, thread_type):
    """Xử lý khi user reply vào message list TikTok để chọn số."""
    if not hasattr(self, "tiktokStates"):
        return

    state = self.tiktokStates.get(user_id)
    if not state:
        return

    raw   = getattr(message_obj, "text", "") or ""
    quoted = getattr(data, "quote", None)
    if not quoted:
        return

    num_str = _extract_number(raw)
    if not num_str:
        return

    is_audio = "audio" in raw.lower()

    # Giả lập gọi command với số đã chọn
    fake_msg = Message(text=f"{getattr(self, 'prefix', '/')}{getattr(self, 'commandName', 'tiktok')} {'audio ' if is_audio else ''}{num_str}")

    # Lưu lại commandName tạm để command xử lý đúng
    old_cmd = getattr(self, "commandName", "tiktok")
    self.commandName = "tiktok"
    TikTokCommand(self, fake_msg, data, user_id, thread_id, thread_type)
    self.commandName = old_cmd

    # Xoá message list sau khi chọn
    try:
        self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], thread_id)
    except Exception:
        pass


# ── onLoad hook ───────────────────────────────────────────────────────────────
def _on_load(self):
    _ensure_state(self)
    _init_timeout_cleaner(self)


# ── dependencies ──────────────────────────────────────────────────────────────
dependencies = {
    "name":        "tiktok",
    "permission":  0,
    "cooldown":    5,
    "description": "Tìm kiếm & tải video TikTok (không watermark)",
    "alias":       ["tt", "tik"],
    "onLoad":      _on_load,
    "main":        TikTokCommand,
}
