from app.core.index import *
import requests
import json
import time
from urllib.parse import quote
_PINTEREST_LIMIT = 50  
_DEFAULT_COUNT   = 3   
_MAX_COUNT       = 20  

def _search_pinterest(query: str, limit: int = _PINTEREST_LIMIT) -> list:
    try:
        encoded_query = quote(query)
        search_url = "https://www.pinterest.com/resource/BaseSearchResource/get/"

        payload = {
            "options": {
                "applied_unified_filters": None,
                "appliedProductFilters": "---",
                "article": None,
                "auto_correction_disabled": False,
                "corpus": None,
                "customized_rerank_type": None,
                "domains": None,
                "filters": None,
                "journey_depth": None,
                "page_size": limit,
                "price_max": None,
                "price_min": None,
                "query_pin_sigs": None,
                "query": query,
                "redux_normalize_feed": True,
                "request_params": None,
                "rs": "typed",
                "scope": "pins",
                "selected_one_bar_modules": None,
                "seoDrawerEnabled": False,
                "source_id": None,
                "source_module_id": None,
                "source_url": f"/search/pins/?q={encoded_query}&rs=typed",
                "top_pin_id": None,
                "top_pin_ids": None,
            },
            "context": {},
        }

        headers = {
            "Accept": "application/json, text/javascript, */*, q=0.01",
            "Referer": "https://www.pinterest.com/",
            "x-app-version": "9237374",
            "x-pinterest-appstate": "active",
            "x-pinterest-source-url": f"/search/pins/?q={encoded_query}&rs=typed",
            "x-requested-with": "XMLHttpRequest",
            "x-pinterest-pws-handler": "www/search/[scope].js",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/133.0.0.0 Safari/537.36"
            ),
        }

        params = {
            "source_url": f"/search/pins/?q={encoded_query}&rs=typed",
            "data": json.dumps(payload),
            "_": int(time.time() * 1000),
        }

        resp = requests.get(search_url, headers=headers, params=params, timeout=15)
        if resp.status_code != 200:
            return []

        data     = resp.json()
        resource = data.get("resource_response", {}).get("data", {})
        results  = resource.get("results", [])

        urls = []
        for pin in results:
            if not pin or "images" not in pin:
                continue
            images = pin["images"]
            url = (
                images.get("orig",  {}).get("url") or
                images.get("1200x", {}).get("url") or
                images.get("736x",  {}).get("url") or
                images.get("600x",  {}).get("url") or
                images.get("474x",  {}).get("url")
            )
            if url:
                urls.append(url)

        return urls

    except Exception as err:
        logger.errorw(f"[Pinterest] Lỗi crawl: {err}")
        return []

def pinterestCommand(self, message, data, userId, threadId, type):
    prefix   = getattr(self, "prefix",      "/")
    cmd_name = getattr(self, "commandName", "pin")

    text_raw = (getattr(message, "text", "") or "").strip()
    cmd_tok  = f"{prefix}{cmd_name}"
    if text_raw.lower().startswith(cmd_tok.lower()):
        args_raw = text_raw[len(cmd_tok):].strip()
    else:
        parts    = text_raw.split(maxsplit=1)
        args_raw = parts[1].strip() if len(parts) > 1 else ""

    if not args_raw:
        guide = (
            f"Thêm từ khoá để tìm kiếm ảnh từ Pinterest!\n\n"
            f"Ví dụ:\n"
            f"📍{prefix}{cmd_name} [Từ_Khoá] - Tìm kiếm ảnh theo từ khoá.\n"
            f"📍{prefix}{cmd_name} [Từ_Khoá] [Số_Lượng] - Tìm kiếm ảnh theo từ khoá và số lượng được yêu cầu."
        )
        return self.replyMessageStyle(
            guide,
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )

    tokens = args_raw.rsplit(maxsplit=1)

    count = _DEFAULT_COUNT
    query = args_raw

    if len(tokens) == 2:
        last = tokens[1]
        if last.isdigit():
            count = max(1, min(int(last), _MAX_COUNT))
            query = tokens[0].strip()

    if not query:
        return self.replyMessageStyle(
            f"Vui lòng nhập từ khoá để tìm kiếm!",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )

    self.sendReaction(data, "🔍", threadId, type, 100000000)

    pool = _search_pinterest(query, limit=max(_PINTEREST_LIMIT, count * 3))

    if not pool:
        self.sendReaction(data, "❌", threadId, type, 100000000)
        return self.replyMessageStyle(
            f"Không tìm thấy ảnh nào với từ khoá: \"{query}\"",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

    selected = pool[:count]

    # Gửi text info trước
    self.replyMessageStyle(
        f"🖼️ Pinterest: \"{query}\"\nĐang gửi {len(selected)} ảnh...",
        data, threadId, type,
        color="gr", title="PINTEREST", userId=userId,
    )

    try:
        self.sendMultiRemoteImage(
            selected, threadId, type,
            width=2560, height=2560,
        )
        self.sendReaction(data, "✅", threadId, type, 100000000)
    except Exception as e:
        logger.errorw(f"[Pinterest] sendMultiRemoteImage thất bại: {e}")
        self.sendReaction(data, "❌", threadId, type, 100000000)
        self.replyMessageStyle(
            "Tìm được ảnh nhưng không thể gửi, vui lòng thử lại sau!",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

dependencies = {
    "name": "pinterest",
    "permission": 0,
    "cooldown": 5,
    "description": "Tìm kiếm ảnh từ Pinterest theo từ khoá",
    "alias": ["pin"],
    "main": pinterestCommand,
}