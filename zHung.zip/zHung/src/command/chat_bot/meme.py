import os
import re
import time
import uuid
import threading
import requests
from app.core.index import *
from app.module.commandLoader import removeMention
from src.services.pillow.memeListCard import draw_meme_list

TENOR_API_KEY = "AIzaSyCzXcYoOGIl1ZAvIN1QJ8La4qJiDwaxWa8"
MAX_LIMIT     = 50
DEFAULT_LIMIT = 10
Timeout       = 120

def _search_tenor(keyword: str, limit: int) -> list[str]:
    try:
        r = requests.get(
            "https://tenor.googleapis.com/v2/search",
            params={"q": keyword, "key": TENOR_API_KEY,
                    "limit": limit, "media_filter": "gif"},
            timeout=8,
        )
        r.raise_for_status()
        return [item["media_formats"]["gif"]["url"]
                for item in r.json().get("results", [])]
    except Exception as e:
        logger.errorw(f"[meme] Tenor error: {e}")
        return []

def _parse_selection(arg: str, total: int) -> list[int] | None:
    arg = arg.strip().lower()
    if arg == "all":
        return list(range(total))

    indices: list[int] = []
    for part in re.split(r"[,\s]+", arg):
        part = part.strip()
        if not part:
            continue
        m = re.fullmatch(r"(\d+)-(\d+)", part)
        if m:
            lo, hi = int(m.group(1)) - 1, int(m.group(2)) - 1
            indices.extend(range(lo, hi + 1))
        elif part.isdigit():
            indices.append(int(part) - 1)
        else:
            return None

    valid = [i for i in dict.fromkeys(indices) if 0 <= i < total]
    return valid if valid else None

def _is_selection_token(text: str) -> bool:
    t = text.strip().lower()
    return t == "all" or bool(re.fullmatch(r"[\d,\-\s]+", t))

class MemeSession:

    __slots__ = (
        "urls", "time", "msgId", "cliMsgId",
        "threadId", "typeGr",
    )

    def __init__(self, urls, msgId, cliMsgId, threadId, typeGr):
        self.urls     = urls
        self.time     = time.time()
        self.msgId    = msgId
        self.cliMsgId = cliMsgId
        self.threadId = threadId
        self.typeGr   = typeGr

    def is_expired(self) -> bool:
        return time.time() - self.time > Timeout

    def to_dict(self) -> dict:
        return {
            "urls":     self.urls,
            "time":     self.time,
            "msgId":    self.msgId,
            "cliMsgId": self.cliMsgId,
            "threadId": self.threadId,
            "typeGr":   self.typeGr,
        }


class MemeHandler:

    _HELP_TEMPLATE = (   
        "  📌 Tìm kiếm\n"
        "     {cmd} <từ khoá>\n"
        "     {cmd} <từ khoá> <số lượng>\n"
        "\n"
        "  📌 Chọn sau khi tìm\n"
        "     {cmd} 3          →  gửi sticker số 3\n"
        "     {cmd} 1,3,5      →  gửi sticker 1, 3 và 5\n"
        "     {cmd} 2-6        →  gửi sticker 2 đến 6\n"
        "     {cmd} 1,3-5,8    →  kết hợp\n"
        "     {cmd} all        →  gửi tất cả\n"
        "\n"
        "  ⏱  Phiên chọn tồn tại 120 giây.\n"
        "     Tối đa {max} sticker / lần tìm."
    )

    def __init__(self, ctx, MessageObj, Data, UserId, ThreadId, ThreadType):
        self._ctx       = ctx
        self._msg       = MessageObj
        self._data      = Data
        self.UserId     = str(UserId)
        self.ThreadId   = ThreadId
        self.ThreadType = ThreadType
        self.cmd        = f"{ctx.prefix}{ctx.commandName}"

    def _reply(self, text: str, *, color: str, title: str):
        return self._ctx.replyMessageStyle(
            text, self._data, self.ThreadId, self.ThreadType,
            color=color, title=title, userId=self.UserId,
        )
    def _warn(self, text: str):
        return self._reply(text, color="yl", title="WARNING")

    def _err(self, text: str):
        return self._reply(text, color="r",  title="ERROR")

    def _ok(self, text: str):
        return self._reply(text, color="gr", title="SUCCESS")

    @property
    def _session(self) -> MemeSession | None:
        return self._ctx.memeStates.get(self.UserId)

    def _drop_session(self):
        s = self._ctx.memeStates.pop(self.UserId, None)
        if s:
            _stop_cooldown(self._ctx, s.msgId)

    def _close_list_msg(self, session: MemeSession):
        _stop_cooldown(self._ctx, session.msgId)
        try:
            self._ctx.deleteMessage(
                session.msgId, self._ctx.uid,
                session.cliMsgId, session.threadId,
            )
        except Exception:
            pass

    def run(self):
        raw  = (self._msg.text or "").strip()
        parts = raw.split()
        args  = parts[1:]   

        if not args:
            return self._warn(self._help())

        arg_str = " ".join(args)

        if _is_selection_token(arg_str):
            return self._handle_select(arg_str)

        return self._handle_search(args)

    def _handle_select(self, arg_str: str):
        session = self._session
        if not session:
            return self._warn(
                f"Chưa có kết quả nào.\n"
                f"Dùng  {self.cmd} <từ khoá>  để tìm trước."
            )
        if session.is_expired():
            self._ctx.memeStates.pop(self.UserId, None)
            return self._warn("Phiên đã hết hạn (120s). Hãy tìm lại.")

        indices = _parse_selection(arg_str, len(session.urls))
        if indices is None:
            return self._warn(
                f"Cú pháp không hợp lệ.\n"
                f"Hỗ trợ: số đơn / 1,3,5 / 2-6 / all"
            )
        if not indices:
            return self._warn(
                f"Số thứ tự ngoài phạm vi (1–{len(session.urls)})."
            )

        self._ctx.memeStates.pop(self.UserId, None)
        self._deliver(session, indices)

    def _handle_search(self, args: list[str]):
        limit         = DEFAULT_LIMIT
        keyword_parts = list(args)
        if len(args) >= 2 and args[-1].isdigit():
            limit         = min(int(args[-1]), MAX_LIMIT)
            keyword_parts = args[:-1]
        keyword = " ".join(keyword_parts).strip()
        if not keyword:
            return self._warn(self._help())

        self._ok(f"🔍 Đang tìm «{keyword}»...")

        urls = _search_tenor(keyword, limit)
        if not urls:
            return self._err(f"Không tìm thấy meme nào với «{keyword}».")
        old = self._session
        if old:
            self._close_list_msg(old)
            self._ctx.memeStates.pop(self.UserId, None)

        Msg = self._send_list(urls, keyword)

        session = MemeSession(
            urls     = urls,
            msgId    = getattr(Msg, "msgId",    None),
            cliMsgId = getattr(Msg, "clientId", None),
            threadId = self.ThreadId,
            typeGr   = self.ThreadType,
        )
        self._ctx.memeStates[self.UserId] = session
        _start_cooldown(self._ctx, Msg, self.ThreadId, self.ThreadType)

    def _send_list(self, urls: list[str], keyword: str):
        name         = self._ctx.userName(self.UserId) or self.UserId
        mention_text = f"@{name}"
        caption      = (
            f"🎭 {mention_text} Tìm thấy {len(urls)} meme cho «{keyword}»\n"
            f"Nhập: số / 1,3,5 / 2-5 / all  •  120s"
        )

        list_path = None
        list_url  = None
        img_w = img_h = 0
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            list_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_meme_list(urls, list_path, keyword=keyword)
            from PIL import Image as _Img
            with _Img.open(list_path) as im:
                img_w, img_h = im.size
            res = self._ctx._uploadImage(list_path, self.ThreadId, self.ThreadType)
            if isinstance(res, dict):
                list_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                list_url = res
        except Exception as e:
            logger.errorw(f"[meme] canvas/upload error: {e}")
        finally:
            if list_path and os.path.exists(list_path):
                try:
                    os.remove(list_path)
                except Exception:
                    pass

        if list_url:
            return self._ctx.sendRemoteImage(
                list_url, self.ThreadId, self.ThreadType,
                width=img_w or 2560, height=img_h or 1440,
                message=Message(
                    text    = caption,
                    mention = Mention(self.UserId, length=len(mention_text), offset=3),
                ),
            )

        lines = "\n".join(f"{i+1}. {u}" for i, u in enumerate(urls[:10]))
        return self._ctx.sendMentionStyle(
            f"Tìm thấy {len(urls)} meme:\n{lines}\n\n"
            f"Dùng {self.cmd} <số / 1,3 / 2-5 / all>",
            self.UserId, self.ThreadId, self.ThreadType,
        )

    def _deliver(self, session: MemeSession, indices: list[int]):
        self._close_list_msg(session)
        self._ok(f"Đang gửi {len(indices)} sticker...")

        urls = session.urls
        ThreadId, ThreadType = self.ThreadId, self.ThreadType

        def _send():
            for i in indices:
                try:
                    self._ctx.sendCustomSticker(
                        staticImgUrl    = urls[i],
                        animationImgUrl = urls[i],
                        threadId       = ThreadId,
                        threadType     = ThreadType,
                        width           = 512,
                        height          = 512,
                    )
                    time.sleep(0.3)
                except Exception as e:
                    logger.errorw(f"[meme] sticker send error idx={i}: {e}")

        threading.Thread(target=_send, daemon=True).start()

    def _help(self) -> str:
        return self._HELP_TEMPLATE.format(cmd=self.cmd, max=MAX_LIMIT)

def _stop_cooldown(ctx, key: str | None):
    if key and hasattr(ctx, "_memeCooldown"):
        ctx._memeCooldown[key] = False

def _start_cooldown(ctx, MsgObj, ThreadId, ThreadType):
    if not hasattr(ctx, "_memeCooldown"):
        ctx._memeCooldown = {}

    key = MsgObj.msgId
    ctx._memeCooldown[key] = True

    msg = MessageObject(
        msgId    = MsgObj.msgId,
        cliMsgId = MsgObj.clientId,
        msgType  = "webchat",
    )

    def Loop():
        for i in range(Timeout, 0, -1):
            if not ctx._memeCooldown.get(key):
                break
            ctx.sendMultiReaction(msg, "🕑", ThreadId, ThreadType, 102229, numreact=i)
            time.sleep(1)
            ctx.sendMultiReaction(msg, "", ThreadId, ThreadType, -1, numreact=i)
        ctx._memeCooldown.pop(key, None)

    threading.Thread(target=Loop, daemon=True).start()

def MemeCommand(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    MemeHandler(self, MessageObj, Data, UserId, ThreadId, ThreadType).run()

def MemeReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    uid     = str(UserId)
    session = self.memeStates.get(uid)
    if not session or not Data.quote:
        return

    cleaned = removeMention(self, Data).strip()
    if not cleaned or not _is_selection_token(cleaned):
        return

    Fake = Message(text=f"{self.prefix}meme {cleaned}")
    MemeHandler(self, Fake, Data, UserId, ThreadId, ThreadType).run()

def InitTimeoutMeme(self, Interval: int = 1):
    def Loop():
        while True:
            Now = time.time()
            for Uid, session in list(self.memeStates.items()):
                if not session.is_expired():
                    continue
                self.memeStates.pop(Uid, None)
                _stop_cooldown(self, session.msgId)
                try:
                    self.deleteMessage(
                        session.msgId, self.uid,
                        session.cliMsgId, session.threadId,
                    )
                except Exception:
                    pass
                self.sendMentionStyle(
                    "Hết thời gian chọn meme. Tìm lại để tiếp tục.",
                    Uid, session.threadId, session.typeGr,
                )
            time.sleep(Interval)

    threading.Thread(target=Loop, daemon=True).start()

dependencies = {
    "name":        "meme",
    "permission":  0,
    "cooldown":    5,
    "description": "Tìm meme / GIF sticker từ Tenor",
    "main":        MemeCommand,
}