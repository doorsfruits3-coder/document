from app.core.index import *
import random

CAPTIONS = [
    # 0-4%
    "Thẳng hơn cả đường cao tốc, không có một khúc cua 🛣️",
    # 5-9%
    "Gần như thẳng 100%, chỉ hơi liếc nhìn BTS một lần thôi 👀",
    # 10-14%
    "Vẫn thẳng nhưng mà follow tài khoản 'thẩm mỹ nam' trên insta 💅",
    # 15-19%
    "Thẳng thớm, nhưng không hiểu sao biết hết lời nhạc BLACKPINK 🎵",
    # 20-24%
    "Cơ bản là thẳng, nhưng hay khen 'thằng đó đẹp trai nhỉ' 😶",
    # 25-29%
    "Bắt đầu có dấu hiệu... nhưng tự nhủ là 'chỉ ngưỡng mộ thôi' 🤔",
    # 30-34%
    "Xem phim romance nam-nam chỉ vì 'cốt truyện hay' 🎬",
    # 35-39%
    "Có gu thời trang hơi... tinh tế. Bạn bè gọi là 'nghệ sĩ' 🎨",
    # 40-44%
    "Tủ quần áo đang tự hỏi liệu bọn mình có đang sống với người thẳng không 👔",
    # 45-49%
    "Đang ở vùng xám, GPS nội tâm đang tìm lại tín hiệu 📡",
    # 50-54%
    "Chính xác ở giữa, như một đồng xu đang quay chưa chịu ngã 🪙",
    # 55-59%
    "Nghiêng về phía bên kia nhiều hơn một chút rồi đó nhen 🌈",
    # 60-64%
    "Hay tìm lý do 'lý thuyết' để giải thích cảm xúc của mình 🧠",
    # 65-69%
    "Bạn bè đã bắt đầu hỏi 'ủa mày thế nào rồi?' mà mày còn chưa trả lời 😂",
    # 70-74%
    "Đang ở giai đoạn 'tôi chỉ đang khám phá bản thân' ✨",
    # 75-79%
    "Màu cầu vồng đã bắt đầu thấm vào tâm hồn rồi đấy 🌈",
    # 80-84%
    "Tủ quần áo đã sẵn sàng, chỉ chờ chủ nhân chịu ra khỏi đó thôi 🚪",
    # 85-89%
    "Gần rồi! Chỉ cần một bộ phim Hàn nữa là xong 🎭",
    # 90-94%
    "Thôi thì mình cứ gọi là 'đặc biệt' cho lịch sự 🦄",
    # 95-99%
    "Gần chạm đỉnh! Chỉ còn thiếu cái nón cầu vồng thôi 👑",
    # 100%
    "FULL GAY! Xin chúc mừng, bạn đã mở khóa thành tựu RAINBOW LEGEND 🏳️‍🌈🎉",
]

def _get_caption(percent: int) -> str:
    if percent == 100:
        return CAPTIONS[20]
    return CAPTIONS[min(percent // 5, 19)]

def _get_name(self, uid: str, fallback: str) -> str:
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        return profile.get("displayName") or profile.get("zaloName") or fallback
    except Exception:
        return fallback

def gayCommand(self, message, data, userId, threadId, type):
    mentions = getattr(data, "mentions", None) or []

    target_uid = None
    for m in mentions:
        uid = str(m.get("uid", ""))
        if uid and uid != str(self.uid):
            target_uid = uid
            break

    if target_uid:
        name = _get_name(self, target_uid, "Người dùng")
    else:
        name = _get_name(self, userId, self.userName(userId))

    percent = random.randint(0, 100)
    caption = _get_caption(percent)

    result_text = (
        f"Phần trăm khả năng gay của {name} là {percent}%\n"
        f"📍{caption}"
    )

    self.replyMessageStyle(
        result_text,
        data, threadId, type,
        color="gr", title="SUCCESS",
        userId=userId,
    )

    self.sendReaction(data, "", threadId, type, -1)
    self.sendReaction(data, "🏳️‍🌈", threadId, type, 100000000)

dependencies = {
    "name": "gay",
    "permission": 0,
    "cooldown": 5,
    "description": "Đo chỉ số gay của bản thân hoặc ai đó",
    "main": gayCommand,
}