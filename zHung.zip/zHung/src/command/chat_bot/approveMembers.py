from app.core.index import *
import threading
import time

_HELP = """{p}{c} on/off             — Bật/Tắt tự động duyệt thành viên
{p}{c} reject on      — Bật/Tắt tự động từ chối yêu cầu
{p}{c} ok             — Duyệt ngay toàn bộ danh sách chờ
{p}{c} reject         — Từ chối ngay toàn bộ danh sách chờ"""

SETTING_KEY = "approveAuto"

def _read(uid: str) -> dict:
    s = read_settings(uid)
    return s.get(SETTING_KEY, {"enabled": False, "rejectEnabled": False})

def _write(uid: str, cfg: dict) -> None:
    s = read_settings(uid)
    s[SETTING_KEY] = cfg
    write_settings(uid, s)

def is_approve_active(uid: str) -> bool:
    return bool(_read(uid).get("enabled", False))

def is_reject_active(uid: str) -> bool:
    return bool(_read(uid).get("rejectEnabled", False))

def _get_managed_groups(bot) -> list[str]:
    settings = read_settings(bot.uid)
    return list(settings.get("allowGroup", []))

def _extract_ids_from_result(result) -> list[str]:
    if hasattr(result, "__dict__"):
        raw = dict(result.__dict__)
    elif isinstance(result, dict):
        raw = result
    else:
        return []

    users_raw = raw.get("users") or []
    if not isinstance(users_raw, list):
        return []

    ids = []
    for m in users_raw:
        if not isinstance(m, dict):
            m = getattr(m, "__dict__", {}) if hasattr(m, "__dict__") else {}
        uid = str(m.get("uid", "") or m.get("id", "") or "")
        if uid:
            ids.append(uid)

    return ids

def _pending_list(bot, groupId: str) -> list[str]:
    try:
        result = bot.viewGroupPending(groupId)
        return _extract_ids_from_result(result)
    except Exception as e:
        print(f"[approveMembers._pending_list] Exception group={groupId}: {type(e).__name__}: {e}")
        return []

def _handle_all_pending(bot, groupId: str, approve: bool) -> int:
    ids = _pending_list(bot, groupId)
    if not ids:
        return 0
    try:
        bot.handleGroupPending(ids, groupId, isApprove=approve)
    except Exception as e:
        print(f"[approveMembers] handleGroupPending FAIL group={groupId}: {type(e).__name__}: {e}")
    return len(ids)

def handle_join_request_event(bot, groupId: str) -> None:
    if is_approve_active(bot.uid):
        _handle_all_pending(bot, groupId, approve=True)
        return

    if is_reject_active(bot.uid):
        _handle_all_pending(bot, groupId, approve=False)

def approveMembersCommand(bot, message, data, userId, threadId, msg_type) -> None:
    p     = bot.prefix
    c     = bot.rawCommand
    parts = (getattr(message, "text", "") or "").strip().split()

    def ok(text):
        bot.replyMessageStyle(
            text, data, threadId, msg_type,
            color="gr", title="APPROVE", userId=userId,
        )

    def warn(text):
        bot.replyMessageStyle(
            text, data, threadId, msg_type,
            color="yl", title="WARNING", userId=userId,
        )

    def err(text):
        bot.replyMessageStyle(
            text, data, threadId, msg_type,
            color="r", title="ERROR", userId=userId,
        )

    cfg = _read(bot.uid)

    if len(parts) < 2:
        return warn(_HELP.format(p=p, c=c))

    sub = parts[1].lower()

    if sub == "on":
        if cfg.get("enabled"):
            return ok("Tự động duyệt thành viên đang BẬT rồi ✅")
        cfg["enabled"] = True
        cfg["rejectEnabled"] = False
        _write(bot.uid, cfg)
        return ok(
            "Tự động duyệt thành viên: BẬT ✅\n"
            "Bot sẽ tự duyệt ngay khi có yêu cầu tham gia nhóm."
        )

    if sub == "off":
        if not cfg.get("enabled"):
            return ok("Tự động duyệt thành viên đang TẮT rồi ❌")
        cfg["enabled"] = False
        _write(bot.uid, cfg)
        return ok("Tự động duyệt thành viên: TẮT ❌")

    if sub == "reject":
        if len(parts) < 3:
            groups = _get_managed_groups(bot)
            if not groups:
                return err("Bot chưa được thêm vào nhóm nào.")

            total = 0

            def _do_reject():
                nonlocal total
                for gid in groups:
                    n = _handle_all_pending(bot, gid, approve=False)
                    total += n

            t = threading.Thread(target=_do_reject, daemon=True)
            t.start()
            t.join(timeout=30)

            if total == 0:
                return ok("Không có yêu cầu nào đang chờ duyệt.")
            return ok(f"Đã từ chối {total} yêu cầu tham gia nhóm ✅")

        action = parts[2].lower()

        if action == "on":
            if cfg.get("rejectEnabled"):
                return ok("Tự động từ chối yêu cầu đang BẬT rồi ✅")
            cfg["rejectEnabled"] = True
            cfg["enabled"] = False
            _write(bot.uid, cfg)
            return ok(
                "Tự động từ chối yêu cầu: BẬT ✅\n"
                "Bot sẽ tự từ chối ngay khi có yêu cầu tham gia nhóm."
            )

        if action == "off":
            if not cfg.get("rejectEnabled"):
                return ok("Tự động từ chối yêu cầu đang TẮT rồi ❌")
            cfg["rejectEnabled"] = False
            _write(bot.uid, cfg)
            return ok("Tự động từ chối yêu cầu: TẮT ❌")

        return warn(_HELP.format(p=p, c=c))

    if sub == "ok":
        groups = _get_managed_groups(bot)
        if not groups:
            return err("Bot chưa được thêm vào nhóm nào.")

        total = 0

        def _do_approve():
            nonlocal total
            for gid in groups:
                n = _handle_all_pending(bot, gid, approve=True)
                total += n

        t = threading.Thread(target=_do_approve, daemon=True)
        t.start()
        t.join(timeout=30)

        if total == 0:
            return ok("Không có yêu cầu nào đang chờ duyệt.")
        return ok(f"Đã duyệt {total} thành viên vào nhóm ✅")

    warn(_HELP.format(p=p, c=c))

dependencies = {
    "name":        "approve",
    "permission":  2,
    "description": "Duyệt, từ chối yêu cầu tham gia nhóm.",
    "cooldown":    3,
    "main":        approveMembersCommand,
}