from app.core.index import *
from src.services.pillow.stickerCore import (
    MaxStickerSize, GetMediaWh,
    CreateStickerUrl,
    CreateStickerLegoUrl,
)
from PIL import Image
import os, urllib, json


def StickerCommand(self, message, data, userId, threadId, type):
    p   = self.prefix
    c   = self.commandName
    cmd = f"{p}{c}"

    Help = (
        f"Quote ảnh/video để tạo sticker.\n"
        f"Args:\n"
        f"  {cmd} sqr           — sticker vuông\n"
        f"  {cmd} spin          — sticker xoay\n"
        f"  {cmd} pixel         — hiệu ứng pixel Lego 3D\n"
        f"  {cmd} pixel [4-32]  — pixel + chỉnh kích thước ô (mặc định 14)\n"
        f"  {cmd} [1-100]       — bo góc theo phần trăm\n"
        f"  {cmd} -scale=0.5    — thu nhỏ ảnh trong khung (0.5–1.0)"
    )

    spin          = False
    sqr           = False
    pixel         = False
    blockSize     = 14
    radiusPercent = 0
    scaleFactor   = 1.0
    sqrDefaultR   = 20
    fps           = 30
    scale         = MaxStickerSize
    seconds       = 30
    q             = 95
    spinFps       = 60
    spinSeconds   = 6

    # Bỏ qua token đầu (tên lệnh có/không prefix)
    tokens = (message.text or "").split()
    prev_pixel = False
    for part in tokens[1:]:
        pl = part.lower()
        if pl == "spin":
            spin = True
            radiusPercent = 100
            prev_pixel = False
            continue
        if pl == "sqr":
            sqr = True
            prev_pixel = False
            continue
        if pl in ("pixel", "lego", "pxl"):
            pixel = True
            prev_pixel = True
            continue
        if pl.startswith("-scale=") or pl.startswith("scale="):
            try:
                v = float(pl.split("=", 1)[1])
                if v > 1.0:
                    v = v / 100.0
                if 0.5 <= v <= 1.0:
                    scaleFactor = v
            except Exception:
                pass
            prev_pixel = False
            continue
        if pl.isdigit():
            v = int(pl)
            # Nếu vừa parse "pixel", số này là blockSize (4–32)
            if prev_pixel and 4 <= v <= 32:
                blockSize = v
            elif 1 <= v <= 100:
                radiusPercent = v
            prev_pixel = False
            continue
        prev_pixel = False

    if sqr:
        if radiusPercent == 100:
            radiusPercent = 0
        if radiusPercent == 0:
            radiusPercent = sqrDefaultR

    if not data.quote:
        return self.replyMessageStyle(
            Help, data, threadId, type,
            color="yl", title="STICKER", userId=userId,
        )

    outputPath = "data/assets/cache/sticker/sticker.webp"
    os.makedirs("data/assets/cache/sticker", exist_ok=True)

    try:
        attach   = json.loads(data.quote.attach)
        imageUrl = attach.get("hdUrl") or attach.get("href")
        if not imageUrl:
            return self.replyMessageStyle(
                "Không lấy được link ảnh từ tin nhắn được quote.",
                data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

        imageUrl = urllib.parse.unquote(imageUrl.replace("\\/", "/"))
        imageUrl = imageUrl.replace("/jxl", "/jpg").replace(".jxl", ".jpg")

        if pixel:
            CreateStickerLegoUrl(
                imageUrl, outputPath,
                blockSize=blockSize,
                maxSize=MaxStickerSize,
                radiusPercent=radiusPercent,
                fps=fps, scale=scale, seconds=seconds, q=q,
            )
        else:
            CreateStickerUrl(
                imageUrl, outputPath,
                maxSize=MaxStickerSize,
                radiusPercent=radiusPercent,
                spin=spin,
                fps=fps, scale=scale, seconds=seconds, q=q,
                spinFps=spinFps, spinSeconds=spinSeconds,
                sqr=sqr, scaleFactor=scaleFactor,
            )

        uploadId = self._state.user_id
        r   = self._uploadAttachment(outputPath, uploadId, ThreadType.USER)
        url = r["fileUrl"] + f"?kefl={self.userName(self.uid).replace(' ', '-')}.webp"
        w, h = GetMediaWh(outputPath)
        self.sendCustomSticker(
            staticImgUrl=url, animationImgUrl=url,
            threadId=threadId, threadType=type,
            width=w, height=h, ttl=3600000, ai=True,
        )

    except Exception as e:
        logger.errorw(f"sticker error: {e}")
        self.replyMessageStyle(
            f"Tạo sticker thất bại: {e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
    finally:
        try: os.remove(outputPath)
        except Exception: pass


dependencies = {
    "name":        "sticker",
    "alias":       ["stk"],
    "permission":  0,
    "cooldown":    3,
    "description": "Create Sticker | pixel Lego 3D",
    "main":        StickerCommand,
}