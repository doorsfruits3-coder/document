from app.core.index import *
from src.services.pillow.drawInfoUser import draw_user_info
import os, time

CACHE_DIR = "data/assets/cache/image"


def _get_profile(self, uid: str) -> dict | None:
    """Gọi fetchUserInfo và trả về dict profile của uid."""
    try:
        info    = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        return profiles.get(str(uid)) or {}
    except Exception:
        return None


def infoCommand(self, message, data, userId, threadId, type):
    # ── Kiểm tra mode: "info text" hay "info" thường ─────────────────────────
    msg_text  = (getattr(message, "text", None) or str(message) or "").strip().lower()
    text_mode = msg_text.endswith("text")

    # ── Xác định target uid ───────────────────────────────────────────────────
    mentions = getattr(data, "mentions", None) or []
    target   = None

    for m in mentions:
        uid = str(m.get("uid", ""))
        if uid and uid != str(self.uid):
            target = uid
            break

    if not target:
        target = userId

    profile = _get_profile(self, target)

    if not profile:
        self.sendReaction(data, "", threadId, type, -1)
        return self.replyMessageStyle(
            "Không lấy được thông tin người dùng.",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )

    name = profile.get("displayName") or profile.get("zaloName") or "User"

    if text_mode:
        # ── MODE TEXT: gửi text + avt + bìa ──────────────────────────────────
        uid_str    = str(profile.get("userId", target))
        username   = str(profile.get("username", "N/A"))
        gender_map = {0: "Nam", 1: "Nữ", 2: "Khác"}
        gender     = gender_map.get(profile.get("gender"), "N/A")
        sdob       = str(profile.get("sdob") or "N/A")
        phone      = str(profile.get("phoneNumber") or "Không Công Khai")
        status_txt = str(profile.get("status") or "")
        acc_status = "Bình Thường" if profile.get("accountStatus", 0) == 0 else "Bị Khoá"
        user_mode  = "Mặc Định" if profile.get("user_mode", 0) == 0 else "Doanh Nghiệp"
        biz        = profile.get("bizPkg") or {}
        biz_lbl    = (biz.get("label") or {}).get("VI", "") or "Kinh Doanh"
        created_ts = profile.get("createdTs", 0)
        ct_str     = (time.strftime("%H:%M:%S %d/%m/%Y", time.localtime(created_ts))
                      if created_ts else "N/A")
        last_ts    = profile.get("lastActionTime", 0)
        if last_ts:
            diff = int(time.time()) - last_ts // 1000
            if   diff <    120: act = "Vừa Mới Truy Cập"
            elif diff <   3600: act = f"{diff // 60} phút trước"
            elif diff <  86400: act = f"{diff // 3600} giờ trước"
            else:               act = f"{diff // 86400} ngày trước"
        else:
            act = "Không rõ"

        info_lines = [
            f"👤 Tên:          {name}",
            f"🆔 ID:            {uid_str}",
            f"🔖 Username:  {username}",
            f"⚧️ Giới tính:   {gender}",
            f"🎂 Sinh nhật:  {sdob}",
            f"📱 SĐT:          {phone}",
            f"📦 Loại TK:    {biz_lbl} / {user_mode}",
            f"🔒 Trạng thái: {acc_status}",
            f"🕐 Hoạt động: {act}",
            f"📅 Ngày tạo:  {ct_str}",
        ]
        if status_txt:
            info_lines.append(f"💬 Status:       {status_txt}")

        self.replyMessageStyle(
            "\n".join(info_lines), data, threadId, type,
            color="gr", title="SUCCESS", userId=userId,
        )

        # Gửi avatar & ảnh bìa cùng lúc bằng sendMultiRemoteImage (chất lượng cao nhất)
        def _hq(url: str) -> str:
            """Nâng URL lên chất lượng cao nhất: xoá param resize, nâng width lên 2048."""
            if not url:
                return url
            import re
            url = re.sub(r'[?&]w=\d+',    '', url)
            url = re.sub(r'[?&]h=\d+',    '', url)
            url = re.sub(r'[?&]s=\d+',    '', url)
            url = re.sub(r'[?&]size=\d+', '', url)
            url = re.sub(r'/w\d+/',        '/w2048/', url)
            url = url.rstrip('?&')
            return url

        avatar_url = _hq(profile.get("avatar", "") or "")
        cover_url  = _hq(profile.get("cover",  "") or "")

        url_list = [u for u in (avatar_url, cover_url) if u]
        if url_list:
            try:
                self.sendMultiRemoteImage(
                    url_list, threadId, type,
                    width=2560, height=2560,
                )
            except Exception as e:
                logger.errorw(f"info sendMultiRemoteImage error: {e}")

    else:
        # ── MODE CARD: vẽ card ảnh như ban đầu ───────────────────────────────
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            out_path = os.path.join(
                CACHE_DIR,
                f"info_{self.uid}_{threadId}_{target}_{int(time.time())}.jpg",
            )
            w, h = draw_user_info(dict(profile), out_path)

            mention = Mention(userId, offset=0, length=len(self.userName(userId)))
            caption = Message(
                text=f"{self.userName(userId)}\nThông tin: {name}",
                mention=mention,
            )

            self.sendLocalImage(out_path, threadId, type, width=w, height=h, message=caption)

            try:
                os.remove(out_path)
            except Exception:
                pass

        except Exception as e:
            self.sendReaction(data, "", threadId, type, -1)
            logger.errorw(f"info draw error: {e}")
            return self.replyMessageStyle(
                f"Lỗi vẽ card: {e}", data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

    self.sendReaction(data, "", threadId, type, -1)
    self.sendReaction(data, "👌", threadId, type, 100000000)


dependencies = {
    "name":        "info",
    "permission":  0,
    "cooldown":    5,
    "description": "Xem thông tin tài khoản Zalo",
    "main":        infoCommand,
}
