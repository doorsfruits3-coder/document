from app.core.index import *
import requests
from urllib.parse import quote as url_quote

SUPPORTED_LANGS: dict[str, str] = {
    "af": "Tiếng Afrikaans",
    "sq": "Tiếng Albania",
    "am": "Tiếng Amharic",
    "ar": "Tiếng Ả Rập",
    "hy": "Tiếng Armenia",
    "az": "Tiếng Azerbaijan",
    "eu": "Tiếng Basque",
    "be": "Tiếng Belarus",
    "bn": "Tiếng Bengal",
    "bs": "Tiếng Bosnia",
    "bg": "Tiếng Bulgaria",
    "ca": "Tiếng Catalan",
    "ceb": "Tiếng Cebuano",
    "ny": "Tiếng Chichewa",
    "zh": "Tiếng Trung (Giản Thể)",
    "zh-TW": "Tiếng Trung (Phồn Thể)",
    "co": "Tiếng Corsica",
    "hr": "Tiếng Croatia",
    "cs": "Tiếng Séc",
    "da": "Tiếng Đan Mạch",
    "nl": "Tiếng Hà Lan",
    "en": "Tiếng Anh",
    "eo": "Tiếng Esperanto",
    "et": "Tiếng Estonia",
    "tl": "Tiếng Filipino",
    "fi": "Tiếng Phần Lan",
    "fr": "Tiếng Pháp",
    "fy": "Tiếng Frisian",
    "gl": "Tiếng Galicia",
    "ka": "Tiếng Gruzia",
    "de": "Tiếng Đức",
    "el": "Tiếng Hy Lạp",
    "gu": "Tiếng Gujarat",
    "ht": "Tiếng Haiti Creole",
    "ha": "Tiếng Hausa",
    "haw": "Tiếng Hawaii",
    "iw": "Tiếng Do Thái",
    "hi": "Tiếng Hindi",
    "hmn": "Tiếng Hmong",
    "hu": "Tiếng Hungary",
    "is": "Tiếng Iceland",
    "ig": "Tiếng Igbo",
    "id": "Tiếng Indonesia",
    "ga": "Tiếng Ireland",
    "it": "Tiếng Ý",
    "ja": "Tiếng Nhật",
    "jw": "Tiếng Java",
    "kn": "Tiếng Kannada",
    "kk": "Tiếng Kazakhstan",
    "km": "Tiếng Khmer",
    "ko": "Tiếng Hàn",
    "ku": "Tiếng Kurdish",
    "ky": "Tiếng Kyrgyz",
    "lo": "Tiếng Lào",
    "la": "Tiếng Latin",
    "lv": "Tiếng Latvia",
    "lt": "Tiếng Lithuania",
    "lb": "Tiếng Luxembourg",
    "mk": "Tiếng Macedonia",
    "mg": "Tiếng Malagasy",
    "ms": "Tiếng Malay",
    "ml": "Tiếng Malayalam",
    "mt": "Tiếng Malta",
    "mi": "Tiếng Maori",
    "mr": "Tiếng Marathi",
    "mn": "Tiếng Mông Cổ",
    "my": "Tiếng Myanmar",
    "ne": "Tiếng Nepal",
    "no": "Tiếng Na Uy",
    "or": "Tiếng Odia",
    "ps": "Tiếng Pashto",
    "fa": "Tiếng Ba Tư",
    "pl": "Tiếng Ba Lan",
    "pt": "Tiếng Bồ Đào Nha",
    "pa": "Tiếng Punjab",
    "ro": "Tiếng Romania",
    "ru": "Tiếng Nga",
    "sm": "Tiếng Samoa",
    "gd": "Tiếng Scotland Gaelic",
    "sr": "Tiếng Serbia",
    "st": "Tiếng Sesotho",
    "sn": "Tiếng Shona",
    "sd": "Tiếng Sindhi",
    "si": "Tiếng Sinhala",
    "sk": "Tiếng Slovak",
    "sl": "Tiếng Slovenia",
    "so": "Tiếng Somali",
    "es": "Tiếng Tây Ban Nha",
    "su": "Tiếng Sunda",
    "sw": "Tiếng Swahili",
    "sv": "Tiếng Thụy Điển",
    "tg": "Tiếng Tajik",
    "ta": "Tiếng Tamil",
    "tt": "Tiếng Tatar",
    "te": "Tiếng Telugu",
    "th": "Tiếng Thái",
    "tr": "Tiếng Thổ Nhĩ Kỳ",
    "tk": "Tiếng Turkmen",
    "uk": "Tiếng Ukraine",
    "ur": "Tiếng Urdu",
    "ug": "Tiếng Uyghur",
    "uz": "Tiếng Uzbek",
    "vi": "Tiếng Việt",
    "cy": "Tiếng Wales",
    "xh": "Tiếng Xhosa",
    "yi": "Tiếng Yiddish",
    "yo": "Tiếng Yoruba",
    "zu": "Tiếng Zulu",
}

_TRANSLATE_URL = "https://translate.googleapis.com/translate_a/single"
_SESSION = requests.Session()
_SESSION.headers.update({
    "User-Agent": "Mozilla/5.0",
})

class TranslateCommand:
    _LANG_HELP_CACHE: str | None = None

    def __init__(self, ctx):
        self._ctx    = ctx
        self.prefix  = getattr(ctx, "prefix", "/")
        self.cmd     = getattr(ctx, "commandName", "dich")

    def _reply(self, text: str, data, threadId, type, *, color: str, title: str, userId):
        return self._ctx.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title, userId=userId,
        )

    @staticmethod
    def _translate(text: str, dest: str = "vi", src: str = "auto") -> str:
        params = {
            "client": "gtx",
            "sl": src,
            "tl": dest,
            "dt": "t",
            "q": text,
        }
        try:
            resp = _SESSION.get(_TRANSLATE_URL, params=params, timeout=8)
            resp.raise_for_status()
            data = resp.json()
            return "".join(
                part[0] for part in data[0] if part and part[0]
            ).strip()
        except Exception as e:
            raise RuntimeError(f"Lỗi khi gọi Google Translate: {e}")

    @classmethod
    def _lang_help_text(cls) -> str:
        if cls._LANG_HELP_CACHE is None:
            lines = [f"{'Mã':<8} {'Ngôn Ngữ'}", "─" * 28]
            lines += [f"{code:<8} {name}" for code, name in sorted(SUPPORTED_LANGS.items())]
            cls._LANG_HELP_CACHE = "\n".join(lines)
        return cls._LANG_HELP_CACHE

    def _parse_lang_pair(self, token: str) -> tuple[str, str] | None:
        if "-" not in token or token.startswith("-"):
            return None
        s, _, d = token.lower().partition("-")
        if d in SUPPORTED_LANGS:
            return (s if s in SUPPORTED_LANGS else "auto", d)
        return None

    def _extract_args(self, text_raw: str) -> str:
        cmd_token = f"{self.prefix}{self.cmd}"
        if text_raw.lower().startswith(cmd_token.lower()):
            return text_raw[len(cmd_token):].strip()
        parts = text_raw.split(maxsplit=1)
        return parts[1].strip() if len(parts) > 1 else ""

    def run(self, message, data, userId, threadId, type):
        text_raw = (getattr(message, "text", "") or "").strip()
        quote    = getattr(data, "quote", None)
        args_raw = self._extract_args(text_raw)

        if args_raw.lower().startswith("help=lang"):
            return self._reply(
                self._lang_help_text(),
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

        dest_lang, src_lang, text_to_translate = "vi", "auto", ""

        tokens = args_raw.split(maxsplit=1)
        if tokens:
            pair = self._parse_lang_pair(tokens[0])
            if pair:
                src_lang, dest_lang = pair
                text_to_translate = tokens[1].strip() if len(tokens) > 1 else ""
            else:
                text_to_translate = args_raw

        if not text_to_translate:
            if quote:
                quote_msg = (getattr(quote, "msg", None) or "").strip()
                if not quote_msg:
                    return self._reply(
                        "Vui lòng reply vào một tin nhắn văn bản để dịch!",
                        data, threadId, type,
                        color="yl", title="WARNING", userId=userId,
                    )
                text_to_translate = quote_msg
            else:
                guide = (
                    f"Nhập Nội Dung Cần Dịch\n\n"
                    f"Ví Dụ:\n"
                    f"  📍 {self.prefix}{self.cmd} Hello Kefl.\n"
                    f"  📍 {self.prefix}{self.cmd} vi-ja Dịch Sang Tiếng Nhật.\n"
                    f"  📍 {self.prefix}{self.cmd} help=lang Xem các ngôn ngữ hỗ trợ dịch."
                )
                return self._reply(
                    guide, data, threadId, type,
                    color="or", title="CAUTION", userId=userId,
                )

        if dest_lang not in SUPPORTED_LANGS:
            return self._reply(
                f"Mã ngôn ngữ '{dest_lang}' không hợp lệ!\n"
                f"Dùng {self.prefix}{self.cmd} help=lang để xem danh sách ngôn ngữ.",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )

        try:
            translated = self._translate(text_to_translate, dest=dest_lang, src=src_lang)
        except Exception as e:
            return self._reply(
                str(e), data, threadId, type,
                color="r", title="ERROR", userId=userId,
            )

        return self._reply(
            translated, data, threadId, type,
            color="gr", title="COMPLETE", userId=userId,
        )

def translateCommand(self, message, data, userId, threadId, type):
    return TranslateCommand(self).run(message, data, userId, threadId, type)

dependencies = {
    "name": "translate",
    "permission": 0,
    "cooldown": 3,
    "description": "Dịch văn bản sang ngôn ngữ khác",
    "main": translateCommand,
}