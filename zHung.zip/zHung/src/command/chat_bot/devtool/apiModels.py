import json
import re
import time
import requests
from typing import List, Optional

_SECRET_PATTERNS = [
    re.compile(r"(key|token|secret|authorization|api[-_]?key)=[^&\s\"']+", re.IGNORECASE),
    re.compile(r"AIza[0-9A-Za-z_\-]{30,}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{20,}"),
    re.compile(r"Bearer\s+[A-Za-z0-9._\-]+", re.IGNORECASE),
]

def redactSecrets(text: str) -> str:
    if not text:
        return text
    out = str(text)
    for pat in _SECRET_PATTERNS:
        out = pat.sub(lambda m: m.group(0).split("=")[0] + "=***" if "=" in m.group(0) else "***", out)
    return out

class ApiError(Exception):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(redactSecrets(message))
        self.status_code = status_code

class ApiModels:
    KEY_PATH = "data/config/ai-database.json"

    def __init__(self):
        self._idx = 0
        self.keys = self._load()

    def _load(self) -> List[str]:
        try:
            with open(self.KEY_PATH, "r", encoding="utf-8") as f:
                return json.load(f).get("GEMINI") or []
        except Exception:
            return []

    def _rotate(self) -> Optional[str]:
        if not self.keys:
            return None
        key = self.keys[self._idx]
        self._idx = (self._idx + 1) % len(self.keys)
        return key

    def geminiCall(self, prompt: str, model: str = "gemini-2.5-flash") -> str:
        last = None
        attempts = max(1, len(self.keys)) * 3

        for attempt in range(attempts):
            key = self._rotate()
            if not key:
                break
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:generateContent"
            )
            body = {"contents": [{"parts": [{"text": prompt}]}]}
            try:
                r = requests.post(url, params={"key": key}, json=body, timeout=30)

                if r.status_code in (503, 429):
                    wait = 3 if r.status_code == 503 else 5
                    time.sleep(wait)
                    last = ApiError(f"AI tạm quá tải (mã {r.status_code}), đang thử lại...", r.status_code)
                    continue

                r.raise_for_status()
                return r.json()["candidates"][0]["content"]["parts"][0]["text"]

            except requests.HTTPError as e:
                code = e.response.status_code if e.response is not None else None
                last = ApiError(f"Lỗi gọi AI (mã {code})", code)
            except Exception as e:
                last = ApiError(f"Lỗi gọi AI: {redactSecrets(str(e))}")

        raise last or ApiError("Không có API key nào được cấu hình")

class GeminiContent:
    def __init__(self, api: ApiModels):
        self.api = api
        self.prompt = ""

    def getText(self) -> str:
        return self.api.geminiCall(self.prompt)