from app.core.index import *
import os
import time

IGNORE_DIRS = {"__pycache__", ".git", ".idea"}
IGNORE_EXT  = {".pyc", ".bak", ".log", ".tmp"}

def is_hidden_file(name):
    return "." not in name

def should_show(name, full, mode):
    if os.path.isdir(full):
        if name in IGNORE_DIRS:
            return False
        return True

    if mode == "hide":
        if is_hidden_file(name):
            return False
        if any(name.endswith(ext) for ext in IGNORE_EXT):
            return False

    if mode == "py":
        return name.endswith(".py")

    if mode == "folder":
        return False

    if mode.startswith("ext:"):
        ext = mode.split(":", 1)[1]
        return name.endswith(ext)

    return True

def build_tree(path, prefix="", mode=""):
    try:
        items = sorted(os.listdir(path))
    except:
        return []

    lines    = []
    filtered = []

    for item in items:
        full = os.path.join(path, item)
        if should_show(item, full, mode):
            filtered.append(item)

    for i, name in enumerate(filtered):
        full    = os.path.join(path, name)
        is_last = (i == len(filtered) - 1)

        connector = "└── " if is_last else "├── "
        lines.append(prefix + connector + name)

        if os.path.isdir(full):
            extension = "    " if is_last else "│   "
            lines.extend(build_tree(full, prefix + extension, mode))

    return lines

def chunk(lines, limit=2000):
    buff = ""
    out  = []

    for line in lines:
        if len(buff) + len(line) + 1 > limit:
            out.append(buff)
            buff = ""
        buff += line + "\n"

    if buff:
        out.append(buff)

    return out

def TreeCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    parts = text.split()
    mode  = ""

    if len(parts) > 1:
        flag = parts[1].lower()
        if flag == "-hide":
            mode = "hide"
        elif flag == "-py":
            mode = "py"
        elif flag == "-folder":
            mode = "folder"
        elif flag == "-ext" and len(parts) > 2:
            mode = "ext:" + parts[2]

    root      = os.getcwd()
    root_name = os.path.basename(root)

    tree_lines = [root_name] + build_tree(root, "", mode)
    chunks     = chunk(tree_lines)

    for i, c in enumerate(chunks):
        # Chỉ mention ở tin nhắn đầu tiên
        self.replyMessageStyle(
            c,
            data,
            threadId,
            type,
            color="gr",
            title="TREE",
            userId=userId if i == 0 else None,
        )
        if i < len(chunks) - 1:
            time.sleep(0.75)


dependencies = {
    "name":        "tree",
    "permission":  3,
    "description": "Advanced tree",
    "cooldown":    5,
    "main":        TreeCommand,
}
