from app.core.index import *
import ast, os, traceback

MAX_LEN  = 1500
CACHE_DIR = "data/assets/cache/image"

try:
    from src.services.pillow.codeDraw import draw_code_image
    _DRAW_OK = True
except Exception:
    _DRAW_OK = False


def split_send(send, msg):
    msg = str(msg)
    if len(msg) <= MAX_LEN:
        send(msg)
        return
    for i in range(0, len(msg), MAX_LEN):
        send(msg[i:i + MAX_LEN], i == 0)


def _find_file(filename: str, hint_path: str | None) -> str | None:
    """Tìm file theo tên + hint_path trong toàn bộ project.

    hint_path:
        None / "Main" / ""  → tìm ở root project (., app/, src/ level 1)
        "src/command/games" → tìm đúng trong thư mục đó
    """
    root = os.getcwd()

    # Nếu hint_path chỉ rõ thư mục → tìm trong đó trước
    if hint_path and hint_path.lower() not in ("main", ""):
        target = os.path.join(root, hint_path.strip("/"), filename)
        if os.path.isfile(target):
            return target
        # Fallback: walk trong hint_path
        base = os.path.join(root, hint_path.strip("/"))
        if os.path.isdir(base):
            for dirpath, _, files in os.walk(base):
                if filename in files:
                    return os.path.join(dirpath, filename)
        return None

    # Không có hint → walk toàn bộ project, bỏ qua __pycache__, .git, node_modules
    _skip = {"__pycache__", ".git", "node_modules", ".venv", "venv"}
    matches = []
    for dirpath, dirnames, files in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in _skip]
        if filename in files:
            matches.append(os.path.join(dirpath, filename))

    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]

    # Nhiều kết quả → ưu tiên root-level nhất (ít thư mục nhất)
    matches.sort(key=lambda p: len(p.split(os.sep)))
    return matches[0]


def _parse_cds_arg(text: str):
    """Parse /sys -cds='name.py' hoặc /sys -cds='name.py'_'path'
    Trả về (filename, hint_path | None)
    """
    import re
    m = re.search(
        r"-cds=['\"]([^'\"]+)['\"](?:_['\"]([^'\"]*)['\"])?",
        text, re.IGNORECASE
    )
    if not m:
        # fallback không có quote
        m = re.search(
            r"-cds=(\S+?)(?:_(\S+))?(?:\s|$)",
            text, re.IGNORECASE
        )
    if not m:
        return None, None
    fname = m.group(1).strip()
    hint  = m.group(2).strip() if m.group(2) else None
    return fname, hint


def _cmd_cds(self, text, data, userId, threadId, type):
    fname, hint = _parse_cds_arg(text)

    if not fname:
        return self.replyMessageStyle(
            "Cú pháp: /sys -cds='tên_file.py'\n"
            "Hoặc:   /sys -cds='tên_file.py'_'src/command/games'",
            data, threadId, type,
            color="yl", title="SYS", userId=userId,
        )

    # Chỉ developer (permission 4) mới được xem code thật
    user_level = self.permissionLevel(userId, threadId)
    if user_level < 4:
        fake_code = 'print("Hello World")'
        if not _DRAW_OK:
            return self.replyMessageStyle(
                fake_code, data, threadId, type,
                color="or", title=fname, userId=userId,
            )
        try:
            os.makedirs(CACHE_DIR, exist_ok=True)
            out_path = os.path.join(CACHE_DIR, f"code_{self.uid}_{userId}.jpg")
            w, h = draw_code_image(fake_code, fname, out_path)
            img_url = None
            try:
                res = self._uploadImage(out_path, threadId, type)
                if isinstance(res, dict):
                    img_url = res.get("normalUrl") or res.get("hdUrl")
                elif isinstance(res, str) and res.startswith("http"):
                    img_url = res
            finally:
                try:
                    os.remove(out_path)
                except Exception:
                    pass
            if img_url:
                user_name = self.userName(userId) or ""
                cap       = f"@{user_name}\n📄 {fname}"
                mention   = Mention(userId, offset=0, length=len(f"@{user_name}"))
                self.sendRemoteImage(
                    img_url, threadId, type,
                    width=w, height=h,
                    message=Message(text=cap, mention=mention),
                )
            else:
                self.replyMessageStyle(
                    fake_code, data, threadId, type,
                    color="or", title=fname, userId=userId,
                )
        except Exception as e:
            self.replyMessageStyle(
                fake_code, data, threadId, type,
                color="or", title=fname, userId=userId,
            )
        return

    fpath = _find_file(fname, hint)

    if not fpath:
        hint_hint = f" trong '{hint}'" if hint else ""
        return self.replyMessageStyle(
            f"Không tìm thấy file '{fname}'{hint_hint}.",
            data, threadId, type,
            color="r", title="SYS", userId=userId,
        )

    try:
        code = open(fpath, encoding="utf-8", errors="replace").read()
    except Exception as e:
        return self.replyMessageStyle(
            f"Không đọc được file: {e}",
            data, threadId, type,
            color="r", title="SYS", userId=userId,
        )

    if not _DRAW_OK:
        # Fallback text nếu không có pillow codeDraw
        preview = code[:3000] + ("\n…(truncated)" if len(code) > 3000 else "")
        return self.replyMessageStyle(
            preview, data, threadId, type,
            color="or", title=fname, userId=userId,
        )

    rel_path = os.path.relpath(fpath, os.getcwd())
    self.sendReaction(data, "💅", threadId, type, 100000000)

    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        out_path = os.path.join(CACHE_DIR, f"code_{self.uid}_{userId}.jpg")
        w, h = draw_code_image(code, fname, out_path)

        img_url = None
        try:
            res = self._uploadImage(out_path, threadId, type)
            if isinstance(res, dict):
                img_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                img_url = res
        finally:
            try:
                os.remove(out_path)
            except Exception:
                pass

        self.sendReaction(data, "", threadId, type, -1)
        self.sendReaction(data, "👀", threadId, type, 100000000)

        if img_url:
            user_name  = self.userName(userId) or ""
            cap        = f"@{user_name}\n📄 {rel_path}"
            mention    = Mention(userId, offset=0, length=len(f"@{user_name}"))
            self.sendRemoteImage(
                img_url, threadId, type,
                width=w, height=h,
                message=Message(text=cap, mention=mention),
            )
        else:
            self.replyMessageStyle(
                f"Render OK nhưng upload lỗi.\n📄 {rel_path}",
                data, threadId, type,
                color="yl", title="SYS", userId=userId,
            )
    except Exception as e:
        self.sendReaction(data, "", threadId, type, -1)
        self.replyMessageStyle(
            f"Lỗi render: {e}", data, threadId, type,
            color="r", title="SYS", userId=userId,
        )


def SysCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    quote = getattr(data, "quote", None)
    parts = text.split(maxsplit=1)
    body  = parts[1].strip() if len(parts) > 1 else ""

    # ── /sys -cds='file.py' ───────────────────────────────────────────────────
    if "-cds=" in text.lower():
        _cmd_cds(self, text, data, userId, threadId, type)
        return

    # ── run code ─────────────────────────────────────────────────────────────
    if not body:
        if not quote or not getattr(quote, "msg", None):
            return self.replyMessageStyle(
                "What do u wanna run?",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        code = quote.msg.strip()
    else:
        code = body

    _sent = [False]

    def send(msg, is_first=False):
        uid = userId if (is_first or not _sent[0]) else None
        _sent[0] = True
        return split_send(
            lambda x, f=is_first: self.replyMessageStyle(
                str(x), data, threadId, type,
                color="gr", title="OUTPUT", userId=uid,
            ),
            msg,
        )

    try:
        tree = ast.parse(code)
        ctx  = {
            "self":       self,
            "this":       self,
            "client":     self,
            "Message":    Message,
            "threadId":   threadId,
            "ThreadType": ThreadType,
            "type":       type,
            "userId":     userId,
            "data":       data,
            "send":       send,
            "print":      lambda *a: send(" ".join(map(str, a))),
        }
        result = None
        if tree.body and isinstance(tree.body[-1], ast.Expr):
            expr      = ast.Expression(tree.body[-1].value)
            tree.body = tree.body[:-1]
            exec(compile(tree, "<sys>", "exec"), {}, ctx)
            result = eval(compile(expr, "<sys>", "eval"), {}, ctx)
        else:
            exec(compile(tree, "<sys>", "exec"), {}, ctx)
        if result is not None:
            send(result)

    except Exception:
        self.replyMessageStyle(
            "ERROR:\n" + traceback.format_exc(limit=5),
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


dependencies = {
    "name":        "sys",
    "permission":  4,
    "description": "System command",
    "cooldown":    5,
    "main":        SysCommand,
}
