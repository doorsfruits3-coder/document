from app.core.index import *
import random

CAPTIONS = [
    # 0-4%
    "Thẳng hơn cả thước kẻ, chưa bao giờ nhìn con gái quá 3 giây 📏",
    # 5-9%
    "Gần như thẳng 100%, chỉ hơi để ý tóc bạn gái hôm nay đẹp thôi 👧",
    # 10-14%
    "Vẫn thẳng nhưng hay rủ bạn gái đi spa cùng hơi nhiều 💆‍♀️",
    # 15-19%
    "Thẳng thớm, nhưng playlist toàn nhạc của Mamamoo với DEAN 🎵",
    # 20-24%
    "Cơ bản là thẳng, nhưng hay khen 'con đó xinh ghê' hơi lâu một chút 😶",
    # 25-29%
    "Bắt đầu có dấu hiệu... nhưng tự nhủ là 'tụi mình chỉ thân thôi' 🤔",
    # 30-34%
    "Xem phim GL chỉ vì 'diễn xuất hay lắm, không có gì đâu' 🎬",
    # 35-39%
    "Hay giữ tay bạn gái khi đi bộ và không thấy có gì lạ cả 🤝",
    # 40-44%
    "Định nghĩa 'bạn thân' của bạn đang bị lung lay nghiêm trọng 🌀",
    # 45-49%
    "Đang ở vùng xám, trái tim đang gửi tín hiệu nhưng não chưa chịu nhận 📡",
    # 50-54%
    "Chính xác ở giữa, như một bông hoa chưa biết nên nở về hướng nào 🌸",
    # 55-59%
    "Nghiêng về phía bên kia nhiều hơn một chút rồi đó nhen 🌈",
    # 60-64%
    "Hay tìm lý do 'lý thuyết' để giải thích tại sao tim đập nhanh khi gặp bạn gái 💓",
    # 65-69%
    "Bạn bè đã bắt đầu hỏi 'ủa mày với con đó là sao?' mà mày còn chưa trả lời 😂",
    # 70-74%
    "Đang ở giai đoạn 'tôi chỉ đang khám phá cảm xúc của mình' ✨",
    # 75-79%
    "Màu tím lavender và cờ tam sắc đã bắt đầu thấm vào tâm hồn rồi 💜",
    # 80-84%
    "Tủ quần áo toàn oversized, playlist toàn nhạc indie girl, sắp rồi đó 🧥",
    # 85-89%
    "Gần rồi! Chỉ cần thêm một lần nhìn vào mắt cô ấy nữa là xong 👀",
    # 90-94%
    "Thôi thì mình cứ gọi là 'yêu theo kiểu bạn bè đặc biệt' cho lịch sự 🦋",
    # 95-99%
    "Gần chạm đỉnh! Chỉ còn thiếu cái cờ sapphic trên tay thôi 🏳️‍🌈",
    # 100%
    "FULL LES! Xin chúc mừng, bạn đã mở khóa thành tựu SAPPHIC LEGEND 💜🎉",
]

def _get_caption(percent: int) -> str:
    if percent == 100:
        return CAPTIONS[20]
    return CAPTIONS[min(percent // 5, 19)]

def _get_name(self, uid: str, fallback: str) -> str:
    try:
        info     = self.fetchUserInfo(uid)
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        return profile.get("displayName") or profile.get("zaloName") or fallback
    except Exception:
        return fallback

def lesCommand(self, message, data, userId, threadId, type):
    mentions = getattr(data, "mentions", None) or []

    target_uid = None
    for m in mentions:
        uid = str(m.get("uid", ""))
        if uid and uid != str(self.uid):
            target_uid = uid
            break

    if target_uid:
        name = _get_name(self, target_uid, "Người dùng")
    else:
        name = _get_name(self, userId, self.userName(userId))

    percent = random.randint(0, 100)
    caption = _get_caption(percent)

    result_text = (
        f"Phần trăm khả năng les của {name} là {percent}%\n"
        f"📍{caption}"
    )

    self.replyMessageStyle(
        result_text,
        data, threadId, type,
        color="gr", title="SUCCESS",
        userId=userId,
    )

    self.sendReaction(data, "", threadId, type, -1)
    self.sendReaction(data, "💜", threadId, type, 100000000)

dependencies = {
    "name": "les",
    "permission": 0,
    "cooldown": 5,
    "description": "Đo chỉ số les của bản thân hoặc ai đó",
    "main": lesCommand,
}