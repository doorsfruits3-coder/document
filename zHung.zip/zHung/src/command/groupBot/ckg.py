from app.core.index import *
from src.services.utils.jsonio import read_settings, write_settings
import threading
import time
import re

_KEY = "ckg"


def _read_cfg(uid: str) -> dict:
    s = read_settings(uid) or {}
    cfg = s.setdefault(_KEY, {
        "main_thread":     None,
        "sent_threads":    [],
        "pending_confirm": {},
        "confirmed":       {},
        "send_count":      {},
        "paid_count":      {},
    })
    cfg.setdefault("send_count", {})
    cfg.setdefault("paid_count", {})
    cfg.pop("resend_ts", None)
    return s


def _save_cfg(uid: str, s: dict):
    write_settings(uid, s)


def _get_cfg(uid: str) -> dict:
    return _read_cfg(uid).get(_KEY, {})


def _update_cfg(uid: str, **kwargs):
    s = _read_cfg(uid)
    s[_KEY].update(kwargs)
    _save_cfg(uid, s)


def _get_group_join_link(self, threadId: str) -> str | None:
    try:
        result = self.getGroupLink(str(threadId))
        print(f"[CKG DEBUG] getGroupLink({threadId}) raw: {result!r}")

        if hasattr(result, "__dict__"):
            result = result.__dict__

        if result is None:
            print("[CKG DEBUG] getGroupLink trả về None — bot chưa phải admin nhóm?")
            return None

        if isinstance(result, dict):
            err = result.get("error") or result.get("errorCode") or result.get("err")
            if err and str(err) not in ("0", "", "None", "null"):
                print(f"[CKG DEBUG] getGroupLink error: {err} — {result.get('message','')}")
                return None

            link = (
                result.get("link") or
                result.get("joinLink") or
                result.get("url") or
                result.get("linkJoin") or
                result.get("join_link") or
                result.get("inviteLink") or
                (result.get("data", {}).get("link") if isinstance(result.get("data"), dict) else None) or
                ""
            )
            if link:
                return str(link)
            print(f"[CKG DEBUG] Không tìm thấy field link trong: {list(result.keys())}")
            return None

        if isinstance(result, str) and result.startswith("http"):
            return result

        print(f"[CKG DEBUG] getGroupLink trả về kiểu lạ: {type(result)}")
    except Exception as e:
        print(f"[CKG DEBUG] getGroupLink exception: {e}")
    return None


def _get_group_info(self, threadId: str) -> tuple:
    """Trả về (name, avatar_url) của nhóm."""
    try:
        info  = self.fetchGroupInfo(str(threadId))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g     = gdata.get(str(threadId)) or {}
        name  = g.get("name") or str(threadId)
        avatar = (
            g.get("avt")       or
            g.get("avatar")    or
            g.get("fullAvt")   or
            g.get("avatarUrl") or
            ""
        )
        if avatar:
            # Nếu URL có path segment /wXXX/ → nâng lên 2048
            if re.search(r'/w\d+/', avatar):
                avatar = re.sub(r'/w\d+/', '/w2048/', avatar)
            else:
                # Xóa các param size cũ rồi thêm lại w=2048&h=2048
                avatar = re.sub(r'([?&])(w|h|s|size)=\d+', '', avatar)
                avatar = avatar.rstrip('?&')
                sep = '&' if '?' in avatar else '?'
                avatar = f"{avatar}{sep}w=2048&h=2048"
        return name, avatar
    except Exception:
        return str(threadId), ""


def _get_group_name(self, threadId: str) -> str:
    name, _ = _get_group_info(self, threadId)
    return name


def _all_group_ids(self) -> list[str]:
    try:
        grid = getattr(self.fetchAllGroups(), "gridVerMap", None) or {}
        return [str(g) for g in (grid if isinstance(grid, dict) else dict(grid)).keys()]
    except Exception:
        return []


def _send_main_link_to(self, target_thread: str, main_link: str, main_name: str, thread_type,
                        main_avatar: str = ""):
    """Gửi link nhóm chính vào nhóm phụ, kèm thumbnail avatar nếu có."""
    try:
        caption = (
            f"🔁 Chéo tag trả nha.\n"
            f"👉 Tham gia: {main_name}\n"
            f"Tag = trả, phạm luật đừng kick tội iem=(."
        )
        self.sendLink(
            linkUrl=main_link,
            title=f"🏠 {main_name}",
            desc=caption,
            thumbnailUrl=main_avatar or None,
            threadId=target_thread,
            type=thread_type,
            message=Message(text=caption),
        )
    except Exception:
        pass


def _send_sub_link_to_main(self, main_tid: str, sub_link: str, sub_name: str, sub_avatar: str,
                            caption: str, title: str):
    """Gửi link nhóm phụ về nhóm chính, kèm thumbnail avatar nếu có."""
    try:
        self.sendLink(
            linkUrl=sub_link,
            title=title,
            desc=caption,
            thumbnailUrl=sub_avatar or None,
            threadId=main_tid,
            type=ThreadType.GROUP,
            message=Message(text=caption),
        )
    except Exception:
        pass


def _cmd_set_now(self, data, userId, threadId, type):
    link = _get_group_join_link(self, threadId)
    name = _get_group_name(self, threadId)

    _update_cfg(self.uid,
        main_thread=str(threadId),
        sent_threads=[],
        pending_confirm={},
        confirmed={},
        send_count={},
        paid_count={},
    )

    if link:
        self.replyMessageStyle(
            f"✅ Set nhóm chính: {name}\n🔗 {link}\n\nDùng {self.prefix}{self.rawCommand} init để gửi ngay.",
            data, threadId, type,
            color="gr", title="COMPLETE", userId=userId,
        )
    else:
        self.replyMessageStyle(
            f"✅ Set nhóm chính: {name}\n⚠️ Không lấy được link — bot chưa có quyền lấy link nhóm?",
            data, threadId, type,
            color="yl", title="CAUTION", userId=userId,
        )


def _broadcast(self, data, userId, threadId, type, delay: float = 0.0):
    cfg      = _get_cfg(self.uid)
    main_tid = cfg.get("main_thread")

    if not main_tid:
        self.replyMessageStyle(
            f"Chưa set nhóm chính, dùng {self.prefix}{self.rawCommand} set now trước",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )
        return

    main_link = _get_group_join_link(self, main_tid)
    if not main_link:
        self.replyMessageStyle(
            "Không lấy được link nhóm chính, kiểm tra quyền bot",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
        return

    main_name, main_avatar = _get_group_info(self, main_tid)
    all_groups = _all_group_ids(self)
    sent_set   = set(cfg.get("sent_threads", []))
    targets    = [g for g in all_groups if g != str(main_tid) and g not in sent_set]

    if not targets:
        self.replyMessageStyle(
            "Không còn nhóm nào chưa gửi",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        return

    action = "init" if delay == 0 else "start"
    self.replyMessageStyle(
        f"{'Gửi ngay' if action == 'init' else 'Rải'} link đến {len(targets)} nhóm...",
        data, threadId, type,
        color="gr", title="COMPLETE", userId=userId,
    )

    def _worker():
        s          = _read_cfg(self.uid)
        cfg_live   = s[_KEY]
        send_count = cfg_live.setdefault("send_count", {})
        new_sent   = list(sent_set)

        for i, gid in enumerate(targets):
            try:
                _send_main_link_to(self, gid, main_link, main_name, ThreadType.GROUP, main_avatar)
                send_count[gid] = send_count.get(gid, 0) + 1
                new_sent.append(gid)
            except Exception:
                pass
            if delay > 0 and i < len(targets) - 1:
                time.sleep(delay)

        cfg_live["send_count"]   = send_count
        cfg_live["sent_threads"] = new_sent
        _save_cfg(self.uid, s)

        try:
            self.replyMessageStyle(
                f"Đã gửi link đến {len(new_sent)} nhóm",
                data, threadId, type,
                color="gr", title="COMPLETE", userId=userId,
            )
        except Exception:
            pass

    threading.Thread(target=_worker, daemon=True).start()


def _cmd_preview(self, data, userId, threadId, type):
    cfg      = _get_cfg(self.uid)
    main_tid = cfg.get("main_thread")

    if not main_tid:
        self.replyMessageStyle(
            f"Chưa set nhóm chính, dùng {self.prefix}{self.rawCommand} set now trước",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId,
        )
        return

    if str(threadId) == str(main_tid):
        self.replyMessageStyle(
            "Đây là nhóm chính rồi, chạy preview từ nhóm phụ",
            data, threadId, type,
            color="yl", title="CAUTION", userId=userId,
        )
        return

    main_link = _get_group_join_link(self, main_tid)
    if not main_link:
        self.replyMessageStyle(
            "Không lấy được link nhóm chính",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
        return

    main_name, main_avatar = _get_group_info(self, main_tid)
    self.replyMessageStyle(
        "Đang gửi test...",
        data, threadId, type,
        color="or", title="CAUTION", userId=userId,
    )
    _send_main_link_to(self, str(threadId), main_link, main_name, type, main_avatar)


def handle_ckg_mention(self, data, userId, threadId, type):
    cfg      = _get_cfg(self.uid)
    main_tid = cfg.get("main_thread")

    if not main_tid:
        return

    tid_str  = str(threadId)
    uid_str  = str(self.uid)
    user_str = str(userId)

    # Bỏ qua nếu chính bot tự tag
    if user_str == uid_str:
        return

    # Bỏ qua nếu tag trong nhóm chính
    if tid_str == str(main_tid):
        return

    send_count      = cfg.get("send_count", {})
    paid_count      = cfg.get("paid_count", {})
    pending_confirm = cfg.get("pending_confirm", {})
    confirmed       = cfg.get("confirmed", {})
    user_name       = self.userName(userId) or str(userId)

    sent = send_count.get(tid_str, 0)
    paid = paid_count.get(tid_str, 0)

    # Bot chưa gửi link vào nhóm này lần nào → bỏ qua
    if sent == 0:
        return

    # ── Đang pending (tag lần 1, chờ xác nhận lần 2) ──
    if tid_str in pending_confirm:
        group_link = _get_group_join_link(self, tid_str)
        group_name, group_avatar = _get_group_info(self, tid_str)

        new_paid = paid + 1

        if group_link:
            caption = f"✅ Trả: {user_name}\n🔗 {group_name}"
            _send_sub_link_to_main(
                self, main_tid, group_link, group_name, group_avatar,
                caption=caption, title=f"↩️ {group_name}",
            )

        pending_confirm.pop(tid_str, None)
        paid_count[tid_str] = new_paid

        if new_paid >= sent:
            confirmed[tid_str] = True

        _update_cfg(self.uid,
            pending_confirm=pending_confirm,
            paid_count=paid_count,
            confirmed=confirmed,
        )

        self.sendReaction(data, "✅", threadId, type, 100000000)
        self.replyMessageStyle(
            "Đã trả, vui lòng vào nhóm mình xem nhé!",
            data, threadId, type,
            color="gr", title="COMPLETE", userId=userId,
        )
        return

    # ── Đã trả đủ rồi → bỏ qua ──
    if tid_str in confirmed and paid >= sent:
        return

    # ── Tag lần đầu (hoặc còn thiếu lần trả): yêu cầu xác nhận ──
    self.sendReaction(data, "💅", threadId, type, 100000000)
    self.replyMessageStyle(
        "Tag bot lần nữa để xác nhận chéo.",
        data, threadId, type,
        color="or", title="CAUTION", userId=userId,
    )
    pending_confirm[tid_str] = True
    _update_cfg(self.uid, pending_confirm=pending_confirm)


def ckgCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) >= 2 else ""
    sub2  = parts[2].lower() if len(parts) >= 3 else ""

    p = self.prefix
    c = self.rawCommand

    if sub == "set" and sub2 == "now":
        _cmd_set_now(self, data, userId, threadId, type)

    elif sub == "init":
        _broadcast(self, data, userId, threadId, type, delay=0.0)

    elif sub == "start":
        _broadcast(self, data, userId, threadId, type, delay=1.0)

    elif sub == "preview":
        _cmd_preview(self, data, userId, threadId, type)

    elif sub == "reset":
        _update_cfg(self.uid,
            sent_threads=[],
            pending_confirm={},
            confirmed={},
        )
        self.replyMessageStyle(
            "Đã reset danh sách nhóm đã gửi. Dùng init hoặc start để rải lại.",
            data, threadId, type,
            color="gr", title="COMPLETE", userId=userId,
        )

    else:
        cfg             = _get_cfg(self.uid)
        main_tid        = cfg.get("main_thread")
        main_name       = _get_group_name(self, main_tid) if main_tid else "Chưa đặt"
        sent_count      = len(cfg.get("sent_threads", []))
        confirmed_count = len(cfg.get("confirmed", {}))

        self.replyMessageStyle(
            f"Nhóm chính: {main_name}\n"
            f"Đã gửi: {sent_count} nhóm | Đã chéo: {confirmed_count} nhóm\n\n"
            f"{p}{c} set now — set nhóm này làm nhóm chính\n"
            f"{p}{c} init    — gửi link đến tất cả nhóm ngay\n"
            f"{p}{c} start   — rải link\n"
            f"{p}{c} preview — test gửi link vào nhóm này\n"
            f"{p}{c} reset   — reset để gửi lại tất cả nhóm",
            data, threadId, type,
            color="or", title="CKG", userId=userId,
        )


dependencies = {
    "name":        "ckg",
    "permission":  2,
    "description": "Chéo link nhóm",
    "cooldown":    3,
    "main":        ckgCommand,
}