from app.core.index import *
from src.services.pillow.eventCard import draw_event_card
from app.module.utils import _get_user_avatar
from PIL import Image
import os

EVENT_KEYS = {
    "welcome": "welcomeOn",
    "leave":   "leaveOn",
    "kick":    "kickOn",
    "block":   "blockOn",
    "admin":   "adminOn",
    "setting": "settingOn",
}

EVENT_LABELS = {
    "welcomeOn": "Welcome (join)",
    "leaveOn":   "Leave",
    "kickOn":    "Kick",
    "blockOn":   "Block",
    "adminOn":   "Add / Remove Admin",
    "settingOn": "Đổi setting nhóm",
}

TEST_MODES = ("welcome", "leave", "kick", "kick_block", "add_admin", "remove_admin",
              "update_setting", "join_request", "new_link")

def _get_thread_cfg(uid: str, threadId: str) -> dict:
    s = read_settings(uid)
    return s.get("eventConfig", {}).get(str(threadId), {})

def _save_thread_cfg(uid: str, threadId: str, cfg: dict):
    s = read_settings(uid)
    s.setdefault("eventConfig", {})[str(threadId)] = cfg
    write_settings(uid, s)

def _save_all_threads(uid: str, key: str, value: bool):
    s  = read_settings(uid)
    ec = s.setdefault("eventConfig", {})
    for tid in list(ec.keys()):
        ec[tid][key] = value
    write_settings(uid, s)

def _save_all_keys_all_threads(uid: str, value: bool):
    s  = read_settings(uid)
    ec = s.setdefault("eventConfig", {})
    for tid in list(ec.keys()):
        for k in EVENT_KEYS.values():
            ec[tid][k] = value
    write_settings(uid, s)

def _ok(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

def _err(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="r",  title="ERROR",   userId=userId)

def _info(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="or", title="EVENT CONFIG", userId=userId)

def _send_test_card(this, target_uid: str, mode: str, threadId: str, type, data):
    name   = this.userName(target_uid) or target_uid
    avatar = _get_user_avatar(this, target_uid)

    try:
        count = 0
        info  = this.fetchGroupInfo(str(threadId))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g     = gdata.get(str(threadId)) or {}
        count = int(g.get("totalMember") or g.get("memberCount") or 0)
    except Exception:
        pass

    path = f"data/assets/cache/image/event_test_{threadId}.jpg"
    try:
        draw_event_card(
            {"name": name, "avatar_url": avatar, "member_count": count},
            path,
            mode=mode,
        )
        upload   = this._uploadImage(path, threadId, type)
        image_hd = upload.get("hdUrl") or upload.get("normalUrl")
        if not image_hd:
            return _err(this, "Upload ảnh thất bại.", data, threadId, type, None)

        with Image.open(path) as img:
            w, h = img.size

        this.sendRemoteImage(
            image_url=image_hd,
            threadId=threadId,
            type=type,
            width=w,
            height=h,
            message=None,
            ttl=86000000,
        )
    except Exception as e:
        print(f"[event._send_test_card] {e}")
        _err(this, f"Lỗi khi vẽ card: {e}", data, threadId, type, None)
    finally:
        try:
            os.remove(path)
        except Exception:
            pass

def eventCommand(this, message, data, userId, threadId, type):
    p     = this.prefix
    c     = this.rawCommand
    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()

    if len(parts) < 2:
        cfg   = _get_thread_cfg(this.uid, threadId)
        lines = [
            f"  {label}: {'✅ ON' if cfg.get(key, False) else '❌ OFF'}"
            for key, label in EVENT_LABELS.items()
        ]
        return _info(
            this,
            "Trạng thái event nhóm này:\n" + "\n".join(lines) +
            f"\n\nDùng:\n"
            f"  {p}{c} welcome on/off\n"
            f"  {p}{c} leave on/off\n"
            f"  {p}{c} kick / block / admin / setting on/off\n"
            f"  {p}{c} all on/off\n"
            f"  {p}{c} global (type) on/off\n"
            f"  {p}{c} test @mention welcome/leave/...",
            data, threadId, type, userId,
        )

    sub = parts[1].lower()

    if sub == "test":
        uids = extractUids(data)
        if not uids:
            return _err(this, f"Cú pháp: {p}{c} test @mention welcome/leave/...",
                        data, threadId, type, userId)

        mode = parts[3].lower() if len(parts) > 3 else (parts[2].lower() if len(parts) > 2 else "")
        raw_words = [w for w in parts[2:] if not w.startswith("@")]
        mode = raw_words[0].lower() if raw_words else "welcome"

        if mode not in TEST_MODES:
            valid = " / ".join(TEST_MODES)
            return _err(this, f"Mode không hợp lệ.\nDùng: {valid}",
                        data, threadId, type, userId)

        _send_test_card(this, uids[0], mode, threadId, type, data)
        return

    if sub == "global":
        if len(parts) < 4:
            return _err(
                this,
                f"Cú pháp: {p}{c} global (type) on/off\n"
                f"hoặc:    {p}{c} global all on/off",
                data, threadId, type, userId,
            )

        g_type      = parts[2].lower()
        g_state_str = parts[3].lower()

        if g_state_str not in ("on", "off"):
            return _err(this, "Thiếu trạng thái. Dùng on hoặc off.",
                        data, threadId, type, userId)

        new_state = (g_state_str == "on")

        if g_type == "all":
            _save_all_keys_all_threads(this.uid, new_state)
            return _ok(
                this,
                f"Đã {'bật' if new_state else 'tắt'} TẤT CẢ event trên toàn bộ thread.",
                data, threadId, type, userId,
            )

        cfg_key = EVENT_KEYS.get(g_type)
        if not cfg_key:
            valid = " / ".join(EVENT_KEYS.keys())
            return _err(this, f"Event không hợp lệ. Dùng: {valid} / all",
                        data, threadId, type, userId)

        _save_all_threads(this.uid, cfg_key, new_state)
        return _ok(
            this,
            f"Đã {'bật' if new_state else 'tắt'} event '{EVENT_LABELS[cfg_key]}' "
            f"trên tất cả thread.",
            data, threadId, type, userId,
        )

    if len(parts) < 3:
        return _err(this, f"Thiếu trạng thái. Dùng: {p}{c} {sub} on/off",
                    data, threadId, type, userId)

    state_str = parts[2].lower()
    if state_str not in ("on", "off"):
        return _err(this, "Trạng thái phải là on hoặc off.",
                    data, threadId, type, userId)

    new_state = (state_str == "on")
    cfg       = _get_thread_cfg(this.uid, threadId)

    if sub == "all":
        for key in EVENT_KEYS.values():
            cfg[key] = new_state
        _save_thread_cfg(this.uid, threadId, cfg)
        return _ok(this, f"Đã {'bật' if new_state else 'tắt'} tất cả event nhóm này.",
                   data, threadId, type, userId)

    cfg_key = EVENT_KEYS.get(sub)
    if not cfg_key:
        valid = " / ".join(EVENT_KEYS.keys())
        return _err(this, f"Event không hợp lệ. Dùng: {valid} / all",
                    data, threadId, type, userId)

    cfg[cfg_key] = new_state
    _save_thread_cfg(this.uid, threadId, cfg)
    _ok(this, f"Đã {'bật' if new_state else 'tắt'} event '{EVENT_LABELS[cfg_key]}'.",
        data, threadId, type, userId)

dependencies = {
    "name":        "event",
    "permission":  2,
    "description": "Bật/tắt thông báo event nhóm (join, leave, kick, block, admin, setting)",
    "cooldown":    3,
    "main":        eventCommand,
}