from app.core.index import *

def dmsgCommand(this, message, data, userId, threadId, type):
    p = this.prefix
    c = this.rawCommand

    quote = getattr(data, "quote", None)

    if not quote:
        help_text = (
            f"Hãy reply vào tin nhắn cần xoá."  
        )
        return this.replyMessageStyle(
            help_text, data, threadId, type,
            color="or", title="CAUTION", userId=userId
        )

    msg_id  = getattr(quote, "globalMsgId",  None) \
           or getattr(quote, "msgId",        None) \
           or getattr(quote, "gMsgId",       None)
    cli_id  = getattr(quote, "cliMsgId",     None) \
           or getattr(quote, "clientMsgId",  None) \
           or getattr(quote, "cMsgId",       None)
    owner   = getattr(quote, "ownerId",      None) \
           or getattr(quote, "uid",          None)

    if not msg_id or not cli_id:
        return this.replyMessageStyle(
            "Không lấy được id tin nhắn từ reply.\n",
            data, threadId, type,
            color="r", title="ERROR", userId=userId
        )

    if not owner:
        owner = getattr(quote, "uidFrom", userId)

    try:
        this.deleteMessage(str(msg_id), str(owner), str(cli_id), str(threadId))
        this.sendReaction(data, "✅", threadId, type, 100000000)
    except Exception as e:
        this.replyMessageStyle(
            f"Bot cần quyền admin nhóm để xoá tin nhắn..",
            data, threadId, type,
            color="r", title="ERROR", userId=userId
        )

dependencies = {
    "name":        "dmsg",
    "permission":  3,        
    "description": "Xoá tin nhắn bằng cách reply vào tin cần xoá",
    "cooldown":    3,
    "main":        dmsgCommand,
}
