from app.core.index import *


def _parse_call_time(message):
    t = (getattr(message, "text", "") or "").strip()
    parts = t.split()
    if len(parts) >= 2 and parts[-1].isdigit():
        return int(parts[-1])
    m = re.search(r"(\d+)\s*$", t)
    if m:
        return int(m.group(1))
    return 1


def _send_warn(this, text, data, threadId, type, userId):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)


def _send_complete(this, text, data, threadId, type, userId):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)


def callCommand(this, message, data, userId, threadId, type):
    p = this.prefix
    c = this.rawCommand

    text  = (getattr(message, "text", "") or "").strip()
    parts = text.split()
    args  = {x.lower() for x in parts[1:]}
    is_me = "-me" in args

    targets = extractUids(data) or []

    if is_me:
        targets = [str(userId)]

    if not targets:
        name = this.userName(userId)
        help_text = (
            f"Nhập Nội Dung Cần Thực Hiện\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} @{name}\n"
            f"      Gọi điện 1 lần cho thành viên được mention.\n\n"
            f"  📍 {p}{c} @{name} 5\n"
            f"      Gọi điện 5 lần liên tiếp.\n\n"
            f"  📍 {p}{c} -me 10\n"
            f"      Tự gọi cho chính mình 10 lần.\n\n"
            f"  ⚠️ Tối đa 500 lần mỗi lệnh."
        )
        return this.replyMessageStyle(help_text, data, threadId, type, color="or", title="CAUTION", userId=userId)

    call_time = _parse_call_time(message)
    if call_time < 1 or call_time > 500:
        return _send_warn(this, "Số lần gọi phải từ 1 → 500..!", data, threadId, type, userId)

    for uid in targets:
        for _ in range(call_time):
            this.sendCall(uid, random.randint(100000000, 999999999))
            time.sleep(1.5)

    _send_complete(this, f"Đã gọi {call_time} lần tới {len(targets)} target.", data, threadId, type, userId)


dependencies = {
    "name":        "call",
    "permission":  3,
    "description": "Gọi điện liên tiếp tới thành viên được mention",
    "cooldown":    5,
    "main":        callCommand,
}
