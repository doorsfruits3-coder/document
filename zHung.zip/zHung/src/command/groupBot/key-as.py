from app.core.index import *
import json
from api.util.msg import Message

def _parse_args(message):
    import shlex
    raw = (getattr(message, "text", None) or "").strip()
    tokens = shlex.split(raw)
    args = set()
    ignore = ""
    use_me = False
    i = 1
    while i < len(tokens):
        t = tokens[i]
        tl = t.lower()
        if tl in ("-i", "--ignore") and i + 1 < len(tokens):
            ignore = tokens[i + 1] or ""
            i += 2
            continue
        if tl in ("-me", "--me"):
            use_me = True
        else:
            args.add(tl)
        i += 1
    return args, ignore, use_me

def _get_group_info(this, threadId):
    try:
        gi = this.fetchGroupInfo(threadId)
        gridinfomap = getattr(gi, "gridInfoMap", None) or {}
        info = gridinfomap.get(threadId) or gridinfomap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}

def _get_admin_ids(info):
    for k in ("adminIds", "adminIdList", "admins", "adminList",
              "adminIdMap", "adminMap", "adminUidList", "adminUidMap"):
        if k not in info:
            continue
        v = info.get(k)
        if isinstance(v, dict):
            return [x for x in v.keys() if x]
        if isinstance(v, (list, tuple, set)):
            return [x for x in v if x]
        if isinstance(v, str):
            return [x for x in v.replace(" ", "").split(",") if x]
        return []
    return []

def _is_group_admin(this, uid, threadId):
    info = _get_group_info(this, threadId)
    admins = _get_admin_ids(info)
    return str(uid) in [str(a) for a in admins]

def _send_fail(this, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)

def _build_mention_message(this, header_text, targets):
    if not targets:
        return header_text, []
    tags = []
    for uid in targets:
        name = this.userName(uid) or str(uid)
        tags.append((uid, f"@{name}"))
    mention_line = " ".join(tag for _, tag in tags)
    full_text = f"{header_text}\n{mention_line}"
    mentions = []
    cursor = len(header_text) + 1
    for uid, tag in tags:
        pos = full_text.index(tag, cursor)
        mentions.append({"uid": str(uid), "pos": pos, "len": len(tag)})
        cursor = pos + len(tag)
    return full_text, mentions

def _send_ok(this, text, targets, data, threadId, type, userId):
    full_text, mentions = _build_mention_message(this, text, targets)
    try:
        Message(text=full_text, mention=json.dumps(mentions))
        this.replyMessageStyle(full_text, data, threadId, type, color="gr", title="SUCCESS", userId=userId)
    except Exception:
        this.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

def _send_complete(this, text, targets, data, threadId, type, userId):
    full_text, mentions = _build_mention_message(this, text, targets)
    try:
        Message(text=full_text, mention=json.dumps(mentions))
        this.replyMessageStyle(full_text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)
    except Exception:
        this.replyMessageStyle(text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)

def keyAs(this, message, data, userId, threadId, type):
    p = this.prefix
    c = this.rawCommand

    args, ignore, use_me = _parse_args(message)

    is_help   = ":help" in args or "help" in args
    is_leader = ":leader" in args
    is_clear  = ":clear" in args

    if is_help or (len(args) == 0 and not use_me and not extractUids(data) and not getattr(data, "quote", None)):
        name = this.userName(userId)
        help_text = (
            f"Nhập Nội Dung Cần Thực Hiện\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} @{name}\n"
            f"      Toggle admin (promote/demote) thành viên.\n\n"
            f"  📍 {p}{c} -me\n"
            f"      Toggle admin cho chính bản thân.\n\n"
            f"  📍 {p}{c} :leader @{name}\n"
            f"      Đổi chủ nhóm sang thành viên được tag.\n\n"
            f"  📍 {p}{c} :leader -me\n"
            f"      Đổi chủ nhóm sang chính bản thân.\n\n"
            f"  📍 {p}{c} :clear\n"
            f"      Xoá toàn bộ admin (trừ chủ nhóm).\n\n"
            f"  📍 {p}{c} :clear -i tên\n"
            f"      Xoá hàng loạt, bỏ qua người có tên chứa từ khoá."
        )
        return this.replyMessageStyle(help_text, data, threadId, type, color="or", title="CAUTION", userId=userId)

    info       = _get_group_info(this, threadId)
    creator_id = str(info.get("creatorId", "") or "")

    if is_clear:
        admins = _get_admin_ids(info)
        if not admins:
            return _send_fail(this, "Không có admin nào để xoá..!", data, threadId, type, userId)

        ignore_kw = ignore.casefold()
        targets, seen = [], set()
        for uid in admins:
            if uid is None:
                continue
            uid_str = str(uid)
            if creator_id and uid_str == creator_id:
                continue
            if uid_str in seen:
                continue
            if ignore_kw:
                name = (this.userName(uid) or "").casefold()
                if ignore_kw in name:
                    seen.add(uid_str)
                    continue
            seen.add(uid_str)
            targets.append(uid)

        if not targets:
            return _send_fail(this, "Không có target hợp lệ..!", data, threadId, type, userId)

        _send_complete(this, f"Đã xoá {len(targets)} admin khỏi nhóm.", targets, data, threadId, type, userId)
        this.removeGroupAdmins(targets, threadId)
        return

    uids  = extractUids(data) or []
    quote = getattr(data, "quote", None)
    targets = list(uids)

    if use_me and userId not in targets:
        targets.append(userId)

    if not targets and quote:
        oid = getattr(quote, "ownerId", None)
        if oid:
            targets = [oid]

    if not targets:
        targets = [userId]

    seen, deduped = set(), []
    for x in targets:
        if x and x not in seen:
            seen.add(x); deduped.append(x)
    targets = deduped

    if not targets:
        return _send_fail(this, "Chỉ có thể thao tác với thành viên trong nhóm..!", data, threadId, type, userId)

    if is_leader:
        owners = [uid for uid in targets if not (creator_id and str(uid) == creator_id)]
        if not owners:
            return _send_fail(this, "Không có target hợp lệ..!", data, threadId, type, userId)
        _send_complete(this, f"Đã đổi chủ nhóm cho {len(owners)} thành viên.", owners, data, threadId, type, userId)
        for uid in owners:
            this.changeGroupOwner(uid, threadId)
        return

    promote, demote = [], []
    for uid in targets:
        if creator_id and str(uid) == creator_id:
            continue
        if _is_group_admin(this, uid, threadId):
            demote.append(uid)
        else:
            promote.append(uid)

    if not promote and not demote:
        return _send_fail(this, "Không có target hợp lệ..!", data, threadId, type, userId)

    all_targets = promote + demote
    parts = []
    if promote:
        parts.append(f"Promoted {len(promote)}")
    if demote:
        parts.append(f"Demoted {len(demote)}")

    _send_ok(this, " & ".join(parts), all_targets, data, threadId, type, userId)

    if promote:
        this.addGroupAdmins(promote, threadId)
    if demote:
        this.removeGroupAdmins(demote, threadId)

dependencies = {
    "name":        "key-as",
    "permission":  3,
    "description": "Toggle admin nhóm / đổi chủ nhóm / xoá hàng loạt admin",
    "cooldown":    5,
    "main":        keyAs,
}