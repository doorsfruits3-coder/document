from app.core.index import *
from src.services.utils.mute_core import parseDuration, formatRemaining

def _reply(self, text, data, threadId, type, userId, color="gr", title="COMPLATE"):
    self.replyMessageStyle(text, data, threadId, type, color=color, title=title, userId=userId)

def silentCommand(self, message, data, userId, threadId, type):
    parts = (getattr(message, "text", None) or "").strip().split()

    s = read_settings(self.uid)

    silentRoot  = s.setdefault("silent", {})
    groupMap    = silentRoot.setdefault("group", {})
    silentMap   = groupMap.setdefault(str(threadId), {})

    silentAllRoot = s.setdefault("isSlientAll", {})
    threadKey     = str(threadId)
    isAll         = bool(silentAllRoot.get(threadKey))

    now = time.time()
    for uid, meta in list(silentMap.items()):
        untilTs = (meta or {}).get("until", 0) or 0
        if untilTs and untilTs <= now:
            silentMap.pop(uid, None)

    uids = extractUids(data)
    sub  = (parts[1] if len(parts) >= 2 else "").lower()

    if (len(parts) == 1) or sub == "list" or (len(parts) == 2 and not uids and sub not in ("for",)):
        lines = [f"Silent All: {isAll}"]
        if not silentMap:
            lines.append("Silent list: Empty")
        else:
            items = sorted(
                silentMap.items(),
                key=lambda x: ((x[1] or {}).get("until", 0) or 0, x[0])
            )
            lines.append("Silent list:")
            for i, (uid, meta) in enumerate(items, 1):
                by_name = self.userName((meta or {}).get("by")) if (meta or {}).get("by") else "unknown"
                lines.append(
                    f"{i}. {self.userName(uid)} | "
                    f"{formatRemaining((meta or {}).get('until', 0) or 0)} | "
                    f"by {by_name}"
                )
        return _reply(self, "\n".join(lines), data, threadId, type, userId)

    if len(parts) >= 3 and sub == "for" and parts[2] == "All":
        if len(parts) >= 4 and parts[3].lower() in ("on", "off"):
            enabled = parts[3].lower() == "on"
        else:
            enabled = not isAll

        if enabled:
            silentAllRoot[threadKey] = True
        else:
            silentAllRoot.pop(threadKey, None)

        write_settings(self.uid, s)
        msg = "All members silented" if enabled else "All can talk now"
        return _reply(self, msg, data, threadId, type, -1)

    if not uids:
        return _reply(
            self,
            "Appoint a user to silent her/him..!",
            data, threadId, type, userId,
            color="yl", title="WARNING"
        )

    durSeconds, durRaw = parseDuration(parts)
    if durSeconds is None:
        durSeconds, durRaw = 3600, "1h"

    changed = False
    for uid in uids:
        uidKey = str(uid)
        if uidKey in silentMap:
            silentMap.pop(uidKey, None)
            _reply(self, f"Unsilenced {self.userName(uid)}", data, threadId, type, userId)
            changed = True
            continue

        if durSeconds == 0:
            silentMap[uidKey] = {"until": 0, "by": userId, "at": now}
            _reply(self, f"Silenced {self.userName(uid)} (inf)", data, threadId, type, userId)
        else:
            silentMap[uidKey] = {"until": now + durSeconds, "by": userId, "at": now}
            _reply(self, f"Silenced {self.userName(uid)} for {durRaw}", data, threadId, type, userId)
        changed = True

    if changed:
        write_settings(self.uid, s)

dependencies = {
    "name":        "silent",
    "permission":  1,
    "cooldown":    3,
    "description": "Silent a user or all members in group",
    "main":        silentCommand,
}