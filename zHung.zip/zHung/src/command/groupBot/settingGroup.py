from app.core.index import *
import threading

_SETTINGS: dict[str, tuple[str, str, str]] = {
    "blockname":   ("blockName",        "Chặn đổi tên & ảnh",        "Không cho phép members đổi tên & ảnh đại diện nhóm"),
    "signadmin":   ("signAdminMsg",     "Đánh dấu tin nhắn admin",   "Đánh dấu tin nhắn từ chủ/phó nhóm"),
    "addonly":     ("addMemberOnly",    "Chỉ admin thêm thành viên", "Chỉ admin được thêm members (khi tắt link tham gia)"),
    "settopic":    ("setTopicOnly",     "Chỉ admin ghim/chủ đề",    "Cho phép members ghim tin nhắn, ghi chú, bình chọn"),
    "msghistory":  ("enableMsgHistory", "Lịch sử chat",              "Cho phép thành viên mới đọc tin nhắn gần nhất"),
    "lockpost":    ("lockCreatePost",   "Khoá tạo ghi chú",          "Không cho phép members tạo ghi chú, nhắc hẹn"),
    "lockpoll":    ("lockCreatePoll",   "Khoá tạo bình chọn",        "Không cho phép members tạo bình chọn"),
    "joinappr":    ("joinAppr",         "Duyệt vào nhóm",            "Bật chế độ phê duyệt khi thành viên tham gia nhóm"),
    "lockchat":    ("lockSendMsg",      "Khoá chat",                  "Không cho phép members gửi tin nhắn"),
    "lockmember":  ("lockViewMember",   "Ẩn danh sách thành viên",   "Không cho phép members xem danh sách thành viên nhóm"),
    "bannfeature": ("bannFeature",      "bannFeature",                "Tính năng ban Zalo nội bộ"),
    "dirtymedia":  ("dirtyMedia",       "dirtyMedia",                 "Lọc media nhạy cảm Zalo nội bộ"),
    "banduration": ("banDuration",      "banDuration",                "Thời gian ban Zalo nội bộ"),
}

_SCHEDULES: dict[tuple, dict] = {}
_SCHED_STARTED = False
_SCHED_LOCK    = threading.Lock()


def _sched_set(bot_uid, tid, lock_h, open_h):
    with _SCHED_LOCK:
        _SCHEDULES[(str(bot_uid), str(tid))] = {"lock_h": lock_h, "open_h": open_h}

def _sched_del(bot_uid, tid):
    with _SCHED_LOCK:
        _SCHEDULES.pop((str(bot_uid), str(tid)), None)

def _sched_get(bot_uid, tid):
    with _SCHED_LOCK:
        return _SCHEDULES.get((str(bot_uid), str(tid)))


def _scheduler_loop(bot):
    import time as _t
    from datetime import datetime
    done: dict = {}
    while True:
        try:
            h = datetime.now().hour
            with _SCHED_LOCK:
                items = list(_SCHEDULES.items())
            for (buid, tid), s in items:
                if buid != str(bot.uid):
                    continue
                if h == s["lock_h"] and not done.get((tid, h, "lock")):
                    try: bot.changeGroupSetting(tid, lockSendMsg=1)
                    except Exception: pass
                    done[(tid, h, "lock")] = True
                if h == s["open_h"] and not done.get((tid, h, "open")):
                    try: bot.changeGroupSetting(tid, lockSendMsg=0)
                    except Exception: pass
                    done[(tid, h, "open")] = True
            if len(done) > 300:
                done.clear()
        except Exception as e:
            print(f"[STG sched] {e}")
        _t.sleep(30)


def _ensure_scheduler(bot):
    global _SCHED_STARTED
    if not _SCHED_STARTED:
        _SCHED_STARTED = True
        threading.Thread(target=_scheduler_loop, args=(bot,), daemon=True).start()


class SettingGroupCommand:

    def __init__(self, ctx):
        self._ctx   = ctx
        self.prefix = getattr(ctx, "prefix", "/")
        self.cmd    = getattr(ctx, "commandName", "stg")

    def _reply(self, text, data, threadId, type, *, color, title, userId):
        return self._ctx.replyMessageStyle(text, data, threadId, type,
                                           color=color, title=title, userId=userId)

    def _fetch(self, threadId) -> dict:
        try:
            gi  = self._ctx.fetchGroupInfo(str(threadId))
            gim = getattr(gi, "gridInfoMap", None) or {}
            return dict((gim.get(str(threadId)) or {}).get("setting") or {})
        except Exception:
            return {}

    def _apply(self, threadId, **kwargs) -> bool:
        try:
            self._ctx.changeGroupSetting(str(threadId), **kwargs)
            return True
        except Exception as e:
            print(f"[STG] {e}")
            return False

    def _guide(self, data, threadId, type, userId):
        p, c = self.prefix, self.cmd
        rows = "\n".join(f"  📍 {p}{c} {alias:<14} {short}"
                         for alias, (_, short, _d) in _SETTINGS.items())
        text = (
            f"Nhập Setting Cần Thay Đổi\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} lockchat           Khoá/mở chat ngay\n"
            f"  📍 {p}{c} lockchat 1 19      Tự khoá 1h, mở 19h mỗi ngày\n"
            f"  📍 {p}{c} blockname on       Bật chặn đổi tên nhóm\n"
            f"  📍 {p}{c} joinappr off       Tắt duyệt thành viên\n"
            f"  📍 {p}{c} status             Xem trạng thái toàn bộ setting\n\n"
            f"Danh Sách Setting:\n"
            f"{rows}\n\n"
            f"Bỏ trống on/off để tự toggle trạng thái hiện tại."
        )
        return self._reply(text, data, threadId, type,
                           color="or", title="CAUTION", userId=userId)

    def _help(self, data, threadId, type, userId):
        p, c = self.prefix, self.cmd
        rows = "\n".join(f"  {alias:<14} {desc}"
                         for alias, (_, _s, desc) in _SETTINGS.items())
        text = (
            f"Mô Tả Chi Tiết Từng Setting\n\n"
            f"{rows}\n\n"
            f"Lockchat Theo Lịch:\n"
            f"  📍 {p}{c} lockchat <giờ_khoá> <giờ_mở>\n"
            f"  📍 {p}{c} lockchat 1 19\n"
            f"  Tự động khoá lúc 01:00, mở lúc 19:00, lặp mỗi ngày.\n"
            f"  Restart bot sẽ mất lịch — cần đặt lại.\n\n"
            f"Giá Trị Hợp Lệ: on / off / 1 / 0 / bật / tắt"
        )
        return self._reply(text, data, threadId, type,
                           color="yl", title="CAUTION", userId=userId)

    def _status(self, data, threadId, type, userId):
        cur = self._fetch(threadId)
        if not cur:
            return self._reply(
                "Không lấy được setting nhóm.\nBot có phải admin/owner không?",
                data, threadId, type, color="r", title="ERROR", userId=userId,
            )
        rows = "\n".join(
            f"  {'✅' if int(cur.get(key, 0) or 0) else '❌'}  {alias:<14} {short}"
            for alias, (key, short, _) in _SETTINGS.items()
        )
        sched = _sched_get(self._ctx.uid, threadId)
        sched_line = (
            f"  ⏰  {sched['lock_h']:02d}:00 khoá  →  {sched['open_h']:02d}:00 mở"
            if sched else "  ⏰  Chưa đặt lịch lockchat"
        )
        return self._reply(
            f"Trạng Thái Setting Nhóm\n\n{rows}\n\n{sched_line}",
            data, threadId, type, color="or", title="CAUTION", userId=userId,
        )

    def _lockchat(self, parts, data, threadId, type, userId):
        p, c = self.prefix, self.cmd

        if len(parts) == 2:
            cur    = self._fetch(threadId)
            locked = int(cur.get("lockSendMsg", 0) or 0) == 1
            new    = 0 if locked else 1
            if self._apply(threadId, lockSendMsg=new):
                msg = "Đã Khoá Chat Nhóm." if new else "Đã Mở Chat Nhóm."
                self._reply(msg, data, threadId, type,
                            color="gr", title="COMPLETE", userId=userId)
            else:
                self._reply("Không thể thay đổi setting.\nBot có phải admin/owner nhóm không?",
                            data, threadId, type, color="r", title="ERROR", userId=userId)
            return

        sub = parts[2].lower()

        if sub == "off":
            if _sched_get(self._ctx.uid, threadId):
                _sched_del(self._ctx.uid, threadId)
                self._reply("Đã Xoá Lịch Lockchat.", data, threadId, type,
                            color="gr", title="COMPLETE", userId=userId)
            else:
                self._reply("Nhóm này chưa có lịch lockchat nào.",
                            data, threadId, type, color="yl", title="WARNING", userId=userId)
            return

        if sub in ("status", "list"):
            s = _sched_get(self._ctx.uid, threadId)
            if s:
                self._reply(
                    f"Lịch Lockchat Hiện Tại\n\n"
                    f"  🔒 Khoá lúc: {s['lock_h']:02d}:00\n"
                    f"  🔓 Mở  lúc:  {s['open_h']:02d}:00",
                    data, threadId, type, color="or", title="CAUTION", userId=userId,
                )
            else:
                self._reply("Nhóm này chưa có lịch lockchat.",
                            data, threadId, type, color="yl", title="WARNING", userId=userId)
            return

        if len(parts) >= 4 and sub.isdigit() and parts[3].isdigit():
            lh, oh = int(sub), int(parts[3])
            if not (0 <= lh <= 23 and 0 <= oh <= 23):
                self._reply("Giờ hợp lệ từ 0 đến 23.",
                            data, threadId, type, color="r", title="ERROR", userId=userId)
                return
            if lh == oh:
                self._reply("Giờ khoá và giờ mở không được trùng nhau.",
                            data, threadId, type, color="r", title="ERROR", userId=userId)
                return
            _ensure_scheduler(self._ctx)
            _sched_set(self._ctx.uid, threadId, lh, oh)
            self._reply(
                f"Đặt Lịch Lockchat Thành Công\n\n"
                f"  🔒 Khoá lúc: {lh:02d}:00\n"
                f"  🔓 Mở  lúc:  {oh:02d}:00\n\n"
                f"Lặp lại mỗi ngày. Dùng {p}{c} lockchat off để huỷ.",
                data, threadId, type, color="gr", title="COMPLETE", userId=userId,
            )
            return

        self._reply(
            f"Nhập Đúng Cú Pháp Lockchat\n\n"
            f"  📍 {p}{c} lockchat            Toggle khoá/mở ngay\n"
            f"  📍 {p}{c} lockchat <kh> <mh>  Đặt lịch tự động\n"
            f"  📍 {p}{c} lockchat off        Xoá lịch\n"
            f"  📍 {p}{c} lockchat status     Xem lịch hiện tại\n\n"
            f"Ví Dụ: {p}{c} lockchat 1 19",
            data, threadId, type, color="yl", title="CAUTION", userId=userId,
        )

    def _toggle(self, alias, parts, data, threadId, type, userId):
        api_key, _, desc = _SETTINGS[alias]

        if len(parts) >= 3:
            v = parts[2].lower()
            if v in ("on", "1", "bật", "bat"):
                new_val = 1
            elif v in ("off", "0", "tắt", "tat"):
                new_val = 0
            else:
                self._reply(
                    f"Giá trị không hợp lệ: '{parts[2]}'\n"
                    f"Dùng: on / off / 1 / 0 / bật / tắt",
                    data, threadId, type, color="r", title="ERROR", userId=userId,
                )
                return
        else:
            cur     = self._fetch(threadId)
            new_val = 0 if int(cur.get(api_key, 0) or 0) == 1 else 1

        if self._apply(threadId, **{api_key: new_val}):
            state = "Đã Bật" if new_val else "Đã Tắt"
            self._reply(f"{state} — {desc}", data, threadId, type,
                        color="gr", title="COMPLETE", userId=userId)
        else:
            self._reply("Không thể thay đổi setting.\nBot có phải admin/owner nhóm không?",
                        data, threadId, type, color="r", title="ERROR", userId=userId)

    def run(self, message, data, userId, threadId, type):
        text  = (getattr(message, "text", None) or "").strip()
        parts = text.split()

        if len(parts) <= 1:
            return self._guide(data, threadId, type, userId)

        sub = parts[1].lower()

        if sub in ("help", "--help", "-h"):
            return self._help(data, threadId, type, userId)
        if sub == "status":
            return self._status(data, threadId, type, userId)
        if sub == "lockchat":
            return self._lockchat(parts, data, threadId, type, userId)
        if sub in _SETTINGS:
            return self._toggle(sub, parts, data, threadId, type, userId)

        self._reply(
            f"Không Nhận Ra Setting '{sub}'\n"
            f"Dùng {self.prefix}{self.cmd} để xem danh sách.",
            data, threadId, type, color="yl", title="WARNING", userId=userId,
        )


def settingGroupCommand(self, message, data, userId, threadId, type):
    return SettingGroupCommand(self).run(message, data, userId, threadId, type)


dependencies = {
    "name":        "stg",
    "permission":  2,
    "cooldown":    3,
    "description": "Quản lý setting nhóm",
    "main":        settingGroupCommand,
}