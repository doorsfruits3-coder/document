from app.core.index import *
from src.services.utils.var_core import var_on, var_stop, var_list

VAR_TXT_PATH = "data/config/var_messages.txt"

def _help(self, data, threadId, type, userId):
    p = self.prefix
    c = self.rawCommand
    text = (
        f"Sử dụng lệnh var:\n\n"
        f"  {p}{c} on @user      – Bật var cho user\n"
        f"  {p}{c} on @u1 @u2    – Bật var nhiều user\n"
        f"  {p}{c} stop @user    – Tắt var (mention)\n"
        f"  {p}{c} stop 1 2 3    – Tắt var (số thứ tự trong list)\n"
        f"  {p}{c} list           – Xem danh sách đang var"
    )
    self.replyMessageStyle(text, data, threadId, type,
                           color="or", title="VAR", userId=userId)

def _parse_indices(parts: list[str]) -> list[int]:
    result = []
    for p in parts:
        if p.isdigit():
            result.append(int(p))
    return result

def varCommand(self, message, data, userId, threadId, type):
    text  = (getattr(message, "text", "") or "").strip()
    parts = text.split()
    sub   = parts[1].lower() if len(parts) >= 2 else ""

    uids = extractUids(data)

    if sub == "on":
        if not uids:
            return self.replyMessageStyle(
                "Mention user cần var..!",
                data, threadId, type, color="yl", title="VAR", userId=userId
            )
        var_on(self, uids, threadId, data, type, userId, VAR_TXT_PATH)

    elif sub == "stop":
        indices = _parse_indices(parts[2:])
        if not uids and not indices:
            return self.replyMessageStyle(
                "Mention user hoặc nhập số thứ tự cần tắt var..!",
                data, threadId, type, color="yl", title="VAR", userId=userId
            )
        var_stop(self, uids, indices, threadId, data, type, userId)

    elif sub == "list":
        var_list(self, threadId, data, type, userId)

    else:
        _help(self, data, threadId, type, userId)

dependencies = {
    "name":        "var",
    "permission":  2,        
    "description": "Var user",
    "cooldown":    2,
    "main":        varCommand,
}
