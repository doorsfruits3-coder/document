from app.core.index import *


# ── helpers nội bộ ────────────────────────────────────────────────────────────

def _reply_err(this, text, data, threadId, type, userId):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)

def _reply_warn(this, text, data, threadId, type, userId):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)

def _reply_ok(this, text, data, threadId, type, userId):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)

def _reply_info(this, title, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="or", title=title, userId=userId)


def _load_blocked(this):
    s  = read_settings(this.uid)
    bl = s.setdefault("botBlocked", [])
    return s, bl

def _is_admin(this, uid):
    s = read_settings(this.uid)
    return (
        uid in s.get("developerAdmin", [])
        or uid in s.get("highAdmin",       [])
        or uid in s.get("adminBot",        [])
    )

def _parse_targets(this, data):
    uids   = extractUids(data) or []
    quote  = getattr(data, "quote", None)
    result = list(uids)
    if not result and quote:
        oid = getattr(quote, "ownerId", None)
        if oid:
            result = [str(oid)]
    seen, out = set(), []
    for x in result:
        s = str(x)
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


# ── listener hook (gọi từ main.py) ───────────────────────────────────────────

def is_bot_blocked(this, userId: str) -> bool:
    """Trả về True nếu userId đang bị block bot → bỏ qua toàn bộ lệnh."""
    s  = read_settings(this.uid)
    bl = s.get("botBlocked", [])
    return str(userId) in bl


# ── main command ──────────────────────────────────────────────────────────────

def blockBotCommand(this, message, data, userId, threadId, type):
    p    = this.prefix
    c    = this.rawCommand
    text = (getattr(message, "text", None) or "").strip()

    # tách sub-command (bỏ qua mention khỏi parts)
    raw_parts = text.split()
    parts     = [x for x in raw_parts[1:] if not x.startswith("@")]
    sub       = parts[0].lower() if parts else ""

    # ── help (hoặc gọi trơn) ─────────────────────────────────────────────────
    if not sub or sub in ("help", ":help"):
        help_text = (
            f"Quản Lý Block Bot\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} add @mention\n"
            f"      Cấm người được mention sử dụng lệnh bot.\n\n"
            f"  📍 {p}{c} un @mention\n"
            f"      Gỡ lệnh cấm, cho phép dùng bot trở lại.\n\n"
            f"  📍 {p}{c} list\n"
            f"      Xem danh sách tất cả người đang bị block bot.\n\n"
            f"⚠️  Lưu ý: Không thể block người đang có quyền admin."
        )
        return _reply_info(this, "BLOCKBOT", help_text, data, threadId, type, userId)

    # ── list ─────────────────────────────────────────────────────────────────
    if sub == "list":
        _, bl = _load_blocked(this)
        if not bl:
            return _reply_warn(this, "Chưa có ai trong danh sách block bot.", data, threadId, type, userId)
        lines = "\n".join(
            f"{i}. {this.userName(uid) or uid}  ({uid})"
            for i, uid in enumerate(bl, 1)
        )
        return _reply_info(this, "BLOCK LIST", f"\n{lines}", data, threadId, type, userId)

    # ── add ──────────────────────────────────────────────────────────────────
    if sub == "add":
        targets = _parse_targets(this, data)
        if not targets:
            return _reply_warn(this, "Mention hoặc reply tin nhắn của người cần block bot.", data, threadId, type, userId)

        s, bl    = _load_blocked(this)
        added    = []
        skipped  = []

        for uid in targets:
            uid = str(uid)
            if _is_admin(this, uid):
                name = this.userName(uid) or uid
                skipped.append(name)
                continue
            if uid not in bl:
                bl.append(uid)
                added.append(uid)

        if added:
            write_settings(this.uid, s)

        lines = []
        if added:
            names = ", ".join(this.userName(u) or u for u in added)
            lines.append(f"Đã block bot: {names}")
        if skipped:
            lines.append(
                f"Không thể block bot, người dùng hiện tại đang là admin bot, yêu cầu gỡ quyền admin để thực hiện thao tác."
                + ", ".join(skipped)
            )
        if not lines:
            return _reply_warn(this, "Những người này đã bị block bot rồi.", data, threadId, type, userId)

        return _reply_ok(this, "\n".join(lines), data, threadId, type, userId)

    # ── un ───────────────────────────────────────────────────────────────────
    if sub in ("un", "unblock"):
        targets = _parse_targets(this, data)
        if not targets:
            return _reply_warn(this, "Mention hoặc reply tin nhắn của người cần gỡ block bot.", data, threadId, type, userId)

        s, bl   = _load_blocked(this)
        removed = []

        for uid in targets:
            uid = str(uid)
            if uid in bl:
                bl.remove(uid)
                removed.append(uid)

        if not removed:
            return _reply_warn(this, "Không tìm thấy ai trong danh sách block bot.", data, threadId, type, userId)

        write_settings(this.uid, s)
        names = ", ".join(this.userName(u) or u for u in removed)
        return _reply_ok(this, f"Đã gỡ block bot: {names}", data, threadId, type, userId)

    # ── sub-command không hợp lệ ─────────────────────────────────────────────
    return _reply_err(
        this,
        f"Sub-lệnh '{sub}' không tồn tại.\nDùng {p}{c} để xem hướng dẫn.",
        data, threadId, type, userId,
    )


dependencies = {
    "name":        "blockbot",
    "permission":  2,
    "description": "Cấm / cho phép người dùng sử dụng lệnh bot",
    "cooldown":    3,
    "main":        blockBotCommand,
}
