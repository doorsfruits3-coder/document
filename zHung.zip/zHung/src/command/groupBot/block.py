from app.core.index import *


def _get_group_info(this, threadId):
    try:
        gi = this.fetchGroupInfo(threadId)
        gridInfoMap = getattr(gi, "gridInfoMap", None) or {}
        info = gridInfoMap.get(threadId) or gridInfoMap.get(str(threadId)) or {}
        return dict(info) if not isinstance(info, dict) else info
    except Exception:
        return {}


def _send_fail(this, text, data, threadId, type, userId):
    this.sendReaction(data, "❌", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)


def _send_warn(this, text, data, threadId, type, userId):
    this.sendReaction(data, "⚠️", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)


def _send_complete(this, text, data, threadId, type, userId):
    this.sendReaction(data, "✅", threadId, type, 100000000)
    this.replyMessageStyle(text, data, threadId, type, color="gr", title="COMPLETE", userId=userId)


def _send_custom(this, title, text, data, threadId, type, userId):
    this.replyMessageStyle(text, data, threadId, type, color="r", title=title, userId=userId)


def _load_blacklist(this, threadId):
    s = read_settings(this.uid)
    bl = s.setdefault("blacklist", {}).setdefault(str(threadId), [])
    return s, bl


def _kick_user(this, uid, threadId):
    fn = (
        getattr(this, "kickUsers", None)
        or getattr(this, "kickUser", None)
        or getattr(this, "removeGroupMembers", None)
    )
    if not fn:
        return False
    try:
        if fn.__name__ == "kickUser":
            fn(uid, threadId)
        else:
            fn([uid], threadId)
        return True
    except Exception:
        return False


def _parse_targets(this, data):
    uids  = extractUids(data) or []
    quote = getattr(data, "quote", None)
    targets = list(uids)
    if not targets and quote:
        oid = getattr(quote, "ownerId", None)
        if oid:
            targets = [oid]
    seen, deduped = set(), []
    for x in targets:
        s = str(x)
        if s not in seen:
            seen.add(s)
            deduped.append(s)
    return deduped


def blockCommand(this, message, data, userId, threadId, type):
    p = this.prefix
    c = this.rawCommand

    text  = (getattr(message, "text", None) or "").strip()
    parts = text.split()
    args  = {x.lower() for x in parts[1:]}

    is_help       = "help" in args or ":help" in args
    is_list       = "-ls" in args
    is_remove     = "-rm" in args
    is_odds       = "-odds" in args
    is_target_all = ":target-all" in args

    if is_help or (len(parts) == 1 and not extractUids(data) and not getattr(data, "quote", None)):
        name = this.userName(userId)
        help_text = (
            f"Nhập Nội Dung Cần Thực Hiện\n\n"
            f"Ví Dụ:\n"
            f"  📍 {p}{c} @{name}\n"
            f"      Block & kick thành viên được mention.\n\n"
            f"  📍 {p}{c} -odds @{name}\n"
            f"      Block & thêm vào blacklist (không cho rejoin).\n\n"
            f"  📍 {p}{c} -odds :target-all @{name}\n"
            f"      Block & kick khỏi tất cả nhóm bot quản lý.\n\n"
            f"  📍 {p}{c} -ls\n"
            f"      Xem danh sách blacklist của nhóm.\n\n"
            f"  📍 {p}{c} -rm <index|uid>\n"
            f"      Xoá khỏi blacklist theo số thứ tự hoặc uid."
        )
        return this.replyMessageStyle(help_text, data, threadId, type, color="or", title="CAUTION", userId=userId)

    if is_list:
        _, bl = _load_blacklist(this, threadId)
        if not bl:
            return _send_warn(this, "Chưa có enemy nào trong blacklist..!", data, threadId, type, userId)
        lines = "\n".join(
            f"{i}. {this.userName(uid) or uid}" for i, uid in enumerate(bl, 1)
        )
        return _send_custom(this, "ENEMY LIST", f"\n{lines}", data, threadId, type, userId)

    if is_remove:
        rm_arg = next(
            (parts[i + 1] for i in range(len(parts) - 1) if parts[i].lower() == "-rm"),
            None,
        )
        if not rm_arg:
            return _send_warn(this, "Nhập index hoặc uid cần xoá..!", data, threadId, type, userId)

        s, bl = _load_blacklist(this, threadId)

        if rm_arg.isdigit():
            idx = int(rm_arg) - 1
            if not (0 <= idx < len(bl)):
                return _send_fail(this, "Index không hợp lệ..!", data, threadId, type, userId)
            uid_removed = bl.pop(idx)
        else:
            if rm_arg not in bl:
                return _send_fail(this, "Không tìm thấy uid trong blacklist..!", data, threadId, type, userId)
            bl.remove(rm_arg)
            uid_removed = rm_arg

        write_settings(this.uid, s)
        return _send_complete(
            this,
            f"Đã xoá {this.userName(uid_removed) or uid_removed} khỏi blacklist.",
            data, threadId, type, userId,
        )

    targets = _parse_targets(this, data)

    if not targets:
        return _send_warn(this, "Vui lòng mention hoặc reply tin nhắn của thành viên cần block..!", data, threadId, type, userId)

    this.blockUsers(targets, threadId)
    _send_complete(this, f"Đã block & kick {len(targets)} thành viên khỏi nhóm.", data, threadId, type, userId)

    if is_odds:
        s, bl = _load_blacklist(this, threadId)
        changed = False
        for uid in targets:
            if uid not in bl:
                bl.append(uid)
                changed = True
        if changed:
            write_settings(this.uid, s)

        if is_target_all:
            try:
                g     = this.fetchAllGroups()
                grids = list(getattr(g, "gridVerMap", {}) or {})
                for gid in grids:
                    mem      = this.getGroupMember(gid)
                    profiles = getattr(mem, "profiles", {}) or {}
                    for uid in targets:
                        if uid in profiles:
                            _kick_user(this, uid, gid)
            except Exception:
                pass


def blacklistEvent(this):
    import threading

    def _loop():
        while True:
            try:
                s   = read_settings(this.uid)
                bls = s.get("blacklist", {})
                for tid, uids in bls.items():
                    for uid in uids:
                        try:
                            this.blockUsers([uid], tid)
                        except Exception:
                            pass
            except Exception:
                pass
            time.sleep(1)

    threading.Thread(target=_loop, daemon=True).start()


dependencies = {
    "name":        "block",
    "permission":  2,
    "description": "Block & kick thành viên / quản lý blacklist",
    "cooldown":    5,
    "main":        blockCommand,
}