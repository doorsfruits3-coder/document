from app.core.index import *
import time
import threading

_EVENT_KIND = {
    "webchat":          "text",
    "chat.sticker":     "sticker",
    "chat.photo":       "image",
    "chat.photo.msg":   "image",
    "chat.gif":         "gif",
    "chat.video.msg":   "video",
    "chat.voice":       "voice",
    "chat.attachment":  "file",
    "chat.recommended": "contact",
    "share.link":       "link",
    "chat.link":        "link",
}


def _kindOf(message, data):
    mt = getattr(data, "msgType", "") or getattr(message, "msgType", "") or ""
    if mt in _EVENT_KIND:
        return _EVENT_KIND[mt]
    for k, v in _EVENT_KIND.items():
        if mt.startswith(k):
            return v
    if getattr(message, "text", None):
        return "text"
    return "other"


def _ensure_state(self):
    if not hasattr(self, "_antiSpamLog"):
        self._antiSpamLog      = {}
    if not hasattr(self, "_antiSpamWarn"):
        self._antiSpamWarn     = {}
    if not hasattr(self, "_antiSpamTimer"):
        self._antiSpamTimer    = {}
    if not hasattr(self, "_antiSpamCooldown"):
        self._antiSpamCooldown = {}


def _schedule_reset(self, key, delay=3):
    old = self._antiSpamTimer.get(key)
    if old:
        old.cancel()

    def _reset():
        self._antiSpamLog.pop(key, None)
        self._antiSpamWarn.pop(key, None)
        self._antiSpamWarn.pop((key, "fast_log"), None)
        self._antiSpamTimer.pop(key, None)
        self._antiSpamCooldown.pop(key, None)

    t = threading.Timer(delay, _reset)
    t.daemon = True
    t.start()
    self._antiSpamTimer[key] = t


def _set_cooldown(self, key, seconds=1.5):
    self._antiSpamCooldown[key] = time.time() + seconds


def _mention(self, userId):
    name = self.userName(userId) or str(userId)
    return f"@{name}"


def antiSpamMessage(self, message, data, userId, threadId, type):
    _ensure_state(self)

    settings = read_settings(self.uid)
    if threadId not in settings.get("antiSpam", []):
        return

    grInfo    = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId, {})
    adminIds  = grInfo.get("adminIds", [])
    creatorId = grInfo.get("creatorId")

    if userId == creatorId or userId in adminIds:
        return
    if admin_of_bot(self, threadId, userId):
        return

    key = (threadId, userId)
    now = time.time()

    if now < self._antiSpamCooldown.get(key, 0):
        return

    logs = self._antiSpamLog.get(key, [])
    logs = [t for t in logs if now - t <= 5]
    logs.append(now)
    self._antiSpamLog[key] = logs

    warn_level = self._antiSpamWarn.get(key, 0)

    _schedule_reset(self, key, delay=3)

    if len(logs) >= 4 and warn_level == 0:
        self._antiSpamWarn[key]  = 1
        self._antiSpamLog[key]   = []
        _set_cooldown(self, key)
        try:
            self.replyMessageStyle(
                f"Chậm tay lại bạn ơi!",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        except Exception:
            pass
        return

    if warn_level == 1:
        fast_logs = self._antiSpamWarn.get((key, "fast_log"), [])
        fast_logs = [t for t in fast_logs if now - t <= 2]
        fast_logs.append(now)
        self._antiSpamWarn[(key, "fast_log")] = fast_logs

        if len(fast_logs) >= 2:
            self._antiSpamWarn[key] = 2
            self._antiSpamWarn[(key, "fast_log")] = []
            _set_cooldown(self, key)
            try:
                self.replyMessageStyle(
                    f"Nhắn thêm 1 tin nữa ra đảo!",
                    data, threadId, type,
                    color="yl", title="WARNING", userId=userId,
                )
            except Exception:
                pass
        return

    if warn_level == 2:
        self._antiSpamWarn[key] = 3
        _set_cooldown(self, key, seconds=10)
        try:
            self.replyMessageStyle(
                f"Spam lắm thì cút!",
                data, threadId, type,
                color="r", title="ANTISPAM", userId=userId,
            )
        except Exception:
            pass

        try:
            self.changeGroupSetting(threadId, lockSendMsg=1)
        except Exception:
            pass
        try:
            self.blockUsers(userId, threadId)
        except Exception:
            pass

        def _unlock():
            time.sleep(2)
            try:
                self.changeGroupSetting(threadId, lockSendMsg=0)
            except Exception:
                pass

        threading.Thread(target=_unlock, daemon=True).start()

        self._antiSpamLog.pop(key, None)
        self._antiSpamWarn.pop(key, None)
        self._antiSpamWarn.pop((key, "fast_log"), None)
        old = self._antiSpamTimer.pop(key, None)
        if old:
            old.cancel()


def antiSpamCommand(self, message, data, userId, threadId, type):
    p        = self.prefix
    c        = self.rawCommand
    parts    = message.text.strip().split()
    settings = read_settings(self.uid)
    antispam = settings.setdefault("antiSpam", [])
    enabled  = threadId in antispam

    if len(parts) < 2:
        enabled = not enabled
    else:
        action = parts[1].lower()
        if action == "on":
            enabled = True
        elif action == "off":
            enabled = False
        else:
            self.replyMessageStyle(
                f"📍Use: {p}{c} on | off",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
            return

    if enabled and threadId not in antispam:
        antispam.append(threadId)
    if not enabled and threadId in antispam:
        antispam.remove(threadId)

    write_settings(self.uid, settings)

    self.replyMessageStyle(
        f"AntiSpam đã được {'bật' if enabled else 'tắt'}.",
        data, threadId, type,
        color="gr", title="SUCCESS", userId=userId,
    )


dependencies = {
    "name":        "antispam",
    "permission":  2,
    "description": "Anti spam",
    "cooldown":    5,
    "main":        antiSpamCommand,
}