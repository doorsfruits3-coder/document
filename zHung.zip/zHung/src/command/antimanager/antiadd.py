from app.core.index import *
import re
import time

# ══════════════════════════════════════════════════════════════════════════════
#  AntiAdd — Tự động rời nhóm / cộng đồng khi bot bị add vào
#  Hỗ trợ: on | off | on -time=Xd Xh Xp  (d=ngày, h=giờ, p=phút)
# ══════════════════════════════════════════════════════════════════════════════

_HELP = """{p}{c}               — Bật / tắt nhanh (toggle)
{p}{c} on            — Bật vĩnh viễn
{p}{c} off           — Tắt
{p}{c} on -time=...  — Bật có hẹn giờ
{p}{c} status        — Xem trạng thái hiện tại

Định dạng thời gian:  1d5h6p  (d=ngày, h=giờ, p=phút)
Ví dụ: {p}{c} on -time=1d  |  {p}{c} on -time=2h30p"""


class AntiAdd:
    """
    Quản lý tính năng Anti-Add cho một bot (uid).

    Storage schema (trong Data-{uid}.json):
        "antiAdd": {
            "enabled": bool,
            "until":   float | null   # epoch; null = vĩnh viễn
        }
    """

    SETTING_KEY = "antiAdd"

    # ─────────────────────────── private helpers ──────────────────────────────

    @staticmethod
    def _parse_duration(raw: str) -> int | None:
        """
        Chuyển chuỗi  Xd Xh Xp  →  giây.
        Ba phần đều tuỳ chọn nhưng phải có ít nhất một.
        """
        m = re.fullmatch(r"(?:(\d+)d)?(?:(\d+)h)?(?:(\d+)p)?", raw.strip().lower())
        if not m or not any(m.groups()):
            return None
        total = (
            int(m.group(1) or 0) * 86400
            + int(m.group(2) or 0) * 3600
            + int(m.group(3) or 0) * 60
        )
        return total if total > 0 else None

    @staticmethod
    def _fmt_duration(seconds: int) -> str:
        d, r = divmod(seconds, 86400)
        h, r = divmod(r, 3600)
        p    = r // 60
        parts = []
        if d: parts.append(f"{d} ngày")
        if h: parts.append(f"{h} giờ")
        if p: parts.append(f"{p} phút")
        return " ".join(parts) or "0 phút"

    @staticmethod
    def _fmt_remaining(until: float) -> str:
        left = max(0, int(until - time.time()))
        if left <= 0:
            return "hết hạn"
        d, r = divmod(left, 86400)
        h, r = divmod(r, 3600)
        p    = r // 60
        parts = []
        if d: parts.append(f"{d}d")
        if h: parts.append(f"{h}h")
        if p: parts.append(f"{p}p")
        return " ".join(parts) or "<1p"

    # ─────────────────────────── storage ──────────────────────────────────────

    def _read(self, uid: str) -> dict:
        s = read_settings(uid)
        return s.get(self.SETTING_KEY, {"enabled": False, "until": None})

    def _write(self, uid: str, cfg: dict) -> None:
        s = read_settings(uid)
        s[self.SETTING_KEY] = cfg
        write_settings(uid, s)

    # ─────────────────────────── public API ───────────────────────────────────

    def is_active(self, uid: str) -> bool:
        """Trả về True nếu antiAdd đang hoạt động (và chưa hết hạn)."""
        cfg = self._read(uid)
        if not cfg.get("enabled"):
            return False
        until = cfg.get("until")
        if until is None:
            return True
        if time.time() < until:
            return True
        # Hết hạn → tự tắt
        self._write(uid, {"enabled": False, "until": None})
        return False

    def enable(self, uid: str, duration: int | None = None) -> dict:
        """
        Bật antiAdd.
        duration = None  →  vĩnh viễn.
        duration = int   →  số giây.
        Trả về cfg đã ghi.
        """
        cfg = {
            "enabled": True,
            "until":   (time.time() + duration) if duration else None,
        }
        self._write(uid, cfg)
        return cfg

    def disable(self, uid: str) -> None:
        """Tắt antiAdd."""
        self._write(uid, {"enabled": False, "until": None})

    def toggle(self, uid: str) -> bool:
        """Toggle; trả về trạng thái MỚI (True = bật)."""
        cfg = self._read(uid)
        new_state = not cfg.get("enabled", False)
        if new_state:
            self.enable(uid)
        else:
            self.disable(uid)
        return new_state

    def get_status_text(self, uid: str) -> str:
        cfg = self._read(uid)
        if not cfg.get("enabled"):
            return "❌ OFF — Bot sẽ không tự rời nhóm khi bị add."
        until = cfg.get("until")
        if until is None:
            return "✅ ON — Bật vĩnh viễn."
        remaining = self._fmt_remaining(until)
        if remaining == "hết hạn":
            return "❌ OFF — Đã hết hạn và tự tắt."
        return f"✅ ON — Còn hiệu lực: {remaining}"

    def on_bot_added(self, bot, group_id: str) -> None:
        """
        Gọi từ event handler khi bot bị add vào nhóm.
        Nếu đang active → leaveGroup ngay.
        """
        if not self.is_active(bot.uid):
            return
        try:
            bot.leaveGroup(group_id, silent=True)
        except Exception as e:
            print(f"[AntiAdd.on_bot_added] leaveGroup({group_id}) error: {e}")

    # ─────────────────────────── command entry-point ──────────────────────────

    def handle(self, bot, message, data, userId, threadId, msg_type) -> None:
        p     = bot.prefix
        c     = bot.rawCommand
        parts = (getattr(message, "text", "") or "").strip().split()

        def ok(text):
            bot.replyMessageStyle(
                text, data, threadId, msg_type,
                color="gr", title="ANTIADD", userId=userId,
            )

        def warn(text):
            bot.replyMessageStyle(
                text, data, threadId, msg_type,
                color="yl", title="WARNING", userId=userId,
            )

        # ── toggle ────────────────────────────────────────────────────────────
        if len(parts) == 1:
            new_state = self.toggle(bot.uid)
            status = "bật ✅" if new_state else "tắt ❌"
            return ok(f"AntiAdd đã được {status}.")

        sub = parts[1].lower()

        # ── status ────────────────────────────────────────────────────────────
        if sub == "status":
            return ok(self.get_status_text(bot.uid))

        # ── off ───────────────────────────────────────────────────────────────
        if sub == "off":
            self.disable(bot.uid)
            return ok("AntiAdd đã tắt ❌\nBot sẽ không tự rời nhóm khi bị add.")

        # ── on [optional -time=...] ───────────────────────────────────────────
        if sub == "on":
            duration  = None
            time_part = next(
                (p2[6:] for p2 in parts[2:] if p2.lower().startswith("-time=")),
                None,
            )

            if time_part:
                duration = self._parse_duration(time_part)
                if duration is None:
                    return warn(
                        f"❌ Định dạng thời gian không hợp lệ: {time_part}\n"
                        f"Ví dụ hợp lệ: 1d  |  2h  |  30p  |  1d5h6p\n"
                        f"d = ngày, h = giờ, p = phút"
                    )

            cfg = self.enable(bot.uid, duration)
            if duration:
                extra = f"⏱ Hiệu lực trong: {self._fmt_duration(duration)}"
            else:
                extra = "⏱ Hiệu lực: vĩnh viễn"

            return ok(
                f"AntiAdd đã bật ✅\n"
                f"{extra}\n"
                f"Bot sẽ tự rời nhóm ngay khi bị add vào."
            )

        # ── unknown sub-command ───────────────────────────────────────────────
        warn(_HELP.format(p=p, c=c))


# ── Singleton ─────────────────────────────────────────────────────────────────
_antiadd = AntiAdd()


# ── Public interface (dùng trong index.py & zaloEvent.py) ─────────────────────

def is_antiadd_active(uid: str) -> bool:
    return _antiadd.is_active(uid)


def handle_antiadd_event(bot, group_id: str) -> None:
    _antiadd.on_bot_added(bot, group_id)


def antiAddCommand(bot, message, data, userId, threadId, msg_type) -> None:
    _antiadd.handle(bot, message, data, userId, threadId, msg_type)


# ── dependencies ──────────────────────────────────────────────────────────────
dependencies = {
    "name":        "antiadd",
    "permission":  3,
    "description": "Tự rời nhóm / cộng đồng khi bot bị add vào. Hỗ trợ hẹn giờ.",
    "cooldown":    3,
    "main":        antiAddCommand,
}
