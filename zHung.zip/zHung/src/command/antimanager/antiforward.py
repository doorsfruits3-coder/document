from app.core.index import *
import json


def isForwardMessage(data):
    try:
        ref = getattr(data, "reference", None)
        if not ref:
            return False
        raw = ref.get("data")
        if not raw:
            return False
        refData = json.loads(raw)
        return bool(refData.get("fwLvl"))
    except:
        return False


def antiForwardCommand(self, message, data, userId, threadId, type):
    p     = self.prefix
    c     = self.rawCommand
    parts = message.text.strip().split()

    settings = read_settings(self.uid)
    antifw   = settings.setdefault("antiForward", [])
    enabled  = threadId in antifw

    if len(parts) < 2:
        enabled = not enabled
    else:
        action = parts[1].lower()
        if action == "on":
            enabled = True
        elif action == "off":
            enabled = False
        else:
            self.replyMessageStyle(
                f"📍Use: {p}{c} on | off",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
            return

    if enabled and threadId not in antifw:
        antifw.append(threadId)
    if not enabled and threadId in antifw:
        antifw.remove(threadId)

    write_settings(self.uid, settings)

    self.replyMessageStyle(
        f"AntiForward đã được {'bật' if enabled else 'tắt'}.",
        data, threadId, type,
        color="gr", title="SUCCESS", userId=userId,
    )


def antiForward(self, message, data, userId, threadId, type):
    if not hasattr(self, "_antiForwardCount"):
        self._antiForwardCount = {}

    settings = read_settings(self.uid)
    antifw   = settings.get("antiForward", [])

    if threadId not in antifw:
        return

    grInfo    = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId, {})
    adminIds  = grInfo.get("adminIds", [])
    creatorId = grInfo.get("creatorId")

    if userId == creatorId or userId in adminIds:
        return
    if admin_of_bot(self, threadId, userId):
        return
    if not isForwardMessage(data):
        return

    key   = (threadId, userId)
    count = self._antiForwardCount.get(key, 0) + 1
    self._antiForwardCount[key] = count

    try:
        self.deleteMessage(data.msgId, data.uidFrom, data.cliMsgId, threadId)
    except:
        pass

    if count < 5:
        remain = 5 - count
        try:
            self.replyMessageStyle(
                f"Không được phép forward tin nhắn trong {self.getGroupTypesE(threadId)}!\n"
                f"Tin nhắn đã bị xoá. Còn {remain} lần nữa sẽ bị kick.",
                data, threadId, type,
                color="yl", title="CẢNH BÁO", userId=userId,
            )
        except Exception:
            pass
        return

    try:
        self.replyMessageStyle(
            "Phát hiện spam forward! Người dùng đã bị kick.",
            data, threadId, type,
            color="r", title="ANTIFORWARD", userId=userId,
        )
    except Exception:
        pass

    self.blockUsers(userId, threadId)
    self._antiForwardCount.pop(key, None)


dependencies = {
    "name":        "antiforward",
    "permission":  2,
    "description": "Anti Forward Message",
    "cooldown":    5,
    "main":        antiForwardCommand,
}
