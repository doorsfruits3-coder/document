from app.core.index import *
from .antibot import antiBot
from .antiforward import antiForward
from .antiurl import antiUrlMessage
from .antispam import antiSpamMessage
from .anticard import antiCard
from .antibadword import antiBadWord
from .antiadd import handle_antiadd_event
from .accessControlList import is_whitelisted
from src.services.utils.mute_core import silentListener
from src.services.utils.var_core import varListener


def handleListenAnti(self, message, data, userId, threadId, type):
    if is_whitelisted(self.uid, userId):
        silentListener(self, message, data, userId, threadId, type)
        varListener(self, message, data, userId, threadId, type)
        return
    antiBot(self, message, data, userId, threadId, type)
    antiForward(self, message, data, userId, threadId, type)
    antiUrlMessage(self, message, data, userId, threadId, type)
    antiSpamMessage(self, message, data, userId, threadId, type)
    antiCard(self, message, data, userId, threadId, type)
    antiBadWord(self, message, data, userId, threadId, type)
    silentListener(self, message, data, userId, threadId, type)
    varListener(self, message, data, userId, threadId, type)
