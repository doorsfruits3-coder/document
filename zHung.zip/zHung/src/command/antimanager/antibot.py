from app.core.index import *


def react(s):
    e, t = [], []
    for c in s:
        (e if c in emoji.EMOJI_DATA else t).append(c)
    return "".join(e), "".join(t).strip()


def detectPlatform(p):
    return {0: "Zalo APP", 1: "Zalo Web", 2: "Zalo PC"}.get(p, "Unknown")


def detectTypeSend(d):
    m = getattr(d, "msgType", "")
    if m == "webchat":
        return "replyMessage" if getattr(d, "quote", None) else "sendMessage"
    return {
        "chat.photo": "sendPhoto",
        "chat.video.msg": "sendVideo",
        "chat.reaction": "sendReaction",
        "chat.recommended": "sendBusinessCard"
    }.get(m, m)


def mentionsData(d):
    if getattr(d, "mentions", None):
        return d.mentions
    a = getattr(d, "attach", None)
    if a:
        try:
            return json.loads(a).get("mentions", [])
        except Exception:
            pass
    return []


def botLogic(self, d):
    s = 0

    uid    = str(getattr(d, "uidFrom", ""))
    userId = str(getattr(d, "userId", ""))
    uin    = str(getattr(d, "uin", ""))
    m      = getattr(d, "msgType", "")
    _raw_c = getattr(d, "content", {})
    if isinstance(_raw_c, str):
        try:
            c = json.loads(_raw_c)
            if not isinstance(c, dict):
                c = {}
        except Exception:
            c = {}
    elif isinstance(_raw_c, dict):
        c = _raw_c
    else:
        c = {}
    pExt   = getattr(d, "paramsExt", None)
    p      = getattr(pExt, "platformType", None) if pExt else None

    if userId == "0" or uin == "0":
        s += 1

    params = c.get("params")
    if (isinstance(params, str) and "styles" in params) or (
        isinstance(params, dict) and "styles" in params
    ):
        s += 10

    if p == 1:
        s += 8
    elif p == 2:
        s += 7
    elif p == 0:
        return 0

    if m in ("chat.photo", "chat.video.msg"):
        href  = str(c.get("href", "")).lower()
        thumb = str(c.get("thumb", "")).lower()

        if "t-" in thumb or "b-" in thumb:
            s += 4

        if p in (1, 2):
            hosts = ("uguu", "catbox", "tmpfiles", "litter", "imgur", "github", "tiktok")
            if any(h in href or h in thumb for h in hosts):
                s += 10

        if mentionsData(d):
            s += 10

    for me in mentionsData(d):
        mid = str(me.uid) if hasattr(me, "uid") else str(me.get("uid"))
        if mid == uid:
            s += 10

    if m == "chat.reaction":
        rIcon = str(c.get("rIcon", ""))
        emoji_part, _ = react(rIcon)
        if emoji_part:
            s += 100

    if m == "chat.recommended":
        desc = c.get("description")
        if isinstance(desc, str):
            try:
                desc = json.loads(desc)
            except Exception:
                desc = {}
        phone = str(desc.get("phone", "")).strip()
        if phone and not re.fullmatch(r"\d+", phone):
            s += 5

    return s


def antiBotCommand(self, message, data, userId, threadId, type):
    p = self.prefix
    c = self.rawCommand

    parts = message.text.strip().split()
    s = read_settings(self.uid)
    a = s.setdefault("antiBot", [])
    enabled = threadId in a

    if len(parts) < 2:
        enabled = not enabled
    elif parts[1].lower() == "on":
        enabled = True
    elif parts[1].lower() == "off":
        enabled = False
    else:
        return self.replyMessageStyle(
            f"📍Use: {p}{c} on | off",
            data, threadId, type,
            color="yl", title="WARNING", userId=userId
        )

    if enabled and threadId not in a:
        a.append(threadId)
    if not enabled and threadId in a:
        a.remove(threadId)

    write_settings(self.uid, s)
    self.replyMessageStyle(
        f"AntiBot đã được {'bật' if enabled else 'tắt'}.",
        data, threadId, type,
        color="gr", title="SUCCESS", userId=userId
    )


def antiBot(self, message, data, userId, threadId, type):
    if not hasattr(self, "_antiBotNotify"):
        self._antiBotNotify = {}
    if not hasattr(self, "_antiBotWarn"):
        self._antiBotWarn = {}

    if threadId not in read_settings(self.uid).get("antiBot", []):
        return

    g = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId, {})
    if userId in g.get("adminIds", []) or userId == g.get("creatorId"):
        return
    if admin_of_bot(self, threadId, userId):
        return

    score = botLogic(self, data)
    if score is None or score < 10:
        return

    key = (threadId, userId)
    now  = time.time()
    last = self._antiBotNotify.get(key, 0)

    m           = getattr(data, "msgType", "")
    is_reaction = (m == "chat.reaction")

    if is_reaction and score >= 100:
        warn_level = self._antiBotWarn.get(key, 0)
        if warn_level == 0:
            self._antiBotWarn[key] = 1
            self._antiBotNotify[key] = now
            try:
                self.replyMessageStyle(
                    "Phát hiện spam reaction nghi bot!\nNếu tiếp tục sẽ bị kick khỏi nhóm.",
                    data, threadId, type,
                    color="yl", title="CẢNH BÁO", userId=userId
                )
            except Exception:
                pass
            return
        else:
            pExt = getattr(getattr(data, "paramsExt", None), "platformType", None)
            self._antiBotNotify[key] = now
            self._antiBotWarn.pop(key, None)
            try:
                self.replyMessageStyle(
                    f"Bot bị phát hiện và đã bị kick!\n"
                    f"Client: {detectPlatform(pExt)}\n"
                    f"Api: {detectTypeSend(data)}",
                    data, threadId, type,
                    color="r", title="ANTIBOT", userId=userId
                )
            except Exception:
                pass
            self.kickUsers(userId, threadId)
            return

    if now - last >= 300:
        self._antiBotNotify[key] = now
        pExt = getattr(getattr(data, "paramsExt", None), "platformType", None)
        try:
            self.replyMessageStyle(
                f"Bot bị phát hiện và đã bị kick!\n"
                f"Client: {detectPlatform(pExt)}\n"
                f"Api: {detectTypeSend(data)}",
                data, threadId, type,
                color="gr", title="ANTIBOT", userId=userId
            )
        except Exception:
            pass

    self.kickUsers(userId, threadId)


dependencies = {
    "name":        "antibot",
    "permission":  2,
    "description": "Anti BOT",
    "cooldown":    5,
    "main":        antiBotCommand,
}