from app.core.index import *
from src.services.init.admin import admin_of_bot

_HELP = """{p}{c} on | off         — Bật/tắt lọc từ cấm
{p}{c} list              — Xem danh sách từ cấm
{p}{c} add <từ>          — Thêm 1 hoặc nhiều từ (phân cách bằng dấu phẩy)
{p}{c} em  <từ>          — Như add, alias tiếng Việt
{p}{c} del <từ>          — Xoá 1 từ khỏi danh sách
{p}{c} clear             — Xoá toàn bộ danh sách từ cấm"""


def _badword_cfg(settings, threadId) -> dict:
    return settings.setdefault("antiBadWord", {}).setdefault(str(threadId), {"enabled": False, "words": []})


def _is_enabled(settings, threadId) -> bool:
    return settings.get("antiBadWord", {}).get(str(threadId), {}).get("enabled", False)


def _get_words(settings, threadId) -> list[str]:
    return settings.get("antiBadWord", {}).get(str(threadId), {}).get("words", [])


def _strip_mentions(text: str, data) -> str:
    try:
        mentions = getattr(data, "mentions", None)
        if not mentions:
            return text
        if isinstance(mentions, str):
            import json as _json
            mentions = _json.loads(mentions)
        if not isinstance(mentions, list):
            return text
        mentions = sorted(mentions, key=lambda x: x.get("pos", 0), reverse=True)
        for m in mentions:
            pos = m.get("pos", 0)
            length = m.get("len", 0)
            text = text[:pos] + text[pos + length:]
        return " ".join(text.split()).strip()
    except Exception:
        return text


def _normalize(text: str) -> str:
    return " ".join(text.lower().split())


def _contains_badword(text: str, words: list[str]) -> str | None:
    t = _normalize(text)
    for w in words:
        if _normalize(w) in t:
            return w
    return None


def antiBadWord(self, message, data, userId, threadId, type):
    settings = read_settings(self.uid)

    if not _is_enabled(settings, str(threadId)):
        return

    raw_text = (getattr(message, "text", "") or "").strip()

    if not raw_text and getattr(data, "msgType", None) == "chat.recommended":
        content  = getattr(data, "content", None)
        raw_text = (getattr(content, "title", "") if content else "") or ""

    raw_text = raw_text.strip()
    if not raw_text:
        return

    text = _strip_mentions(raw_text, data)

    try:
        grInfo    = self.fetchGroupInfo(threadId).gridInfoMap.get(str(threadId), {})
        adminIds  = grInfo.get("adminIds", [])
        creatorId = grInfo.get("creatorId")
    except Exception:
        return

    if userId == creatorId or userId in adminIds:
        return
    if admin_of_bot(self, threadId, userId):
        return

    words   = _get_words(settings, str(threadId))
    matched = _contains_badword(text, words)
    if not matched:
        return

    try:
        self.deleteMessage(data.msgId, data.uidFrom, data.cliMsgId, threadId)
    except Exception:
        pass

    if not hasattr(self, "_antiBadWordWarn"):
        self._antiBadWordWarn = {}

    key   = (str(threadId), str(userId))
    count = self._antiBadWordWarn.get(key, 0) + 1
    self._antiBadWordWarn[key] = count

    if count < 3:
        try:
            self.replyMessageStyle(
                f"Tin nhắn chứa từ cấm \"{matched}\" và đã bị xoá!\n"
                f"Cảnh báo lần {count}/3 — còn {3 - count} lần nữa sẽ bị kick.",
                data, threadId, type,
                color="yl", title="⚠️ CẢNH BÁO", userId=userId,
            )
        except Exception:
            pass
        return

    try:
        self.replyMessageStyle(
            "Vi phạm từ cấm quá 3 lần, đã bị kick khỏi nhóm!",
            data, threadId, type,
            color="r", title="🚫 VI PHẠM", userId=userId,
        )
    except Exception:
        pass

    try:
        self.kickUsers(userId, threadId)
    except Exception:
        pass

    self._antiBadWordWarn.pop(key, None)


def antiBadWordCommand(self, message, data, userId, threadId, type):
    p     = self.prefix
    c     = self.rawCommand
    parts = message.text.strip().split(maxsplit=2)
    sub   = parts[1].lower() if len(parts) > 1 else ""
    arg   = parts[2].strip() if len(parts) > 2 else ""
    tid   = str(threadId)

    settings = read_settings(self.uid)

    def reply(text, color="yl", title="WARNING"):
        self.replyMessageStyle(
            text, data, threadId, type,
            color=color, title=title, userId=userId,
        )

    if sub in ("on", "off"):
        enabled = sub == "on"
        cfg = _badword_cfg(settings, tid)
        cfg["enabled"] = enabled
        write_settings(self.uid, settings)
        return reply(
            f"AntiBadWord đã được {'bật' if enabled else 'tắt'}.",
            color="gr", title="COMPLETE",
        )

    if sub == "list":
        words = _get_words(settings, tid)
        if not words:
            return reply("Danh sách từ cấm đang trống.")
        body = "\n".join(f"  {i+1}. {w}" for i, w in enumerate(words))
        return reply(
            f"Danh sách từ cấm ({len(words)} từ):\n{body}",
            color="or", title="BADWORD LIST",
        )

    if sub in ("add", "em"):
        if not arg:
            return reply(f"Nhập từ cần thêm.\nVí dụ: {p}{c} add từ1, từ2, từ3")
        new_words = [w.strip().lower() for w in arg.split(",") if w.strip()]
        if not new_words:
            return reply("Không có từ hợp lệ để thêm.")
        cfg   = _badword_cfg(settings, tid)
        words = cfg.get("words", [])
        added = [w for w in new_words if w not in words]
        dups  = [w for w in new_words if w in words]
        cfg["words"] = words + added
        write_settings(self.uid, settings)
        lines = []
        if added:
            lines.append(f"✅ Đã thêm: {', '.join(added)}")
        if dups:
            lines.append(f"⚠️ Đã có sẵn: {', '.join(dups)}")
        return reply("\n".join(lines), color="gr", title="COMPLETE")

    if sub == "del":
        if not arg:
            return reply(f"Nhập từ cần xoá.\nVí dụ: {p}{c} del từ1")
        target = arg.strip().lower()
        cfg    = _badword_cfg(settings, tid)
        words  = cfg.get("words", [])
        if target not in words:
            return reply(f"Từ '{target}' không có trong danh sách.")
        words.remove(target)
        cfg["words"] = words
        write_settings(self.uid, settings)
        return reply(f"Đã xoá từ '{target}' khỏi danh sách.", color="gr", title="COMPLETE")

    if sub == "clear":
        cfg = _badword_cfg(settings, tid)
        cfg["words"] = []
        write_settings(self.uid, settings)
        return reply("Đã xoá toàn bộ danh sách từ cấm.", color="gr", title="COMPLETE")

    reply(_HELP.format(p=p, c=c), color="or", title="CAUTION")


dependencies = {
    "name":        "antibadword",
    "permission":  2,
    "cooldown":    3,
    "description": "Chặn tin nhắn chứa từ cấm",
    "main":        antiBadWordCommand,
}