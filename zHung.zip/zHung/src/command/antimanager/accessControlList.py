from app.core.index import *

SETTING_KEY = "acl"
VALID_FLAGS = {"bypass"}


def _read(uid: str) -> dict:
    return read_settings(uid).get(SETTING_KEY, {})


def _write(uid: str, acl: dict) -> None:
    s = read_settings(uid)
    s[SETTING_KEY] = acl
    write_settings(uid, s)


def has_flag(uid: str, userId: str, flag: str) -> bool:
    return flag in _read(uid).get(str(userId), [])


def is_whitelisted(uid: str, userId: str) -> bool:
    return has_flag(uid, userId, "bypass")


def _err(self, msg, data, threadId, type, userId):
    self.replyMessageStyle(msg, data, threadId, type, color="r", title="ERROR", userId=userId)

def _warn(self, msg, data, threadId, type, userId):
    self.replyMessageStyle(msg, data, threadId, type, color="yl", title="WARNING", userId=userId)

def _ok(self, msg, data, threadId, type, userId):
    self.replyMessageStyle(msg, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

def _info(self, msg, data, threadId, type, userId):
    self.replyMessageStyle(msg, data, threadId, type, color="or", title="CAUTION", userId=userId)


def _name(self, uid: str) -> str:
    try:
        return self.userName(str(uid)) or str(uid)
    except Exception:
        return str(uid)


def _targets(self, data) -> list[str]:
    uids = list(extractUids(data) or [])
    if not uids:
        q = getattr(data, "quote", None)
        if q:
            oid = getattr(q, "ownerId", None)
            if oid:
                uids = [str(oid)]
    seen, out = set(), []
    for u in uids:
        s = str(u)
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _parse_flag(raw: str) -> str | None:
    f = raw.lstrip(":").lower()
    return f if f in VALID_FLAGS else None


def aclCommand(self, message, data, userId, threadId, type) -> None:
    p    = self.prefix
    c    = self.rawCommand
    text = (getattr(message, "text", None) or "").strip()

    tokens = [t for t in text.split()[1:] if not t.startswith("@")]
    verb   = tokens[0].lower() if tokens else ""

    if not verb or verb == "help":
        msg = (
            f"Usage\n\n"
            f"  📍 {p}{c} @mention grant :bypass\n"
            f"      Cấp quyền miễn toàn bộ anti cho người được mention.\n\n"
            f"  📍 {p}{c} @mention revoke :bypass\n"
            f"      Thu hồi quyền đã cấp.\n\n"
            f"  📍 {p}{c} inspect @mention\n"
            f"      Xem flags hiện tại của người đó.\n\n"
            f"  📍 {p}{c} --list\n"
            f"      Xem toàn bộ danh sách người dùng được miễn trừ anti."
        )
        return _info(self, msg, data, threadId, type, userId)

    acl = _read(self.uid)

    if verb == "--list":
        if not acl:
            return _warn(self, "Danh sách trống, chưa có entry nào.", data, threadId, type, userId)
        lines = []
        for i, (uid, flags) in enumerate(acl.items(), 1):
            flag_str = "  ".join(f":{f}" for f in sorted(flags)) or "(none)"
            lines.append(f"[{i}] {_name(self, uid)}  ({uid})\n     flags: {flag_str}")
        return _info(self, "\n\n".join(lines), data, threadId, type, userId)

    if verb == "inspect":
        targets = _targets(self, data)
        if not targets:
            return _warn(self, "Mention người cần inspect.", data, threadId, type, userId)
        uid   = targets[0]
        flags = acl.get(uid, [])
        flag_str = "  ".join(f":{f}" for f in sorted(flags)) if flags else "(none)"
        msg = (
            f"uid      {uid}\n"
            f"name     {_name(self, uid)}\n"
            f"flags    {flag_str}"
        )
        return _info(self, msg, data, threadId, type, userId)

    if verb in ("grant", "revoke"):
        targets   = _targets(self, data)
        flag_args = [t for t in tokens[1:] if t.startswith(":")]

        if not targets:
            return _warn(self, "Mention ít nhất một người.", data, threadId, type, userId)
        if not flag_args:
            return _warn(
                self,
                f"Thiếu flag.\n📍 {p}{c} @mention {verb} :bypass",
                data, threadId, type, userId,
            )

        parsed, invalid = [], []
        for raw in flag_args:
            f = _parse_flag(raw)
            if f: parsed.append(f)
            else: invalid.append(raw)

        if invalid:
            return _err(
                self,
                f"Flag không hợp lệ: {', '.join(invalid)}\n"
                f"Flags hỗ trợ: {', '.join(':' + f for f in VALID_FLAGS)}",
                data, threadId, type, userId,
            )

        changed, skipped = [], []

        for uid in targets:
            uid       = str(uid)
            cur_flags = list(acl.get(uid, []))

            if verb == "grant":
                added = [f for f in parsed if f not in cur_flags]
                if added:
                    cur_flags.extend(added)
                    acl[uid] = cur_flags
                    changed.append(f"{_name(self, uid)}  +{' +'.join(added)}")
                else:
                    skipped.append(_name(self, uid))
            else:
                removed = [f for f in parsed if f in cur_flags]
                if removed:
                    acl[uid] = [f for f in cur_flags if f not in removed]
                    if not acl[uid]:
                        del acl[uid]
                    changed.append(f"{_name(self, uid)}  -{' -'.join(removed)}")
                else:
                    skipped.append(_name(self, uid))

        if changed:
            _write(self.uid, acl)

        lines = []
        if changed:
            verb_past = "granted" if verb == "grant" else "revoked"
            lines.append(f"{verb_past}:\n" + "\n".join(f"  {x}" for x in changed))
        if skipped:
            no_op = "flag đã có" if verb == "grant" else "flag không có"
            lines.append(f"no-op ({no_op}):\n" + "\n".join(f"  {x}" for x in skipped))

        return _ok(self, "\n\n".join(lines), data, threadId, type, userId)

    return _err(
        self,
        f"Unknown verb '{verb}'.\n📍 {p}{c} để xem usage.",
        data, threadId, type, userId,
    )


dependencies = {
    "name":        "acl",
    "permission":  2,
    "description": "Access Control List.",
    "cooldown":    3,
    "main":        aclCommand,
}
