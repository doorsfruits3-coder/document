from app.core.index import *
from api.util.Enum import MsgStyle

def aliasCommand(self, message, data, userId, threadId, type):
    text  = message.text or ""
    parts = text.strip().split()
    p     = self.prefix
    c     = self.rawCommand

    config_path = f"data/config/bot/Data-{self.uid}.json"
    config      = load_json(config_path, {"command": []})

    def ok(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color=MsgStyle.SUCCESS.value,
                               title=MsgStyle.SUCCESS.name,
                               userId=userId)

    def warn(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color=MsgStyle.WARNING.value,
                               title=MsgStyle.WARNING.name,
                               userId=userId)

    def err(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color=MsgStyle.ERROR.value,
                               title=MsgStyle.ERROR.name,
                               userId=userId)

    def info(msg):
        self.replyMessageStyle(msg, data, threadId, type,
                               color="or", title="CAUTION",
                               userId=userId)

    if not config.get("command"):
        return err("Data dont have any command")

    cmd_map = {cmd["name"]: cmd for cmd in config["command"]}

    if len(parts) < 2:
        return info(
            f"Alias manager:\n"
            f"  {p}{c} add [command] [alias]\n"
            f"  {p}{c} remove [alias]\n"
            f"  {p}{c} list"
        )

    action = parts[1].lower()

    if action == "list":
        lines     = []
        has_alias = False
        for cmd in config["command"]:
            aliases = cmd.get("alias", [])
            if aliases:
                has_alias = True
                lines.append(f"  {cmd['name']}: {', '.join(aliases)}")

        if not has_alias:
            return warn("Chưa có alias nào được đặt.")

        return info("Alias list:\n" + "\n".join(lines))

    if action == "add":
        if len(parts) < 4:
            return warn(f"Cú pháp: {p}{c} add [command] [alias]")

        cmd_name = parts[2].lower()
        alias    = parts[3].lower()

        if cmd_name not in cmd_map:
            return err(f"Không tìm thấy lệnh: {cmd_name}")

        if alias in self.commands:
            return err(f"'{alias}' đã là tên của một lệnh, không thể dùng làm alias.")

        for cmd in config["command"]:
            if alias in cmd.get("alias", []):
                return warn(f"Alias '{alias}' đã được đặt cho lệnh '{cmd['name']}'.")

        cmd_map[cmd_name].setdefault("alias", []).append(alias)
        save_json(config_path, config)
        return ok(f"Đã thêm alias '{alias}' cho lệnh '{cmd_name}'.")

    if action == "remove":
        if len(parts) < 3:
            return warn(f"Cú pháp: {p}{c} remove [alias]")

        alias   = parts[2].lower()
        removed = False

        for cmd in config["command"]:
            if alias in cmd.get("alias", []):
                cmd["alias"].remove(alias)
                removed = True
                break

        if not removed:
            return err(f"Không tìm thấy alias '{alias}'.")

        save_json(config_path, config)
        return ok(f"Đã xoá alias '{alias}'.")

    err("Subcommand không hợp lệ.")

dependencies = {
    "name":        "alias",
    "permission":  3,
    "description": "Command alias manage",
    "main":        aliasCommand,
}