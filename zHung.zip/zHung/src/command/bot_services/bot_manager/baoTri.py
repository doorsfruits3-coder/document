from app.core.index import *
from api.util.Enum import MsgStyle


def _ok(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.SUCCESS.value, title=MsgStyle.SUCCESS.name)

def _warn(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.WARNING.value, title=MsgStyle.WARNING.name)

def _err(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.name)

def _info(self, msg, data, threadId, type):
    self.replyMessageStyle(msg, data, threadId, type,
                           color=MsgStyle.INFO.value, title="Bảo Trì")


def _resolve_cmd(self, target: str) -> str | None:
    target = target.lower()
    # Khớp trực tiếp với tên lệnh
    if target in self.commands:
        return target
    # Tìm qua alias trong config
    config_path = f"data/config/bot/Data-{self.uid}.json"
    config = load_json(config_path, {"command": []})
    for cmd in config.get("command", []):
        if target in cmd.get("alias", []):
            return cmd["name"]
    return None

def baoTriCommand(self, message, data, userId, threadId, type):
    text  = message.text or ""
    parts = text.strip().split()
    name  = self.userName(userId)
    p     = self.prefix
    c     = self.rawCommand

    settings    = read_settings(self.uid)
    maintenance = settings.setdefault("maintenance", [])

    if len(parts) < 2:
        return _info(self,
            f"Quản lý bảo trì lệnh:\n"
            f"  {p}{c} add [lệnh/alias]  — Đưa lệnh vào bảo trì\n"
            f"  {p}{c} rm  [lệnh/alias]  — Gỡ lệnh khỏi bảo trì\n"
            f"  {p}{c} list               — Xem danh sách đang bảo trì",
            data, threadId, type
        )

    action = parts[1].lower()

    if action == "list":
        if not maintenance:
            return _warn(self,
                "Hiện không có lệnh nào đang trong chế độ bảo trì.",
                data, threadId, type
            )
        lines = "\n".join(f"  • {cmd}" for cmd in sorted(maintenance))
        return _info(self,
            f"Danh sách lệnh đang bảo trì ({len(maintenance)}):\n{lines}",
            data, threadId, type
        )

    # ── add ───────────────────────────────────────────────────────────────
    if action == "add":
        if len(parts) < 3:
            return _warn(self,
                f"Cú pháp: {p}{c} add [tên lệnh hoặc alias]",
                data, threadId, type
            )
        target   = parts[2].lower()
        real_cmd = _resolve_cmd(self, target)
        if not real_cmd:
            return _err(self,
                f"Không tìm thấy lệnh hoặc alias: '{target}'",
                data, threadId, type
            )
        if real_cmd == c:
            return _err(self,
                "Không thể đưa lệnh bảo trì vào chính nó.",
                data, threadId, type
            )
        if real_cmd in maintenance:
            return _warn(self,
                f"Lệnh '{real_cmd}' đã đang trong chế độ bảo trì rồi.",
                data, threadId, type
            )
        maintenance.append(real_cmd)
        write_settings(self.uid, settings)
        return _ok(self,
            f"Đã đưa lệnh '{real_cmd}' vào bảo trì.\n"
            f"Chỉ Hight Admin mới có thể sử dụng lệnh này!",
            data, threadId, type
        )

    # ── rm / remove ───────────────────────────────────────────────────────
    if action in ("rm", "remove"):
        if len(parts) < 3:
            return _warn(self,
                f"Cú pháp: {p}{c} rm [tên lệnh hoặc alias]",
                data, threadId, type
            )
        target   = parts[2].lower()
        real_cmd = _resolve_cmd(self, target)
        # Nếu không resolve được, thử tìm trực tiếp trong danh sách maintenance
        if not real_cmd:
            real_cmd = target if target in maintenance else None
        if not real_cmd or real_cmd not in maintenance:
            return _err(self,
                f"Lệnh '{target}' không có trong danh sách bảo trì.",
                data, threadId, type
            )
        maintenance.remove(real_cmd)
        write_settings(self.uid, settings)
        return _ok(self,
            f"Đã gỡ lệnh '{real_cmd}' khỏi bảo trì.\n"
            f"Lệnh này đã hoạt động trở lại bình thường.",
            data, threadId, type
        )

    # ── invalid ───────────────────────────────────────────────────────────
    _err(self,
        f"Subcommand không hợp lệ, vui lòng thử lại.",
        data, threadId, type
    )

dependencies = {
    "name":        "baotri",
    "permission":  3,
    "description": "Quản lý bảo trì lệnh.",
    "cooldown":    3,
    "main":        baoTriCommand,
}
