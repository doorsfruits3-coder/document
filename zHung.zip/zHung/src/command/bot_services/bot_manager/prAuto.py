from app.core.index import *
import mimetypes
import urllib.parse
import urllib.request

def _getAllGroups(self):
    try:
        result = self.fetchAllGroups()
        grid = getattr(result, "gridVerMap", None) or {}
        if not isinstance(grid, dict):
            try:
                grid = dict(grid)
            except Exception:
                grid = {}
        return [str(gid) for gid in grid.keys()]
    except Exception:
        return []

def _isAllMode(groups):
    return isinstance(groups, list) and len(groups) == 1 and groups[0] == -1

def _guessExt(url, content_type=""):
    path = urllib.parse.urlparse(url or "").path or ""
    ext = os.path.splitext(path)[1].lower()
    if ext and len(ext) <= 8:
        return ext
    ct = (content_type or "").split(";")[0].strip().lower()
    if ct:
        mapped = {
            "image/jpeg": ".jpg",
            "image/png": ".png",
            "image/webp": ".webp",
            "image/gif": ".gif",
            "video/mp4": ".mp4",
            "video/quicktime": ".mov",
            "video/x-matroska": ".mkv",
            "video/webm": ".webm",
        }.get(ct)
        if mapped:
            return mapped
        ext2 = mimetypes.guess_extension(ct) or ""
        if ext2:
            return ext2
    return ".bin"

def _downloadFile(url, timeout=30):
    url = (url or "").strip()
    if not url:
        return "", "", b""
    try:
        r = requests.get(url, timeout=timeout, stream=True, headers={"User-Agent": "Mozilla/5.0"})
        r.raise_for_status()
        ct = r.headers.get("Content-Type", "") or ""
        data = r.content
    except Exception:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            ct = resp.headers.get("Content-Type", "") or ""
            data = resp.read()
    if not data:
        return "", "", b""
    import tempfile as _tempfile
    fd, path = _tempfile.mkstemp(prefix="pr-", suffix=_guessExt(url, ct))
    os.close(fd)
    with open(path, "wb") as f:
        f.write(data)
    return path, ct, data

def _imageWhFromBytes(data_bytes):
    if not data_bytes:
        return 1280, 720
    try:
        from io import BytesIO
        with Image.open(BytesIO(data_bytes)) as im:
            return int(im.size[0]), int(im.size[1])
    except Exception:
        return 1280, 720

def _ffmpegPath():
    return "ffmpeg"

def _ffprobePath():
    return "ffprobe"

def _getVideoMeta(file_path):
    try:
        r = subprocess.run(
            [
                _ffprobePath(),
                "-v", "error",
                "-select_streams", "v:0",
                "-show_entries", "stream=width,height:format=duration",
                "-of", "json",
                file_path,
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        d = json.loads((r.stdout or "").strip() or "{}")
        st = (d.get("streams") or [{}])[0] or {}
        fm = d.get("format") or {}
        return int(st.get("width") or 1280), int(st.get("height") or 720), int(float(fm.get("duration") or 0))
    except Exception:
        return 1280, 720, 0

def _makeVideoThumb(file_path, width=1280, height=720):
    import tempfile as _tempfile
    out = _tempfile.NamedTemporaryFile(delete=False, suffix=".jpg").name
    vf = f"scale={int(width)}:{int(height)}:force_original_aspect_ratio=decrease"
    subprocess.run(
        [_ffmpegPath(), "-y", "-ss", "0.5", "-i", file_path, "-vframes", "1", "-vf", vf, out],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    if os.path.exists(out) and os.path.getsize(out) > 0:
        return out
    try:
        os.remove(out)
    except Exception:
        pass
    return ""

def _uploadThumb(self, thumb_path, thread_id, ttype):
    if not thumb_path:
        return ""
    try:
        res = self._uploadImage(thumb_path, thread_id, ttype)
        if isinstance(res, dict):
            for k in ("hdUrl", "href", "url", "downloadUrl", "fileUrl"):
                v = res.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()
    except Exception:
        pass
    finally:
        try:
            os.remove(thumb_path)
        except Exception:
            pass
    return ""

def _normalizePrContent(v):
    if isinstance(v, dict):
        ctx = (v.get("context") or "").strip()
        imgs = v.get("imageAttachment")
        vids = v.get("videoAttachment")
        if isinstance(imgs, str):
            imgs = [imgs] if imgs.strip() else []
        elif not isinstance(imgs, list):
            imgs = []
        if isinstance(vids, str):
            vids = [vids] if vids.strip() else []
        elif not isinstance(vids, list):
            vids = []
        return {
            "context": ctx,
            "imageAttachment": [str(x).strip() for x in imgs if str(x).strip()],
            "videoAttachment": [str(x).strip() for x in vids if str(x).strip()],
        }
    return {"context": (v or "").strip(), "imageAttachment": [], "videoAttachment": []}

def _extractUrls(attach):
    if isinstance(attach, str):
        try:
            attach = json.loads(attach) if attach else {}
        except Exception:
            attach = {"href": attach}
    if not isinstance(attach, dict):
        return [], attach
    urls = []
    for k in ("href", "hdUrl", "url", "originUrl", "downloadUrl", "fileUrl"):
        v = attach.get(k)
        if isinstance(v, str) and v.strip().startswith("http"):
            urls.append(v.strip())
    items = attach.get("items") or attach.get("data") or attach.get("medias") or attach.get("list")
    if isinstance(items, list):
        for it in items:
            if isinstance(it, str) and it.strip().startswith("http"):
                urls.append(it.strip())
            elif isinstance(it, dict):
                for k in ("href", "hdUrl", "url", "originUrl", "downloadUrl", "fileUrl"):
                    v = it.get(k)
                    if isinstance(v, str) and v.strip().startswith("http"):
                        urls.append(v.strip())
    return list(dict.fromkeys(urls)), attach

def _parseTimes(parts, start_index):
    raw = " ".join(parts[start_index:]).strip()
    if not raw:
        return []
    raw = raw.replace(";", ",").replace("|", ",")
    seen = set()
    out = []
    for chunk in raw.split(","):
        for t in chunk.strip().split():
            if ":" not in t:
                continue
            hh, mm = t.split(":", 1)
            if not (hh.isdigit() and mm.isdigit()):
                continue
            h, m = int(hh), int(mm)
            if 0 <= h <= 23 and 0 <= m <= 59:
                s = f"{h:02d}:{m:02d}"
                if s not in seen:
                    seen.add(s)
                    out.append(s)
    return out

def _shouldFireNow(self, times_list):
    if not times_list:
        return False
    hm = datetime.now().strftime("%H:%M")
    if hm not in times_list:
        return False
    key = datetime.now().strftime("%Y%m%d") + "|" + hm
    if getattr(self, "_prLastTick", "") == key:
        return False
    self._prLastTick = key
    return True

def _sendVideoWithMeta(self, video_url, thread_id, ttype):
    video_path, _, _ = _downloadFile(video_url)
    if not video_path:
        return
    try:
        w, h, dur = _getVideoMeta(video_path)
        thumb_url = _uploadThumb(self, _makeVideoThumb(video_path, w, h), thread_id, ttype)
        self.sendRemoteVideo(video_url, thumb_url, int(dur), thread_id, ttype, width=int(w), height=int(h))
    except Exception as e:
        logger.error(f"PR sendVideo error: {e}")
    finally:
        try:
            os.remove(video_path)
        except Exception:
            pass

def _sendPrContent(self, thread_id, ttype, content=None):
    content = _normalizePrContent(content)
    ctx = content.get("context") or "..."
    imgs = content.get("imageAttachment") or []
    vids = content.get("videoAttachment") or []

    from api.util.msg import Message as Msg
    self.send(Msg(text=ctx), thread_id, ttype)
    time.sleep(0.25)

    if imgs:
        _, _, b = _downloadFile(imgs[0])
        w, h = _imageWhFromBytes(b)
        if len(imgs) == 1:
            self.sendRemoteImage(imgs[0], thread_id, ttype, width=int(w), height=int(h))
        else:
            self.sendMultiRemoteImage(imgs, thread_id, ttype, width=int(w), height=int(h))
        time.sleep(0.25)

    for vurl in vids:
        _sendVideoWithMeta(self, vurl, thread_id, ttype)
        time.sleep(0.25)

def _prOnce(self, gids):
    content = _normalizePrContent((read_settings(self.uid) or {}).get("prContent"))
    for gid in gids:
        try:
            _sendPrContent(self, gid, ThreadType.GROUP, content)
        except Exception as e:
            logger.error(f"PR error gid={gid}: {e}")

def _prWorker(self):
    while True:
        pr = read_settings(self.uid) or {}
        if not pr.get("prAuto", False):
            break
        groups = pr.get("prGroups", [])
        gids = _getAllGroups(self) if _isAllMode(groups) else [str(g) for g in groups if g != -1]
        times_list = pr.get("prTimes")
        if isinstance(times_list, str):
            times_list = [times_list]
        times_list = [str(x).strip() for x in times_list if str(x).strip()] if isinstance(times_list, list) else []
        if times_list:
            if gids and _shouldFireNow(self, times_list):
                _prOnce(self, gids)
            time.sleep(1)
        else:
            if gids:
                _prOnce(self, gids)
            time.sleep(30)

def _startPR(self):
    t = getattr(self, "_prThread", None)
    if t and t.is_alive():
        return
    self._prThread = threading.Thread(target=_prWorker, args=(self,), daemon=True)
    self._prThread.start()

def _initPR(self):
    pr = read_settings(self.uid) or {}
    groups = pr.get("prGroups", [])
    gids = _getAllGroups(self) if (_isAllMode(groups) or not groups) else [str(g) for g in groups if g != -1]
    if gids:
        _prOnce(self, gids)

def _uniqMerge(base_list, add_list):
    seen = set()
    out = []
    for x in (base_list if isinstance(base_list, list) else []) + (add_list if isinstance(add_list, list) else []):
        s = str(x).strip()
        if s and s not in seen:
            seen.add(s)
            out.append(s)
    return out

def _buildPrContentFromQuote(data, fallback_text=""):
    q = getattr(data, "quote", None)
    out = {"context": (fallback_text or "").strip(), "videoAttachment": [], "imageAttachment": []}
    if not q:
        return out
    mt = getattr(q, "cliMsgType", None)
    if mt == 1:
        out["context"] = (getattr(q, "msg", "") or "").strip() or out["context"]
        return out
    urls, attach = _extractUrls(getattr(q, "attach", None))
    if not urls:
        return out
    is_video = (mt == 44) or bool(isinstance(attach, dict) and (attach.get("duration") or attach.get("video") or attach.get("isVideo")))
    out["videoAttachment" if is_video else "imageAttachment"] = urls
    return out

def _prDetailText(pr):
    content = _normalizePrContent(pr.get("prContent"))
    lines = [f"Content: {content.get('context') or '(empty)'}"]
    if content.get("videoAttachment"):
        lines.append("Video:")
        for i, u in enumerate(content["videoAttachment"], 1):
            lines.append(f"{i}. {u}")
    if content.get("imageAttachment"):
        lines.append("Images:")
        for i, u in enumerate(content["imageAttachment"], 1):
            lines.append(f"{i}. {u}")
    times_list = pr.get("prTimes")
    if isinstance(times_list, str):
        times_list = [times_list]
    times_list = [str(x).strip() for x in times_list if str(x).strip()] if isinstance(times_list, list) else []
    lines.append("")
    lines.append("Time: " + (", ".join(sorted(set(times_list))) if times_list else "None"))
    lines.append(f"Status: {bool(pr.get('prAuto', False))}")
    return "\n".join(lines)

def _ok(self, text, data, userId, threadId, type):
    self.replyMessageStyle(text, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

def _warn(self, text, data, userId, threadId, type):
    self.replyMessageStyle(text, data, threadId, type, color="yl", title="WARNING", userId=userId)

def _err(self, text, data, userId, threadId, type):
    self.replyMessageStyle(text, data, threadId, type, color="r", title="ERROR", userId=userId)

def prCommand(self, message, data, userId, threadId, type):
    parts = (message.text or "").strip().split()
    pr_help = (
        f"{self.prefix}pr start/stop — bật/tắt auto PR\n"
        f"{self.prefix}pr init — gửi ngay 1 lần\n"
        f"{self.prefix}pr preview — xem trước nội dung\n"
        f"{self.prefix}pr detail — xem cấu hình\n"
        f"{self.prefix}pr add [all] — thêm nhóm hiện tại (hoặc tất cả)\n"
        f"{self.prefix}pr remove [all] — xóa nhóm hiện tại (hoặc tất cả)\n"
        f"{self.prefix}pr set <nội dung> — đặt text (hoặc reply ảnh/video)\n"
        f"{self.prefix}pr set reset — xóa toàn bộ nội dung\n"
        f"{self.prefix}pr set rm video|image <index|all>\n"
        f"{self.prefix}pr time add|rm <HH:MM ...> — quản lý giờ gửi\n"
        f"{self.prefix}pr time list"
    )

    if len(parts) < 2:
        return _warn(self, pr_help, data, userId, threadId, type)

    action = parts[1].lower()
    pr = read_settings(self.uid) or {}
    pr.setdefault("prGroups", [])
    tid = str(threadId)

    if action == "help":
        return _warn(self, pr_help, data, userId, threadId, type)

    if action == "start":
        pr["prAuto"] = True
        write_settings(self.uid, pr)
        _startPR(self)
        return _ok(self, "PR started", data, userId, threadId, type)

    if action == "stop":
        pr["prAuto"] = False
        write_settings(self.uid, pr)
        return _ok(self, "PR stopped", data, userId, threadId, type)

    if action == "init":
        _initPR(self)
        return _ok(self, "PR init done", data, userId, threadId, type)

    if action == "preview":
        content = _normalizePrContent(pr.get("prContent"))
        if not content.get("context") and not content.get("imageAttachment") and not content.get("videoAttachment"):
            return _warn(self, "Empty content", data, userId, threadId, type)
        try:
            _sendPrContent(self, threadId, type, content)
            return _ok(self, "PR preview done", data, userId, threadId, type)
        except Exception as e:
            return _err(self, str(e), data, userId, threadId, type)

    if action == "detail":
        return _ok(self, _prDetailText(pr), data, userId, threadId, type)

    if action == "time":
        if len(parts) < 3:
            return _warn(self, pr_help, data, userId, threadId, type)
        sub = parts[2].lower()
        times_list = pr.get("prTimes")
        if isinstance(times_list, str):
            times_list = [times_list]
        times_list = [str(x).strip() for x in times_list if str(x).strip()] if isinstance(times_list, list) else []

        if sub == "list":
            return _ok(self, "\n".join(sorted(set(times_list))) if times_list else "No times", data, userId, threadId, type)

        items = _parseTimes(parts, 3)
        if not items:
            return _warn(self, "No valid time (use HH:MM format)", data, userId, threadId, type)

        s = set(times_list)
        if sub == "add":
            s.update(items)
            pr["prTimes"] = sorted(s)
            write_settings(self.uid, pr)
            return _ok(self, "Added: " + ", ".join(items), data, userId, threadId, type)
        if sub == "rm":
            removed = [t for t in items if t in s]
            for t in removed:
                s.remove(t)
            pr["prTimes"] = sorted(s)
            write_settings(self.uid, pr)
            return _ok(self, "Removed: " + (", ".join(removed) if removed else "None"), data, userId, threadId, type)
        return _warn(self, pr_help, data, userId, threadId, type)

    if action == "add":
        if len(parts) >= 3 and parts[2].lower() == "all":
            pr["prGroups"] = [-1]
            write_settings(self.uid, pr)
            return _ok(self, "PR set to all groups", data, userId, threadId, type)
        if -1 in pr["prGroups"]:
            return _warn(self, "PR is in all-groups mode", data, userId, threadId, type)
        if tid not in pr["prGroups"]:
            pr["prGroups"].append(tid)
            write_settings(self.uid, pr)
        return _ok(self, "Added current group to PR", data, userId, threadId, type)

    if action == "remove":
        if len(parts) >= 3 and parts[2].lower() == "all":
            pr["prGroups"] = []
            write_settings(self.uid, pr)
            return _ok(self, "Removed all groups from PR", data, userId, threadId, type)
        if tid in pr["prGroups"]:
            pr["prGroups"].remove(tid)
            write_settings(self.uid, pr)
        return _ok(self, "Removed current group from PR", data, userId, threadId, type)

    if action == "set":
        try:
            sub = parts[2].lower() if len(parts) >= 3 else ""
            cur = _normalizePrContent(pr.get("prContent"))

            if sub == "reset":
                pr["prContent"] = {"context": "", "videoAttachment": [], "imageAttachment": []}
                write_settings(self.uid, pr)
                return _ok(self, "PR content reset", data, userId, threadId, type)

            if sub == "rm" and len(parts) >= 5:
                kind = parts[3].lower()
                arg = parts[4].lower()
                if kind not in ("video", "image"):
                    return _warn(self, "Use: set rm video|image <index|all>", data, userId, threadId, type)
                key = "videoAttachment" if kind == "video" else "imageAttachment"
                arr = cur.get(key) or []
                if arg == "all":
                    cur[key] = []
                    pr["prContent"] = cur
                    write_settings(self.uid, pr)
                    return _ok(self, f"Cleared {kind}", data, userId, threadId, type)
                if not arg.isdigit():
                    return _warn(self, "Invalid index", data, userId, threadId, type)
                idx = int(arg)
                if idx <= 0 or idx > len(arr):
                    return _warn(self, "Index out of range", data, userId, threadId, type)
                arr.pop(idx - 1)
                cur[key] = arr
                pr["prContent"] = cur
                write_settings(self.uid, pr)
                return _ok(self, f"Removed {kind} #{idx}", data, userId, threadId, type)

            neu = _buildPrContentFromQuote(data, " ".join(parts[2:]).strip())
            if neu.get("context"):
                cur["context"] = neu["context"]
            if neu.get("imageAttachment"):
                cur["imageAttachment"] = _uniqMerge(cur.get("imageAttachment"), neu.get("imageAttachment"))
            if neu.get("videoAttachment"):
                cur["videoAttachment"] = _uniqMerge(cur.get("videoAttachment"), neu.get("videoAttachment"))
            if not cur.get("context") and not cur.get("imageAttachment") and not cur.get("videoAttachment"):
                return _warn(self, "Empty content", data, userId, threadId, type)
            pr["prContent"] = cur
            write_settings(self.uid, pr)
            return _ok(self, "PR content saved", data, userId, threadId, type)
        except Exception as e:
            return _err(self, str(e), data, userId, threadId, type)

    return _warn(self, pr_help, data, userId, threadId, type)


dependencies = {
    "name": "pr",
    "permission": 3,
    "cooldown": 2,
    "description": "Auto PR content to groups",
    "main": prCommand,
}