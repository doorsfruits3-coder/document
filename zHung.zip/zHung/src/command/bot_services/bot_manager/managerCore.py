from app.core.index import *
import os


def managerCommand(self, message, data, userId, threadId, type):
    try:
        p = self.prefix
        c = self.rawCommand

        text  = message.text or ""
        if p and not text.startswith(p):
            return

        text  = text[len(p):].strip() if p else text.strip()
        parts = text.split()

        if not parts or parts[0].lower() != c:
            return

        def info(msg):
            return self.replyMessageStyle(msg, data, threadId, type, color="yl", title="MANAGER", userId=userId)

        def success(msg):
            return self.replyMessageStyle(msg, data, threadId, type, color="gr", title="SUCCESS", userId=userId)

        def warn(msg):
            return self.replyMessageStyle(msg, data, threadId, type, color="r", title="WARNING", userId=userId)

        if len(parts) == 1:
            return info(
                f"{p}{c} listen  -help\n"
                f"{p}{c} data    -help"
            )

        sub = parts[1].lower()

        if sub == "listen":
            if len(parts) == 2:
                return info(
                    f"{p}{c} listen  -help\n"
                    f"{p}{c} data    -help"
                )

            arg = parts[2].lower()

            if arg == "-help":
                return info(
                    f"{p}{c} listen add      - cho phép bot nhận lệnh tại thread này\n"
                    f"{p}{c} listen rm       - tắt bot nhận lệnh tại thread này\n"
                    f"{p}{c} listen -status  - kiểm tra trạng thái\n"
                    f"\n"
                    f"⚠️  listen add/rm chỉ kiểm soát việc bot có PHẢN HỒI LỆNH ở đây không.\n"
                    f"    Tin nhắn vẫn được đếm cho alys bất kể trạng thái listen."
                )

            settings    = read_settings(self.uid)
            allow_group = settings.setdefault("allowGroup", [])
            is_group    = type.name == "GROUP"
            location    = f"nhóm {self.groupInfo(threadId)}" if is_group else "chat riêng này"

            if arg == "add":
                if threadId not in allow_group:
                    allow_group.append(threadId)
                    write_settings(self.uid, settings)
                return success(
                    f"Đã bật nhận lệnh tại {location}.\n"
                )

            if arg == "rm":
                if threadId in allow_group:
                    allow_group.remove(threadId)
                    write_settings(self.uid, settings)
                return warn(
                    f"Đã tắt nhận lệnh tại {location}.\n"
                )

            if arg == "-status":
                state = "ON" if threadId in allow_group else "OFF"
                return info(f"Nhận lệnh tại {location}: {state}")

            if arg == "usr":
                settings     = read_settings(self.uid)
                listen_users = settings.setdefault("listenUsers", [])
                uids         = extractUids(data)

                if len(parts) < 4:
                    return info(
                        f"{p}{c} listen usr add @..  - thêm user được dùng lệnh mọi nơi\n"
                        f"{p}{c} listen usr rm  @..  - xoá user khỏi danh sách\n"
                        f"{p}{c} listen usr list     - xem danh sách"
                    )

                usr_arg = parts[3].lower()

                if usr_arg == "list":
                    if not listen_users:
                        return info("Chưa có user nào trong danh sách listenUsers.")
                    lines = [f"  • {self.userName(uid)} ({uid})" for uid in listen_users]
                    return info(f"Danh sách listenUsers ({len(listen_users)}):\n" + "\n".join(lines))

                if usr_arg == "add":
                    if not uids:
                        return warn("Vui lòng @mention user cần thêm.")
                    added, already = [], []
                    for uid in uids:
                        if uid in listen_users:
                            already.append(self.userName(uid))
                        else:
                            listen_users.append(uid)
                            added.append(self.userName(uid))
                    write_settings(self.uid, settings)
                    lines = []
                    if added:
                        lines.append(f"Đã thêm: {', '.join(added)}")
                    if already:
                        lines.append(f"Đã có sẵn: {', '.join(already)}")
                    return success("\n".join(lines))

                if usr_arg == "rm":
                    if not uids:
                        return warn("Vui lòng @mention user cần xoá.")
                    removed, not_found = [], []
                    for uid in uids:
                        if uid in listen_users:
                            listen_users.remove(uid)
                            removed.append(self.userName(uid))
                        else:
                            not_found.append(self.userName(uid))
                    write_settings(self.uid, settings)
                    lines = []
                    if removed:
                        lines.append(f"Đã xoá: {', '.join(removed)}")
                    if not_found:
                        lines.append(f"Không có trong danh sách: {', '.join(not_found)}")
                    return success("\n".join(lines)) if removed else warn("\n".join(lines))

                return info(
                    f"{p}{c} listen usr add @..  - thêm user\n"
                    f"{p}{c} listen usr rm  @..  - xoá user\n"
                    f"{p}{c} listen usr list     - xem danh sách"
                )

            return info(
                f"{p}{c} listen  -help\n"
                f"{p}{c} data    -help"
            )

        if sub == "data":
            if len(parts) == 2:
                return info(
                    f"{p}{c} listen  -help\n"
                    f"{p}{c} data    -help"
                )

            arg = parts[2].lower()

            if arg == "-help":
                return info(f"{p}{c} data rm  - xoá file data config của bot này (chỉ xoá data của chính mình)")

            if arg == "rm":
                data_path = f"data/config/bot/Data-{self.uid}.json"
                if not os.path.exists(data_path):
                    return warn("File data không tồn tại.")
                try:
                    os.remove(data_path)
                    return success(f"Đã xoá file data config của bot {self.uid}.\nBot sẽ load lại data mặc định khi cần.")
                except Exception as e:
                    return warn(f"Xoá thất bại: {e}")

            return info(
                f"{p}{c} listen  -help\n"
                f"{p}{c} data    -help"
            )

        return info(
            f"{p}{c} listen  -help\n"
            f"{p}{c} data    -help"
        )

    except Exception as e:
        print("managerCommand error:", e)
        return self.replyMessageStyle(
            "error", data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


dependencies = {
    "name":        "manager",
    "permission":  3,
    "cooldown":    2,
    "description": "Quản lý listen (nhận lệnh) và data config.",
    "main":        managerCommand,
}
