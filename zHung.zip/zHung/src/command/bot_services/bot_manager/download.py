"""
download.py  –  Lệnh download video / audio cho zBot
Đặt file này vào:  zBot/src/command/bot_services/download.py
"""

import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.core.index import *
from src.command.bot_services.download_core import (
    process_single_link,
    get_platform_info,
    MAX_WORKERS,
)

URL_RE = re.compile(r"https?://\S+", re.I)


# ── Auto-download state ────────────────────────────────────────────────────────

def _read_dl_auto(self, thread_id: str) -> bool:
    from src.services.utils.jsonio import load_json
    data = load_json(f"data/config/bot/Data-{self.uid}.json", {})
    return str(thread_id) in data.get("dlAuto", [])


def _write_dl_auto(self, thread_id: str, enabled: bool) -> bool:
    from src.services.utils.jsonio import load_json, save_json
    path  = f"data/config/bot/Data-{self.uid}.json"
    data  = load_json(path, {})
    arr   = data.setdefault("dlAuto", [])
    tid   = str(thread_id)
    if enabled and tid not in arr:
        arr.append(tid)
    if not enabled and tid in arr:
        arr.remove(tid)
    save_json(path, data)
    return enabled


def _toggle_dl_auto(self, thread_id: str) -> bool:
    return _write_dl_auto(self, thread_id, not _read_dl_auto(self, thread_id))


# ── Parallel runner ────────────────────────────────────────────────────────────

def _start_parallel(self, data, user_id, thread_id, type, links, is_audio):
    links = (links or [])[:10]
    if not links:
        return

    def _run():
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as ex:
            fts = [
                ex.submit(process_single_link, i, u, is_audio, thread_id, type, self, data, user_id)
                for i, u in enumerate(links)
            ]
            for ft in as_completed(fts):
                try:
                    ft.result()
                except Exception as e:
                    print(f"[Download] parallel error: {e}")

    threading.Thread(target=_run, daemon=True).start()


# ── Command handler ────────────────────────────────────────────────────────────

def handleDownload(self, message, data, userId, threadId, type):
    text = (getattr(message, "text", None) or "").strip()
    args = text.split()

    if len(args) < 2:
        self.replyMessageStyle(
            "Vui lòng cung cấp URL.\n"
            f"Ví dụ: {self.prefix}{self.rawCommand} https://...\n"
            f"Tùy chọn: thêm -a để tải âm thanh\n"
            f"         --auto on/off để bật/tắt tự động",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        return

    # --auto toggle
    if "--auto" in args:
        action = None
        for a in args[2:]:
            if a.lower() in ("on", "off"):
                action = a.lower()
                break
        if action == "on":
            enabled = _write_dl_auto(self, threadId, True)
        elif action == "off":
            enabled = _write_dl_auto(self, threadId, False)
        else:
            enabled = _toggle_dl_auto(self, threadId)

        status = "bật ✅" if enabled else "tắt ❌"
        self.replyMessageStyle(
            f"Tự động tải video đã được {status}.",
            data, threadId, type,
            color="gr" if enabled else "r",
            title="AUTO DOWNLOAD",
            userId=userId,
        )
        return

    is_audio = "-a" in args
    if is_audio:
        args = [x for x in args if x != "-a"]

    links = [x for x in args[1:] if x.startswith("http")]
    if not links:
        self.replyMessageStyle(
            "URL không hợp lệ.",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )
        return

    _start_parallel(self, data, userId, threadId, type, links, is_audio)


# ── Danh sách msgType KHÔNG phải tin nhắn text thuần → bỏ qua ─────────────────
# chat.photo / chat.video.msg: message.text bị gán = href (CDN URL của ảnh/video Zalo)
# chat.sticker / chat.gif / chat.voice / ...: không thể chứa link nền tảng
_SKIP_MSG_TYPES = frozenset({
    "chat.photo",
    "chat.photo.msg",
    "chat.video.msg",
    "chat.sticker",
    "chat.gif",
    "chat.voice",
    "chat.doodle",
    "chat.location.new",
    "share.file",
    "chat.reaction",
    "chat.delete",
    "chat.revoke",
})

# Domain nội bộ của Zalo — không bao giờ là link nền tảng hợp lệ
_ZALO_DOMAINS = (
    "zalo.me",
    "zadn.vn",
    "zaloapp.com",
    "chat.zalo.me",
    "tt-files.chat.zalo.me",
    "covers.zalo.me",
    "hdcover.zadn.vn",
    "image.zadn.vn",
    "zalo-api.zadn.vn",
    "stc-zmp.zdn.vn",
    "stc-znews.zdn.vn",
)

# Chỉ xử lý link từ các nền tảng được hỗ trợ
_SUPPORTED_DOMAINS = (
    "tiktok.com",
    "vt.tiktok.com",
    "vm.tiktok.com",
    "facebook.com",
    "fb.watch",
    "fb.com",
    "youtube.com",
    "youtu.be",
    "instagram.com",
    "threads.net",
    "threads.com",
    "soundcloud.com",
    "spotify.com",
    "open.spotify.com",
    "capcut.com",
)


def _is_supported_link(url: str) -> bool:
    """Chỉ trả về True nếu URL thuộc nền tảng được hỗ trợ (không phải CDN Zalo)."""
    u = url.lower()
    return any(d in u for d in _SUPPORTED_DOMAINS)


# ── Auto-link listener (gọi từ onMessage) ─────────────────────────────────────

def DownloadAutoLink(self, message, data, userId, threadId, type):
    """
    Tự động phát hiện link nền tảng và tải.

    Bugs đã fix:
      1. Bỏ qua các msgType không phải text (chat.photo, chat.video.msg, ...)
         vì main.py gán message.text = href (CDN URL Zalo) cho các loại đó,
         khiến URL_RE bắt nhầm link CDN nội bộ.
      2. Lọc URL qua _is_supported_link — chỉ xử lý link thuộc nền tảng
         thực sự được hỗ trợ, loại bỏ mọi CDN/API nội bộ của Zalo.
      3. Với chat.recommended: chỉ lấy href/url khi domain là nền tảng hỗ trợ.
    """
    if not _read_dl_auto(self, threadId):
        return

    # ── Bug 1 fix: lọc sớm theo msgType ──────────────────────────────────────
    msg_type_str = getattr(data, "msgType", None) or ""
    if msg_type_str in _SKIP_MSG_TYPES:
        return

    txt = ""
    try:
        if msg_type_str == "chat.recommended":
            # Bài đăng chia sẻ từ nền tảng — URL thực nằm trong content,
            # KHÔNG dùng message.text (chỉ là tiêu đề bài)
            content = getattr(data, "content", None)
            if content:
                for attr in ("href", "url", "link", "redirectLink"):
                    v = (
                        getattr(content, attr, None)
                        or (content.get(attr) if isinstance(content, dict) else None)
                    )
                    if v and str(v).strip().startswith("http"):
                        candidate = str(v).strip()
                        # ── Bug 3 fix: chỉ lấy nếu là domain hỗ trợ ──────────
                        if _is_supported_link(candidate):
                            txt = candidate
                            break
        else:
            # webchat (text thuần) — message.text là nội dung người dùng gõ
            txt = (getattr(message, "text", None) or "").strip()
    except Exception:
        pass

    if not txt:
        return

    # Bỏ qua nếu là lệnh bot
    pfx = getattr(self, "prefix", "") or ""
    if pfx and txt.startswith(pfx):
        return

    # ── Bug 2 fix: chỉ giữ link thuộc nền tảng hỗ trợ ───────────────────────
    raw_links = URL_RE.findall(txt)
    links = [u for u in raw_links if _is_supported_link(u)]
    if not links:
        return

    if not hasattr(self, "_DlAutoCooldown"):
        self._DlAutoCooldown = {}

    k    = (str(threadId), str(userId))
    now  = int(time.time() * 1000)
    last = self._DlAutoCooldown.get(k, 0)
    if now - last < 5000:
        return

    self._DlAutoCooldown[k] = now
    try:
        self.sendReaction(data, "/-ok", threadId, type, 10000000)
    except Exception:
        pass
    _start_parallel(self, data, userId, threadId, type, links, False)


# ── dependencies (đăng ký lệnh) ───────────────────────────────────────────────

dependencies = {
    "name":        "download",
    "alias":       ["dl", "tải"],
    "permission":  0,
    "description": "Tải video/audio từ TikTok, YouTube, Facebook, Instagram, ...",
    "cooldown":    5,
    "main":        handleDownload,
}
