from app.core.index import *
import time
import re


def _do_help(self, data, userId, threadId, type, p, c):
    help_text = (
        f" Nhập lệnh để kiểm tra chức năng bot.\n\n"
        f"  📌 {p}{c} ping\n"
        f"     └ Kiểm tra độ trễ phản hồi.\n\n"
        f"  📌 {p}{c} txt=<nội dung>\n"
        f"     └ Gửi lại nội dung văn bản.\n\n"
        f"  📌 {p}{c} img=<link ảnh>\n"
        f"     └ Gửi ảnh từ đường dẫn URL.\n\n"
        f"  📌 {p}{c} sticker=<link sticker>\n"
        f"     └ Gửi sticker tuỳ chỉnh.\n\n"
        f"  📌 {p}{c} voice=<link audio>\n"
        f"     └ Gửi tin nhắn thoại.\n\n"
        f"  📌 {p}{c} reaction(\"<icon>\",\"<số lượng>\")\n"
        f"     └ Thả reaction hàng loạt."
    )
    self.replyMessageStyle(
        help_text, data, threadId, type,
        color="or", title="CAUTION", userId=userId,
    )


def _do_ping(self, data, userId, threadId, type):
    t0 = time.time()
    elapsed_ms = round((time.time() - t0) * 1000, 2)
    self.replyMessageStyle(
        f"🏓 Pong! Bot phản hồi thành công.\n"
        f"⚡ Độ trễ: {elapsed_ms} ms\n"
        f"✅ Hệ thống đang hoạt động ổn định.",
        data, threadId, type,
        color="gr", title="COMPLATE SUCCESS", userId=userId, ttl=86400000
    )


def _do_txt(self, data, userId, threadId, type, value):
    self.replyMessageStyle(
        f"📨 Nội dung đã nhận:\n\n{value}",
        data, threadId, type,
        color="gr", title="COMPLATE SUCCESS", userId=userId,
    )


def _do_img(self, data, userId, threadId, type, url):
    try:
        self.replyMessageStyle(
            f"🖼️ Đang tải và gửi ảnh...\n📎 URL: {url}",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        self.sendRemoteImage(url, threadId, type)
    except Exception as e:
        self.replyMessageStyle(
            f"❌ Gửi ảnh thất bại!\n🔎 Chi tiết lỗi:\n{e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


def _do_sticker(self, data, userId, threadId, type, url):
    try:
        self.replyMessageStyle(
            f"🎭 Đang tải và gửi sticker...\n📎 URL: {url}",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        self.sendCustomSticker(
            staticImgUrl=url,
            animationImgUrl=url,
            threadId=threadId,
            threadType=type,
        )
    except Exception as e:
        self.replyMessageStyle(
            f"❌ Gửi sticker thất bại!\n🔎 Chi tiết lỗi:\n{e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


def _do_voice(self, data, userId, threadId, type, url):
    try:
        self.replyMessageStyle(
            f"🎙️ Đang tải và gửi voice...\n📎 URL: {url}",
            data, threadId, type,
            color="or", title="CAUTION", userId=userId,
        )
        self.sendRemoteVoice(url, threadId, type)
    except Exception as e:
        self.replyMessageStyle(
            f"❌ Gửi voice thất bại!\n🔎 Chi tiết lỗi:\n{e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


def _do_reaction(self, data, userId, threadId, type, icon, count):
    count      = max(1, min(count, 1000000))
    chunk_size = 1
    chunks     = count // chunk_size
    remainder  = count % chunk_size
    self.replyMessageStyle(
        f"😄 Đang thả reaction '{icon}' × {count} lần...\n"
        f"⏳ Vui lòng chờ trong giây lát.",
        data, threadId, type,
        color="or", title="CAUTION", userId=userId,
    )
    try:
        for _ in range(chunks):
            self.sendMultiReaction(data, icon, threadId, type, 102229, numreact=chunk_size)
        if remainder:
            self.sendMultiReaction(data, icon, threadId, type, 102229, numreact=remainder)
        self.replyMessageStyle(
            f"✅ Đã thả reaction '{icon}' × {count} lần thành công!",
            data, threadId, type,
            color="gr", title="COMPLATE SUCCESS", userId=userId,
        )
    except Exception as e:
        self.replyMessageStyle(
            f"❌ Thả reaction thất bại!\n🔎 Chi tiết lỗi:\n{e}",
            data, threadId, type,
            color="r", title="ERROR", userId=userId,
        )


def _parse_kv(raw, key):
    m = re.search(rf"{re.escape(key)}\s*=\s*(.+)", raw, re.IGNORECASE | re.DOTALL)
    return m.group(1).strip() if m else None


def _parse_reaction(raw):
    m = re.search(
        r'reaction\s*\(\s*["\']?(.+?)["\']?\s*,\s*["\']?(\d+)["\']?\s*\)',
        raw, re.IGNORECASE
    )
    if m:
        return m.group(1).strip(), int(m.group(2))
    return None, None


def testCoreCommand(self, message, data, userId, threadId, type):
    p        = self.prefix
    c        = self.rawCommand
    text_raw = (getattr(message, "text", None) or str(message) or "").strip()

    cmd_token = f"{p}{c}"
    if text_raw.lower().startswith(cmd_token.lower()):
        body = text_raw[len(cmd_token):].strip()
    else:
        parts = text_raw.split(maxsplit=1)
        body  = parts[1].strip() if len(parts) > 1 else ""

    if not body:
        return _do_help(self, data, userId, threadId, type, p, c)

    lower = body.lower()

    if lower == "ping":
        return _do_ping(self, data, userId, threadId, type)

    if lower.startswith("txt"):
        value = _parse_kv(body, "txt")
        if not value:
            return self.replyMessageStyle(
                f"⚠️ Thiếu nội dung!\n"
                f"📌 Cú pháp đúng: {p}{c} txt=<nội dung cần gửi lại>",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        return _do_txt(self, data, userId, threadId, type, value)

    if lower.startswith("img"):
        url = _parse_kv(body, "img")
        if not url:
            return self.replyMessageStyle(
                f"⚠️ Thiếu đường dẫn ảnh!\n"
                f"📌 Cú pháp đúng: {p}{c} img=<URL ảnh>",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        return _do_img(self, data, userId, threadId, type, url)

    if lower.startswith("sticker"):
        url = _parse_kv(body, "sticker")
        if not url:
            return self.replyMessageStyle(
                f"⚠️ Thiếu đường dẫn sticker!\n"
                f"📌 Cú pháp đúng: {p}{c} sticker=<URL sticker>",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        return _do_sticker(self, data, userId, threadId, type, url)

    if lower.startswith("voice"):
        url = _parse_kv(body, "voice")
        if not url:
            return self.replyMessageStyle(
                f"⚠️ Thiếu đường dẫn audio!\n"
                f"📌 Cú pháp đúng: {p}{c} voice=<URL audio/voice>",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        return _do_voice(self, data, userId, threadId, type, url)

    if lower.startswith("reaction"):
        icon, count = _parse_reaction(body)
        if icon is None:
            return self.replyMessageStyle(
                f"⚠️ Sai cú pháp reaction!\n"
                f"📌 Cú pháp đúng: {p}{c} reaction(\"<icon>\",\"<số lượng>\")\n"
                f"📍 Ví dụ: {p}{c} reaction(\"😭\",\"10\")",
                data, threadId, type,
                color="yl", title="WARNING", userId=userId,
            )
        return _do_reaction(self, data, userId, threadId, type, icon, count)

    self.replyMessageStyle(
        f"❓ Lệnh con \"{body}\" không tồn tại.\n"
        f"📌 Dùng: {p}{c}  để xem danh sách lệnh hỗ trợ.",
        data, threadId, type,
        color="yl", title="WARNING", userId=userId,
    )

dependencies = {
    "name":        "test",
    "permission":  3,
    "cooldown":    3,
    "description": "Bộ lệnh kiểm tra chức năng bot.",
    "main":        testCoreCommand,
}
