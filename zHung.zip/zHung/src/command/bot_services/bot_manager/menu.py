from app.core.index import *
from api.util.Enum import PermissionLevel, MsgStyle, ThreadType
from src.services.pillow.menuDraw import draw_menu, MAX_PER_PAGE
import os, math, threading, time

CACHE_DIR = "data/assets/cache/image"
Timeout   = 120

# Dùng sys.modules làm nơi lưu state để share giữa các lần module bị load lại
# (main.py import với key đầy đủ, loader() import với key ngắn → 2 instance)
import sys as _sys
_MENU_STATES_KEY  = "__zbot_menu_states__"
_MENU_THREAD_KEY  = "__zbot_menu_timeout_started__"
if _MENU_STATES_KEY not in _sys.modules:
    _sys.modules[_MENU_STATES_KEY] = {}  # type: ignore
if _MENU_THREAD_KEY not in _sys.modules:
    _sys.modules[_MENU_THREAD_KEY] = False  # type: ignore
_GLOBAL_MENU_STATES: dict[str, dict] = _sys.modules[_MENU_STATES_KEY]  # type: ignore

def _build_cmd_list(config: dict) -> list[dict]:
    items = []
    for name, conf in sorted(config.items()):
        if not conf.get("status", True):
            continue
        items.append({
            "name":        name,
            "description": conf.get("description", ""),
            "permission":  conf.get("permission", 0),
            "alias":       conf.get("alias", []),
        })
    return items


def _parse_menu_arg(msg: str):
    msg = str(msg).strip().lower()

    if msg in ("out", "ok", "0", "thoat", "thoát"):
        return "exit", None

    parts = msg.split()
    if not parts:
        return None, None

    first = parts[0]

    if first in ("next", "sang", "sáng"):
        if len(parts) >= 2 and parts[1].isdigit():
            return "next", int(parts[1])
        return "next", None

    if first in ("prev", "back"):
        return "prev", None

    if first.isdigit():
        return "goto", int(first)

    return None, None

def _strip_mention(self, MessageObj, Data) -> str:
    try:
        from app.module.commandLoader import removeMention
        stripped = removeMention(self, Data).strip()
        if stripped:
            return stripped
    except Exception:
        pass
    text = getattr(MessageObj, "text", None)
    if isinstance(text, str):
        return text.strip()
    return str(MessageObj).strip()

def _send_page(self, page: int, state: dict, userId, threadId, threadType):
    items      = state["items"]
    total_page = state["total_page"]
    prefix     = state["prefix"]
    user_level = state["user_level"]
    bot_name   = getattr(self, "bot", "Bot")
    user_name  = self.userName(userId)
    bg_url     = state.get("bg_url")  # custom background URL

    chunk    = items[(page - 1) * MAX_PER_PAGE : page * MAX_PER_PAGE]
    out_path = os.path.join(CACHE_DIR,
                            f"menu_{self.uid}_{threadId}_u{userId}_p{page}.jpg")

    os.makedirs(CACHE_DIR, exist_ok=True)
    w, h = draw_menu(
        chunk, out_path,
        page=page, total_page=total_page,
        prefix=prefix, user_level=user_level,
        bot_name=bot_name,
        bg_url=bg_url,
    )

    nav_parts = []
    if page < total_page:
        nav_parts.append(f"sáng / next {page + 1}")
    if page > 1:
        nav_parts.append("back")
    nav_parts.append("thoát/ok")
    nav_hint = "  |  ".join(nav_parts)

    cap_text = (
        f"{user_name}\n"
        f"• Page {page}/{total_page}"
    )
    mention = Mention(userId, offset=0, length=len(user_name))
    caption = Message(text=cap_text, mention=mention)

    img_url = None
    try:
        res = self._uploadImage(out_path, threadId, threadType)
        if isinstance(res, dict):
            img_url = res.get("normalUrl") or res.get("hdUrl")
        elif isinstance(res, str) and res.startswith("http"):
            img_url = res
    except Exception as e:
        print(f"[menu] _uploadImage error: {e}")
    finally:
        try:
            os.remove(out_path)
        except Exception:
            pass

    if not img_url:
        return None

    try:
        resp = self.sendRemoteImage(
            img_url, threadId, threadType,
            width=w, height=h, message=caption,
        )
    except Exception as e:
        print(f"[menu] sendRemoteImage error: {e}")
        resp = None

    return resp

def _menu_key(userId, threadId) -> str:
    return f"{userId}:{threadId}"

def _del_menu_msg(self, state: dict):
    try:
        msg_id = state.get("msgId")
        cli_id = state.get("clientId")
        t_id   = state.get("threadId")
        t_type = state.get("typeGr")
        if not (msg_id and cli_id and t_id):
            return

        if t_type == ThreadType.GROUP:
            self.deleteMessage(msg_id, self.uid, cli_id, t_id)
        else:
            self.undoMessage(msg_id, cli_id, t_id, t_type)
    except Exception:
        pass

def InitTimeoutMenu(self, interval=1):
    # Chỉ khởi động đúng 1 thread duy nhất dù module bị load nhiều lần
    if _sys.modules.get(_MENU_THREAD_KEY):
        return
    _sys.modules[_MENU_THREAD_KEY] = True

    def Loop():
        while True:
            now = time.time()
            for key, state in list(_GLOBAL_MENU_STATES.items()):
                if now - state["time"] > Timeout:
                    # Đánh dấu expired TRƯỚC khi xử lý để tránh gửi nhiều lần
                    if state.get("_expired"):
                        continue
                    state["_expired"] = True
                    _del_menu_msg(self, state)
                    _GLOBAL_MENU_STATES.pop(key, None)
                    try:
                        uid_part = key.split(":")[0]
                        self.sendMentionStyle(
                            "Menu đã hết hạn, gọi lại để xem nhé.",
                            uid_part,
                            state["threadId"],
                            state["typeGr"],
                        )
                    except Exception:
                        pass
            time.sleep(interval)

    threading.Thread(target=Loop, daemon=True).start()

def menuCommand(self, message, data, userId, threadId, type):
    try:
        msg_text = (message.text if hasattr(message, "text") else str(message)).strip()
        args     = msg_text.split()
        sub      = args[1].lower() if len(args) > 1 else ""

        # ── menu set bgrd=(url) | menu set bgrd=md ──────────────────
        if sub == "set":
            if len(args) < 3:
                self.replyMessageStyle(
                    "Cú pháp: menu set bgrd=(url) hoặc menu set bgrd=md",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return
            third = args[2]
            if not third.lower().startswith("bgrd="):
                self.replyMessageStyle(
                    "Cú pháp: menu set bgrd=(url) hoặc menu set bgrd=md",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return

            user_level = self.permissionLevel(userId, threadId)
            if user_level < 3:
                self.replyMessageStyle(
                    "Bạn không có quyền dùng lệnh này (cần cấp 3+).",
                    data, threadId, type,
                    color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
                )
                return

            value = third[len("bgrd="):]
            settings = read_settings(self.uid)

            if value.lower() == "md":
                settings.pop("menu_bg_url", None)
                write_settings(self.uid, settings)
                self.replyMessageStyle(
                    "✅ Đã đặt lại nền menu về mặc định.",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value, title=MsgStyle.SUCCESS.title,
                )
            else:
                settings["menu_bg_url"] = value
                write_settings(self.uid, settings)
                self.replyMessageStyle(
                    f"✅ Đã lưu ảnh nền menu:\n{value}",
                    data, threadId, type,
                    color=MsgStyle.SUCCESS.value, title=MsgStyle.SUCCESS.title,
                )
            return
        # ─────────────────────────────────────────────────────────────

        config     = load_command_config(self.uid)
        user_level = self.permissionLevel(userId, threadId)
        items      = _build_cmd_list(config)
        total_page = math.ceil(len(items) / MAX_PER_PAGE) or 1
        prefix     = self.prefix

        # Lấy custom bg_url từ settings nếu có
        _settings = read_settings(self.uid)
        _bg_url   = _settings.get("menu_bg_url")

        if sub == "all":
            bot_name  = getattr(self, "bot", "Bot")
            user_name = self.userName(userId)
            groups: dict[int, list[str]] = {}
            for it in items:
                groups.setdefault(it["permission"], []).append(it["name"])

            section_names = {
                0: "User", 1: "Group Admin",
                2: "Bot Admin", 3: "High Admin", 4: "Developer"
            }
            lines = [
                f"List Command - {bot_name}",
                f"{user_name}  ·  Cấp: {PermissionLevel.label(user_level)}",
                "",
            ]
            for lvl in range(5):
                cmds = groups.get(lvl, [])
                if not cmds:
                    continue
                locked = user_level < lvl
                marker = "🔒" if locked else "✅"
                lines.append(f"{marker} {section_names.get(lvl, str(lvl))}")
                for cmd in cmds:
                    desc  = config[cmd].get("description", "")
                    alias = config[cmd].get("alias", [])
                    a_str = f"  ({', '.join(alias)})" if alias else ""
                    d_str = f" — {desc}" if desc else ""
                    lines.append(f"  {prefix}{cmd}{a_str}{d_str}")
                lines.append("")

            lines.append(f"Tổng: {len(items)} lệnh")
            self.replyMessageStyle(
                "\n".join(lines), data, threadId, type,
                color=MsgStyle.INFO.value, title=MsgStyle.INFO.title,
            )
            return

        try:
            page = max(1, min(int(sub), total_page)) if sub.isdigit() else 1
        except Exception:
            page = 1

        key = _menu_key(userId, threadId)
        old = _GLOBAL_MENU_STATES.get(key)
        if old:
            _del_menu_msg(self, old)
            _GLOBAL_MENU_STATES.pop(key, None)

        state = {
            "page":       page,
            "total_page": total_page,
            "items":      items,
            "prefix":     prefix,
            "user_level": user_level,
            "bg_url":     _bg_url,
            "msgId":      None,
            "clientId":   None,
            "threadId":   threadId,
            "typeGr":     type,
            "time":       time.time(),
        }

        self.sendReaction(data, "", threadId, type, -1)
        self.sendReaction(data, "💅", threadId, type, 100000000)
        resp = _send_page(self, page, state, userId, threadId, type)
        self.sendReaction(data, "", threadId, type, -1)
        self.sendReaction(data, "👀", threadId, type, 100000000)

        msg_id = getattr(resp, "msgId", None)
        cli_id = getattr(resp, "clientId", None)

        if not msg_id or not cli_id:
            return

        state["msgId"]    = msg_id
        state["clientId"] = cli_id
        _GLOBAL_MENU_STATES[key] = state

    except Exception as e:
        self.sendReaction(data, "", threadId, type, -1)
        logger.errorw(f"menu error: {e}")
        self.replyMessageStyle(
            f"Lỗi hiển thị menu: {e}", data, threadId, type,
            color=MsgStyle.ERROR.value, title=MsgStyle.ERROR.title,
        )

def MenuReply(self, MessageObj, Data, UserId, ThreadId, ThreadType):
    key   = _menu_key(UserId, ThreadId)
    state = _GLOBAL_MENU_STATES.get(key)
    if not state:
        return

    if time.time() - state["time"] > Timeout:
        _del_menu_msg(self, state)
        _GLOBAL_MENU_STATES.pop(key, None)
        return

    Msg    = _strip_mention(self, MessageObj, Data)
    action, target_page = _parse_menu_arg(Msg)

    if action is None:
        return

    total_page = state["total_page"]
    cur_page   = state["page"]

    if action == "exit":
        _del_menu_msg(self, state)
        _GLOBAL_MENU_STATES.pop(key, None)
        self.sendReaction(Data, "", ThreadId, ThreadType, -1)
        self.sendReaction(Data, "💅", ThreadId, ThreadType, 100000000)
        self.sendReaction(Data, "", ThreadId, ThreadType, -1)
        self.sendReaction(Data, "👀", ThreadId, ThreadType, 100000000)
        return

    if action == "next":
        if target_page is not None:
            page = max(1, min(target_page, total_page))
        else:
            page = cur_page + 1

        if page > total_page:
            self.sendMentionStyle(
                f"Đây là trang cuối rồi ({cur_page}/{total_page}).",
                UserId, ThreadId, ThreadType,
            )
            return

        if page == cur_page:
            self.sendMentionStyle(
                f"Bạn đang ở trang {cur_page} rồi.",
                UserId, ThreadId, ThreadType,
            )
            return

        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

    if action == "prev":
        page = cur_page - 1
        if page < 1:
            self.sendMentionStyle(
                f"Đây là trang đầu rồi (1/{total_page}).",
                UserId, ThreadId, ThreadType,
            )
            return
        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

    if action == "goto":
        page = max(1, min(target_page, total_page))
        if page == cur_page:
            self.sendMentionStyle(
                f"Bạn đang ở trang {cur_page} rồi.",
                UserId, ThreadId, ThreadType,
            )
            return
        _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType)
        return

def _go_to_page(self, page, state, key, Data, UserId, ThreadId, ThreadType):
    _del_menu_msg(self, state)

    state["page"]     = page
    state["time"]     = time.time()
    state["msgId"]    = None
    state["clientId"] = None

    self.sendReaction(Data, "", ThreadId, ThreadType, -1)
    self.sendReaction(Data, "💅", ThreadId, ThreadType, 100000000)
    resp = _send_page(self, page, state, UserId, ThreadId, ThreadType)
    self.sendReaction(Data, "", ThreadId, ThreadType, -1)
    self.sendReaction(Data, "👀", ThreadId, ThreadType, 100000000)

    msg_id = getattr(resp, "msgId", None)
    cli_id = getattr(resp, "clientId", None)

    if not msg_id or not cli_id:
        _GLOBAL_MENU_STATES.pop(key, None)
        return

    state["msgId"]    = msg_id
    state["clientId"] = cli_id
    _GLOBAL_MENU_STATES[key] = state

dependencies = {
    "name":        "menu",
    "permission":  0,
    "cooldown":    5,
    "description": "Hiển thị danh sách lệnh",
    "alias":       ["help"],
    "main":        menuCommand,
    "onLoad":      InitTimeoutMenu,
}