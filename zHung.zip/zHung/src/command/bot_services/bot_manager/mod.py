import threading
from app.core.index import *
from app.module.commandLoader import removeMention
from src.services.utils.modGroupCore import (
    start_grp_session,
    handle_grp_input,
    start_cleanup,
)

def modCommand(ctx, message, data, userId, threadId, type):
    p    = getattr(ctx, "prefix", "/")
    c    = getattr(ctx, "rawCommand", None) or getattr(ctx, "commandName", "mod")
    text = removeMention(ctx, data).strip() or (getattr(message, "text", "") or "").strip()

    if text.startswith(p):
        text = text[len(p):].strip()
    parts = text.split()
    if parts and parts[0].lower() == c.lower():
        parts = parts[1:]

    sub = parts[0].lower() if parts else ""

    if handle_grp_input(ctx, " ".join(parts), data, userId, threadId, type):
        return

    if sub == "grp":
        threading.Thread(
            target=lambda: start_grp_session(ctx, data, userId, threadId, type),
            daemon=True,
        ).start()
        return

    guide = (
        f"Account Modifier\n\n"
        f"Commands:\n"
        f"  📍 {p}{c} fr      : Account Friends\n"
        f"  📍 {p}{c} grp     : Account Groups\n"
        f"  📍 {p}{c} memm    : Group Members\n"
        f"  📍 {p}{c} bmemm   : Blocked Members\n"
        f"  📍 {p}{c} grpinv  : Account Group Invites\n"
        f"  📍 {p}{c} joinreq : Group Join Requests"
    )
    ctx.replyMessageStyle(guide, data, threadId, type,
                          color="or", title="MOD", userId=userId)

def ModReply(ctx, message, data, userId, threadId, type):
    from app.module.commandLoader import removeMention as _rm
    text = _rm(ctx, data).strip() or (getattr(message, "text", "") or "").strip()
    if not text:
        return
    handle_grp_input(ctx, text, data, userId, threadId, type)

def _on_load(bot_instance):
    start_cleanup()

dependencies = {
    "name":        "mod",
    "permission":  4,
    "cooldown":    0,
    "description": "Account Modifier",
    "main":        modCommand,
    "onLoad":      _on_load,
}