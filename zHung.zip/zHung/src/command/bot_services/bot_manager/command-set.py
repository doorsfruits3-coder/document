from app.module.commandLoader import loader
from app.core.index import *
from src.services.init.clearpycache import clearpyc


def cmdCommand(self, message, data, userId, threadId, type):
    text  = message.text or ""
    parts = text.strip().split()
    p     = self.prefix
    c     = self.rawCommand

    config_path = f"data/config/bot/Data-{self.uid}.json"
    config      = load_json(config_path, {"command": []})

    def ok(msg):
        self.replyMessageStyle(msg, data, threadId, type, color="gr", title="SUCCESS")

    def warn(msg):
        self.replyMessageStyle(msg, data, threadId, type, color="yl", title="WARNING")

    def err(msg):
        self.replyMessageStyle(msg, data, threadId, type, color="r", title="ERROR")

    if not config.get("command"):
        return warn("Dữ liệu lệnh trống")

    cmd_map = {c_["name"]: c_ for c_ in config["command"]}

    if len(parts) < 2:
        help_text = (
            f"Quản Lý Lệnh\n"
            f"\n"
            f"Cooldown\n"
            f"  📍 {p}{c} cooldown <giây> <lệnh>\n"
            f"     Đặt thời gian chờ cho lệnh\n"
            f"\n"
            f"Quyền Hạn\n"
            f"  📍 {p}{c} permission <cấp> <lệnh>\n"
            f"     Đặt quyền sử dụng lệnh (0 - 4)\n"
            f"\n"
            f"Trạng Thái\n"
            f"  📍 {p}{c} on <lệnh>\n"
            f"     Bật lệnh\n"
            f"  📍 {p}{c} off <lệnh>\n"
            f"     Tắt lệnh\n"
            f"\n"
            f"Hệ Thống\n"
            f"  📍 {p}{c} load\n"
            f"     Tải lại toàn bộ lệnh"
        )
        return warn(help_text)

    action = parts[1].lower()

    # ── cooldown ──────────────────────────────────────────────────────────────
    if action == "cooldown":
        if len(parts) < 4:
            return warn(f"Cú pháp: {p}{c} cooldown <giây> <lệnh>")
        try:
            seconds = int(parts[2])
        except ValueError:
            return err("Cooldown phải là số nguyên")

        cmd = parts[3].lower()
        if cmd not in cmd_map:
            return err(f"Không tìm thấy lệnh: {cmd}")

        cmd_map[cmd]["cooldown"] = max(0, seconds)
        save_json(config_path, config)
        return ok(f"Đã đặt cooldown {seconds}s cho lệnh '{cmd}'")

    # ── load ──────────────────────────────────────────────────────────────────
    if action == "load":
        try:
            self.commands.clear()
            new_cmds = loader(self, "src/command")
            self.commands.update(new_cmds)
            clearpyc(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
            return ok(f"Đã tải lại {len(new_cmds)} lệnh thành công")
        except Exception as e:
            return err(f"Lỗi khi tải lại: {e}")

    # ── permission ────────────────────────────────────────────────────────────
    if action == "permission":
        if len(parts) < 4:
            return warn(f"Cú pháp: {p}{c} permission <cấp> <lệnh>")
        try:
            level = int(parts[2])
        except ValueError:
            return err("Cấp quyền phải là số nguyên (0 - 4)")

        cmd = parts[3].lower()
        if cmd not in cmd_map:
            return err(f"Không tìm thấy lệnh: {cmd}")

        caller_level = self.permissionLevel(userId, threadId)

        origin_perm = self.commands.get(cmd, {}).get("permission", 0)
        if origin_perm > caller_level:
            return err(
                f"Lệnh '{cmd}' có quyền gốc là {origin_perm}, "
                f"bạn không đủ quyền để chỉnh sửa."
            )

        if level > caller_level:
            return err(
                f"Bạn chỉ được đặt quyền tối đa bằng cấp của mình ({caller_level})."
            )

        cmd_map[cmd]["permission"] = max(0, level)
        save_json(config_path, config)
        return ok(f"Đã đặt quyền {level} cho lệnh '{cmd}'")

    # ── on / off ──────────────────────────────────────────────────────────────
    if action in ("on", "off"):
        if len(parts) < 3:
            return warn(f"Cú pháp: {p}{c} {action} <lệnh>")

        cmd = parts[2].lower()
        if cmd not in cmd_map:
            return err(f"Không tìm thấy lệnh: {cmd}")

        cmd_map[cmd]["status"] = action == "on"
        save_json(config_path, config)
        state = "bật" if action == "on" else "tắt"
        return ok(f"Lệnh '{cmd}' đã được {state}")

    err(f"Hành động không hợp lệ. Dùng {p}{c} để xem hướng dẫn.")


dependencies = {
    "name":        "command",
    "permission":  3,
    "cooldown":    5,
    "description": "Quản lý cài đặt lệnh",
    "main":        cmdCommand,
}