from app.core.index import *
from src.services.index import *

def botm(self, bots, data):
    uids = extractUids(data)
    if not uids:
        return None

    uid = str(uids[0])
    mention_name = self.userName(uid).strip().lower()

    for bot in bots:
        if bot.get("username", "").strip().lower() == mention_name:
            return bot
    return None


def checkPrefix(self, message, data, userId, threadId, type):
    try:
        text = message.text or ""
        parts = text.strip().split()
        if len(parts) < 2:
            return

        new_prefix = parts[-1]

        data_config = load_json(logindb)
        bots = data_config.get("data", [])
        uids = extractUids(data)
        if uids:
            if not self.is_main_bot:
                return

            bot = botm(self, bots, data)
            if not bot:
                return self.sendReplyMention(
                    "I dont see ur mention id",
                    userId, data, threadId, type
                )

            bot["prefix"] = new_prefix
            save_json(logindb, data_config)
            restart_single_bot(bot)

            return self.sendReplyMention(
                f"Changed prefix for {bot.get('username')} to: {new_prefix}",
                userId, data, threadId, type
            )

        mybot = next(
            (b for b in bots if str(b.get("author_id")) == str(userId)),
            None
        )

        if not mybot:
            return self.sendReplyMention(
                "I dont know ur bot",
                userId, data, threadId, type
            )

        mybot["prefix"] = new_prefix
        save_json(logindb, data_config)
        restart_single_bot(mybot)

        return self.sendReplyMention(
            f"Changed prefix to: {new_prefix}",
            userId, data, threadId, type
        )

    except Exception as e:
        logger.error(f"Prefix error: {e}")
        self.sendReplyMention(
            "Đã xảy ra lỗi",
            userId, data, threadId, type
        )


dependencies = { 
    "name": "prefix",
    "permission": 3, 
    "description": "Check or change prefix", 
    "cooldown": 3,
    "main": checkPrefix
}