from app.core.index import *
import random
import time
import math
import hashlib

DATA_DIR = "data/tutien"

REALMS = [
    {"id": 0,  "name": "Phàm Nhân",          "emoji": "👤", "required_qi": 0,         "multiplier": 1.0},
    {"id": 1,  "name": "Luyện Khí Tầng 1",   "emoji": "🌱", "required_qi": 100,       "multiplier": 1.2},
    {"id": 2,  "name": "Luyện Khí Tầng 2",   "emoji": "🌿", "required_qi": 300,       "multiplier": 1.4},
    {"id": 3,  "name": "Luyện Khí Tầng 3",   "emoji": "🍃", "required_qi": 700,       "multiplier": 1.7},
    {"id": 4,  "name": "Trúc Cơ Sơ Kỳ",      "emoji": "🔥", "required_qi": 1500,      "multiplier": 2.0},
    {"id": 5,  "name": "Trúc Cơ Trung Kỳ",   "emoji": "🔆", "required_qi": 3000,      "multiplier": 2.5},
    {"id": 6,  "name": "Trúc Cơ Hậu Kỳ",     "emoji": "⚡", "required_qi": 6000,      "multiplier": 3.0},
    {"id": 7,  "name": "Kim Đan Sơ Kỳ",       "emoji": "💠", "required_qi": 12000,     "multiplier": 4.0},
    {"id": 8,  "name": "Kim Đan Trung Kỳ",    "emoji": "💎", "required_qi": 25000,     "multiplier": 5.0},
    {"id": 9,  "name": "Kim Đan Hậu Kỳ",      "emoji": "🌟", "required_qi": 50000,     "multiplier": 6.5},
    {"id": 10, "name": "Nguyên Anh Sơ Kỳ",    "emoji": "👁️", "required_qi": 100000,    "multiplier": 8.0},
    {"id": 11, "name": "Nguyên Anh Trung Kỳ", "emoji": "🌀", "required_qi": 200000,    "multiplier": 10.0},
    {"id": 12, "name": "Nguyên Anh Hậu Kỳ",   "emoji": "🌌", "required_qi": 400000,    "multiplier": 13.0},
    {"id": 13, "name": "Hóa Thần Sơ Kỳ",      "emoji": "☄️", "required_qi": 800000,    "multiplier": 16.0},
    {"id": 14, "name": "Hóa Thần Trung Kỳ",   "emoji": "🌠", "required_qi": 1600000,   "multiplier": 20.0},
    {"id": 15, "name": "Hóa Thần Hậu Kỳ",     "emoji": "✨", "required_qi": 3200000,   "multiplier": 25.0},
    {"id": 16, "name": "Luyện Hư Kỳ",         "emoji": "🌈", "required_qi": 8000000,   "multiplier": 32.0},
    {"id": 17, "name": "Hợp Thể Kỳ",          "emoji": "🔮", "required_qi": 20000000,  "multiplier": 42.0},
    {"id": 18, "name": "Đại Thừa Kỳ",         "emoji": "👑", "required_qi": 50000000,  "multiplier": 55.0},
    {"id": 19, "name": "Độ Kiếp Kỳ",          "emoji": "⚔️", "required_qi": 120000000, "multiplier": 70.0},
    {"id": 20, "name": "Tiên Nhân",            "emoji": "🌸", "required_qi": 300000000, "multiplier": 100.0},
]

LINH_BAO_SHOP = [
    {"id": "lingcao_1",   "name": "Linh Thảo Cấp 1",    "emoji": "🌿", "price": 200,    "qi_bonus": 50,    "desc": "Tăng 50 LK/lần tu luyện trong 5 lần"},
    {"id": "lingcao_2",   "name": "Linh Thảo Cấp 2",    "emoji": "🍀", "price": 600,    "qi_bonus": 150,   "desc": "Tăng 150 LK/lần tu luyện trong 5 lần"},
    {"id": "lingcao_3",   "name": "Linh Quả Tiên",       "emoji": "🍑", "price": 2000,   "qi_bonus": 600,   "desc": "Tăng 600 LK/lần tu luyện trong 5 lần"},
    {"id": "danhunwan",   "name": "Đan Hồn Hoàn",        "emoji": "💊", "price": 5000,   "qi_bonus": 0,     "qi_instant": 2000,   "desc": "Dùng ngay: +2.000 linh khí"},
    {"id": "phetian_dan", "name": "Phế Thiên Đan",       "emoji": "🟣", "price": 15000,  "qi_bonus": 0,     "qi_instant": 8000,   "desc": "Dùng ngay: +8.000 linh khí"},
    {"id": "xuan_tian",   "name": "Huyền Thiên Tiên Đan","emoji": "🔵", "price": 50000,  "qi_bonus": 0,     "qi_instant": 30000,  "desc": "Dùng ngay: +30.000 linh khí"},
    {"id": "hualing_dan", "name": "Hóa Linh Thánh Đan",  "emoji": "🌟", "price": 200000, "qi_bonus": 0,     "qi_instant": 150000, "desc": "Dùng ngay: +150.000 linh khí"},
    {"id": "tienling_bao","name": "Tiên Linh Bảo Bình",  "emoji": "🏺", "price": 800000, "qi_bonus": 0,     "qi_instant": 700000, "desc": "Dùng ngay: +700.000 linh khí"},
]

PHAO_BAO_SHOP = [
    {"id": "kiem_go",    "name": "Gỗ Kiếm",              "emoji": "🪵", "price": 500,    "atk_bonus": 10,   "def_bonus": 0,    "desc": "Kiếm gỗ thô sơ, +10 công"},
    {"id": "kiem_sat",   "name": "Sắt Kiếm",             "emoji": "⚔️", "price": 2000,   "atk_bonus": 35,   "def_bonus": 5,    "desc": "Kiếm sắt bình thường, +35 công +5 thủ"},
    {"id": "ao_vai",     "name": "Vải Bào",               "emoji": "👘", "price": 1500,   "atk_bonus": 0,    "def_bonus": 25,   "desc": "Áo vải thô, +25 thủ"},
    {"id": "kiem_linh",  "name": "Linh Kiếm Cấp 1",      "emoji": "🗡️", "price": 8000,   "atk_bonus": 100,  "def_bonus": 20,   "desc": "Kiếm linh cơ bản, +100 công +20 thủ"},
    {"id": "giap_linh",  "name": "Linh Giáp Cấp 1",      "emoji": "🛡️", "price": 8000,   "atk_bonus": 20,   "def_bonus": 100,  "desc": "Giáp linh cơ bản, +20 công +100 thủ"},
    {"id": "kiem_linh2", "name": "Linh Kiếm Cấp 2",      "emoji": "⚡", "price": 30000,  "atk_bonus": 350,  "def_bonus": 60,   "desc": "Kiếm linh cấp 2, +350 công +60 thủ"},
    {"id": "giap_linh2", "name": "Linh Giáp Cấp 2",      "emoji": "🔵", "price": 30000,  "atk_bonus": 60,   "def_bonus": 350,  "desc": "Giáp linh cấp 2, +60 công +350 thủ"},
    {"id": "thanthu",    "name": "Thần Thú Nhẫn",         "emoji": "💍", "price": 80000,  "atk_bonus": 500,  "def_bonus": 500,  "desc": "Nhẫn thần thú, +500 công +500 thủ"},
    {"id": "hoan_kiem",  "name": "Hoàn Thiên Thần Kiếm",  "emoji": "🌟", "price": 300000, "atk_bonus": 2000, "def_bonus": 500,  "desc": "Kiếm thần huyền thoại, +2000 công +500 thủ"},
    {"id": "tien_giap",  "name": "Tiên Thiên Thần Giáp",  "emoji": "👑", "price": 300000, "atk_bonus": 500,  "def_bonus": 2000, "desc": "Giáp tiên huyền thoại, +500 công +2000 thủ"},
    {"id": "vo_ji_kiem", "name": "Vô Cực Thần Kiếm",      "emoji": "☄️", "price": 1500000,"atk_bonus": 10000,"def_bonus": 2000, "desc": "Bảo kiếm tối thượng, +10000 công +2000 thủ"},
]

THU_CUNG_SHOP = [
    {"id": "meo_linh",    "name": "Linh Miêu",        "emoji": "🐱", "price": 3000,    "qi_multi": 1.05, "atk_bonus": 0,    "desc": "Mèo linh nhỏ nhắn, +5% linh khí tu luyện"},
    {"id": "rong_nho",    "name": "Tiểu Long",         "emoji": "🐉", "price": 10000,   "qi_multi": 1.10, "atk_bonus": 50,   "desc": "Rồng nhỏ dễ thương, +10% LK +50 công"},
    {"id": "phuong",      "name": "Linh Phụng",        "emoji": "🦅", "price": 25000,   "qi_multi": 1.15, "atk_bonus": 100,  "desc": "Phụng hoàng linh, +15% LK +100 công"},
    {"id": "ho_bach",     "name": "Bạch Hổ",           "emoji": "🐯", "price": 50000,   "qi_multi": 1.10, "atk_bonus": 300,  "desc": "Hổ trắng thần mãnh, +10% LK +300 công"},
    {"id": "quy_linh",    "name": "Linh Quy",          "emoji": "🐢", "price": 40000,   "qi_multi": 1.08, "atk_bonus": 0,    "def_bonus": 400, "desc": "Rùa thần trường thọ, +8% LK +400 thủ"},
    {"id": "xich_long",   "name": "Xích Long",         "emoji": "🔴", "price": 100000,  "qi_multi": 1.20, "atk_bonus": 500,  "desc": "Rồng đỏ thần uy, +20% LK +500 công"},
    {"id": "tuong_quy",   "name": "Huyền Quy Thần Thú","emoji": "🌀", "price": 200000,  "qi_multi": 1.15, "atk_bonus": 0,    "def_bonus": 1500,"desc": "Quy thần cổ đại, +15% LK +1500 thủ"},
    {"id": "kim_long",    "name": "Kim Long",           "emoji": "⭐", "price": 500000,  "qi_multi": 1.30, "atk_bonus": 2000, "def_bonus": 500, "desc": "Rồng vàng thần thoại, +30% LK +2000 công +500 thủ"},
    {"id": "tien_he",     "name": "Tiên Hạc",           "emoji": "🕊️", "price": 150000,  "qi_multi": 1.25, "atk_bonus": 200,  "desc": "Hạc tiên thoát tục, +25% LK +200 công"},
    {"id": "chaos_beast", "name": "Hỗn Độn Thú",       "emoji": "🌌", "price": 2000000, "qi_multi": 1.50, "atk_bonus": 5000, "def_bonus": 5000,"desc": "Thần thú hỗn độn, +50% LK +5000 công +5000 thủ"},
]

TU_LUYEN_EVENTS = [
    {"chance": 0.25, "type": "normal",  "msg": None},
    {"chance": 0.15, "type": "bonus",   "msg": "✨ Linh mạch thăng hoa! Linh khí tăng gấp đôi!",          "multi": 2.0},
    {"chance": 0.10, "type": "bonus",   "msg": "🌟 Gặp cơ duyên! Linh khí tăng gấp 3 lần!",              "multi": 3.0},
    {"chance": 0.08, "type": "bonus",   "msg": "💫 Hư không rung chuyển! Linh khí tăng gấp 5 lần!",       "multi": 5.0},
    {"chance": 0.05, "type": "bonus",   "msg": "☄️ Thiên địa linh khí tuôn trào! Tăng gấp 10 lần!",      "multi": 10.0},
    {"chance": 0.18, "type": "stone",   "msg": "💎 Phát hiện linh thạch trong lúc tu luyện!",              "stone": (1, 5)},
    {"chance": 0.08, "type": "stone",   "msg": "💠 Mạch linh thạch ẩn xuất hiện!",                        "stone": (5, 15)},
    {"chance": 0.04, "type": "stone",   "msg": "🌟 Linh thạch tinh chất nổ ra!",                           "stone": (15, 40)},
    {"chance": 0.07, "type": "item",    "msg": "🍀 Linh thảo cấp 1 rơi xuống trước mặt!",                  "item": "lingcao_1"},
    {"chance": 0.03, "type": "item",    "msg": "🍑 Một trái linh quả tiên xuất hiện!",                      "item": "lingcao_2"},
    {"chance": 0.02, "type": "bad",     "msg": "⚠️ Tẩu hỏa nhập ma! Mất 20% linh khí vừa tu!",            "penalty": 0.20},
]

MINE_EVENTS = [
    {"chance": 0.30, "stone": (30,   45),  "msg": "⛏️ Khai được {n} linh thạch thường"},
    {"chance": 0.22, "stone": (45,  75),  "msg": "💠 Phát hiện mạch nhỏ! +{n} linh thạch"},
    {"chance": 0.18, "stone": (75,  150),  "msg": "✨ Trúng mạch linh thạch! +{n} linh thạch"},
    {"chance": 0.12, "stone": (150,  225), "msg": "🌟 Linh thạch phong phú! +{n} linh thạch"},
    {"chance": 0.08, "stone": (225, 300), "msg": "💎 Mạch cấp cao! +{n} linh thạch"},
    {"chance": 0.05, "stone": (300, 425), "msg": "⭐ Đại mạch linh thạch! +{n} linh thạch"},
    {"chance": 0.03, "stone": (425, 825), "msg": "🔥 SIÊU ĐẠI MẠCH! +{n} linh thạch!!!"},
    {"chance": 0.02, "stone": (825,1500), "msg": "🌌 HUYỀN THIÊN LINH MẠCH! +{n} linh thạch cực phẩm!!"},
]

DOTPHA_EVENTS = [
    {"chance": 0.45, "type": "success",    "msg": ""},
    {"chance": 0.25, "type": "fail_qi",    "msg": "❌ Đột phá thất bại! Linh khí chưa đủ dày, cần tu thêm."},
    {"chance": 0.15, "type": "tribulation","msg": "⚡ Thiên lôi giáng xuống! Vượt qua thiên kiếp thành công!"},
    {"chance": 0.10, "type": "insight",    "msg": "💡 Đốn ngộ đại đạo! Đột phá suôn sẻ, thêm 20% linh khí!"},
    {"chance": 0.05, "type": "backlash",   "msg": "💥 Phản công từ thiên đạo! Thất bại, mất 10% linh khí."},
]

PK_PENDING = {}

# ══════════════════════════════════════════════════════
#  THÔNG THIÊN THÁP — 150 tầng, boss mỗi 30 tầng
# ══════════════════════════════════════════════════════

TOWER_MAX_FLOOR = 150

# Phẩm màu theo tier
TOWER_TIERS = [
    {"floors": range(1,  31),  "grade": "Trắng",     "grade_emoji": "⚪", "color_key": "white"},
    {"floors": range(31, 61),  "grade": "Xanh Lá",   "grade_emoji": "🟢", "color_key": "green"},
    {"floors": range(61, 91),  "grade": "Xanh Dương", "grade_emoji": "🔵", "color_key": "blue"},
    {"floors": range(91, 121), "grade": "Tím",        "grade_emoji": "🟣", "color_key": "purple"},
    {"floors": range(121,151), "grade": "Vàng",       "grade_emoji": "🟡", "color_key": "gold"},
]

# Boss mỗi 30 tầng
TOWER_BOSSES = {
    30:  {"name": "Huyết Vương Quỷ",       "emoji": "👹", "title": "Ác Ma Chi Chủ"},
    60:  {"name": "Hắc Long Thần Quân",    "emoji": "🐲", "title": "Vạn Long Thống Lĩnh"},
    90:  {"name": "Tử Thần Vũ Tiên",       "emoji": "💀", "title": "Thần Vũ Hóa Thần"},
    120: {"name": "Thiên Phong Đế Tôn",    "emoji": "⚡", "title": "Lôi Đình Chi Chủ"},
    150: {"name": "Hỗn Độn Cổ Thần",      "emoji": "🌌", "title": "Vô Thủy Vô Chung Chi Thần"},
}

# Tỉ lệ gặp thú cưng mỗi tầng thường: 10%, random hoàn toàn trong THU_CUNG_SHOP
TOWER_PET_ENCOUNTER_CHANCE = 0.10

# Phần thưởng tăng dần theo từng tầng (tầng 1 → 150)
def _calc_tower_reward(floor):
    """Stone và qi tăng dần theo tầng, công thức mũ nhẹ."""
    f = floor / 150.0
    stone_min = int(5   + 595   * (f ** 1.4))
    stone_max = int(15  + 1485  * (f ** 1.4))
    qi_min    = int(50  + 4950  * (f ** 1.5))
    qi_max    = int(200 + 19800 * (f ** 1.5))
    return stone_min, stone_max, qi_min, qi_max

# Pending thu phục thú khi leo tháp: uid -> {pet_id, qi_cost, floor}
TOWER_PET_PENDING = {}

def _get_tower_grade(floor):
    for t in TOWER_TIERS:
        if floor in t["floors"]:
            return t["grade"], t["grade_emoji"]
    return "Vàng", "🟡"

def _calc_tower_enemy(floor):
    """Tính chỉ số kẻ địch tầng tháp — tăng dần, cân bằng với người chơi thực tế."""
    is_boss = False  # Không có boss cố định, 150 tầng đánh bình thường
    tier_idx = (floor - 1) // 30  # 0..4

    # Base scale theo tier
    tier_scales = [1.0, 2.5, 6.0, 15.0, 40.0]
    scale = tier_scales[min(tier_idx, 4)]

    # Nội trong tier tăng dần
    within_tier = ((floor - 1) % 30) / 29.0  # 0..1
    scale *= (1.0 + within_tier * 0.8)

    # Boss mạnh hơn 2.5x
    if is_boss:
        scale *= 2.5

    base_atk = int(500 * scale)
    base_hp  = int(base_atk * 10)
    base_def = int(base_atk * 0.8)
    spd      = round(100 + floor * 8.5, 2)
    bao_kick = round(30 + floor * 0.24, 2)
    sat_bao  = round(200 + floor * 3.5, 2)
    chinh_xac = round(50 + floor * 0.22, 2)
    ne_tranh  = round(30 + floor * 0.24, 2)
    phan_don  = round(30 + floor * 0.24, 2)
    khang_bao = round(30 + floor * 0.24, 2)
    khang_phan = round(30 + floor * 0.24, 2)

    if is_boss:
        boss_info = TOWER_BOSSES.get(floor, {"name": f"Tháp Boss Tầng {floor}", "emoji": "👊", "title": ""})
        name = f"{boss_info['emoji']} {boss_info['name']}"
    else:
        normal_names = [
            "Thạch Khối Ma", "Hỏa Hồ Ly", "Lôi Điểu", "Băng Lang", "Độc Xà Tinh",
            "Cốt Linh Quỷ", "Phong Ưng", "Huyết Sói", "Thiết Giáp Hùng", "Ngân Hổ",
            "Lôi Hổ Tinh", "Hắc Ưng Ma", "Thiên Tàm", "Kim Xà Vương", "Ngọc Kỳ Lân",
        ]
        seed = (floor * 7 + 13) % len(normal_names)
        name = normal_names[seed]

    grade, grade_emoji = _get_tower_grade(floor)
    power = int(base_atk * 0.3 + base_hp * 0.05 + base_def * 0.2)

    return {
        "name":       name,
        "atk":        base_atk,
        "hp":         base_hp,
        "def":        base_def,
        "power":      power,
        "grade":      grade,
        "grade_emoji": grade_emoji,
        "spd":        spd,
        "bao_kick":   bao_kick,
        "sat_bao":    sat_bao,
        "chinh_xac":  chinh_xac,
        "ne_tranh":   ne_tranh,
        "phan_don":   phan_don,
        "khang_bao":  khang_bao,
        "khang_phan": khang_phan,
        "is_boss":    is_boss,
    }

def _calc_player_tower_stats(p):
    """Tính HP/ATK/DEF của người chơi trong tháp — dựa vào trang bị + cảnh giới."""
    realm = _get_realm(p["realm"])
    atk = p.get("atk", 10)
    def_ = p.get("def", 10)
    hp = int(1000 + p.get("qi", 0) * 0.002 + def_ * 5 + realm["multiplier"] * 500)
    return atk, def_, hp

def _simulate_tower_battle(player_name, p_atk, p_def, p_hp, enemy):
    """Mô phỏng chiến đấu theo hiệp, trả về (win, logs, hieps)."""
    e_hp  = enemy["hp"]
    e_atk = enemy["atk"]
    e_def = enemy["def"]
    cur_p_hp = p_hp
    logs = []
    hiep = 0

    while cur_p_hp > 0 and e_hp > 0 and hiep < 30:
        hiep += 1
        hiep_lines = []

        # Lượt người chơi
        crit_p = random.random() < 0.20
        dmg_p  = int(p_atk * random.uniform(0.85, 1.15))
        dmg_p  = max(1, dmg_p - int(e_def * 0.3))
        if crit_p:
            dmg_p = int(dmg_p * random.uniform(2.0, 3.0))
        ne_enemy = random.random() < (enemy["ne_tranh"] / 300.0)
        if ne_enemy:
            hiep_lines.append(f"  🔹{player_name} ⚔️ {'💥 Chí mạng! ' if crit_p else ''}{enemy['name']} 🌀 né!")
        else:
            e_hp -= dmg_p
            hiep_lines.append(f"  🔹{player_name} ⚔️ {'💥 Chí mạng! ' if crit_p else ''}Gây {dmg_p:,} sát thương\n  {enemy['name']}: {max(0,e_hp):,}❤️")

        # Lượt kẻ địch
        if e_hp > 0:
            crit_e = random.random() < (enemy["bao_kick"] / 200.0)
            dmg_e  = int(e_atk * random.uniform(0.85, 1.15))
            dmg_e  = max(1, dmg_e - int(p_def * 0.3))
            if crit_e:
                dmg_e = int(dmg_e * (enemy["sat_bao"] / 200.0))
            ne_player = random.random() < 0.15
            if ne_player:
                hiep_lines.append(f"  🔹{enemy['name']} ⚔️ {player_name} 🌀 né!\n  {player_name}: {max(0,cur_p_hp):,}❤️")
            else:
                cur_p_hp -= dmg_e
                hiep_lines.append(f"  🔹{enemy['name']} ⚔️ Gây {dmg_e:,} sát thương\n  {player_name}: {max(0,cur_p_hp):,}❤️")

        logs.append((hiep, hiep_lines))

    win = e_hp <= 0
    return win, logs, hiep

def _get_tower_pet_encounter(floor):
    """10% mỗi tầng gặp thú cưng, random hoàn toàn trong THU_CUNG_SHOP."""
    if random.random() < TOWER_PET_ENCOUNTER_CHANCE:
        pet = random.choice(THU_CUNG_SHOP)
        return {
            "pet_id":  pet["id"],
            "qi_cost": pet["price"],
        }
    return None

def _path_tower_record():
    os.makedirs(DATA_DIR, exist_ok=True)
    return f"{DATA_DIR}/tower_records.json"

def _load_tower_records():
    try:
        with open(_path_tower_record(), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_tower_records(records):
    with open(_path_tower_record(), "w", encoding="utf-8") as f:
        json.dump(records, f, ensure_ascii=False, indent=2)

def _get_player_tower_floor(uid):
    records = _load_tower_records()
    return records.get(str(uid), {}).get("floor", 0)

def _set_player_tower_floor(uid, floor, name):
    records = _load_tower_records()
    records[str(uid)] = {"floor": floor, "name": name}
    _save_tower_records(records)

def _cmd_leothap(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    current_floor = _get_player_tower_floor(uid)

    # Nếu có số thì leo tầng đó, không thì leo tầng tiếp theo
    target_floor = None
    if args and args[0].isdigit():
        target_floor = int(args[0])
        if not (1 <= target_floor <= TOWER_MAX_FLOOR):
            body = f"  Tầng không hợp lệ! (1 - {TOWER_MAX_FLOOR})"
            self.replyMessageStyle(_msg_box("❌","THÔNG THIÊN THÁP",body),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            return
        if target_floor > current_floor + 1:
            body = f"  Ngươi chưa đạt tầng {target_floor}!\n  Tầng cao nhất đã qua: {current_floor}"
            self.replyMessageStyle(_msg_box("❌","THÔNG THIÊN THÁP",body),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            return
    else:
        target_floor = current_floor + 1

    if target_floor > TOWER_MAX_FLOOR:
        body = f"  🎉 Ngươi đã chinh phục toàn bộ {TOWER_MAX_FLOOR} tầng Thông Thiên Tháp!\n  Thiên hạ vô địch!"
        self.replyMessageStyle(_msg_box("🌌","THÔNG THIÊN THÁP",body),data,threadId,type,color="cyan",title="TU TIÊN",userId=userId)
        return

    enemy = _calc_tower_enemy(target_floor)
    p_atk, p_def, p_hp = _calc_player_tower_stats(p)

    win, logs, total_hiep = _simulate_tower_battle(p["name"], p_atk, p_def, p_hp, enemy)

    # Format log chiến đấu
    battle_lines = []
    for hiep_num, lines in logs:
        battle_lines.append(f"\n  ━━━━━🎯Hiệp {hiep_num}━━━━━\n" + "\n".join(lines))
    battle_text = "\n".join(battle_lines)

    grade_txt = f"{enemy['grade_emoji']} {enemy['grade']}"

    if win:
        # Cập nhật tầng nếu là tầng mới
        if target_floor > current_floor:
            _set_player_tower_floor(uid, target_floor, p["name"])

        # Phần thưởng tăng dần theo tầng
        stone_min, stone_max, qi_min, qi_max = _calc_tower_reward(target_floor)
        stone_gain = random.randint(stone_min, stone_max)
        qi_gain    = random.randint(qi_min, qi_max)

        # Ngẫu nhiên linh bảo/pháp bảo rơi, cộng vào kho
        bonus_drop = ""
        roll_drop = random.random()
        if roll_drop < 0.03:
            drop_item = random.choice(LINH_BAO_SHOP)
            p.setdefault("inventory", {})[drop_item["id"]] = p["inventory"].get(drop_item["id"], 0) + 1
            stone_gain += 500
            bonus_drop = f"\n  🎁 Rơi ra: {drop_item['emoji']} {drop_item['name']} → vào kho! (+500💠)"
        elif roll_drop < 0.08:
            drop_item = random.choice(PHAO_BAO_SHOP)
            p.setdefault("inventory", {})[drop_item["id"]] = p["inventory"].get(drop_item["id"], 0) + 1
            stone_gain += 150
            bonus_drop = f"\n  🎁 Rơi ra: {drop_item['emoji']} {drop_item['name']} → vào kho! (+150💠)"

        p["stones"]    = p.get("stones", 0) + stone_gain
        p["qi"]        = p.get("qi", 0) + qi_gain
        p["qi_total"]  = p.get("qi_total", 0) + qi_gain
        _save_player(uid, p)

        reward_text = (
            f"  🎁 Phần thưởng:\n"
            f"  💠 Linh thạch: +{stone_gain}\n"
            f"  💧 Linh khí: +{_format_num(qi_gain)}"
            f"{bonus_drop}"
        )

        header = f"🏯 Vượt ải Thông Thiên Tháp Tầng {target_floor} thành công! 🎉"

        body = (
            f"  🚦 {p['name']}\n"
            f"  {header}\n"
            f"{battle_text}\n\n"
            f"  🏆 Kết quả: {p['name']} Thắng!\n\n"
            f"{reward_text}"
        )

        # Kiểm tra gặp thú cưng
        enc = _get_tower_pet_encounter(target_floor)
        if enc:
            pet_info = _item_by_id(enc["pet_id"])
            if pet_info and p.get("qi", 0) >= enc["qi_cost"]:
                TOWER_PET_PENDING[uid] = {
                    "pet_id":  enc["pet_id"],
                    "qi_cost": enc["qi_cost"],
                    "floor":   target_floor,
                }
                pet_msg = (
                    f"\n\n  ✨✨✨ PHÁT HIỆN LINH THÚ! ✨✨✨\n"
                    f"  {pet_info['emoji']} {pet_info['name']} xuất hiện giữa đống tàn tích!\n"
                    f"  Linh thú này dường như đang trong hoàn cảnh nguy hiểm...\n\n"
                    f"  💰 Chi phí thu phục: {_format_num(enc['qi_cost'])} linh khí\n"
                    f"  💧 Linh khí ngươi có: {_format_num(p['qi'])}\n\n"
                    f"  👉 Nhập {_cc(self)} ok để thu phục và tiêu {_format_num(enc['qi_cost'])} LK\n"
                    f"  👉 Nhập {_cc(self)} huy để bước qua, bỏ lại linh thú"
                )
                body += pet_msg

        self.replyMessageStyle(_msg_box("🏯","THÔNG THIÊN THÁP",body),data,threadId,type,color="cyan",title="TU TIÊN",userId=userId)

    else:
        body = (
            f"  🚦 {p['name']}\n"
            f"  ❌ Thất bại tại Tầng {target_floor}!\n"
            f"{battle_text}\n\n"
            f"  💀 Kết quả: {p['name']} Thua!\n"
            f"  Hãy tăng cường tu luyện và thử lại!"
        )
        self.replyMessageStyle(_msg_box("💀","THÔNG THIÊN THÁP",body),data,threadId,type,color="r",title="TU TIÊN",userId=userId)

def _cmd_soithap(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    current_floor = _get_player_tower_floor(uid)

    if args and args[0].isdigit():
        target_floor = int(args[0])
        if not (1 <= target_floor <= TOWER_MAX_FLOOR):
            body = f"  Tầng không hợp lệ! (1 - {TOWER_MAX_FLOOR})"
            self.replyMessageStyle(_msg_box("❌","THÔNG THIÊN THÁP",body),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            return
    else:
        target_floor = current_floor + 1
        if target_floor > TOWER_MAX_FLOOR:
            target_floor = TOWER_MAX_FLOOR

    enemy = _calc_tower_enemy(target_floor)
    p_atk, p_def, p_hp = _calc_player_tower_stats(p)

    stone_min, stone_max, qi_min, qi_max = _calc_tower_reward(target_floor)
    rw_txt = f"  💠 {stone_min}-{stone_max} linh thạch\n  💧 {_format_num(qi_min)}-{_format_num(qi_max)} linh khí"

    body = (
        f"  🛎️ Trấn giữ 🏯 Thông Thiên Tháp Tầng {target_floor}\n"
        f"  {enemy['name']}\n\n"
        f"  💪 Sức mạnh: {enemy['power']:,}\n"
        f"  🪬 Phẩm: {enemy['grade']} {enemy['grade_emoji']}\n\n"
        f"  🧬 Chỉ số:\n"
        f"  ➜ ⚔️ Công: {enemy['atk']:,}\n"
        f"  ➜ ❤️ HP: {enemy['hp']:,}\n"
        f"  ➜ 🛡️ Thủ: {enemy['def']:,}\n"
        f"  ➜ ⚡ Tốc: {enemy['spd']}\n"
        f"  ➜ 💢 Bạo Kích: {enemy['bao_kick']}%\n"
        f"  ➜ 💥 Sát Thương Bạo: {enemy['sat_bao']}%\n"
        f"  ➜ 🎯 Chính Xác: {enemy['chinh_xac']}%\n"
        f"  ➜ 🌀 Né Tránh: {enemy['ne_tranh']}%\n"
        f"  ➜ 🔁 Phản Đòn: {enemy['phan_don']}%\n"
        f"  ➜ 🔰 Kháng Bạo: {enemy['khang_bao']}%\n"
        f"  ➜ 💫 Kháng Phản: {enemy['khang_phan']}%\n\n"
        f"  ⚔️ Chỉ số ngươi:\n"
        f"  ➜ Công: {p_atk:,} · Thủ: {p_def:,} · HP: {p_hp:,}\n\n"
        f"  🏆 Phần thưởng:\n{rw_txt}"
    )
    self.replyMessageStyle(_msg_box("🔍","SOI THÁP",body),data,threadId,type,color="cyan",title="TU TIÊN",userId=userId)

def _cmd_bxhthap(self, data, userId, threadId, type):
    records = _load_tower_records()
    if not records:
        body = "  Chưa có ai chinh phục Thông Thiên Tháp!"
        self.replyMessageStyle(_msg_box("🏆","BXH THÔNG THIÊN THÁP",body),data,threadId,type,color="yl",title="TU TIÊN",userId=userId)
        return

    sorted_records = sorted(records.items(), key=lambda x: x[1].get("floor", 0), reverse=True)[:10]
    medals = ["🥇","🥈","🥉"]
    lines  = []
    for i, (uid, rec) in enumerate(sorted_records):
        medal = medals[i] if i < 3 else f"{i+1}."
        floor = rec.get("floor", 0)
        name  = rec.get("name", f"Tu sĩ #{uid[-4:]}")
        grade, grade_emoji = _get_tower_grade(min(floor, TOWER_MAX_FLOOR)) if floor > 0 else ("?","❓")
        lines.append(f"  {medal} {name}\n     🏯 Tầng {floor} · {grade_emoji} {grade}")

    body = "  🏯 Ai leo cao nhất Thông Thiên Tháp?\n\n" + "\n\n".join(lines)
    self.replyMessageStyle(_msg_box("🏆","BXH THÔNG THIÊN THÁP",body),data,threadId,type,color="cyan",title="TU TIÊN",userId=userId)

def _cmd_thu_phuc_pet(self, data, userId, threadId, type, p, answer):
    uid = str(userId)
    pending = TOWER_PET_PENDING.get(uid)
    if not pending:
        return False  # Không có pending

    pet_id  = pending["pet_id"]
    qi_cost = pending["qi_cost"]
    floor   = pending["floor"]
    pet_info = _item_by_id(pet_id)

    del TOWER_PET_PENDING[uid]

    if answer in ("ok", "ок", "OK", "Ok"):
        if p.get("qi", 0) < qi_cost:
            body = (
                f"  Linh khí không đủ để thu phục!\n"
                f"  Cần: {_format_num(qi_cost)} · Có: {_format_num(p.get('qi',0))}\n"
                f"  {pet_info['emoji']} {pet_info['name']} đã bỏ đi..."
            )
            self.replyMessageStyle(_msg_box("❌","THU PHỤC THẤT BẠI",body),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            return True

        # Thu phục thành công
        old_pet_id = p.get("pet")
        if old_pet_id and old_pet_id != pet_id:
            old_pet = _item_by_id(old_pet_id)
            if old_pet:
                p["atk"] = max(10, p.get("atk", 10) - old_pet.get("atk_bonus", 0))
                p["def"] = max(10, p.get("def", 10) - old_pet.get("def_bonus", 0))

        p["qi"]  = p.get("qi", 0) - qi_cost
        p["atk"] = p.get("atk", 10) + pet_info.get("atk_bonus", 0)
        p["def"] = p.get("def", 10) + pet_info.get("def_bonus", 0)
        p["pet"] = pet_id
        p["pet_bonus_synced"] = True
        _save_player(uid, p)

        body = (
            f"  {pet_info['emoji']} {pet_info['name']} đã theo ngươi tu hành!\n\n"
            f"  💰 Tiêu tốn: {_format_num(qi_cost)} linh khí\n"
            f"  💧 LK còn lại: {_format_num(p['qi'])}\n"
            f"  ⚔️ Công: {p['atk']} · 🛡️ Thủ: {p['def']}\n\n"
            f"  🐾 Linh thú hoạn nạn nay đã là bạn đồng hành!"
        )
        self.replyMessageStyle(_msg_box("✅","THU PHỤC THÀNH CÔNG",body),data,threadId,type,color="cyan",title="TU TIÊN",userId=userId)
        return True

    elif answer in ("huy", "HUY", "Huy", "bỏ", "bo"):
        body = (
            f"  Ngươi bước qua, để lại {pet_info['emoji']} {pet_info['name']}...\n"
            f"  Linh thú nhìn theo bóng ngươi khuất xa. Hoặc là một cơ duyên khác đang chờ?"
        )
        self.replyMessageStyle(_msg_box("🚶","BỎ QUA LINH THÚ",body),data,threadId,type,color="yl",title="TU TIÊN",userId=userId)
        return True

    return False  # Không phải ok/huy → không xử lý

def _path_player(uid):
    os.makedirs(DATA_DIR, exist_ok=True)
    return f"{DATA_DIR}/player_{uid}.json"

def _safe_bang_key(bang_id):
    normalized = (bang_id or "").strip().lower()
    return hashlib.md5(normalized.encode("utf-8")).hexdigest()

def _path_bang(bang_id):
    os.makedirs(DATA_DIR, exist_ok=True)
    return f"{DATA_DIR}/bang_{_safe_bang_key(bang_id)}.json"

def _load_player(uid):
    try:
        with open(_path_player(uid), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return None

def _save_player(uid, data):
    with open(_path_player(uid), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _new_player(name):
    return {
        "name":        name,
        "realm":       0,
        "qi":          0,
        "qi_total":    0,
        "stones":      0,
        "atk":         10,
        "def":         10,
        "equipment":   [],
        "pet":         None,
        "inventory":   {},
        "active_buff": None,
        "buff_uses":   0,
        "bang":        None,
        "last_tuluy":  0,
        "last_mine":   0,
        "pk_wins":     0,
        "pk_losses":   0,
        "created_at":  int(time.time()),
    }

def _load_bang(bang_id):
    try:
        with open(_path_bang(bang_id), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        pass

    legacy_path = f"{DATA_DIR}/bang_{bang_id}.json"
    try:
        with open(legacy_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None

    try:
        _save_bang(bang_id, data)
        if os.path.abspath(legacy_path) != os.path.abspath(_path_bang(bang_id)):
            os.remove(legacy_path)
    except Exception:
        pass
    return data

def _save_bang(bang_id, data):
    with open(_path_bang(bang_id), "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def _get_realm(realm_id):
    return REALMS[min(realm_id, len(REALMS)-1)]

def _get_next_realm(realm_id):
    nxt = realm_id + 1
    if nxt >= len(REALMS):
        return None
    return REALMS[nxt]

def _calc_combat_power(p):
    """Chiến lực. atk/def đã bao gồm trang bị + thú cưng rồi, không tính đôi."""
    realm    = _get_realm(p.get("realm", 0))
    base_cp  = p.get("qi_total", 0) * 0.1
    eq_cp    = p.get("atk", 10) * 2 + p.get("def", 10)
    realm_cp = realm["multiplier"] * 100
    return int(base_cp + eq_cp + realm_cp)

def _format_num(n):
    if n >= 1_000_000_000:
        return f"{n/1_000_000_000:.2f}tỷ"
    if n >= 1_000_000:
        return f"{n/1_000_000:.2f}triệu"
    if n >= 1_000:
        return f"{n/1_000:.1f}k"
    return str(n)

def _item_by_id(item_id):
    for item in LINH_BAO_SHOP + PHAO_BAO_SHOP + THU_CUNG_SHOP:
        if item["id"] == item_id:
            return item
    return None

def _all_players_sorted():
    players = []
    for fname in os.listdir(DATA_DIR):
        if fname.startswith("player_") and fname.endswith(".json"):
            uid = fname[7:-5]
            p = _load_player(uid)
            if p:
                players.append((uid, p))
    players.sort(key=lambda x: (x[1]["realm"], x[1]["qi"]), reverse=True)
    return players

DIV = "· · ·"

def _msg_box(title_emoji, title, body):
    return f"{title_emoji} {title}\n{DIV}\n{body}\n{DIV}"

IMAGE_DIR = "data/imagetutien"
_FONT_PATH = "assets/font/Goldman/Goldman-Bold.ttf"

def _get_realm_image_path(realm_id):
    """Trả về đường dẫn ảnh cảnh giới.
    realm 0 = Phàm Nhân → ảnh 1.webp
    realm 1..19 → ảnh 2.webp..20.webp
    realm 20 = Tiên Nhân → ảnh 20.png
    """
    img_id = max(1, min(realm_id + 1, 20))
    for ext in ("webp", "png", "jpg", "jpeg"):
        path = f"{IMAGE_DIR}/{img_id}.{ext}"
        if os.path.exists(path):
            return path
    return f"{IMAGE_DIR}/{img_id}.webp"

def _draw_realm_label_on_image(img_path, realm_name, out_path):
    """Vẽ tên cảnh giới lên đầu ảnh — chữ vàng + nền tối mờ + stroke.
    Trả về True nếu thành công, False nếu lỗi (Pillow chưa cài, v.v.)
    """
    try:
        from PIL import Image as _Img, ImageDraw, ImageFont

        img = _Img.open(img_path).convert("RGBA")
        w, h = img.size

        font_size = max(36, w // 15)
        font = None
        if os.path.exists(_FONT_PATH):
            try:
                font = ImageFont.truetype(_FONT_PATH, font_size)
            except Exception:
                pass
        if font is None:
            font = ImageFont.load_default()

        # Đo kích thước text
        _tmp = ImageDraw.Draw(_Img.new("RGBA", (1, 1)))
        bbox = _tmp.textbbox((0, 0), realm_name, font=font)
        tw = bbox[2] - bbox[0]
        th = bbox[3] - bbox[1]

        pad_v = int(th * 0.45)
        banner_h = th + pad_v * 2

        # Tạo lớp overlay banner
        overlay = _Img.new("RGBA", (w, banner_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)

        # Nền tối mờ fade ở 2 mép trái/phải
        fade_px = min(80, w // 6)
        for x in range(w):
            edge = min(x, w - x)
            alpha = min(195, int(195 * edge / fade_px)) if edge < fade_px else 195
            draw.line([(x, 0), (x, banner_h)], fill=(15, 8, 4, alpha))

        # Viền vàng dưới banner
        draw.line([(0, banner_h - 2), (w, banner_h - 2)], fill=(255, 200, 30, 200), width=2)

        # Vẽ text với stroke đen để không bị dìm vào bất kỳ màu nền nào
        tx = (w - tw) // 2 - bbox[0]
        ty = pad_v - bbox[1]
        stroke_w = max(2, font_size // 18)
        for dx in range(-stroke_w, stroke_w + 1):
            for dy in range(-stroke_w, stroke_w + 1):
                if dx or dy:
                    draw.text((tx + dx, ty + dy), realm_name, font=font, fill=(0, 0, 0, 255))
        # Chữ vàng nổi
        draw.text((tx, ty), realm_name, font=font, fill=(255, 232, 90, 255))

        result = img.copy()
        result.paste(overlay, (0, 0), overlay)
        result.convert("RGB").save(out_path, "JPEG", quality=94)
        return True
    except Exception as e:
        print(f"[TuTien] draw_realm_label error: {e}")
        return False

def _send_with_realm_image(self, caption_text, realm_id, thread_id, thread_type, userId=None):
    """Vẽ tên cảnh giới lên ảnh rồi upload + gửi với caption. Trả về True nếu OK."""
    img_path = _get_realm_image_path(realm_id)
    if not os.path.exists(img_path):
        return False

    realm = _get_realm(realm_id)
    label = f"{realm['emoji']} {realm['name']}"

    import tempfile
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".jpg")
    os.close(tmp_fd)

    img_url = None
    img_w = img_h = 0
    try:
        ok = _draw_realm_label_on_image(img_path, label, tmp_path)
        send_path = tmp_path if ok else img_path

        from PIL import Image as _Img
        with _Img.open(send_path) as im:
            img_w, img_h = im.size

        res = self._uploadImage(send_path, thread_id, thread_type)
        if isinstance(res, dict):
            img_url = res.get("normalUrl") or res.get("hdUrl")
        elif isinstance(res, str) and res.startswith("http"):
            img_url = res
    except Exception as e:
        print(f"[TuTien] upload error: {e}")
    finally:
        try:
            os.remove(tmp_path)
        except Exception:
            pass

    if img_url:
        try:
            mention = None
            full_caption = caption_text
            if userId:
                name = self.userName(str(userId))
                if name:
                    mention_str = f"@{name}"
                    mention = Mention(str(userId), length=len(mention_str), offset=0)
                    full_caption = f"{mention_str}\n{caption_text}"
            self.sendRemoteImage(
                img_url, thread_id, thread_type,
                width=img_w or 800, height=img_h or 800,
                message=Message(text=full_caption, mention=mention),
            )
            return True
        except Exception as e:
            print(f"[TuTien] sendRemoteImage error: {e}")
    return False

def _cc(self):
    pfx = getattr(self, "prefix", "/") or "/"
    cmd = getattr(self, "rawCommand", None) or getattr(self, "commandName", None) or "tutien"
    return f"{pfx}{cmd}"

def _cmd_start(self, data, userId, threadId, type, player_data):
    uid = str(userId)
    if player_data:
        r = _get_realm(player_data["realm"])
        body = (
            f"  Ngươi đã là tu sĩ rồi!\n"
            f"  {r['emoji']} {r['name']}\n\n"
            f"  Dùng {_cc(self)} tt để xem thông tin."
        )
        self.replyMessageStyle(
            _msg_box("🌸", "THIÊN ĐẠO CHI LỘ", body),
            data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
        )
        return

    name = self.userName(uid) or f"Đạo Hữu_{uid[-4:]}"
    p = _new_player(name)
    _save_player(uid, p)

    body = (
        f"  Chào {name} bước vào con đường tu tiên!\n\n"
        f"  👤 Phàm Nhân · 0 Linh Khí · 0 Linh Thạch\n\n"
        f"  ✦ Lệnh cơ bản:\n"
        f"  {_cc(self)} tl   — Tu luyện (10s hồi)\n"
        f"  {_cc(self)} db   — Đột phá cảnh giới\n"
        f"  {_cc(self)} tt   — Xem thông tin\n"
        f"  {_cc(self)} shop — Cửa hàng\n"
        f"  {_cc(self)} mine — Khai thác linh thạch (30s hồi)\n\n"
        f"  ⚡ Hành trình vạn dặm bắt đầu từ một bước nhỏ..."
    )
    caption = _msg_box("🌸", "CHÀO MỪNG TU SĨ MỚI", body)
    sent = _send_with_realm_image(self, caption, 0, threadId, type, userId=userId)
    if not sent:
        self.replyMessageStyle(caption, data, threadId, type, color="cyan", title="TU TIÊN", userId=userId)

def _cmd_tuluy(self, data, userId, threadId, type, p):
    uid = str(userId)
    now = int(time.time())
    bang = _load_bang(p["bang"]) if p.get("bang") else None
    is_leader = bang and bang.get("leader") == uid
    cooldown = 10 if is_leader else 10

    if now - p.get("last_tuluy", 0) < cooldown:
        remain = cooldown - (now - p["last_tuluy"])
        body = (
            f"  ⏳ Linh khí chưa phục hồi đủ!\n"
            f"  Còn {remain}s nữa mới có thể tu tiếp."
        )
        self.replyMessageStyle(
            _msg_box("⏳", "TU LUYỆN", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    realm   = _get_realm(p["realm"])
    base_qi = int(50 * realm["multiplier"])
    rand_qi = random.randint(int(base_qi * 0.8), int(base_qi * 1.2))

    bonus_qi = 0
    buff_msg = ""
    if p.get("active_buff") and p.get("buff_uses", 0) > 0:
        item = _item_by_id(p["active_buff"])
        if item and item.get("qi_bonus", 0) > 0:
            bonus_qi = item["qi_bonus"]
            p["buff_uses"] -= 1
            buff_msg = f"\n  🌿 [{item['name']}] +{_format_num(bonus_qi)} LK ({p['buff_uses']} lần còn lại)"
            if p["buff_uses"] <= 0:
                p["active_buff"] = None
                p["buff_uses"] = 0
                buff_msg += "\n  ⚠️ Linh bảo đã hết tác dụng!"

    pet_qi_extra = 0
    pet_msg = ""
    if p.get("pet"):
        pet = _item_by_id(p["pet"])
        if pet and pet.get("qi_multi", 1.0) > 1.0:
            pet_qi_extra = int(rand_qi * (pet["qi_multi"] - 1.0))
            pet_msg = f"\n  {pet['emoji']} {pet['name']} ban phước +{_format_num(pet_qi_extra)} LK"

    bang_qi_extra = 0
    bang_qi_msg = ""
    if p.get("bang_qi_bonus"):
        bang_qi_extra = int(rand_qi * p["bang_qi_bonus"])
        bang_qi_msg = f"\n  🏯 Hàng bang phù hộ +{_format_num(bang_qi_extra)} LK"

    event_msg  = ""
    roll       = random.random()
    acc        = 0
    final_multi = 1.0
    penalty    = 0
    stone_gain = 0
    item_gain  = None

    for ev in TU_LUYEN_EVENTS:
        acc += ev["chance"]
        if roll < acc:
            if ev["type"] == "bonus":
                final_multi = ev["multi"]
                event_msg   = f"\n\n  {ev['msg']}"
            elif ev["type"] == "stone":
                stone_gain = random.randint(*ev["stone"])
                event_msg  = f"\n\n  {ev['msg']} (+{stone_gain} 💠)"
            elif ev["type"] == "item":
                item_gain = ev["item"]
                event_msg = f"\n\n  {ev['msg']}"
            elif ev["type"] == "bad":
                penalty   = ev["penalty"]
                event_msg = f"\n\n  {ev['msg']}"
            break

    total_qi = int((rand_qi + bonus_qi + pet_qi_extra + bang_qi_extra) * final_multi)
    if penalty > 0:
        penalty_amount = int(total_qi * penalty)
        total_qi -= penalty_amount

    total_qi = max(1, total_qi)
    p["qi"]       += total_qi
    p["qi_total"] += total_qi
    p["last_tuluy"] = now

    if stone_gain:
        p["stones"] = p.get("stones", 0) + stone_gain
    if item_gain:
        p.setdefault("inventory", {})[item_gain] = p["inventory"].get(item_gain, 0) + 1

    next_realm = _get_next_realm(p["realm"])
    qi_needed  = (next_realm["required_qi"] - _get_realm(p["realm"])["required_qi"]) if next_realm else 0
    current_progress = p["qi"] - _get_realm(p["realm"])["required_qi"]
    pct = min(100, int(current_progress / qi_needed * 100)) if qi_needed > 0 else 100
    bar = "▓" * (pct // 10) + "░" * (10 - pct // 10)

    body = (
        f"  {realm['emoji']} {realm['name']}\n"
        f"  +{_format_num(total_qi)} linh khí thu hoạch"
        f"{buff_msg}{pet_msg}{bang_qi_msg}{event_msg}\n\n"
        f"  💧 Linh khí: {_format_num(p['qi'])}\n"
        f"  💠 Linh thạch: {p['stones']}\n"
    )
    if next_realm:
        body += f"\n  [{bar}] {pct}%\n  ↑ Cần thêm {_format_num(max(0, next_realm['required_qi'] - p['qi']))} LK để đột phá"
    else:
        body += "\n  ✦ Đạt đỉnh Tiên Nhân! Vô thượng cảnh giới!"

    _save_player(uid, p)
    self.replyMessageStyle(
        _msg_box("⚡", "TU LUYỆN", body),
        data, threadId, type, color="or", title="TU TIÊN", userId=userId
    )

def _cmd_dotpha(self, data, userId, threadId, type, p):
    uid = str(userId)
    next_realm = _get_next_realm(p["realm"])
    if not next_realm:
        body = "  🌸 Ngươi đã đạt đỉnh Tiên Nhân!\n  Không còn cảnh giới nào cao hơn!"
        self.replyMessageStyle(
            _msg_box("🌸", "ĐỘT PHÁ", body),
            data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
        )
        return

    if p["qi"] < next_realm["required_qi"]:
        needed = next_realm["required_qi"] - p["qi"]
        body = (
            f"  Linh khí chưa đủ để đột phá!\n\n"
            f"  ⟶ {next_realm['emoji']} {next_realm['name']}\n"
            f"  Cần: {_format_num(next_realm['required_qi'])} · Hiện có: {_format_num(p['qi'])}\n"
            f"  Còn thiếu: {_format_num(needed)} LK\n\n"
            f"  Tiếp tục tu luyện thêm nhé!"
        )
        self.replyMessageStyle(
            _msg_box("❌", "ĐỘT PHÁ THẤT BẠI", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    roll   = random.random()
    acc    = 0
    ev_type = "success"
    ev_msg  = ""
    for ev in DOTPHA_EVENTS:
        acc += ev["chance"]
        if roll < acc:
            ev_type = ev["type"]
            ev_msg  = ev["msg"]
            break

    if ev_type == "fail_qi":
        body = f"  {ev_msg}\n\n  💧 Linh khí hiện có: {_format_num(p['qi'])}"
        self.replyMessageStyle(
            _msg_box("⚠️", "ĐỘT PHÁ", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    if ev_type == "backlash":
        penalty = int(p["qi"] * 0.10)
        p["qi"] -= penalty
        _save_player(uid, p)
        body = f"  {ev_msg}\n\n  Mất {_format_num(penalty)} LK. Thử lại sau!"
        self.replyMessageStyle(
            _msg_box("💥", "ĐỘT PHÁ THẤT BẠI", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    old_realm = _get_realm(p["realm"])
    p["realm"] += 1
    p["qi"]    -= next_realm["required_qi"]

    bonus_qi = 0
    if ev_type == "insight":
        bonus_qi = int(p["qi"] * 0.20)
        p["qi"] += bonus_qi

    new_realm = _get_realm(p["realm"])
    atk_gain  = int(20 * new_realm["multiplier"])
    def_gain  = int(15 * new_realm["multiplier"])
    p["atk"] += atk_gain
    p["def"] += def_gain

    _save_player(uid, p)

    event_text = f"\n  {ev_msg}" if ev_msg else ""
    bonus_text = f"\n  💡 Đốn ngộ: +{_format_num(bonus_qi)} LK" if bonus_qi > 0 else ""

    body = (
        f"  {old_realm['emoji']} {old_realm['name']}\n"
        f"         ↓ ĐỘT PHÁ ↓\n"
        f"  {new_realm['emoji']} {new_realm['name']}"
        f"{event_text}{bonus_text}\n\n"
        f"  ⚔️ +{atk_gain} công · 🛡️ +{def_gain} thủ\n"
        f"  💧 Linh khí dư: {_format_num(p['qi'])}"
    )
    caption = _msg_box("🌟", "ĐỘT PHÁ THÀNH CÔNG", body)
    # Gửi ảnh cảnh giới mới khi đột phá thành công
    sent = _send_with_realm_image(self, caption, p["realm"], threadId, type, userId=userId)
    if not sent:
        self.replyMessageStyle(caption, data, threadId, type, color="cyan", title="TU TIÊN", userId=userId)

def _cmd_thongtin(self, data, userId, threadId, type, p, target_p=None, target_uid=None):
    # Nếu xem người khác thì dùng target_p và target_uid
    view_p    = target_p if target_p else p
    view_uid  = target_uid if target_uid else str(userId)
    is_other  = target_p is not None

    realm      = _get_realm(view_p["realm"])
    next_realm = _get_next_realm(view_p["realm"])
    cp = _calc_combat_power(view_p)

    eq_names = []
    for eq_id in view_p.get("equipment", []):
        item = _item_by_id(eq_id)
        if item:
            eq_names.append(f"{item['emoji']} {item['name']}")
    eq_text = " · ".join(eq_names) if eq_names else "Chưa có trang bị"

    pet_text = "Chưa có"
    if view_p.get("pet"):
        pet = _item_by_id(view_p["pet"])
        if pet:
            pet_text = f"{pet['emoji']} {pet['name']}"

    bang_text = view_p.get("bang") or "Chưa gia nhập bang"

    progress_text = ""
    if next_realm and not is_other:
        qi_to_next = next_realm["required_qi"] - view_p["qi"]
        pct = min(100, int((view_p["qi"] - realm["required_qi"]) / (next_realm["required_qi"] - realm["required_qi"]) * 100)) if next_realm["required_qi"] > realm["required_qi"] else 100
        bar = "▓" * (pct // 10) + "░" * (10 - pct // 10)
        progress_text = (
            f"\n\n  ⟦ Tiến độ đột phá ⟧\n"
            f"  [{bar}] {pct}%\n"
            f"  ⟶ {next_realm['emoji']} {next_realm['name']}\n"
            f"  Cần {_format_num(next_realm['required_qi'])} · Thiếu {_format_num(max(0, qi_to_next))}"
        )

    tower_floor = _get_player_tower_floor(view_uid)
    tower_txt = f"🏯 Tầng {tower_floor}" if tower_floor > 0 else "Chưa leo"

    body = (
        f"  ✦ {view_p['name']}{' (Người dùng khác)' if is_other else ''}\n\n"
        f"  {realm['emoji']} {realm['name']}\n"
        f"  💧 Linh khí: {_format_num(view_p['qi'])}\n"
        f"  💠 Linh thạch: {view_p['stones']}\n"
        f"  ⚡ Chiến lực: {_format_num(cp)}\n"
        f"  ⚔️ Công: {view_p['atk']} · 🛡️ Thủ: {view_p['def']}\n\n"
        f"  🎒 Trang bị: {eq_text}\n"
        f"  🐾 Thú cưng: {pet_text}\n"
        f"  🏯 Hàng bang: {bang_text}\n"
        f"  🗼 Thông Thiên Tháp: {tower_txt}\n"
        f"  🏆 Thắng/Thua: {view_p.get('pk_wins',0)}/{view_p.get('pk_losses',0)}"
        f"{progress_text}"
    )
    caption = _msg_box("📜", "THÔNG TIN TU SĨ", body)
    # Gửi kèm ảnh cảnh giới; nếu thất bại thì fallback text
    sent = _send_with_realm_image(
        self, caption, view_p["realm"], threadId, type,
        userId=None if is_other else userId
    )
    if not sent:
        self.replyMessageStyle(caption, data, threadId, type, color="cyan", title="TU TIÊN", userId=userId)

def _cmd_shop(self, data, userId, threadId, type, p, sub_args):
    sub = sub_args[0].lower() if sub_args else ""

    if sub in ("linhbao", "lb", "linh"):
        _shop_linhbao(self, data, userId, threadId, type, p, sub_args[1:])
    elif sub in ("phaobao", "pb", "phao"):
        _shop_phaobao(self, data, userId, threadId, type, p, sub_args[1:])
    elif sub in ("thucung", "tc", "thu"):
        _shop_thucung(self, data, userId, threadId, type, p, sub_args[1:])
    else:
        body = (
            f"  Chào mừng đến Linh Bảo Các!\n"
            f"  💠 Linh thạch: {p['stones']}\n\n"
            f"  🌿 {_cc(self)} shop linhbao  — Linh bảo tu luyện\n"
            f"  ⚔️  {_cc(self)} shop phaobao  — Pháp bảo chiến đấu\n"
            f"  🐉 {_cc(self)} shop thucung  — Thú cưng đồng hành\n\n"
            f"  Thêm số để mua: {_cc(self)} shop linhbao 1 hoặc mua theo số lượng (stt)x(số lượng cần mua) ví dụ: 1x3"
        )
        self.replyMessageStyle(
            _msg_box("🏪", "LINH BẢO CÁC", body),
            data, threadId, type, color="or", title="TU TIÊN", userId=userId
        )

def _parse_shop_args(args):
    """Parse '2x5' → (idx=1, qty=5), '2' → (idx=1, qty=1). Trả None nếu không hợp lệ."""
    if not args:
        return None, 1
    raw = args[0].lower().replace(" ", "")
    qty = 1
    if "x" in raw:
        parts = raw.split("x", 1)
        idx_str, qty_str = parts[0], parts[1]
        qty = int(qty_str) if qty_str.isdigit() and int(qty_str) > 0 else 1
    else:
        idx_str = raw
    if idx_str.isdigit():
        return int(idx_str) - 1, qty
    return None, 1

def _shop_linhbao(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    idx, qty = _parse_shop_args(args)
    if idx is not None:
        if 0 <= idx < len(LINH_BAO_SHOP):
            _buy_item(self, data, userId, threadId, type, p, LINH_BAO_SHOP[idx], "linhbao", qty=qty)
            return

    lines = []
    for i, item in enumerate(LINH_BAO_SHOP, 1):
        affordable = "✓" if p["stones"] >= item["price"] else "✗"
        lines.append(
            f"  [{i}] {item['emoji']} {item['name']}\n"
            f"      💠 {_format_num(item['price'])} linh thạch {affordable}\n"
            f"      {item['desc']}"
        )

    body = (
        f"  💠 Linh thạch: {p['stones']}\n\n"
        + "\n\n".join(lines)
        + f"\n\n  Mua: {_cc(self)} shop linhbao [số]"
    )
    self.replyMessageStyle(
        _msg_box("🌿", "LINH BẢO CÁC · LINH BẢO", body),
        data, threadId, type, color="or", title="TU TIÊN", userId=userId
    )

def _shop_phaobao(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    idx, qty = _parse_shop_args(args)
    if idx is not None:
        if 0 <= idx < len(PHAO_BAO_SHOP):
            _buy_item(self, data, userId, threadId, type, p, PHAO_BAO_SHOP[idx], "phaobao", qty=qty)
            return

    lines = []
    equipped = set(p.get("equipment", []))
    for i, item in enumerate(PHAO_BAO_SHOP, 1):
        eq_tag = " ★" if item["id"] in equipped else ""
        affordable = "✓" if p["stones"] >= item["price"] else "✗"
        stat_parts = []
        if item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{item['atk_bonus']}")
        if item.get("def_bonus"):
            stat_parts.append(f"🛡️+{item['def_bonus']}")
        stats = " ".join(stat_parts)
        lines.append(
            f"  [{i}] {item['emoji']} {item['name']}{eq_tag}\n"
            f"      💠 {_format_num(item['price'])} {affordable}  {stats}\n"
            f"      {item['desc']}"
        )

    body = (
        f"  💠 Linh thạch: {p['stones']}\n\n"
        + "\n\n".join(lines)
        + f"\n\n  Mua: {_cc(self)} shop phaobao [số]"
    )
    self.replyMessageStyle(
        _msg_box("⚔️", "LINH BẢO CÁC · PHÁP BẢO", body),
        data, threadId, type, color="or", title="TU TIÊN", userId=userId
    )

def _shop_thucung(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    idx, qty = _parse_shop_args(args)
    if idx is not None:
        if 0 <= idx < len(THU_CUNG_SHOP):
            _buy_item(self, data, userId, threadId, type, p, THU_CUNG_SHOP[idx], "thucung", qty=qty)
            return

    lines = []
    current_pet = p.get("pet")
    for i, item in enumerate(THU_CUNG_SHOP, 1):
        pet_tag = " ♥" if item["id"] == current_pet else ""
        affordable = "✓" if p["stones"] >= item["price"] else "✗"
        stat_parts = [f"🔮+{int((item.get('qi_multi',1)-1)*100)}%LK"]
        if item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{item['atk_bonus']}")
        if item.get("def_bonus"):
            stat_parts.append(f"🛡️+{item.get('def_bonus',0)}")
        stats = " ".join(stat_parts)
        lines.append(
            f"  [{i}] {item['emoji']} {item['name']}{pet_tag}\n"
            f"      💠 {_format_num(item['price'])} {affordable}  {stats}\n"
            f"      {item['desc']}"
        )

    current_pet_name = "Chưa có"
    if current_pet and _item_by_id(current_pet):
        cp = _item_by_id(current_pet)
        current_pet_name = f"{cp['emoji']} {cp['name']}"

    body = (
        f"  💠 Linh thạch: {p['stones']}\n"
        f"  🐾 Thú hiện tại: {current_pet_name}\n\n"
        + "\n\n".join(lines)
        + f"\n\n  Mua/đổi: {_cc(self)} shop thucung [số]"
    )
    self.replyMessageStyle(
        _msg_box("🐉", "LINH BẢO CÁC · THÚ CƯNG", body),
        data, threadId, type, color="or", title="TU TIÊN", userId=userId
    )

def _buy_item(self, data, userId, threadId, type, p, item, category, qty=1):
    uid = str(userId)
    qty = max(1, int(qty))
    # Phaobao/thucung không stack → luôn qty=1
    if category in ("phaobao", "thucung"):
        qty = 1
    total_price = item["price"] * qty
    if p["stones"] < total_price:
        body = (
            f"  Linh thạch không đủ!\n\n"
            f"  {item['emoji']} {item['name']}{f' x{qty}' if qty > 1 else ''}\n"
            f"  Giá: {_format_num(total_price)} · Bạn có: {p['stones']}\n"
            f"  Thiếu: {_format_num(total_price - p['stones'])} linh thạch"
        )
        self.replyMessageStyle(
            _msg_box("❌", "KHÔNG ĐỦ LINH THẠCH", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    p["stones"] -= total_price
    result_text = ""

    if category == "linhbao":
        p.setdefault("inventory", {})[item["id"]] = p["inventory"].get(item["id"], 0) + qty
        if item.get("qi_instant", 0) > 0:
            result_text = f"  ✦ Đã vào kho! Dùng {_cc(self)} sd để nhận +{_format_num(item['qi_instant'])} LK tức thì."
        else:
            result_text = f"  ✦ Đã vào kho! Dùng {_cc(self)} sd để kích hoạt buff +{_format_num(item['qi_bonus'])} LK/lần."

    elif category == "phaobao":
        p.setdefault("inventory", {})[item["id"]] = p["inventory"].get(item["id"], 0) + 1
        stat_parts = []
        if item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{item['atk_bonus']}")
        if item.get("def_bonus"):
            stat_parts.append(f"🛡️+{item['def_bonus']}")
        result_text = f"  ✦ Đã vào kho! Dùng {_cc(self)} sd để trang bị. " + " ".join(stat_parts)

    elif category == "thucung":
        p.setdefault("inventory", {})[item["id"]] = p["inventory"].get(item["id"], 0) + 1
        stat_parts = []
        if item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{item['atk_bonus']}")
        if item.get("def_bonus"):
            stat_parts.append(f"🛡️+{item.get('def_bonus', 0)}")
        stats_txt = ("  " + " ".join(stat_parts)) if stat_parts else ""
        result_text = f"  ✦ {item['name']} đã vào kho! Dùng {_cc(self)} sd để mang theo.{stats_txt}"

    _save_player(uid, p)
    qty_tag = f" x{qty}" if qty > 1 else ""
    body = (
        f"  {item['emoji']} {item['name']}{qty_tag}\n\n"
        f"{result_text}\n\n"
        f"  💠 Linh thạch còn: {p['stones']}\n"
        f"  ⚔️ Công: {p['atk']} · 🛡️ Thủ: {p['def']}"
    )
    self.replyMessageStyle(
        _msg_box("✅", "MUA THÀNH CÔNG", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_mine(self, data, userId, threadId, type, p):
    uid = str(userId)
    now = int(time.time())
    bang = _load_bang(p["bang"]) if p.get("bang") else None
    is_leader = bang and bang.get("leader") == uid
    cooldown = 30 if is_leader else 30

    if now - p.get("last_mine", 0) < cooldown:
        remain = cooldown - (now - p["last_mine"])
        body = (
            f"  ⛏️ Linh mạch cần thời gian phục hồi!\n"
            f"  Còn {remain}s nữa."
        )
        self.replyMessageStyle(
            _msg_box("⛏️", "KHAI THÁC LINH THẠCH", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    roll = random.random()
    acc  = 0
    ev   = MINE_EVENTS[-1]
    for e in MINE_EVENTS:
        acc += e["chance"]
        if roll < acc:
            ev = e
            break

    stone_gain = random.randint(*ev["stone"])
    if p.get("bang_qi_bonus"):
        stone_gain = int(stone_gain * 1.05)
    p["stones"]    = p.get("stones", 0) + stone_gain
    p["last_mine"] = now
    _save_player(uid, p)

    body = (
        f"  {ev['msg'].format(n=stone_gain)}\n\n"
        f"  +{stone_gain} 💠 linh thạch\n"
        f"  Tổng: {p['stones']} linh thạch"
    )
    self.replyMessageStyle(
        _msg_box("⛏️", "KHAI THÁC LINH THẠCH", body),
        data, threadId, type, color="or", title="TU TIÊN", userId=userId
    )

def _simulate_pk_rounds(attacker, defender, rounds=3):
    a_hp = int(1000 + attacker.get("def", 10) * 8 + attacker.get("atk", 10) * 2)
    d_hp = int(1000 + defender.get("def", 10) * 8 + defender.get("atk", 10) * 2)

    logs = []
    hiep = 0
    MAX_HIEP = 20

    while a_hp > 0 and d_hp > 0 and hiep < MAX_HIEP:
        hiep += 1
        hiep_lines = []

        # Lượt A đánh D
        crit_a = random.random() < 0.20
        ne_d   = random.random() < 0.12
        a_dmg  = max(1, int(attacker.get("atk", 10) * random.uniform(0.85, 1.15)) - int(defender.get("def", 10) * 0.35))
        if crit_a:
            a_dmg = int(a_dmg * random.uniform(2.0, 3.0))
        crit_tag = "💥 Chí mạng! " if crit_a else ""
        if ne_d:
            hiep_lines.append(f"  🔹{attacker['name']} ⚔️ {crit_tag}{defender['name']} 🌀 né!\n  {defender['name']}: {max(0,d_hp):,}❤️")
        else:
            d_hp -= a_dmg
            hiep_lines.append(f"  🔹{attacker['name']} ⚔️ {crit_tag}Gây {a_dmg:,} sát thương\n  {defender['name']}: {max(0,d_hp):,}❤️")

        if d_hp <= 0:
            hiep_lines.append(f"  {defender['name']}: Ngủm! 🥇 {attacker['name']} hạ gục!")
            logs.append((hiep, hiep_lines))
            break

        # Lượt D đánh A
        crit_d = random.random() < 0.20
        ne_a   = random.random() < 0.12
        d_dmg  = max(1, int(defender.get("atk", 10) * random.uniform(0.85, 1.15)) - int(attacker.get("def", 10) * 0.35))
        if crit_d:
            d_dmg = int(d_dmg * random.uniform(2.0, 3.0))
        crit_tag2 = "💥 Chí mạng! " if crit_d else ""
        if ne_a:
            hiep_lines.append(f"  🔹{defender['name']} ⚔️ {crit_tag2}{attacker['name']} 🌀 né!\n  {attacker['name']}: {max(0,a_hp):,}❤️")
        else:
            a_hp -= d_dmg
            hiep_lines.append(f"  🔹{defender['name']} ⚔️ {crit_tag2}Gây {d_dmg:,} sát thương\n  {attacker['name']}: {max(0,a_hp):,}❤️")

        if a_hp <= 0:
            hiep_lines.append(f"  {attacker['name']}: Ngủm! 🥇 {defender['name']} hạ gục!")

        logs.append((hiep, hiep_lines))

    # Hết 20 hiệp → ai HP cao hơn thắng
    if a_hp > 0 and d_hp > 0:
        winner = "attacker" if a_hp >= d_hp else "defender"
        logs.append((hiep+1, [f"  ⏱️ Hết giờ! HP còn: {attacker['name']} {max(0,a_hp):,}❤️ vs {defender['name']} {max(0,d_hp):,}❤️"]))
    else:
        winner = "attacker" if d_hp <= 0 else "defender"

    a_wins = sum(1 for _, lines in logs if any(attacker['name'] + " hạ gục" in l or "Chí mạng" in l for l in lines))
    d_wins = len(logs) - a_wins

    flat_logs = []
    for hiep_num, lines in logs:
        flat_logs.append(f"\n  ━━━━━🎯Hiệp {hiep_num}━━━━━\n" + "\n".join(lines))

    return winner, a_wins, d_wins, flat_logs

def _cmd_pk(self, data, userId, threadId, type, p, mentions):
    uid = str(userId)
    if not mentions:
        body = f"  Cần tag người muốn thách đấu!\n\n  {_cc(self)} pk @tên"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    target_uid = str(mentions[0])
    if target_uid == uid:
        body = "  Không thể tự chiến với bản thân!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    target_p = _load_player(target_uid)
    if not target_p:
        body = "  Đạo hữu kia chưa bắt đầu tu tiên!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    PK_PENDING[target_uid] = {
        "challenger_uid":  uid,
        "challenger_name": p["name"],
        "target_name":     target_p["name"],
        "time":            int(time.time()),
    }

    my_cp    = _calc_combat_power(p)
    their_cp = _calc_combat_power(target_p)

    body = (
        f"  ⚔️ {p['name']} thách đấu {target_p['name']}!\n\n"
        f"  Chiến lực:\n"
        f"  🔴 {p['name']}: {_format_num(my_cp)}\n"
        f"  🔵 {target_p['name']}: {_format_num(their_cp)}\n\n"
        f"  🕐 Đang chờ {target_p['name']} phản hồi...\n\n"
        f"  {target_p['name']} dùng:\n"
        f"  {_cc(self)} chapthu — Chấp thuận\n"
        f"  {_cc(self)} tuchoi  — Từ chối\n\n"
        f"  (Hết hiệu lực sau 60 giây)"
    )
    self.replyMessageStyle(
        _msg_box("⚔️", "LỜI THÁCH ĐẤU", body),
        data, threadId, type, color="yl", title="TU TIÊN", userId=userId
    )
    
def _cmd_chapthu(self, data, userId, threadId, type, p):
    uid = str(userId)
    pending = PK_PENDING.get(uid)

    if not pending:
        body = "  Không có lời thách đấu nào đang chờ ngươi!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    if int(time.time()) - pending["time"] > 60:
        del PK_PENDING[uid]
        body = "  Lời thách đấu đã hết hạn!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    challenger_uid  = pending["challenger_uid"]
    challenger_p    = _load_player(challenger_uid)
    if not challenger_p:
        del PK_PENDING[uid]
        body = "  Người thách đấu không còn tồn tại!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    del PK_PENDING[uid]

    winner_side, a_wins, d_wins, round_logs = _simulate_pk_rounds(challenger_p, p)

    stone_bet = random.randint(10, 40)
    if winner_side == "attacker":
        winner_p   = challenger_p
        loser_p    = p
        winner_uid = challenger_uid
        loser_uid  = uid
    else:
        winner_p   = p
        loser_p    = challenger_p
        winner_uid = uid
        loser_uid  = challenger_uid

    actual_gain = min(stone_bet, loser_p.get("stones", 0))
    winner_p["stones"] = winner_p.get("stones", 0) + actual_gain
    loser_p["stones"]  = max(0, loser_p.get("stones", 0) - actual_gain)
    winner_p["pk_wins"]   = winner_p.get("pk_wins", 0) + 1
    loser_p["pk_losses"]  = loser_p.get("pk_losses", 0) + 1

    _save_player(winner_uid, winner_p)
    _save_player(loser_uid, loser_p)

    logs_text = "\n".join(round_logs)
    score_text = f"  🔴 {challenger_p['name']}: {a_wins} hiệp | 🔵 {p['name']}: {d_wins} hiệp"

    body = (
        f"  ⚔️ {challenger_p['name']} VS {p['name']}\n\n"
        f"{logs_text}\n\n"
        f"{score_text}\n\n"
        f"  🏆 {winner_p['name']} đại thắng!\n"
        f"  💠 Nhận {actual_gain} linh thạch từ {loser_p['name']}"
    )
    self.replyMessageStyle(
        _msg_box("🏆" if winner_side == "defender" else "⚔️", "KẾT QUẢ PK", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_tuchoi(self, data, userId, threadId, type, p):
    uid = str(userId)
    pending = PK_PENDING.get(uid)

    if not pending:
        body = "  Không có lời thách đấu nào đang chờ ngươi!"
        self.replyMessageStyle(
            _msg_box("⚔️", "THÁCH ĐẤU", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    del PK_PENDING[uid]
    body = (
        f"  {p['name']} đã từ chối lời thách đấu\n"
        f"  của {pending['challenger_name']}.\n\n"
        f"  Đạo hữu chưa muốn động thủ hôm nay... 😌"
    )
    self.replyMessageStyle(
        _msg_box("🚫", "TỪ CHỐI THÁCH ĐẤU", body),
        data, threadId, type, color="yl", title="TU TIÊN", userId=userId
    )

def _cmd_kho(self, data, userId, threadId, type, p, target_p=None):
    view_p = target_p if target_p else p
    is_other = target_p is not None
    title_name = f"KHO ĐỒ — {view_p['name']}" if is_other else "KHO ĐỒ"

    inv = view_p.get("inventory", {})
    if not inv:
        body = f"  {'Kho đồ của ' + view_p['name'] + ' trống rỗng!' if is_other else 'Kho đồ trống rỗng!'}"
        if not is_other:
            body += "\n\n  Hãy tu luyện hoặc ghé shop để có vật phẩm."
        self.replyMessageStyle(
            _msg_box("🎒", title_name, body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    lines = []
    for stt, (item_id, qty) in enumerate(inv.items(), 1):
        item = _item_by_id(item_id)
        if item:
            lines.append(f"  [{stt}] {item['emoji']} {item['name']} x{qty}")

    active_buff = ""
    if view_p.get("active_buff"):
        item = _item_by_id(view_p["active_buff"])
        if item:
            active_buff = f"\n\n  🟢 Buff: {item['emoji']} {item['name']} ({view_p.get('buff_uses',0)} lần còn)"

    body = "\n".join(lines) + active_buff
    if not is_other:
        body += f"\n\n  Dùng: {_cc(self)} sd [số] hoặc {_cc(self)} sd [tên]"

    self.replyMessageStyle(
        _msg_box("🎒", title_name, body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_sudung(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    if not args:
        body = f"  Cú pháp: {_cc(self)} sd [số] hoặc {_cc(self)} sd [tên]\n  VD: {_cc(self)} sd 1  hoặc  {_cc(self)} sd linh thảo cấp 1"
        self.replyMessageStyle(
            _msg_box("📦", "SỬ DỤNG VẬT PHẨM", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    keyword    = " ".join(args).lower().strip()
    found_item = None
    found_id   = None
    inv_items  = list(p.get("inventory", {}).items())

    # Tìm theo STT (số thứ tự)
    if keyword.isdigit():
        idx = int(keyword) - 1
        if 0 <= idx < len(inv_items):
            found_id   = inv_items[idx][0]
            found_item = _item_by_id(found_id)
    else:
        for item_id, qty in inv_items:
            item = _item_by_id(item_id)
            if item and (keyword in item["name"].lower() or keyword == item_id):
                found_item = item
                found_id   = item_id
                break

    if not found_item:
        body = f"  Không tìm thấy vật phẩm '{' '.join(args)}' trong kho!"
        self.replyMessageStyle(
            _msg_box("❌", "VẬT PHẨM KHÔNG HỢP LỆ", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    p["inventory"][found_id] = p["inventory"].get(found_id, 1) - 1
    if p["inventory"][found_id] <= 0:
        del p["inventory"][found_id]

    result_text = ""
    # Kiểm tra thú cưng
    is_pet = any(item["id"] == found_id for item in THU_CUNG_SHOP)
    # Kiểm tra pháp bảo
    is_phao = any(item["id"] == found_id for item in PHAO_BAO_SHOP)

    if is_pet:
        old_pet_id = p.get("pet")
        if old_pet_id and old_pet_id != found_id:
            old_pet = _item_by_id(old_pet_id)
            if old_pet:
                p["atk"] = max(10, p.get("atk", 10) - old_pet.get("atk_bonus", 0))
                p["def"] = max(10, p.get("def", 10) - old_pet.get("def_bonus", 0))
        if old_pet_id != found_id:
            p["atk"] = p.get("atk", 10) + found_item.get("atk_bonus", 0)
            p["def"] = p.get("def", 10) + found_item.get("def_bonus", 0)
        p["pet"] = found_id
        p["pet_bonus_synced"] = True
        stat_parts = []
        if found_item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{found_item['atk_bonus']}")
        if found_item.get("def_bonus"):
            stat_parts.append(f"🛡️+{found_item.get('def_bonus',0)}")
        result_text = f"  ✦ {found_item['name']} đã theo ngươi tu hành! " + " ".join(stat_parts)
    elif is_phao:
        old_eq = list(p.get("equipment", []))
        is_atk_item = found_item.get("atk_bonus", 0) >= found_item.get("def_bonus", 0)
        new_eq = []
        for eid in old_eq:
            old_item = _item_by_id(eid)
            if not old_item:
                continue
            old_is_atk = old_item.get("atk_bonus", 0) >= old_item.get("def_bonus", 0)
            if old_is_atk == is_atk_item and eid != found_id:
                p["atk"] = max(10, p.get("atk", 10) - old_item.get("atk_bonus", 0))
                p["def"] = max(10, p.get("def", 10) - old_item.get("def_bonus", 0))
                continue
            new_eq.append(eid)
        if found_id not in new_eq:
            new_eq.append(found_id)
        p["equipment"] = new_eq
        p["atk"] = p.get("atk", 10) + found_item.get("atk_bonus", 0)
        p["def"] = p.get("def", 10) + found_item.get("def_bonus", 0)
        stat_parts = []
        if found_item.get("atk_bonus"):
            stat_parts.append(f"⚔️+{found_item['atk_bonus']}")
        if found_item.get("def_bonus"):
            stat_parts.append(f"🛡️+{found_item['def_bonus']}")
        result_text = "  ✦ Đã trang bị! " + " ".join(stat_parts)
    elif found_item.get("qi_instant", 0) > 0:
        p["qi"]       += found_item["qi_instant"]
        p["qi_total"] += found_item["qi_instant"]
        result_text = f"  ✦ +{_format_num(found_item['qi_instant'])} linh khí ngay lập tức!"
    elif found_item.get("qi_bonus", 0) > 0:
        p["active_buff"] = found_item["id"]
        p["buff_uses"]   = 5
        result_text = f"  ✦ Buff +{_format_num(found_item['qi_bonus'])} LK trong 5 lần tu luyện!"

    _save_player(uid, p)
    body = (
        f"  {found_item['emoji']} {found_item['name']}\n\n"
        f"{result_text}\n\n"
        f"  💧 Linh khí: {_format_num(p['qi'])}"
    )
    self.replyMessageStyle(
        _msg_box("✅", "SỬ DỤNG THÀNH CÔNG", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_bang(self, data, userId, threadId, type, p, args):
    uid = str(userId)
    sub = args[0].lower() if args else ""

    if sub == "tao" and len(args) >= 2:
        _bang_create(self, data, userId, threadId, type, p, args[1:])
    elif sub == "vao" and len(args) >= 2:
        _bang_join(self, data, userId, threadId, type, p, " ".join(args[1:]).strip())
    elif sub == "roi":
        _bang_leave(self, data, userId, threadId, type, p)
    elif sub == "xem":
        _bang_info(self, data, userId, threadId, type, p)
    else:
        body = (
            f"  🏯 Bang hiện tại: {p.get('bang') or 'Chưa gia nhập'}\n\n"
            f"  {_cc(self)} hb tao [tên] — Tạo bang (500💠)\n"
            f"  {_cc(self)} hb vao [tên] — Gia nhập bang\n"
            f"  {_cc(self)} hb roi       — Rời bang\n"
            f"  {_cc(self)} hb xem       — Thông tin bang"
        )
        self.replyMessageStyle(
            _msg_box("🏯", "HÀNG BANG", body),
            data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
        )

def _bang_create(self, data, userId, threadId, type, p, name_parts):
    uid = str(userId)
    if p.get("bang"):
        body = f"  Bạn đang trong bang '{p['bang']}'.\n  Hãy rời bang trước!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return
    if p.get("stones", 0) < 500:
        body = f"  Cần 500💠 để lập bang!\n  Bạn chỉ có {p['stones']} linh thạch."
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    bang_name = " ".join(name_parts).strip()[:30]
    if not bang_name:
        body = "  Tên bang không được để trống!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    if _load_bang(bang_name):
        body = f"  Hàng bang '{bang_name}' đã tồn tại!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    p["stones"] -= 500
    p["bang"]    = bang_name
    bang_data = {
        "name":        bang_name,
        "leader":      uid,
        "members":     {uid: {"name": p["name"], "rank": "Bang Chủ"}},
        "created_at":  int(time.time()),
        "total_power": _calc_combat_power(p),
    }
    _save_bang(bang_name, bang_data)
    _save_player(uid, p)

    body = (
        f"  🏯 '{bang_name}' đã được thành lập!\n\n"
        f"  Bang chủ: {p['name']}\n"
        f"  Chi phí: 500💠 · Còn lại: {p['stones']}💠"
    )
    self.replyMessageStyle(
        _msg_box("🏯", "LẬP BANG THÀNH CÔNG", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _bang_join(self, data, userId, threadId, type, p, bang_name):
    uid = str(userId)
    if p.get("bang"):
        body = f"  Bạn đang trong bang '{p['bang']}'.\n  Hãy rời bang trước!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    bang = _load_bang(bang_name)
    if not bang:
        body = f"  Không tìm thấy hàng bang '{bang_name}'!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    p["bang"] = bang_name
    p["atk"]  = p.get("atk", 10) + 100
    p["def"]  = p.get("def", 10) + 100
    p["bang_qi_bonus"] = 0.10
    bang["members"][uid] = {"name": p["name"], "rank": "Thành Viên"}
    bang["total_power"]  = sum(
        _calc_combat_power(_load_player(mid) or {})
        for mid in bang["members"]
        if _load_player(mid)
    )
    _save_bang(bang_name, bang)
    _save_player(uid, p)

    body = (
        f"  Gia nhập '{bang_name}' thành công!\n\n"
        f"  Bang chủ: {bang['members'].get(bang['leader'],{}).get('name','?')}\n"
        f"  Thành viên: {len(bang['members'])} người\n\n"
        f"  ✦ Bonus hàng bang:\n"
        f"  ⚔️ +100 công · 🛡️ +100 thủ\n"
        f"  💧 +10% linh khí tu luyện\n"
        f"  💠 +5% linh thạch mine"
    )
    self.replyMessageStyle(
        _msg_box("🏯", "GIA NHẬP BANG", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _bang_leave(self, data, userId, threadId, type, p):
    uid = str(userId)
    if not p.get("bang"):
        body = "  Bạn chưa gia nhập hàng bang nào!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    bang_name = p["bang"]
    bang      = _load_bang(bang_name)
    p["bang"] = None
    p["atk"]  = max(10, p.get("atk", 10) - 100)
    p["def"]  = max(10, p.get("def", 10) - 100)
    p.pop("bang_qi_bonus", None)
    _save_player(uid, p)

    if bang:
        bang["members"].pop(uid, None)
        if not bang["members"]:
            try:
                os.remove(_path_bang(bang_name))
            except Exception:
                pass
        else:
            _save_bang(bang_name, bang)

    body = f"  Đã rời khỏi hàng bang '{bang_name}'."
    self.replyMessageStyle(
        _msg_box("🏯", "RỜI BANG", body),
        data, threadId, type, color="yl", title="TU TIÊN", userId=userId
    )

def _bang_info(self, data, userId, threadId, type, p):
    bang_name = p.get("bang")
    if not bang_name:
        body = f"  Bạn chưa gia nhập hàng bang!\n\n  {_cc(self)} hb vao [tên bang]"
        self.replyMessageStyle(
            _msg_box("🏯", "HÀNG BANG", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    bang = _load_bang(bang_name)
    if not bang:
        body = f"  Không tải được thông tin bang '{bang_name}'!"
        self.replyMessageStyle(
            _msg_box("❌", "HÀNG BANG", body),
            data, threadId, type, color="r", title="TU TIÊN", userId=userId
        )
        return

    members_text = []
    for mid, mdata in bang.get("members", {}).items():
        mp       = _load_player(mid)
        realm_txt = _get_realm(mp["realm"])["name"] if mp else "?"
        members_text.append(f"  {mdata['rank']}: {mdata['name']} ({realm_txt})")

    body = (
        f"  🏯 {bang_name}\n\n"
        f"  Bang chủ: {bang['members'].get(bang['leader'],{}).get('name','?')}\n"
        f"  ⚡ Tổng chiến lực: {_format_num(bang.get('total_power',0))}\n"
        f"  Thành viên ({len(bang['members'])} người):\n"
        + "\n".join(members_text)
    )
    self.replyMessageStyle(
        _msg_box("🏯", "THÔNG TIN HÀNG BANG", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_bxh(self, data, userId, threadId, type):
    players = _all_players_sorted()[:10]
    if not players:
        body = "  Chưa có ai tu tiên!"
        self.replyMessageStyle(
            _msg_box("🏆", "BẢNG XẾP HẠNG", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    medals = ["🥇", "🥈", "🥉"]
    lines  = []
    for i, (uid, p) in enumerate(players):
        realm = _get_realm(p["realm"])
        medal = medals[i] if i < 3 else f"{i+1}."
        cp    = _calc_combat_power(p)
        lines.append(
            f"  {medal} {p['name']}\n"
            f"     {realm['emoji']} {realm['name']} · ⚡{_format_num(cp)}"
        )

    body = "\n\n".join(lines)
    self.replyMessageStyle(
        _msg_box("🏆", "BẢNG XẾP HẠNG TU TIÊN", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _cmd_help(self, data, userId, threadId, type, p):
    body = (
        f"  ✦ THIÊN ĐẠO CHI LỘ ✦\n"
        f"  Game tu tiên nhập vai\n\n"
        f"  📌 CƠ BẢN:\n"
        f"  ➜ {_cc(self)} start: Bắt đầu tu tiên\n"
        f"  ➜ {_cc(self)} tl: Tu luyện\n"
        f"  ➜ {_cc(self)} db: Đột phá cảnh giới\n"
        f"  ➜ {_cc(self)} info: Thông tin tu sĩ\n"
        f"  ➜ {_cc(self)} mine: Khai thác linh thạch\n\n"
        f"  🏪 CỬA HÀNG:\n"
        f"  ➜ {_cc(self)} shop: Menu shop\n\n"
        f"  ⚔️ CHIẾN ĐẤU:\n"
        f"  ➜ {_cc(self)} pk @người: Thách đấu\n"
        f"  ➜ {_cc(self)} chapthu: Chấp thuận đấu\n"
        f"  ➜ {_cc(self)} tuchoi: Từ chối đấu\n\n"
        f"  🏯 HÀNG BANG:\n"
        f"  ➜ {_cc(self)} hb: Menu hàng bang\n"
        f"  ➜ {_cc(self)} bxh: Bảng xếp hạng\n\n"
        f"  🗼 THÔNG THIÊN THÁP:\n"
        f"  ➜ {_cc(self)} leothap: Leo tầng tiếp theo\n"
        f"  ➜ {_cc(self)} leothap [n]: Leo tầng n\n"
        f"  ➜ {_cc(self)} soithap: Soi tầng tiếp theo\n"
        f"  ➜ {_cc(self)} soithap [n]: Soi tầng tháp\n"
        f"  ➜ {_cc(self)} bxhthap: BXH thông thiên tháp\n\n"
        f"  🎒 VẬT PHẨM:\n"
        f"  ➜ {_cc(self)} kho: Xem Kho đồ\n"
        f"  ➜{_cc(self)} sd [số/tên]: Dùng vật phẩm"
    )
    self.replyMessageStyle(
        _msg_box("📖", "HƯỚNG DẪN TU TIÊN", body),
        data, threadId, type, color="cyan", title="TU TIÊN", userId=userId
    )

def _repair_pet_bonus(uid, p):
    if not p or p.get("pet_bonus_synced"):
        return p
    pet_id = p.get("pet")
    if pet_id:
        pet = _item_by_id(pet_id)
        if pet:
            p["atk"] = p.get("atk", 10) + pet.get("atk_bonus", 0)
            p["def"] = p.get("def", 10) + pet.get("def_bonus", 0)
    p["pet_bonus_synced"] = True
    _save_player(uid, p)
    return p

def tutienCommand(self, message, data, userId, threadId, type):
    uid  = str(userId)
    raw  = (getattr(message, "text", "") or "").strip()
    parts = raw.split()
    args  = parts[1:] if len(parts) > 1 else []
    sub   = args[0].lower() if args else ""

    p = _load_player(uid)
    if p:
        p = _repair_pet_bonus(uid, p)

    mentions = extractUids(data)

    if sub in ("start", "bắt đầu", "batdau", ""):
        if sub == "" and not p:
            _cmd_help(self, data, userId, threadId, type, p)
        elif sub == "" and p:
            _cmd_thongtin(self, data, userId, threadId, type, p)
        else:
            _cmd_start(self, data, userId, threadId, type, p)
        return

    if not p and sub not in ("help", "?", "h", "hd"):
        body = (
            f"  Ngươi chưa bắt đầu hành trình tu tiên!\n\n"
            f"  Dùng {_cc(self)} start để bắt đầu."
        )
        self.replyMessageStyle(
            _msg_box("⚠️", "CHƯA BẮT ĐẦU", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )
        return

    # Xử lý ok/huy thu phục thú cưng tháp
    if sub in ("ok", "huy") and uid in TOWER_PET_PENDING:
        _cmd_thu_phuc_pet(self, data, userId, threadId, type, p, sub)
        return

    if sub in ("tl", "tuluy", "tu", "tuluyện"):
        _cmd_tuluy(self, data, userId, threadId, type, p)
    elif sub in ("db", "dotpha", "đotpha", "breakthrough"):
        _cmd_dotpha(self, data, userId, threadId, type, p)
    elif sub in ("tt", "thongtin", "info", "stat"):
        if mentions:
            target_uid = str(mentions[0])
            target_p = _load_player(target_uid)
            if not target_p:
                self.replyMessageStyle(_msg_box("❌","THÔNG TIN",f"  Đạo hữu đó chưa bắt đầu tu tiên!"),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            else:
                _cmd_thongtin(self, data, userId, threadId, type, p, target_p=target_p, target_uid=target_uid)
        else:
            _cmd_thongtin(self, data, userId, threadId, type, p)
    elif sub in ("shop", "cua", "hang"):
        _cmd_shop(self, data, userId, threadId, type, p, args[1:])
    elif sub in ("mine", "khai", "dao", "khaithac"):
        _cmd_mine(self, data, userId, threadId, type, p)
    elif sub in ("pk", "fight", "pvp", "danh", "thach"):
        _cmd_pk(self, data, userId, threadId, type, p, mentions)
    elif sub in ("chapthu", "chapnhan", "accept", "ct"):
        _cmd_chapthu(self, data, userId, threadId, type, p)
    elif sub in ("tuchoi", "refuse", "deny", "tc"):
        _cmd_tuchoi(self, data, userId, threadId, type, p)
    elif sub in ("kho", "inventory", "bag", "tui"):
        if mentions:
            target_uid = str(mentions[0])
            target_p = _load_player(target_uid)
            if not target_p:
                self.replyMessageStyle(_msg_box("❌","KHO ĐỒ",f"  Đạo hữu đó chưa bắt đầu tu tiên!"),data,threadId,type,color="r",title="TU TIÊN",userId=userId)
            else:
                _cmd_kho(self, data, userId, threadId, type, p, target_p=target_p)
        else:
            _cmd_kho(self, data, userId, threadId, type, p)
    elif sub in ("sd", "dung", "use", "sudung"):
        _cmd_sudung(self, data, userId, threadId, type, p, args[1:])
    elif sub in ("hb", "bang", "guild"):
        _cmd_bang(self, data, userId, threadId, type, p, args[1:])
    elif sub in ("bxh", "rank", "top", "xephang"):
        _cmd_bxh(self, data, userId, threadId, type)
    elif sub in ("leothap", "lt", "leo"):
        _cmd_leothap(self, data, userId, threadId, type, p, args[1:])
    elif sub in ("soithap", "st", "soi"):
        _cmd_soithap(self, data, userId, threadId, type, p, args[1:])
    elif sub in ("bxhthap", "bxht", "rankthap"):
        _cmd_bxhthap(self, data, userId, threadId, type)
    elif sub in ("help", "?", "h", "hd", "huongdan"):
        _cmd_help(self, data, userId, threadId, type, p)
    else:
        body = (
            f"  Lệnh '{sub}' không tồn tại!\n\n"
            f"  Dùng {_cc(self)} help để xem hướng dẫn."
        )
        self.replyMessageStyle(
            _msg_box("❓", "LỆNH KHÔNG HỢP LỆ", body),
            data, threadId, type, color="yl", title="TU TIÊN", userId=userId
        )


dependencies = {
    "name":        "tutien",
    "permission":  0,
    "cooldown":    0,
    "description": "Game tu tiên nhập vai - Thiên Đạo Chi Lộ",
    "alias":       ["tt", "thiendao"],
    "main":        tutienCommand,
}
