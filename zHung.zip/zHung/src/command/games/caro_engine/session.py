import os, sys, time, threading

TURN_TIMEOUT = 120

DIFFICULTY_NAMES = {
    1: "🟢 Dễ",
    2: "🟡 Trung bình",
    3: "🔴 Khó",
    4: "💀 Ác mộng",
}


def _load_module(mod_key, filename):
    m = sys.modules.get(mod_key)
    if m is not None:
        return m
    import importlib.util
    _dir  = os.path.dirname(os.path.abspath(__file__))
    spec  = importlib.util.spec_from_file_location(mod_key, os.path.join(_dir, filename))
    mod   = importlib.util.module_from_spec(spec)
    mod.__package__ = "games.caro_engine"
    # exec TRƯỚC, cache SAU
    spec.loader.exec_module(mod)
    sys.modules.setdefault(mod_key, mod)
    return mod


def _get_Board():
    return _load_module("games.caro_engine.board", "board.py").Board

def _get_CaroAI():
    return _load_module("games.caro_engine.ai", "ai.py").CaroAI


def _get_Board():
    return _load_module("games.caro_engine.board", "board.py").Board

def _get_CaroAI():
    return _load_module("games.caro_engine.ai", "ai.py").CaroAI


class CaroSession:
    def __init__(self, user_id, thread_id, thread_type, difficulty,
                 msg_id=None, cli_msg_id=None):
        Board = _get_Board()
        CaroAI = _get_CaroAI()
        self.board = Board()
        self.ai = CaroAI(difficulty=difficulty)
        self.user_id = str(user_id)
        self.thread_id = str(thread_id)
        self.thread_type = thread_type
        self.msg_id = msg_id
        self.cli_msg_id = cli_msg_id
        self.last_active = time.time()
        self.difficulty = difficulty
        self.human_player = 1
        self.bot_player = 2
        self.is_user_turn = True
        self.move_count = 0

    def touch(self):
        self.last_active = time.time()

    def is_expired(self):
        return time.time() - self.last_active > TURN_TIMEOUT


def _caro_store():
    import sys
    key = "__caro_sessions_store__"
    if key not in sys.modules:
        import types, threading
        m = types.ModuleType(key)
        m._lock = threading.Lock()
        m._sessions = {}
        sys.modules[key] = m
    return sys.modules[key]


class SessionManager:
    @classmethod
    def get(cls, user_id):
        return _caro_store()._sessions.get(str(user_id))

    @classmethod
    def create(cls, user_id, thread_id, thread_type, difficulty,
               msg_id=None, cli_msg_id=None):
        store = _caro_store()
        with store._lock:
            sess = CaroSession(user_id, thread_id, thread_type, difficulty,
                               msg_id, cli_msg_id)
            store._sessions[str(user_id)] = sess
            return sess

    @classmethod
    def remove(cls, user_id):
        store = _caro_store()
        with store._lock:
            store._sessions.pop(str(user_id), None)

    @classmethod
    def cleanup_expired(cls):
        store = _caro_store()
        with store._lock:
            expired = [uid for uid, s in store._sessions.items() if s.is_expired()]
            for uid in expired:
                store._sessions.pop(uid, None)
        return expired

    # Cho phép truy cập SessionManager._sessions trực tiếp từ bên ngoài
    class _SessionsProxy:
        def items(self): return _caro_store()._sessions.items()
        def values(self): return _caro_store()._sessions.values()
        def keys(self): return _caro_store()._sessions.keys()
        def get(self, k, d=None): return _caro_store()._sessions.get(k, d)
        def __iter__(self): return iter(_caro_store()._sessions)
    _sessions = _SessionsProxy()
