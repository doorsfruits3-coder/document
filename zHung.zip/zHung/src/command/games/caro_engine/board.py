import time

SIZE = 16

SCORE_FIVE       = 10_000_000
SCORE_FOUR_OPEN  =    500_000
SCORE_FOUR       =     50_000
SCORE_THREE_OPEN =     10_000
SCORE_THREE      =      1_000
SCORE_TWO_OPEN   =        200
SCORE_TWO        =         20
SCORE_ONE        =          2


def cell_to_num(r, c):
    return r * SIZE + c + 1


def num_to_cell(n):
    n = int(n) - 1
    if not (0 <= n < SIZE * SIZE):
        return None, None
    return divmod(n, SIZE)


class Board:

    __slots__ = ("cells", "history")

    def __init__(self):
        self.cells: list = [[0] * SIZE for _ in range(SIZE)]
        self.history: list = []

    def copy(self):
        b = Board()
        b.cells = [row[:] for row in self.cells]
        b.history = self.history[:]
        return b

    def is_empty(self, r, c):
        return 0 <= r < SIZE and 0 <= c < SIZE and self.cells[r][c] == 0

    def place(self, r, c, player):
        self.cells[r][c] = player
        self.history.append((r, c))

    def undo(self, r, c):
        self.cells[r][c] = 0
        if self.history and self.history[-1] == (r, c):
            self.history.pop()

    def last_move(self):
        return self.history[-1] if self.history else None

    def check_win(self, r, c, player):
        dirs = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dr, dc in dirs:
            count = 1
            for sign in (1, -1):
                nr, nc = r + sign * dr, c + sign * dc
                while 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == player:
                    count += 1
                    nr += sign * dr
                    nc += sign * dc
            if count >= 5:
                return True
        return False

    def get_win_line(self, r, c, player):
        """Trả về list 5+ ô thắng, hoặc [] nếu không có."""
        dirs = [(0, 1), (1, 0), (1, 1), (1, -1)]
        for dr, dc in dirs:
            line = [(r, c)]
            for sign in (1, -1):
                nr, nc = r + sign * dr, c + sign * dc
                while 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == player:
                    line.append((nr, nc))
                    nr += sign * dr
                    nc += sign * dc
            if len(line) >= 5:
                return sorted(line)
        return []

    def is_full(self):
        return all(self.cells[r][c] != 0 for r in range(SIZE) for c in range(SIZE))

    def get_candidates(self, radius=2):
        if not self.history:
            center = SIZE // 2
            return [(center, center)]
        occupied = set(self.history)
        candidates = set()
        for r, c in self.history:
            for dr in range(-radius, radius + 1):
                for dc in range(-radius, radius + 1):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < SIZE and 0 <= nc < SIZE and (nr, nc) not in occupied:
                        candidates.add((nr, nc))
        return list(candidates)

    def _count_line(self, r, c, dr, dc, player):
        count = 0
        open_ends = 0
        nr, nc = r + dr, c + dc
        while 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == player:
            count += 1
            nr += dr; nc += dc
        if 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == 0:
            open_ends += 1
        nr, nc = r - dr, c - dc
        while 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == player:
            count += 1
            nr -= dr; nc -= dc
        if 0 <= nr < SIZE and 0 <= nc < SIZE and self.cells[nr][nc] == 0:
            open_ends += 1
        return count, open_ends

    def score_cell(self, r, c, player):
        if self.cells[r][c] != 0:
            return -1
        self.cells[r][c] = player
        score = self._eval_pos(r, c, player)
        self.cells[r][c] = 0
        return score

    def _eval_pos(self, r, c, player):
        dirs = [(0, 1), (1, 0), (1, 1), (1, -1)]
        total = 0
        for dr, dc in dirs:
            cnt, opens = self._count_line(r, c, dr, dc, player)
            total += cnt
            length = cnt + 1
            if length >= 5:
                total += SCORE_FIVE
            elif length == 4:
                total += SCORE_FOUR_OPEN if opens == 2 else SCORE_FOUR
            elif length == 3:
                total += SCORE_THREE_OPEN if opens == 2 else SCORE_THREE
            elif length == 2:
                total += SCORE_TWO_OPEN if opens == 2 else SCORE_TWO
            else:
                total += SCORE_ONE
        return total

    def evaluate_board(self, bot_player):
        human = 3 - bot_player
        score = 0
        for r in range(SIZE):
            for c in range(SIZE):
                p = self.cells[r][c]
                if p == bot_player:
                    score += self._eval_pos(r, c, bot_player)
                elif p == human:
                    score -= self._eval_pos(r, c, human)
        return score
