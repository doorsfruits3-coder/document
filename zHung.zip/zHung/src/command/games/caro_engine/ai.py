import time, random

INF  = 10_000_000_000
GRID = 15
WIN  = 5
DIRS = [(0,1),(1,0),(1,1),(1,-1)]

# ══════════════════════════════════════════════════════════════
# SCORE CONSTANTS
# ══════════════════════════════════════════════════════════════
S5       = 100_000_000
S4O      =  20_000_000   # open-4: thắng ngay lượt sau
S4B      =   1_500_000   # blocked-4
S4G      =   8_000_000   # gap-4 (X_XX, XX_X)
S3O      =     300_000   # open-3
S3G      =     150_000   # gap-3
S3B      =      15_000   # blocked-3
S2O      =       2_000
S2B      =         200
S_FORK   =  35_000_000   # double-threat
S_DFORK  =  18_000_000   # 4+3 fork
S_D3     =   9_000_000   # double open-3

S_CONN   =       5_000   # connectivity
S_CENTER =       3_000   # center bonus
S_VCF    = S5 * 2        # victory by continuous forced

# ── Per-call threat cache (reset mỗi lần best_move) ──────────
_THREAT_CACHE = {}

def _threat_cache_key(board, r, c, player):
    # Hash nhanh: chỉ xét 5x5 xung quanh (r,c)
    h = player * 1000000 + r * 1000 + c
    for dr in range(-4, 5):
        for dc in range(-4, 5):
            nr, nc = r + dr, c + dc
            if _in_bounds(nr, nc):
                h = h * 3 + board[nr][nc]
    return h

def _cached_count_threats(board, r, c, player):
    key = _threat_cache_key(board, r, c, player)
    if key in _THREAT_CACHE:
        return _THREAT_CACHE[key]
    result = _count_threats(board, r, c, player)
    _THREAT_CACHE[key] = result
    return result

# ── Board utils ───────────────────────────────────────────────

def _in_bounds(r, c):
    return 0 <= r < GRID and 0 <= c < GRID

def _get_line(board, r, c, dr, dc, length=11):
    half = length // 2
    line = []
    for k in range(-half, half + 1):
        nr, nc = r + dr * k, c + dc * k
        line.append(board[nr][nc] if _in_bounds(nr, nc) else -1)
    return line

def _score_line(line, player):
    s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
    if 'XXXXX' in s:
        return S5 * 10
    score = 0
    # ── Open-4: 2 đầu trống ──
    if '_XXXX_' in s:
        score += S4O
    # ── Gap-4: 4 quân có 1 lỗ hổng ──
    for pat in ('XX_XX', 'X_XXX', 'XXX_X'):
        if pat in s:
            score += S4G
            break  # chỉ cộng 1 lần dù match nhiều
    # ── Blocked-4: 1 đầu bị chặn ──
    if '_XXXX_' not in s:
        for pat in ('_XXXX', 'XXXX_', 'BXXXX', 'XXXXB'):
            if pat in s:
                score += S4B
                break
    # ── Open-3 ──
    if '_XXX_' in s and 'X_XXX_' not in s and '_XXX_X' not in s:
        score += S3O
    elif '__XXX_' in s or '_XXX__' in s:   # open-3 có thêm khoảng trống xa
        score += S3O
    # ── Gap-3 ──
    for pat in ('_XX_X_', '_X_XX_', 'XX_X_', '_X_XX', '_X_X_X_', 'X_X_X', '_XX__X', 'X__XX_'):
        if pat in s:
            score += S3G
            break
    # ── Blocked-3 ──
    for pat in ('BXXX_', '_XXXB', 'BXX_X', 'X_XXB'):
        if pat in s:
            score += S3B
            break
    # ── Open-2 ──
    if '_XX_' in s:
        score += S2O
    elif 'XX_' in s or '_XX' in s:
        score += S2B
    return score

def _is_win(board, r, c, player):
    board[r][c] = player
    for dr, dc in DIRS:
        cnt = 1
        for sign in (1, -1):
            nr, nc = r + sign*dr, c + sign*dc
            while _in_bounds(nr, nc) and board[nr][nc] == player:
                cnt += 1; nr += sign*dr; nc += sign*dc
        if cnt >= WIN:
            board[r][c] = 0
            return True
    board[r][c] = 0
    return False

# ══════════════════════════════════════════════════════════════
# THREAT ANALYSIS (nâng cấp mạnh)
# ══════════════════════════════════════════════════════════════

def _count_threats(board, r, c, player):
    board[r][c] = player
    n4o = n4b = n4g = n3o = n3g = 0
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        if '_XXXX_' in s:
            n4o += 1
        elif any(p in s for p in ('XX_XX','X_XXX','XXX_X')):
            n4g += 1
        elif any(p in s for p in ('_XXXX','XXXX_')):
            n4b += 1
        if '_XXX_' in s:
            n3o += 1
        elif any(p in s for p in ('_XX_X_','_X_XX_','XX_X_','_X_XX')):
            n3g += 1
    board[r][c] = 0
    return n4o, n4b, n4g, n3o, n3g

def _threat_value(board, r, c, player):
    opp = 3 - player
    atk = def_ = 0
    board[r][c] = player
    for dr, dc in DIRS:
        atk += _score_line(_get_line(board, r, c, dr, dc), player)
    board[r][c] = opp
    for dr, dc in DIRS:
        def_ += _score_line(_get_line(board, r, c, dr, dc), opp)
    board[r][c] = 0
    return atk * 1.15 + def_ * 0.95

def _threat_value_v2(board, r, c, player, aggr_bonus=0.0):
    opp = 3 - player
    atk = def_ = 0
    board[r][c] = player
    for dr, dc in DIRS:
        atk += _score_line(_get_line(board, r, c, dr, dc), player)
    board[r][c] = opp
    for dr, dc in DIRS:
        def_ += _score_line(_get_line(board, r, c, dr, dc), opp)
    board[r][c] = 0

    conn = 0
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if dr == 0 and dc == 0:
                continue
            nr, nc = r + dr, c + dc
            if _in_bounds(nr, nc) and board[nr][nc] == player:
                conn += S_CONN

    cx = cy = GRID // 2
    dist = abs(r - cx) + abs(c - cy)
    center_bonus = max(0, S_CENTER * (6 - dist))

    atk_coeff = 1.15 + aggr_bonus
    return atk * atk_coeff + def_ * 0.95 + conn + center_bonus

def _is_fork(board, r, c, player):
    n4o, n4b, n4g, n3o, n3g = _cached_count_threats(board, r, c, player)
    if n4o >= 2: return True
    if n4o >= 1 and (n4b + n4g) >= 1: return True
    if (n4o + n4g) >= 2: return True
    if n4b >= 2: return True          # 2 blocked-4 cũng là fork khó chặn
    if n4o >= 1 and n3o >= 1: return True
    if n3o >= 2: return True
    if n4g >= 1 and n3o >= 1: return True   # gap-4 + open-3 cũng nguy hiểm
    return False

def _fork_score(board, r, c, player):
    n4o, n4b, n4g, n3o, n3g = _cached_count_threats(board, r, c, player)
    score = 0
    if n4o >= 2:              score += S_FORK
    elif n4o >= 1 and (n4b+n4g) >= 1: score += S_FORK * 0.9
    elif (n4o+n4g) >= 2:     score += S_FORK * 0.85
    elif n4b >= 2:            score += S_FORK * 0.75   # double blocked-4
    elif n4o >= 1 and n3o >= 1: score += S_DFORK
    elif n4g >= 1 and n3o >= 1: score += S_DFORK * 0.8
    elif n3o >= 2:            score += S_D3
    elif n4o >= 1:            score += S4O * 0.8
    elif n3o >= 1 and n3g >= 1: score += S3O * 3
    if n4b >= 2:              score += S4B * 1.5
    if n3g >= 2:              score += S3G * 2
    return score

def _is_threat4(board, r, c, player):
    n4o, n4b, n4g, _, _ = _cached_count_threats(board, r, c, player)
    return (n4o + n4b + n4g) >= 1

def _count_open3(board, r, c, player):
    board[r][c] = player
    n3o = 0
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        if '_XXX_' in s:
            n3o += 1
    board[r][c] = 0
    return n3o

# ══════════════════════════════════════════════════════════════
# PATTERN MATCHER — nhận dạng các thế cờ nguy hiểm chi tiết
# ══════════════════════════════════════════════════════════════

# Các pattern phân loại theo mức độ nguy hiểm
_PATTERNS_WIN    = ('XXXXX',)
_PATTERNS_4O     = ('_XXXX_',)
_PATTERNS_4G     = ('XX_XX', 'X_XXX', 'XXX_X', 'X_XX_X')
_PATTERNS_4B     = ('_XXXX', 'XXXX_')
_PATTERNS_3O     = ('_XXX_',)
_PATTERNS_3G_STR = ('_XX_X_', '_X_XX_', 'XX_X_', '_X_XX', '_X_X_X_', 'X_X_X')
_PATTERNS_3B     = ('BXXX_', '_XXXB')
_PATTERNS_2O     = ('_XX_',)
_PATTERNS_2B     = ('XX_', '_XX')

def _pattern_classify(board, r, c, player):
    """Phân loại mức nguy hiểm của ô (r,c) nếu player đặt vào đó."""
    board[r][c] = player
    cats = set()
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        for p in _PATTERNS_WIN:
            if p in s: cats.add('WIN')
        for p in _PATTERNS_4O:
            if p in s: cats.add('4O')
        for p in _PATTERNS_4G:
            if p in s: cats.add('4G')
        for p in _PATTERNS_4B:
            if p in s and '_XXXX_' not in s: cats.add('4B')
        for p in _PATTERNS_3O:
            if p in s: cats.add('3O')
        for p in _PATTERNS_3G_STR:
            if p in s: cats.add('3G')
        for p in _PATTERNS_3B:
            if p in s: cats.add('3B')
    board[r][c] = 0
    return cats


# ══════════════════════════════════════════════════════════════
# DOUBLE-THREAT MATRIX — phân tích song song 2 mối đe dọa
# ══════════════════════════════════════════════════════════════

def _dual_threat_score(board, r, c, player):
    """
    Tính điểm dựa trên số lượng và loại threat trong từng hướng.
    Thưởng mạnh nếu 1 nước tạo được 2+ loại threat khác nhau.
    """
    board[r][c] = player
    threat_levels = []
    for dr, dc in DIRS:
        line = _get_line(board, r, c, dr, dc)
        s = ''.join('X' if v == player else ('_' if v == 0 else 'B') for v in line)
        lvl = 0
        if 'XXXXX' in s:    lvl = 6
        elif '_XXXX_' in s: lvl = 5
        elif any(p in s for p in ('XX_XX','X_XXX','XXX_X')): lvl = 4
        elif any(p in s for p in ('_XXXX','XXXX_')): lvl = 3
        elif '_XXX_' in s:  lvl = 2
        elif any(p in s for p in ('_XX_X_','_X_XX_','XX_X_','_X_XX')): lvl = 1
        threat_levels.append(lvl)
    board[r][c] = 0

    base = sum(threat_levels)
    # Thưởng lớn khi có ≥2 hướng threat cấp cao
    high = [l for l in threat_levels if l >= 4]
    mid  = [l for l in threat_levels if l >= 2]
    if len(high) >= 2:   base += 50_000_000
    elif len(high) >= 1 and len(mid) >= 2: base += 20_000_000
    elif len(mid) >= 3:  base += 8_000_000
    return base


# ══════════════════════════════════════════════════════════════
# DANGER ZONE HEATMAP
# ══════════════════════════════════════════════════════════════

def _build_danger_map(board, attacker):
    danger = {}
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c] == 0:
                score = 0
                for dr, dc in DIRS:
                    score += _score_line(_get_line(board, r, c, dr, dc), attacker)
                if score > 0:
                    danger[(r, c)] = score
    return danger


# ══════════════════════════════════════════════════════════════
# DUAL DANGER MAP — kết hợp nguy hiểm của cả 2 bên
# ══════════════════════════════════════════════════════════════

def _build_dual_danger_map(board, player, opp):
    """
    Trả về dict (r,c) -> combined_score.
    combined = atk_score * 1.2 + def_score * 1.0
    Dùng để ưu tiên nước vừa tấn công vừa chặn.
    """
    dual = {}
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c] == 0:
                atk_s = def_s = 0
                for dr, dc in DIRS:
                    atk_s += _score_line(_get_line(board, r, c, dr, dc), player)
                    def_s += _score_line(_get_line(board, r, c, dr, dc), opp)
                combined = atk_s * 1.2 + def_s * 1.0
                if combined > 0:
                    dual[(r, c)] = combined
    return dual


# ══════════════════════════════════════════════════════════════
# VCF — Victory by Continuous Forced moves
# ══════════════════════════════════════════════════════════════

def _vcf_search(board, player, depth, start_time, time_limit):
    if time.time() - start_time > time_limit * 0.8:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    threat4_moves = [(r, c) for r, c in cands if _is_threat4(board, r, c, player)]
    if not threat4_moves:
        return None

    for r, c in threat4_moves:
        board[r][c] = player
        opp_cands = _get_candidates(board, radius=3)   # radius=3 để không miss
        opp_blocks = [(or2, oc2) for or2, oc2 in opp_cands
                      if _is_win(board, or2, oc2, opp)
                      or _is_threat4(board, or2, oc2, opp)]

        if not opp_blocks:
            board[r][c] = 0
            return (r, c)

        all_win = True
        for or2, oc2 in opp_blocks[:4]:
            board[or2][oc2] = opp
            next_move = _vcf_search(board, player, depth - 2, start_time, time_limit)
            board[or2][oc2] = 0
            if next_move is None:
                all_win = False
                break
        board[r][c] = 0
        if all_win and opp_blocks:
            return (r, c)

    return None


# ══════════════════════════════════════════════════════════════
# VCF DEEP — tìm VCF với chiều sâu lớn hơn, xét nhiều phản ứng hơn
# (chỉ dùng level 4)
# ══════════════════════════════════════════════════════════════

def _vcf_deep(board, player, depth, start_time, time_limit, memo=None):
    """
    VCF nâng cấp: xét toàn bộ phản ứng của opp (không giới hạn 4),
    dùng memo để tránh tính lại.
    """
    if memo is None:
        memo = {}
    if time.time() - start_time > time_limit * 0.75:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    # Lấy tất cả nước tạo threat-4 hoặc win
    threat_moves = []
    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)
        if _is_threat4(board, r, c, player):
            threat_moves.append((r, c, _dual_threat_score(board, r, c, player)))
    threat_moves.sort(key=lambda x: -x[2])

    for r, c, _ in threat_moves[:6]:
        board[r][c] = player
        zh = _zhash(board)
        if zh in memo:
            board[r][c] = 0
            if memo[zh]:
                return (r, c)
            continue

        # Tìm tất cả nước bắt buộc của opp — radius=3
        opp_cands = _get_candidates(board, radius=3)
        must_blocks = []
        for or2, oc2 in opp_cands:
            if _is_win(board, or2, oc2, opp):
                must_blocks.append((or2, oc2))
            elif _is_threat4(board, or2, oc2, opp):
                must_blocks.append((or2, oc2))

        if not must_blocks:
            board[r][c] = 0
            memo[zh] = True
            return (r, c)

        all_win = True
        for or2, oc2 in must_blocks:
            board[or2][oc2] = opp
            nxt = _vcf_deep(board, player, depth - 2, start_time, time_limit, memo)
            board[or2][oc2] = 0
            if nxt is None:
                all_win = False
                break

        board[r][c] = 0
        memo[zh] = all_win and bool(must_blocks)
        if all_win and must_blocks:
            return (r, c)

    return None


# ══════════════════════════════════════════════════════════════
# VCT — Victory by Continuous Threat (open-3 → fork)
# ══════════════════════════════════════════════════════════════

def _vct_search(board, player, depth, start_time, time_limit):
    if time.time() - start_time > time_limit * 0.7:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    threat_moves = []
    for r, c in cands:
        n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
        if n3o >= 2 or (n3o >= 1 and (n4o + n4g) >= 1) or n4o >= 1:
            threat_moves.append((r, c, n4o * 10 + n3o * 5 + n4g * 3 + n3g))

    threat_moves.sort(key=lambda x: -x[2])

    for r, c, _ in threat_moves[:6]:
        board[r][c] = player
        if _is_fork(board, r, c, player):
            board[r][c] = 0
            return (r, c)
        opp_cands = _get_candidates(board, radius=2)
        opp_forced = [(or2, oc2) for or2, oc2 in opp_cands
                      if _is_win(board, or2, oc2, opp)
                      or _is_fork(board, or2, oc2, opp)]

        if not opp_forced:
            opp_forced = sorted(opp_cands,
                                key=lambda rc: _threat_value(board, rc[0], rc[1], opp),
                                reverse=True)[:4]

        all_win = True
        for or2, oc2 in opp_forced[:3]:
            board[or2][oc2] = opp
            next_move = _vct_search(board, player, depth - 2, start_time, time_limit)
            board[or2][oc2] = 0
            if next_move is None:
                all_win = False
                break
        board[r][c] = 0
        if all_win:
            return (r, c)

    return None


# ══════════════════════════════════════════════════════════════
# VCT DEEP — VCT nâng cao, xét toàn bộ phản ứng của opp
# (chỉ dùng level 4)
# ══════════════════════════════════════════════════════════════

def _vct_deep(board, player, depth, start_time, time_limit, memo=None):
    """
    VCT nâng cấp: kết hợp threat-4 và open-3, xét sâu hơn.
    Xét phản ứng tối ưu của opp thay vì chỉ lấy top-3.
    """
    if memo is None:
        memo = {}
    if time.time() - start_time > time_limit * 0.72:
        return None
    opp = 3 - player
    cands = _get_candidates(board, radius=2)

    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c)

    if depth <= 0:
        return None

    threat_moves = []
    for r, c in cands:
        n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
        score = n4o * 20 + n3o * 8 + n4g * 5 + n3g * 2 + n4b
        if score > 0:
            threat_moves.append((r, c, score))
    threat_moves.sort(key=lambda x: -x[2])

    for r, c, _ in threat_moves[:8]:
        board[r][c] = player
        zh = _zhash(board)
        if zh in memo:
            board[r][c] = 0
            if memo[zh]:
                return (r, c)
            continue

        if _is_fork(board, r, c, player):
            board[r][c] = 0
            memo[zh] = True
            return (r, c)

        opp_cands = _get_candidates(board, radius=2)
        # Opp sẽ đánh nước tốt nhất có thể
        opp_scored = []
        for or2, oc2 in opp_cands:
            if _is_win(board, or2, oc2, opp):
                opp_scored.append((or2, oc2, INF))
            elif _is_fork(board, or2, oc2, opp):
                opp_scored.append((or2, oc2, S_FORK))
            else:
                tv = _threat_value_v2(board, or2, oc2, opp, 0.0)
                if tv > 0:
                    opp_scored.append((or2, oc2, tv))
        opp_scored.sort(key=lambda x: -x[2])
        opp_best = [(r2, c2) for r2, c2, _ in opp_scored[:5]]

        if not opp_best:
            board[r][c] = 0
            memo[zh] = True
            return (r, c)

        all_win = True
        for or2, oc2 in opp_best:
            board[or2][oc2] = opp
            nxt = _vct_deep(board, player, depth - 2, start_time, time_limit, memo)
            board[or2][oc2] = 0
            if nxt is None:
                all_win = False
                break

        board[r][c] = 0
        memo[zh] = all_win
        if all_win:
            return (r, c)

    return None


# ══════════════════════════════════════════════════════════════
# FORCED SEQUENCE ANALYZER — chuỗi nước bắt buộc tổng quát
# (level 4 — phân tích trước khi minimax)
# ══════════════════════════════════════════════════════════════

def _forced_sequence(board, player, start_time, time_limit):
    """
    Phân tích xem có chuỗi nước bắt buộc nào không:
    1. Win ngay
    2. Block opp win
    3. VCF deep
    4. VCT deep
    5. Fork ngay
    Trả về (move, reason) hoặc None.
    """
    opp = 3 - player
    cands = _get_candidates(board, radius=3)

    # 1. Win ngay — radius=3
    for r, c in cands:
        if _is_win(board, r, c, player):
            return (r, c), 'WIN'

    # 2. Block opp win — radius=3 để không miss ô xa
    blk_cands_fs = _get_candidates(board, radius=3)
    blk = [(r, c) for r, c in blk_cands_fs if _is_win(board, r, c, opp)]
    if blk:
        # Nếu phải chặn ≥2 điểm → thua chắc, nhưng tìm nước tốt nhất
        if len(blk) >= 2:
            best_blk = max(blk, key=lambda rc: _dual_threat_score(board, rc[0], rc[1], player))
            return best_blk, 'BLK_MULTI'
        return blk[0], 'BLK'

    # 3. VCF deep
    if time.time() - start_time < time_limit * 0.3:
        memo = {}
        vcf = _vcf_deep(board, player, 16, start_time, time_limit, memo)
        if vcf:
            return vcf, 'VCF'

    # 4. Block opp VCF (nếu opp có chuỗi thắng)
    if time.time() - start_time < time_limit * 0.5:
        # Kiểm tra opp có VCF không — nếu có, ta phải phá
        opp_vcf = _vcf_deep(board, opp, 12, start_time, time_limit, {})
        if opp_vcf:
            # Chỉ counter fork nếu ta thắng NGAY lập tức (1 nước) — không thì phải chặn
            win_now = [rc for rc in cands if _is_win(board, rc[0], rc[1], player)]
            if win_now:
                return win_now[0], 'WIN'
            return opp_vcf, 'BLK_VCF'

    # 5. VCT deep
    if time.time() - start_time < time_limit * 0.6:
        memo2 = {}
        vct = _vct_deep(board, player, 12, start_time, time_limit, memo2)
        if vct:
            return vct, 'VCT'

    # 5b. Block opp VCT — nếu opp có chuỗi tạo fork bắt buộc
    if time.time() - start_time < time_limit * 0.72:
        opp_vct = _vct_deep(board, opp, 8, start_time, time_limit, {})
        if opp_vct:
            # Ưu tiên: nếu ta có threat-4 ngay thì counter
            my_t4_now = [rc for rc in cands if _is_threat4(board, rc[0], rc[1], player)]
            if my_t4_now:
                best_t4 = max(my_t4_now, key=lambda rc: _dual_threat_score(board, rc[0], rc[1], player))
                return best_t4, 'T4_VS_VCT'
            return opp_vct, 'BLK_VCT'

    # 6. Fork ngay
    fork_cands = [(r, c) for r, c in cands if _is_fork(board, r, c, player)]
    if fork_cands:
        best_fork = max(fork_cands, key=lambda rc:
                        _fork_score(board, rc[0], rc[1], player)
                        + _dual_threat_score(board, rc[0], rc[1], player))
        return best_fork, 'FORK'

    # 7. Block opp fork
    opp_forks = [(r, c) for r, c in cands if _is_fork(board, r, c, opp)]
    if opp_forks:
        # Trước khi chặn, kiểm tra ta có threat-4 không
        my_t4 = [(r, c) for r, c in cands if _is_threat4(board, r, c, player)]
        if my_t4:
            best_t4 = max(my_t4, key=lambda rc: _dual_threat_score(board, rc[0], rc[1], player))
            return best_t4, 'T4_COUNTER'
        best_blk = max(opp_forks, key=lambda rc: _threat_value_v2(board, rc[0], rc[1], player, 0.2))
        return best_blk, 'BLK_FORK'

    return None, None


# ══════════════════════════════════════════════════════════════
# OPENING BOOK
# ══════════════════════════════════════════════════════════════

_OPENING_RESPONSES = {
    # Đối thủ đánh trung tâm
    (7, 7): [(6, 6), (6, 8), (8, 6), (8, 8), (7, 6), (6, 7)],
    # Các góc lệch
    (6, 6): [(7, 7), (7, 6), (6, 7), (8, 8), (7, 8)],
    (8, 8): [(7, 7), (7, 8), (8, 7), (6, 6), (6, 7)],
    (6, 8): [(7, 7), (6, 7), (7, 8), (8, 7)],
    (8, 6): [(7, 7), (7, 6), (8, 7), (6, 7)],
    # Lệch xa hơn — kéo về gần trung tâm
    (5, 5): [(6, 6), (7, 7), (6, 7)],
    (9, 9): [(8, 8), (7, 7), (8, 7)],
    (5, 9): [(6, 8), (7, 7), (6, 7)],
    (9, 5): [(8, 6), (7, 7), (8, 7)],
    (7, 5): [(7, 6), (7, 7), (6, 6)],
    (7, 9): [(7, 8), (7, 7), (6, 8)],
    (5, 7): [(6, 7), (7, 7), (6, 6)],
    (9, 7): [(8, 7), (7, 7), (8, 8)],
}

def _opening_book_move(board, bot_player, history_len):
    if history_len > 6:
        return None
    cx = cy = GRID // 2

    if history_len == 0:
        return (cx, cy)

    if history_len == 1:
        opp_last = None
        for r in range(GRID):
            for c in range(GRID):
                if board[r][c] == (3 - bot_player):
                    opp_last = (r, c)
        if opp_last and opp_last in _OPENING_RESPONSES:
            candidates = _OPENING_RESPONSES[opp_last]
            for r, c in candidates:
                if board[r][c] == 0:
                    return (r, c)
        for dr, dc in [(1,1),(-1,-1),(1,-1),(-1,1),(0,1),(1,0)]:
            nr, nc = cx + dr, cy + dc
            if _in_bounds(nr, nc) and board[nr][nc] == 0:
                return (nr, nc)

    if 2 <= history_len <= 5:
        cands = _get_candidates(board, radius=2)
        best = None
        best_score = -1
        for r, c in cands:
            n3o = _count_open3(board, r, c, bot_player)
            bonus = max(0, 4 - (abs(r - cx) + abs(c - cy)))
            score = n3o * 100 + bonus
            if score > best_score:
                best_score = score
                best = (r, c)
        if best and best_score > 0:
            return best

    return None


# ══════════════════════════════════════════════════════════════
# CANDIDATE GENERATION
# ══════════════════════════════════════════════════════════════

def _get_candidates(board, radius=2):
    cands = set()
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c]:
                for dr in range(-radius, radius+1):
                    for dc in range(-radius, radius+1):
                        nr, nc = r+dr, c+dc
                        if _in_bounds(nr, nc) and not board[nr][nc]:
                            cands.add((nr, nc))
    return list(cands) or [(GRID//2, GRID//2)]

def _classify_candidates(board, player, opp):
    cands = _get_candidates(board, radius=3)   # radius=3 để không miss win/block
    wins=[]; blk_win=[]; forks=[]; blk_fork=[]; t4=[]; blk_t4=[]; rest=[]

    for r, c in cands:
        if _is_win(board, r, c, player):
            wins.append((r, c))
        elif _is_win(board, r, c, opp):
            blk_win.append((r, c))
        elif _is_fork(board, r, c, player):
            forks.append((r, c))
        elif _is_fork(board, r, c, opp):
            blk_fork.append((r, c))
        elif _is_threat4(board, r, c, player):
            t4.append((r, c))
        elif _is_threat4(board, r, c, opp):
            blk_t4.append((r, c))
        else:
            rest.append((r, c))

    if wins:     return wins, 3
    if blk_win:  return blk_win, 3          # STRICT: chỉ block, không mix fork
    if forks:    return forks + blk_fork + t4 + blk_t4, 2
    if blk_fork: return blk_fork + t4 + blk_t4 + rest[:6], 2
    if t4 or blk_t4: return t4 + blk_t4 + rest[:12], 1
    return rest, 0


# ══════════════════════════════════════════════════════════════
# ZOBRIST HASH
# ══════════════════════════════════════════════════════════════

import random as _rng
_rng.seed(20240101)
_ZOB = [[[_rng.getrandbits(64) for _ in range(3)] for _ in range(GRID)] for _ in range(GRID)]

def _zhash(board):
    h = 0
    for r in range(GRID):
        for c in range(GRID):
            v = board[r][c]
            if v: h ^= _ZOB[r][c][v]
    return h


# ══════════════════════════════════════════════════════════════
# FULL BOARD EVALUATION
# ══════════════════════════════════════════════════════════════

def _eval_board(board, bot, opp, aggr=1.15):
    ai_s = hu_s = 0
    ai_mobility = hu_mobility = 0
    cx = cy = GRID // 2

    for r in range(GRID):
        for c in range(GRID):
            p = board[r][c]
            if p == bot:
                for dr, dc in DIRS:
                    ai_s += _score_line(_get_line(board, r, c, dr, dc), bot)
                dist = abs(r - cx) + abs(c - cy)
                ai_s += max(0, S_CENTER * (8 - dist))
            elif p == opp:
                for dr, dc in DIRS:
                    hu_s += _score_line(_get_line(board, r, c, dr, dc), opp)
                dist = abs(r - cx) + abs(c - cy)
                hu_s += max(0, S_CENTER * (8 - dist))

    for r in range(GRID):
        for c in range(GRID):
            p = board[r][c]
            if p == 0:
                continue
            free = sum(1 for dr in (-1,0,1) for dc in (-1,0,1)
                       if _in_bounds(r+dr, c+dc) and board[r+dr][c+dc] == 0)
            if p == bot:   ai_mobility += free * S_CONN
            else:          hu_mobility += free * S_CONN

    ai_s += ai_mobility
    hu_s += hu_mobility
    return int(ai_s * aggr - hu_s)


def _eval_board_v2(board, bot, opp, aggr=1.15):
    """Eval nâng cao: thêm pattern density, threat asymmetry."""
    base = _eval_board(board, bot, opp, aggr)

    bot_open3 = sum(
        _count_open3(board, r, c, bot)
        for r in range(GRID) for c in range(GRID)
        if board[r][c] == bot
    )
    opp_open3 = sum(
        _count_open3(board, r, c, opp)
        for r in range(GRID) for c in range(GRID)
        if board[r][c] == opp
    )
    asymmetry_bonus = (bot_open3 - opp_open3) * S3O * 0.3

    cx = cy = GRID // 2
    density_bonus = 0
    for r in range(cx - 3, cx + 4):
        for c in range(cy - 3, cy + 4):
            if _in_bounds(r, c) and board[r][c] == bot:
                density_bonus += S_CENTER * 2

    return int(base + asymmetry_bonus + density_bonus)


def _eval_board_v3(board, bot, opp, aggr=1.60):
    """
    Eval cực mạnh cho level 4:
    - Tính _eval_board_v2 làm nền
    - Thêm: fork potential score (tổng fork_score của tất cả quân bot)
    - Thêm: threat chain bonus (liên kết nhiều quân thành chuỗi đe dọa)
    - Thêm: mobility asymmetry (bot có nhiều lựa chọn hơn opp → tốt)
    - Thêm: center control score (kiểm soát vùng 5x5 trung tâm)
    - Phạt nặng nếu opp có open-4 hoặc fork chưa bị chặn
    """
    base = _eval_board_v2(board, bot, opp, aggr)

    cx = cy = GRID // 2

    # Fork potential: toàn bộ ô trống xung quanh quân bot
    fork_potential = 0
    opp_fork_danger = 0
    bot_cands = _get_candidates(board, radius=2)
    for r, c in bot_cands[:40]:  # giới hạn để nhanh
        fs_bot = _fork_score(board, r, c, bot)
        fs_opp = _fork_score(board, r, c, opp)
        fork_potential  += fs_bot * 0.15
        opp_fork_danger += fs_opp * 0.20  # phạt nặng hơn

    # Threat chain: đếm số hướng có ≥3 quân liên tiếp
    chain_bonus = 0
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c] == bot:
                for dr, dc in DIRS:
                    cnt = 0
                    nr, nc = r, c
                    while _in_bounds(nr, nc) and board[nr][nc] == bot:
                        cnt += 1; nr += dr; nc += dc
                    if cnt >= 3:
                        chain_bonus += S3O * cnt * 0.1

    # Center control: trọng số theo khoảng cách
    center_control = 0
    for r in range(cx - 4, cx + 5):
        for c in range(cy - 4, cy + 5):
            if _in_bounds(r, c):
                dist = max(abs(r - cx), abs(c - cy))  # Chebyshev
                weight = max(0, 5 - dist)
                if board[r][c] == bot:
                    center_control += weight * S_CENTER * 3
                elif board[r][c] == opp:
                    center_control -= weight * S_CENTER * 2

    # Mobility asymmetry: số ô trống xung quanh bot - opp
    bot_mob = opp_mob = 0
    for r in range(GRID):
        for c in range(GRID):
            p = board[r][c]
            if p == 0: continue
            free = sum(1 for dr in (-1,0,1) for dc in (-1,0,1)
                       if _in_bounds(r+dr,c+dc) and board[r+dr][c+dc]==0)
            if p == bot:  bot_mob += free
            else:         opp_mob += free
    mob_bonus = (bot_mob - opp_mob) * S_CONN * 0.5

    # Phạt nặng nếu opp có open-4 chưa bị chặn
    opp_open4_penalty = 0
    for r in range(GRID):
        for c in range(GRID):
            if board[r][c] == 0:
                n4o, n4b, n4g, _, _ = _count_threats(board, r, c, opp)
                if n4o >= 1:
                    opp_open4_penalty += S4O * 0.8
                elif n4g >= 1:
                    opp_open4_penalty += S4G * 0.5

    return int(base
               + fork_potential
               - opp_fork_danger
               + chain_bonus
               + center_control
               + mob_bonus
               - opp_open4_penalty)


# ══════════════════════════════════════════════════════════════
# MULTI-LAYER PRE-FORK PLANNING
# ══════════════════════════════════════════════════════════════

def _find_pre_fork_deep(board, player, opp, cands, start_time, time_limit, depth=3):
    if time.time() - start_time > time_limit * 0.6:
        return None

    top = sorted(cands,
                 key=lambda rc: _threat_value_v2(board, rc[0], rc[1], player, 0.1),
                 reverse=True)[:12]

    def can_force_fork(b, p, o, remaining, t_start):
        if remaining <= 0:
            return False
        if time.time() - t_start > time_limit * 0.7:
            return False
        my_cands = _get_candidates(b, radius=2)
        for mr, mc in my_cands[:10]:
            if _is_fork(b, mr, mc, p):
                return True
            if _is_win(b, mr, mc, p):
                return True
        if remaining <= 1:
            return False
        for mr, mc in my_cands[:8]:
            b[mr][mc] = p
            o_cands = _get_candidates(b, radius=2)
            o_best = sorted(o_cands,
                            key=lambda rc: _threat_value_v2(b, rc[0], rc[1], o, 0),
                            reverse=True)[:5]
            all_good = True
            for or2, oc2 in o_best:
                b[or2][oc2] = o
                result = can_force_fork(b, p, o, remaining - 1, t_start)
                b[or2][oc2] = 0
                if not result:
                    all_good = False
                    break
            b[mr][mc] = 0
            if all_good and o_best:
                return True
        return False

    for r, c in top:
        board[r][c] = player
        opp_cands = _get_candidates(board, radius=2)[:10]
        fork_guaranteed = True
        for or2, oc2 in opp_cands:
            board[or2][oc2] = opp
            has_path = can_force_fork(board, player, opp, depth - 1, start_time)
            board[or2][oc2] = 0
            if not has_path:
                fork_guaranteed = False
                break
        board[r][c] = 0
        if fork_guaranteed and opp_cands:
            return r, c

    return None

def _find_pre_fork(board, player, opp, cands):
    top = sorted(cands,
                 key=lambda rc: _threat_value(board, rc[0], rc[1], player),
                 reverse=True)[:10]

    for r, c in top:
        board[r][c] = player
        opp_cands = _get_candidates(board, radius=2)[:12]
        fork_guaranteed = True
        for or2, oc2 in opp_cands:
            board[or2][oc2] = opp
            my_next = _get_candidates(board, radius=2)
            has_fork = any(_is_fork(board, nr, nc, player) for nr, nc in my_next)
            board[or2][oc2] = 0
            if not has_fork:
                fork_guaranteed = False
                break
        board[r][c] = 0
        if fork_guaranteed:
            return r, c

    best_pre = max(top,
                   key=lambda rc: _fork_score(board, rc[0], rc[1], player),
                   default=None)
    if best_pre and _fork_score(board, best_pre[0], best_pre[1], player) >= S3O * 2:
        return best_pre
    return None


# ══════════════════════════════════════════════════════════════
# MULTI-STEP THREAT BUILDER — xây dựng chuỗi đe dọa bắt buộc
# (level 4 — hoàn toàn mới)
# ══════════════════════════════════════════════════════════════

def _build_threat_chain(board, player, opp, start_time, time_limit):
    """
    Tìm chuỗi nước A → B → ... sao cho sau mỗi nước của ta,
    opp buộc phải phản ứng, và cuối chuỗi ta đạt fork hoặc thắng.

    Chiến lược:
    1. Đánh nước tạo threat-4 hoặc open-3 mạnh
    2. Opp buộc chặn (forced response)
    3. Ta đánh nước tiếp theo tạo threat mới
    4. Lặp cho đến khi fork hoặc thắng
    """
    if time.time() - start_time > time_limit * 0.65:
        return None

    cands = _get_candidates(board, radius=3)

    # Bước 1: tìm nước tạo threat-4 ngay
    t4_moves = [(r, c) for r, c in cands if _is_threat4(board, r, c, player)]
    if t4_moves:
        # Ưu tiên nước threat-4 kép (2 hướng)
        best_t4 = max(t4_moves, key=lambda rc: _dual_threat_score(board, rc[0], rc[1], player))
        return best_t4

    # Bước 2: tìm nước tạo open-3 kép → chuẩn bị fork
    double_3 = []
    for r, c in cands:
        n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
        if n3o >= 2:
            double_3.append((r, c, n3o * 5 + n4g * 3))
    if double_3:
        double_3.sort(key=lambda x: -x[2])
        r, c, _ = double_3[0]
        return (r, c)

    # Bước 3: nước chuẩn bị — kết hợp open-3 + gap-3
    prep = []
    for r, c in cands:
        n4o, n4b, n4g, n3o, n3g = _count_threats(board, r, c, player)
        if n3o >= 1 and (n4g + n3g) >= 1:
            prep.append((r, c, n3o * 3 + n4g * 2 + n3g))
    if prep:
        prep.sort(key=lambda x: -x[2])
        r, c, _ = prep[0]
        return (r, c)

    return None


# ══════════════════════════════════════════════════════════════
# STRATEGIC POSITION EVALUATOR — đánh giá vị trí chiến lược
# (level 4 — hoàn toàn mới)
# ══════════════════════════════════════════════════════════════

def _strategic_score(board, r, c, player, opp):
    """
    Tính điểm chiến lược tổng thể cho nước đi (r,c).
    Kết hợp:
    1. Dual threat score (tấn công + phòng thủ)
    2. Fork potential (sau nước này ta có thể fork không)
    3. Connectivity score
    4. Center control
    5. Đe dọa hai hướng đồng thời
    6. Phá thế của opp
    """
    # 1. Dual threat
    dual = _dual_threat_score(board, r, c, player)

    # 2. Fork potential (nhìn 1 nước trước)
    board[r][c] = player
    next_cands = _get_candidates(board, radius=2)
    fork_pot = max((_fork_score(board, nr, nc, player) for nr, nc in next_cands[:15]), default=0)
    board[r][c] = 0

    # 3. Connectivity
    conn = sum(S_CONN * 2 for dr in (-1,0,1) for dc in (-1,0,1)
               if _in_bounds(r+dr, c+dc) and board[r+dr][c+dc] == player)

    # 4. Center control
    cx = cy = GRID // 2
    dist = max(abs(r - cx), abs(c - cy))
    center = max(0, S_CENTER * 4 * (5 - dist))

    # 5. Disruption: phá thế của opp (đặt vào điểm mà opp cần)
    board[r][c] = opp
    opp_disrupted = sum(_score_line(_get_line(board, r, c, dr, dc), opp) for dr, dc in DIRS)
    board[r][c] = 0

    return int(dual + fork_pot * 0.2 + conn + center + opp_disrupted * 0.3)


# ══════════════════════════════════════════════════════════════
# ASPIRATION WINDOW SEARCH — tìm kiếm theo cửa sổ kỳ vọng
# (level 4 — hoàn toàn mới)
# ══════════════════════════════════════════════════════════════

def _aspiration_search(root_fn, board, cands, depth, player, opp, prev_score, window=2_000_000):
    """
    Tìm kiếm với cửa sổ alpha-beta thu hẹp xung quanh điểm kỳ vọng.
    Nếu fail-low hoặc fail-high thì mở rộng cửa sổ và tìm lại.
    """
    alpha = prev_score - window
    beta  = prev_score + window

    # Lần 1: cửa sổ hẹp
    move, score = root_fn(board, cands, depth, player, opp, alpha, beta)

    if score <= alpha:
        # Fail-low: mở rộng xuống
        move, score = root_fn(board, cands, depth, player, opp, -INF, beta)
    elif score >= beta:
        # Fail-high: mở rộng lên
        move, score = root_fn(board, cands, depth, player, opp, alpha, INF)

    return move, score


# ══════════════════════════════════════════════════════════════
# CaroAI MAIN CLASS
# ══════════════════════════════════════════════════════════════

class CaroAI:
    """
    Mức 1 – Dễ       : greedy 1-ply, random top-3, không minimax.
    Mức 2 – Trung bình: depth-4, 1.0s, fork detection cơ bản.
    Mức 3 – Khó      : depth-7, 2.5s, pre-fork 1 lớp, VCF, aggr=1.25.
    Mức 4 – Không thể thắng:
        - depth-12, 8.0s
        - VCF Deep (16 lớp, toàn bộ phản ứng opp)
        - VCT Deep (12 lớp, toàn bộ phản ứng opp)
        - Forced Sequence Analyzer (phân tích bắt buộc 7 tầng)
        - Multi-step Threat Builder (xây dựng chuỗi đe dọa)
        - Strategic Position Evaluator (đánh giá chiến lược tổng thể)
        - Dual Danger Map (kết hợp tấn công + phòng thủ)
        - Eval_v3 (đánh giá sâu: fork potential, chain, center, mobility)
        - Aspiration Window Search (tìm kiếm cửa sổ thu hẹp)
        - Pre-fork planning 3 lớp
        - aggr=1.80
    """

    _CFG = {
        1: dict(depth=1,  time=0.3,  branch=5,  aggr=1.0,  radius=2),
        2: dict(depth=4,  time=1.0,  branch=14, aggr=1.08, radius=2),
        3: dict(depth=7,  time=2.5,  branch=20, aggr=1.25, radius=2),
        4: dict(depth=12, time=8.0,  branch=28, aggr=1.80, radius=3),
    }

    def __init__(self, difficulty=3):
        self.difficulty     = max(1, min(4, difficulty))
        cfg                 = self._CFG[self.difficulty]
        self._max_depth     = cfg['depth']
        self._time_limit    = cfg['time']
        self._branch        = cfg['branch']
        self._aggr          = cfg['aggr']
        self._radius        = cfg['radius']
        self.nodes_searched = 0
        self.start_time     = time.time()
        self._tt            = {}
        self._killers       = [[] for _ in range(60)]
        self._history       = {}
        self._prev_score    = 0  # dùng cho aspiration window

    def best_move(self, board_obj, bot_player):
        self.nodes_searched = 0
        self.start_time     = time.time()
        self._tt.clear()
        self._history.clear()
        for km in self._killers: km.clear()
        _THREAT_CACHE.clear()   # reset threat cache mỗi lượt

        board   = [row[:] for row in board_obj.cells]
        opp     = 3 - bot_player
        history = board_obj.history if hasattr(board_obj, 'history') else []

        # ── Nước đầu tiên: trung tâm ──
        if not history:
            return GRID // 2, GRID // 2

        # ── Opening book (level 3+) ──
        if self.difficulty >= 3:
            ob = _opening_book_move(board, bot_player, len(history))
            if ob:
                return ob

        cands = _get_candidates(board, radius=self._radius)

        # ══ Level 4: Forced Sequence Analyzer ══
        if self.difficulty == 4:
            forced_move, reason = _forced_sequence(board, bot_player, self.start_time, self._time_limit)
            if forced_move:
                return forced_move

        # ── Instant win (level 1-3 fallback) — dùng radius=3 để không miss ──
        wide_cands = _get_candidates(board, radius=3)
        for r, c in wide_cands:
            if _is_win(board, r, c, bot_player):
                return r, c

        # ── Block instant loss ── (dùng radius=3 để không miss ô xa)
        blk_cands = _get_candidates(board, radius=3)
        blk_list = [(r, c) for r, c in blk_cands if _is_win(board, r, c, opp)]
        if blk_list:
            if self.difficulty >= 3:
                for fr, fc in cands:
                    if _is_fork(board, fr, fc, bot_player) and _is_win(board, fr, fc, bot_player):
                        return fr, fc
                if len(blk_list) >= 2:
                    best_blk = max(blk_list,
                                   key=lambda rc: _strategic_score(board, rc[0], rc[1], bot_player, opp)
                                   if self.difficulty == 4
                                   else _threat_value_v2(board, rc[0], rc[1], bot_player, 0.2))
                    return best_blk
            return blk_list[0]

        # ── Level 1: easy mode ──
        if self.difficulty == 1:
            return self._easy(board, bot_player, cands)

        # ══ Level 4: VCF search (backup nếu forced_sequence miss) ══
        if self.difficulty == 4:
            if time.time() - self.start_time < self._time_limit * 0.25:
                vcf = _vcf_deep(board, bot_player, 16, self.start_time, self._time_limit, {})
                if vcf:
                    return vcf
                opp_vcf = _vcf_deep(board, opp, 12, self.start_time, self._time_limit, {})
                if opp_vcf:
                    fork_list = [(r, c) for r, c in cands if _is_fork(board, r, c, bot_player)]
                    if fork_list:
                        best_fork = max(fork_list,
                                        key=lambda rc: _fork_score(board, rc[0], rc[1], bot_player))
                        return best_fork
                    return opp_vcf

        # ══ Level 3+: VCF lite ══
        if self.difficulty == 3:
            vcf = _vcf_search(board, bot_player, 8, self.start_time, self._time_limit)
            if vcf:
                return vcf

        # ── Fork attack (level 2+) ──
        fork_cands = [(r, c) for r, c in cands if _is_fork(board, r, c, bot_player)]
        if fork_cands:
            if self.difficulty == 4:
                best = max(fork_cands,
                           key=lambda rc: _fork_score(board, rc[0], rc[1], bot_player)
                                          + _strategic_score(board, rc[0], rc[1], bot_player, opp))
            else:
                best = max(fork_cands,
                           key=lambda rc: _fork_score(board, rc[0], rc[1], bot_player)
                                          + _threat_value_v2(board, rc[0], rc[1], bot_player,
                                                             0.2 if self.difficulty == 4 else 0.0))
            return best

        # ── Block opponent fork (level 2+) ──
        opp_forks = [(r, c) for r, c in cands if _is_fork(board, r, c, opp)]
        if opp_forks:
            if self.difficulty >= 3:
                my_t4 = [(r, c) for r, c in cands if _is_threat4(board, r, c, bot_player)]
                if my_t4:
                    if self.difficulty == 4:
                        best_t4 = max(my_t4,
                                      key=lambda rc: _strategic_score(board, rc[0], rc[1], bot_player, opp))
                    else:
                        best_t4 = max(my_t4,
                                      key=lambda rc: _threat_value_v2(board, rc[0], rc[1], bot_player, 0.1))
                    return best_t4
            if self.difficulty == 4:
                best = max(opp_forks,
                           key=lambda rc: _strategic_score(board, rc[0], rc[1], bot_player, opp))
            else:
                best = max(opp_forks,
                           key=lambda rc: _threat_value(board, rc[0], rc[1], bot_player))
            return best

        # ══ Level 4: VCT search ══
        if self.difficulty == 4:
            if time.time() - self.start_time < self._time_limit * 0.45:
                vct = _vct_deep(board, bot_player, 12, self.start_time, self._time_limit, {})
                if vct:
                    return vct

        # ══ Level 4: Multi-step Threat Builder ══
        if self.difficulty == 4:
            chain = _build_threat_chain(board, bot_player, opp, self.start_time, self._time_limit)
            if chain:
                # Kiểm tra đây có phải là nước tốt không (không bị chặn ngay)
                cr, cc = chain
                board[cr][cc] = bot_player
                opp_blocks_chain = any(_is_win(board, r2, c2, opp) for r2, c2 in _get_candidates(board, radius=2))
                board[cr][cc] = 0
                # Chỉ dùng nếu opp không thể block ngay bằng win
                if not opp_blocks_chain:
                    # Nhưng nếu ta dùng chain mà opp có fork → bỏ qua
                    opp_fork_after = any(_is_fork(board, r2, c2, opp)
                                         for r2, c2 in _get_candidates(board, radius=2)
                                         if (r2, c2) != chain)
                    if not opp_fork_after:
                        pass  # chain ok, nhưng vẫn để minimax quyết định cuối

        # ── Pre-fork planning ──
        if self.difficulty == 4:
            pre = _find_pre_fork_deep(board, bot_player, opp, cands,
                                      self.start_time, self._time_limit, depth=3)
            if pre:
                return pre
        elif self.difficulty == 3:
            pre = _find_pre_fork(board, bot_player, opp, cands)
            if pre:
                return pre

        # ══ Level 4: Dual Danger Map + Strategic Scoring ══
        if self.difficulty == 4:
            dual_map = _build_dual_danger_map(board, bot_player, opp)
            scored_full = sorted(
                cands,
                key=lambda rc: (
                    _strategic_score(board, rc[0], rc[1], bot_player, opp)
                    + dual_map.get(rc, 0) * 0.4
                ),
                reverse=True
            )
            top = scored_full[:self._branch]
        else:
            scored = sorted(cands,
                            key=lambda rc: _threat_value(board, rc[0], rc[1], bot_player),
                            reverse=True)
            top = scored[:self._branch]

        best_r, best_c = top[0]

        # ── Iterative deepening minimax với aspiration window ──
        prev_score = self._prev_score
        for depth in range(1, self._max_depth + 1):
            if time.time() - self.start_time > self._time_limit * 0.55:
                break
            if self.difficulty == 4 and depth >= 3:
                # Aspiration window search
                move, score = _aspiration_search(
                    self._root_with_score,
                    board, top, depth, bot_player, opp, prev_score,
                    window=max(1_000_000, 3_000_000 // depth)
                )
                prev_score = score
            else:
                move = self._root(board, top, depth, bot_player, opp)
                score = 0
            best_r, best_c = move

        self._prev_score = prev_score
        return best_r, best_c

    def stats(self):
        e = max(time.time() - self.start_time, 0.001)
        return f"{self.nodes_searched:,} nodes | {int(self.nodes_searched/e):,}/s | {e:.2f}s"

    # ── Root search (trả về move) ──────────────────────────────

    def _root(self, board, cands, depth, player, opp):
        move, _ = self._root_with_score(board, cands, depth, player, opp, -INF, INF)
        return move

    # ── Root search (trả về move + score) ─────────────────────

    def _root_with_score(self, board, cands, depth, player, opp, alpha, beta):
        best_score = -INF
        best_move  = cands[0]
        for r, c in cands:
            if time.time() - self.start_time > self._time_limit:
                break
            board[r][c] = player
            score = self._minimax(board, depth-1, alpha, beta, False, player, opp, 1)
            board[r][c] = 0
            self.nodes_searched += 1
            if score > best_score:
                best_score = score
                best_move  = (r, c)
            alpha = max(alpha, score)
            if alpha >= beta:
                break
        return best_move, best_score

    # ── Minimax + alpha-beta + enhancements ──────────────────

    def _minimax(self, board, depth, alpha, beta, is_max, bot, opp, ply):
        self.nodes_searched += 1

        if time.time() - self.start_time > self._time_limit:
            if self.difficulty == 4:
                return _eval_board_v3(board, bot, opp, self._aggr)
            return _eval_board(board, bot, opp, self._aggr)

        zh = _zhash(board)
        tt = self._tt.get(zh)
        if tt and tt[0] >= depth:
            _, flag, val = tt
            if flag == 0: return val
            if flag == 1: alpha = max(alpha, val)
            elif flag == 2: beta = min(beta, val)
            if alpha >= beta: return val

        if depth == 0:
            if self.difficulty == 4:
                return _eval_board_v3(board, bot, opp, self._aggr)
            return _eval_board(board, bot, opp, self._aggr)

        player = bot if is_max else opp
        enemy  = opp if is_max else bot

        tcands, tlv = _classify_candidates(board, player, enemy)

        if tlv == 3:
            cands = tcands  # KHÔNG giới hạn — win/block phải xét toàn bộ
        elif tlv >= 1 and depth <= 2:
            cands = tcands[:10]
        else:
            raw = _get_candidates(board, radius=self._radius if depth >= 3 else 2)
            km  = self._killers[ply] if ply < len(self._killers) else []
            if self.difficulty == 4:
                raw.sort(key=lambda rc:
                         _strategic_score(board, rc[0], rc[1], player, enemy)
                         + (800_000 if rc in km else 0)
                         + self._history.get(rc, 0),
                         reverse=True)
            else:
                raw.sort(key=lambda rc:
                         _threat_value(board, rc[0], rc[1], player)
                         + (800_000 if rc in km else 0)
                         + self._history.get(rc, 0),
                         reverse=True)
            # Level 4: giới hạn rộng hơn để tìm sâu hơn
            if self.difficulty == 4:
                lim = {12:3, 11:4, 10:4, 9:5, 8:6, 7:7, 6:8, 5:10,
                       4:12, 3:14, 2:18, 1:22}.get(depth, 10)
            else:
                lim = {7:5, 6:6, 5:8, 4:10, 3:12, 2:16, 1:20}.get(depth, 12)
            cands = raw[:lim]

        # Immediate win shortcut — check toàn bộ candidates radius=3
        win_cands = _get_candidates(board, radius=3) if depth >= 2 else cands
        for r, c in win_cands:
            if _is_win(board, r, c, player):
                return (S5 + ply * 1000) * (1 if is_max else -1)

        # Immediate loss check — enemy có thể thắng ngay? (quan trọng hơn fork)
        for r, c in win_cands:
            if _is_win(board, r, c, enemy):
                # Enemy thắng ngay nếu ta không chặn — đây là tình huống tệ
                if is_max:
                    pass  # ta sẽ chọn chặn trong vòng lặp bình thường
                else:
                    return -(S5 + ply * 500)  # min node: enemy thắng sớm = rất tệ cho ta

        # Level 3-4: nút max có fork ngay → return sớm (CHỈ nếu enemy không thắng ngay)
        enemy_wins_now = any(_is_win(board, r, c, enemy) for r, c in win_cands)
        if not enemy_wins_now and is_max and self.difficulty >= 3:
            for r, c in cands:
                if _is_fork(board, r, c, player):
                    fs = _fork_score(board, r, c, player)
                    threshold = S_D3 if self.difficulty == 3 else S3O * 3
                    if fs >= threshold:
                        return fs

        # Level 4: nút min có fork ngay → cũng xét (CHỈ nếu ta không thắng ngay)
        my_wins_now = any(_is_win(board, r, c, bot) for r, c in win_cands)
        if not my_wins_now and not is_max and self.difficulty == 4:
            for r, c in cands:
                if _is_fork(board, r, c, player):
                    fs = _fork_score(board, r, c, player)
                    if fs >= S_D3:
                        return -fs

        best      = -INF if is_max else INF
        orig_alpha = alpha

        for r, c in cands:
            board[r][c] = player
            val = self._minimax(board, depth-1, alpha, beta, not is_max, bot, opp, ply+1)
            board[r][c] = 0

            if is_max:
                if val > best: best = val
                alpha = max(alpha, best)
            else:
                if val < best: best = val
                beta = min(beta, best)

            if beta <= alpha:
                km = self._killers[ply]
                if (r, c) not in km:
                    km.insert(0, (r, c))
                    if len(km) > 3: km.pop()
                self._history[(r, c)] = self._history.get((r, c), 0) + 2**depth
                break

            if time.time() - self.start_time > self._time_limit:
                break

        flag = 0 if orig_alpha < best < beta else (1 if best >= beta else 2)
        tt_limit = 300_000 if self.difficulty == 4 else 120_000
        if len(self._tt) < tt_limit:
            self._tt[zh] = (depth, flag, best)

        return best

    # ── Easy mode ─────────────────────────────────────────────

    def _easy(self, board, player, cands):
        scored = []
        for r, c in cands:
            board[r][c] = player
            s = sum(_score_line(_get_line(board, r, c, dr, dc), player) for dr, dc in DIRS)
            board[r][c] = 0
            scored.append((s, r, c))
        scored.sort(reverse=True)
        _, r, c = random.choice(scored[:3])
        return r, c
