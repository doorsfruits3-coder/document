from app.core.index import *
import os
import subprocess
import sys
import time
import random
import string
import threading

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
_LOGIN_DB   = "data/config/login.json"
_QR_PATH    = "data/assets/cache/image/qr_code.png"
_QR_TIMEOUT = 120
_DEV_LEVEL  = 4


# ══════════════════════════════════════════════════════════════════════════════
#  JSON HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _load_login() -> dict:
    return load_json(_LOGIN_DB, {"data": []})


def _save_login(cfg: dict) -> bool:
    try:
        save_json(_LOGIN_DB, cfg)
        return True
    except Exception as e:
        logger.error(f"[multibot] save_login error: {e}")
        return False


# ══════════════════════════════════════════════════════════════════════════════
#  BOT LOOKUP
# ══════════════════════════════════════════════════════════════════════════════
def _get_bot(cfg: dict, bot_id: str):
    bots = cfg.get("data", [])
    for b in bots:
        if str(b.get("author_id", "")) == bot_id:
            return b
    for b in bots:
        if str(b.get("author_id", "")).startswith(bot_id):
            return b
    return None


def _bot_label(b: dict) -> str:
    name = b.get("nickname") or b.get("username") or b.get("author_id", "?")
    tag  = " [MAIN]" if b.get("is_main_bot") else ""
    st   = "[ON]" if b.get("status") else "[OFF]"
    return f"{st} {name}{tag}"


def _runtime_client(bot: dict):
    try:
        from app.login.client import mainclient, clientlist
        if bot.get("is_main_bot"):
            return mainclient
        return clientlist.get(str(bot.get("author_id", "")))
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════════════════
#  REPLY SHORTCUT / PERMISSION
# ══════════════════════════════════════════════════════════════════════════════
def _r(self, msg, data, threadId, type, userId, color="yl", title="MULTIBOT"):
    return self.replyMessageStyle(msg, data, threadId, type,
                                  color=color, title=title, userId=userId)


def _is_dev(self, userId, threadId) -> bool:
    return self.permissionLevel(userId, threadId) >= _DEV_LEVEL


def _deny_dev(self, data, threadId, type, userId):
    return _r(self, "Lệnh này chỉ dành cho Developer.",
              data, threadId, type, userId, color="r", title="NO PERMISSION")


# ══════════════════════════════════════════════════════════════════════════════
#  DATE HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _parse_date(raw: str):
    if not raw:
        return None
    from datetime import datetime
    for fmt in ("%H:%M:%S/%d/%m/%Y", "%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(raw, fmt)
        except ValueError:
            pass
    return None


def _format_approved(raw: str) -> str:
    """'18:00:00/27/05/2026' → '06 PM 27 - 18 5 2026'"""
    dt = _parse_date(raw)
    if not dt:
        return raw or "N/A"
    hour24 = dt.hour
    hour12 = hour24 % 12 or 12
    ampm   = "AM" if hour24 < 12 else "PM"
    return f"{hour12:02d} {ampm} {dt.day} - {dt.day} {dt.month} {dt.year}"


def _remaining_days(raw: str) -> str:
    from datetime import datetime
    dt = _parse_date(raw)
    if not dt:
        return "Unlimited"
    delta = (dt - datetime.now()).days
    return "Expired" if delta < 0 else f"{delta} Days"


def _login_type(b: dict) -> str:
    raw = b.get("login_type", "")
    if raw:
        return raw.upper()
    imei = str(b.get("imei", ""))
    return "PC" if imei.startswith("5") else "WEB"


# ══════════════════════════════════════════════════════════════════════════════
#  QR COUNTDOWN  (giống zingmp3)
# ══════════════════════════════════════════════════════════════════════════════
def _extract_ids(msg_obj):
    """Extract (msgId, cliMsgId) from either a dict response or an object."""
    if isinstance(msg_obj, dict):
        return (
            msg_obj.get("globalMsgId") or msg_obj.get("msgId"),
            msg_obj.get("cliMsgId")    or msg_obj.get("clientId"),
        )
    return (
        getattr(msg_obj, "msgId",    None) or getattr(msg_obj, "globalMsgId", None),
        getattr(msg_obj, "clientId", None) or getattr(msg_obj, "cliMsgId",    None),
    )


def _start_countdown(self, msg_obj, threadId, threadType, key, timeout=_QR_TIMEOUT):
    if not hasattr(self, "_mbCountdown"):
        self._mbCountdown = {}
    self._mbCountdown[key] = True

    msg_id, cli_msg_id = _extract_ids(msg_obj)

    # Guard: nếu không lấy được msgId hoặc cliMsgId thì không thể reaction
    if msg_id is None or cli_msg_id is None:
        logger.warning(f"[countdown] Cannot start countdown for key={key}: msgId={msg_id}, cliMsgId={cli_msg_id}")
        self._mbCountdown.pop(key, None)
        return

    # Ép kiểu int an toàn
    try:
        msg_id_int     = int(msg_id)
        cli_msg_id_int = int(cli_msg_id)
    except (TypeError, ValueError) as e:
        logger.warning(f"[countdown] Cannot convert ids to int: msgId={msg_id}, cliMsgId={cli_msg_id} — {e}")
        self._mbCountdown.pop(key, None)
        return

    # MessageObject is DefaultMunch — set attributes after construction
    react_msg          = MessageObject()
    react_msg.msgId    = msg_id_int
    react_msg.cliMsgId = cli_msg_id_int
    react_msg.msgType  = "webchat"

    def _loop():
        for i in range(timeout, 0, -1):
            if not self._mbCountdown.get(key):
                break
            try:
                self.sendMultiReaction(react_msg, "🕑", threadId, threadType, 102229, numreact=i)
                time.sleep(1)
                self.sendMultiReaction(react_msg, "",   threadId, threadType, -1,     numreact=i)
            except Exception as _e:
                logger.warning(f"[countdown] reaction error: {_e}")
                break
        self._mbCountdown.pop(key, None)

    threading.Thread(target=_loop, daemon=True).start()


def _stop_countdown(self, key):
    if hasattr(self, "_mbCountdown"):
        self._mbCountdown[key] = False


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG LIST  —  session + reply handler
# ══════════════════════════════════════════════════════════════════════════════
_cfg_sessions: dict = {}   # userId → session state


def _bot_info_msg(b: dict) -> str:
    name      = b.get("nickname") or b.get("username") or b.get("author_id", "?")
    uid       = b.get("author_id", "?")
    prefix    = b.get("prefix", "?")
    bot_type  = "mainBot" if b.get("is_main_bot") else "subBot"
    login     = _login_type(b)

    # kich_hoat / het_han có thể là None hoặc "" → hiển thị "N/A" / "Unlimited"
    kich_hoat_raw = b.get("kich_hoat") or ""
    het_han_raw   = b.get("het_han")   or ""
    approved  = _format_approved(kich_hoat_raw) if kich_hoat_raw else "N/A"
    remaining = _remaining_days(het_han_raw)    if het_han_raw   else "Unlimited"

    status_icon = "" if b.get("status") else ""

    return (
        f"Base\n"
        f"  Name     : {name}\n"
        f"  Type     : {bot_type} {status_icon}\n"
        f"  Uid      : {uid}\n"
        f"  Prefix   : {prefix}\n"
        f"  Login    : {login}\n"
        f"\n"
        f"Services\n"
        f"  Activated: {approved}\n"
        f"  Remaining: {remaining}\n"
        f"  Database : Local JSON"
    )


def _cfg_close_session(self, userId):
    state = _cfg_sessions.pop(userId, None)
    if not state:
        return
    _stop_countdown(self, state["key"])
    try:
        self.deleteMessage(state["msgId"], self.uid, state["cliMsgId"], state["threadId"])
    except Exception:
        pass


def _handle_config_reply(self, message, data, userId, threadId, threadType) -> bool:
    """Returns True if the reply was consumed by a config session."""
    state = _cfg_sessions.get(userId)
    if not state:
        return False
    if time.time() - state["time"] > _QR_TIMEOUT:
        _cfg_sessions.pop(userId, None)
        return False

    text = (getattr(message, "text", "") or "").strip()
    if not text.isdigit():
        return False

    num  = int(text)
    bots = state["bots"]

    if num == 0:
        _cfg_close_session(self, userId)
        return True

    if num < 1 or num > len(bots):
        return False

    bot = bots[num - 1]
    _cfg_close_session(self, userId)
    _r(self, _bot_info_msg(bot), data, threadId, threadType, userId,
       color="gr", title="BOT INFO")
    return True


def _parse_sl_flag(parts: list):
    """Parse -sl=<n> or -sl <n> from parts. Returns (sl_index_or_None, clean_parts)."""
    sl_index   = None
    clean      = []
    i          = 0
    while i < len(parts):
        arg = parts[i]
        if arg.lower().startswith("-sl="):
            try:
                sl_index = int(arg.split("=", 1)[1])
            except ValueError:
                pass
        elif arg.lower() == "-sl" and i + 1 < len(parts):
            try:
                sl_index = int(parts[i + 1])
                i += 1
            except ValueError:
                pass
        else:
            clean.append(arg)
        i += 1
    return sl_index, clean


def _handle_config(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    sl_index, clean_parts = _parse_sl_flag(parts)

    if len(clean_parts) < 3 or clean_parts[2].lower() != "list":
        return _r(self, f"Usage: {p}{c} config list [-sl=<số>]",
                  data, threadId, type, userId, color="yl", title="CONFIG")

    cfg  = _load_login()
    bots = cfg.get("data", [])
    if not bots:
        return _r(self, "No bots registered in config.",
                  data, threadId, type, userId, color="yl", title="CONFIG LIST")

    # -sl=<n>: hiển thị thẳng info chi tiết, không cần reply session
    if sl_index is not None:
        if sl_index < 1 or sl_index > len(bots):
            return _r(self,
                f"Số thứ tự không hợp lệ. Có {len(bots)} bot(s) (1–{len(bots)}).",
                data, threadId, type, userId, color="r", title="CONFIG LIST")
        bot = bots[sl_index - 1]
        return _r(self, _bot_info_msg(bot), data, threadId, type, userId,
                  color="gr", title="BOT INFO")

    lines = [f"Total: {len(bots)} bot(s)\n"]
    for idx, b in enumerate(bots, 1):
        name = b.get("nickname") or b.get("username") or b.get("author_id", "?")
        bid  = b.get("author_id", "?")
        lines.append(f"{idx}. {name}\n   ID: {bid}")
    lines.append(f"\n📌 hãy thêm -sl=(stt bot) ở cuối dòng lệnh để xem thông tin chi tiết bot account đó.")

    msg_obj = _r(self, "\n".join(lines), data, threadId, type, userId,
                 color="gr", title="CONFIG LIST")

    if msg_obj:
        key = f"cfg_{userId}"
        msg_id, cli_msg_id = _extract_ids(msg_obj)
        _cfg_sessions[userId] = {
            "bots":     bots,
            "threadId": threadId,
            "time":     time.time(),
            "msgId":    msg_id,
            "cliMsgId": cli_msg_id,
            "key":      key,
        }
        _start_countdown(self, msg_obj, threadId, type, key)


# Background cleaner for expired config sessions
def _cfg_timeout_cleaner(interval=10):
    def _loop():
        while True:
            now = time.time()
            for uid in list(_cfg_sessions):
                if now - _cfg_sessions[uid]["time"] > _QR_TIMEOUT:
                    _cfg_sessions.pop(uid, None)
            time.sleep(interval)
    threading.Thread(target=_loop, daemon=True).start()

_cfg_timeout_cleaner()


# ══════════════════════════════════════════════════════════════════════════════
#  HELP
# ══════════════════════════════════════════════════════════════════════════════
def _handle_help(self, p, c, data, threadId, type, userId):
    is_dev = _is_dev(self, userId, threadId)

    user_cmds = (
        f"Commands:\n"
        f"\t┌─ ACCOUNT\n"
        f"\t│ {p}{c} account qrl\n"
        f"\t└ {p}{c} account add <prefix> [nickname]\n"
    )

    dev_cmds = (
        f"\t─\n"
        f"\t┌─ EMERGENCY\n"
        f"\t└ {p}{c} emergency gone\n"
        f"\t─\n"
        f"\t┌─ GLOBAL\n"
        f"\t└ {p}{c} global reset\n"
        f"\t─\n"
        f"\t┌─ CONFIG\n"
        f"\t└ {p}{c} config list [-sl=<số>]\n"
        f"\t─\n"
        f"\t┌─ BOT\n"
        f"\t│ {p}{c} bot status\n"
        f"\t│ {p}{c} bot check    <id>\n"
        f"\t│ {p}{c} bot start    <id>\n"
        f"\t│ {p}{c} bot stop     <id>\n"
        f"\t│ {p}{c} bot active   <id>\n"
        f"\t│ {p}{c} bot deactive <id>\n"
        f"\t└ {p}{c} bot restart  <id>\n"
        f"\t─\n"
        f"\t┌─ CURRENT\n"
        f"\t│ {p}{c} current check\n"
        f"\t│ {p}{c} current start\n"
        f"\t│ {p}{c} current stop\n"
        f"\t│ {p}{c} current deactive\n"
        f"\t│ {p}{c} current restart\n"
        f"\t└ {p}{c} current replace <imei> <zpw_sek>\n"
        f"\t─\n"
        f"\t┌─ ACCOUNT (DEV)\n"
        f"\t└ {p}{c} account raw\n"
        f"\t─\n"
        f"\t┌─ MULTIBOT\n"
        f"\t└ {p}{c} execute <cmd>"
    )

    msg = user_cmds + (dev_cmds if is_dev else "")
    return _r(self, msg, data, threadId, type, userId, color="yl", title="MultiBot Manager")


# ══════════════════════════════════════════════════════════════════════════════
#  EMERGENCY / GLOBAL
# ══════════════════════════════════════════════════════════════════════════════
def _handle_emergency(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    if len(parts) < 3 or parts[2].lower() != "gone":
        return _r(self,
            f"Usage: {p}{c} emergency gone\n"
            f"WARNING: This will shut down ALL bots immediately.",
            data, threadId, type, userId, color="r", title="EMERGENCY")

    cfg = _load_login()
    for b in cfg.get("data", []):
        b["status"] = False
        client = _runtime_client(b)
        if client and hasattr(client, "stop_listening"):
            try:
                client.stop_listening()
            except Exception:
                pass
    _save_login(cfg)
    return _r(self, "All bots have been shut down.",
              data, threadId, type, userId, color="r", title="EMERGENCY")


def _handle_global(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    if len(parts) < 3 or parts[2].lower() != "reset":
        return _r(self,
            f"Usage: {p}{c} global reset\n"
            f"WARNING: Resets all bot states to OFF.",
            data, threadId, type, userId, color="yl", title="GLOBAL")

    cfg   = _load_login()
    count = len(cfg.get("data", []))
    for b in cfg.get("data", []):
        b["status"] = False
    _save_login(cfg)
    return _r(self,
        f"Reset complete. {count} bot(s) set to OFF.\n"
        f"Restart the process to apply.",
        data, threadId, type, userId, color="gr", title="GLOBAL RESET")


# ══════════════════════════════════════════════════════════════════════════════
#  BOT
# ══════════════════════════════════════════════════════════════════════════════
def _handle_bot(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    if len(parts) < 3:
        return _r(self,
            f"Missing argument.\nUsage: {p}{c} bot <status|check|start|stop|active|deactive|restart> [id]",
            data, threadId, type, userId, color="yl", title="BOT")

    action = parts[2].lower()
    cfg    = _load_login()
    bots   = cfg.get("data", [])

    if action == "status":
        if not bots:
            return _r(self, "No bots registered.", data, threadId, type, userId,
                      color="yl", title="BOT STATUS")
        lines   = [_bot_label(b) + f"\n   ID: {b.get('author_id','?')}" for b in bots]
        online  = sum(1 for b in bots if b.get("status"))
        offline = len(bots) - online
        return _r(self,
            f"Online: {online}  Offline: {offline}\n\n" + "\n\n".join(lines),
            data, threadId, type, userId, color="gr", title="BOT STATUS")

    if len(parts) < 4:
        return _r(self,
            f"Bot ID required.\nUsage: {p}{c} bot {action} <id>",
            data, threadId, type, userId, color="yl", title="BOT")

    bot_id = parts[3]
    bot    = _get_bot(cfg, bot_id)
    if not bot:
        return _r(self, f"Bot not found: {bot_id}",
                  data, threadId, type, userId, color="r", title="BOT")

    name   = bot.get("nickname") or bot.get("username") or bot.get("author_id", "?")
    client = _runtime_client(bot)

    if action == "check":
        live      = getattr(client, "listening", False) if client else False
        het_han   = bot.get("het_han") or "Unlimited"
        kich_hoat = bot.get("kich_hoat") or "Not activated"
        return _r(self,
            f"Name     : {name}\n"
            f"ID       : {bot.get('author_id','?')}\n"
            f"Prefix   : {bot.get('prefix','?')}\n"
            f"Config   : {'ON' if bot.get('status') else 'OFF'}\n"
            f"Runtime  : {'ALIVE' if live else 'DEAD'}\n"
            f"Activated: {kich_hoat}\n"
            f"Expires  : {het_han}\n"
            f"Main bot : {'yes' if bot.get('is_main_bot') else 'no'}",
            data, threadId, type, userId, color="gr", title="BOT CHECK")

    if action == "start":
        bot["status"] = True
        _save_login(cfg)
        if client and not getattr(client, "listening", False):
            threading.Thread(target=lambda: client.listen(thread=True), daemon=True).start()
            note = "listen() called."
        elif client:
            note = "Bot is already listening."
        else:
            note = "Runtime not loaded — restart process to apply."
        return _r(self, f"Bot {name} started.\n{note}",
                  data, threadId, type, userId, color="gr", title="BOT START")

    if action == "stop":
        bot["status"] = False
        _save_login(cfg)
        if client and hasattr(client, "stop_listening"):
            try: client.stop_listening()
            except Exception: pass
        return _r(self, f"Bot {name} stopped.",
                  data, threadId, type, userId, color="r", title="BOT STOP")

    if action == "active":
        bot["status"] = True
        _save_login(cfg)
        return _r(self, f"Bot {name} activated.",
                  data, threadId, type, userId, color="gr", title="BOT ACTIVE")

    if action == "deactive":
        bot["status"] = False
        _save_login(cfg)
        if client and hasattr(client, "stop_listening"):
            try: client.stop_listening()
            except Exception: pass
        return _r(self, f"Bot {name} deactivated.",
                  data, threadId, type, userId, color="r", title="BOT DEACTIVE")

    if action == "restart":
        from src.services.index import restart_single_bot
        bot["status"] = True
        _save_login(cfg)
        threading.Thread(target=lambda: restart_single_bot(bot), daemon=True).start()
        return _r(self, f"Restarting bot {name}...",
                  data, threadId, type, userId, color="yl", title="BOT RESTART")

    return _r(self, f"Unknown action: '{action}'.",
              data, threadId, type, userId, color="r", title="BOT")


# ══════════════════════════════════════════════════════════════════════════════
#  CURRENT
# ══════════════════════════════════════════════════════════════════════════════
def _handle_current(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    if len(parts) < 3:
        return _r(self,
            f"Missing argument.\nUsage: {p}{c} current <check|start|stop|deactive|restart|replace>",
            data, threadId, type, userId, color="yl", title="CURRENT")

    action = parts[2].lower()
    cfg    = _load_login()
    bot    = _get_bot(cfg, self.uid)

    if not bot:
        return _r(self, "Current bot not found in config.",
                  data, threadId, type, userId, color="r", title="CURRENT")

    name = bot.get("nickname") or bot.get("username") or self.bot or self.uid

    if action == "check":
        live      = getattr(self, "listening", False)
        het_han   = bot.get("het_han") or "Unlimited"
        kich_hoat = bot.get("kich_hoat") or "Not activated"
        return _r(self,
            f"Name     : {name}\n"
            f"ID       : {self.uid}\n"
            f"Prefix   : {self.prefix}\n"
            f"Config   : {'ON' if bot.get('status') else 'OFF'}\n"
            f"Runtime  : {'ALIVE' if live else 'DEAD'}\n"
            f"Activated: {kich_hoat}\n"
            f"Expires  : {het_han}\n"
            f"Main bot : {'yes' if bot.get('is_main_bot') else 'no'}",
            data, threadId, type, userId, color="gr", title="CURRENT CHECK")

    if action == "start":
        bot["status"] = True
        _save_login(cfg)
        if not getattr(self, "listening", False):
            threading.Thread(target=lambda: self.listen(thread=True), daemon=True).start()
        return _r(self, f"Bot {name} started.",
                  data, threadId, type, userId, color="gr", title="CURRENT START")

    if action == "stop":
        bot["status"] = False
        _save_login(cfg)
        if hasattr(self, "stop_listening"):
            threading.Thread(target=self.stop_listening, daemon=True).start()
        return _r(self, f"Bot {name} stopped.",
                  data, threadId, type, userId, color="r", title="CURRENT STOP")

    if action == "deactive":
        bot["status"] = False
        _save_login(cfg)
        if hasattr(self, "stop_listening"):
            threading.Thread(target=self.stop_listening, daemon=True).start()
        return _r(self, f"Bot {name} deactivated.",
                  data, threadId, type, userId, color="r", title="CURRENT DEACTIVE")

    if action == "restart":
        from src.services.init.admin import save_restart_thread
        save_restart_thread(threadId)
        bot["status"] = True
        _save_login(cfg)
        _r(self, f"Restarting bot {name}...",
           data, threadId, type, userId, color="yl", title="CURRENT RESTART")
        threading.Thread(
            target=lambda: subprocess.Popen([sys.executable, "main.py"]),
            daemon=True
        ).start()
        if hasattr(self, "stop_listening"):
            time.sleep(1.5)
            self.stop_listening()
        return

    if action == "replace":
        if len(parts) < 5:
            return _r(self,
                f"Usage: {p}{c} current replace <imei> <zpw_sek>",
                data, threadId, type, userId, color="yl", title="CURRENT REPLACE")
        bot["imei"]            = parts[3].strip()
        bot["session_cookies"] = {"zpw_sek": parts[4].strip()}
        bot["status"]          = True
        _save_login(cfg)
        return _r(self,
            f"IMEI and cookie updated for bot {name}.\n"
            f"Restart bot to apply new session.",
            data, threadId, type, userId, color="gr", title="CURRENT REPLACE")

    return _r(self, f"Unknown action: '{action}'.",
              data, threadId, type, userId, color="r", title="CURRENT")


# ══════════════════════════════════════════════════════════════════════════════
#  ACCOUNT
# ══════════════════════════════════════════════════════════════════════════════
def _gen_nickname() -> str:
    letters = random.choices(string.ascii_uppercase, k=2)
    digits  = random.choices(string.digits, k=2)
    return "".join(letters + digits)


def _handle_account(self, p, c, parts, data, threadId, type, userId):
    if len(parts) < 3:
        return _r(self, f"Usage: {p}{c} account <qrl|add>",
                  data, threadId, type, userId, color="yl", title="ACCOUNT")

    action = parts[2].lower()

    # ── raw (dev only) ────────────────────────────────────────────────────────
    if action == "raw":
        if not _is_dev(self, userId, threadId):
            return _deny_dev(self, data, threadId, type, userId)
        cfg = _load_login()
        bot = _get_bot(cfg, self.uid)
        if not bot:
            return _r(self, "Current bot data not found.",
                      data, threadId, type, userId, color="r", title="ACCOUNT RAW")
        imei    = bot.get("imei", "?")
        cookies = bot.get("session_cookies", {})
        zpw_sek = cookies.get("zpw_sek", "?") if isinstance(cookies, dict) else "?"
        name    = bot.get("nickname") or bot.get("username") or self.uid
        return _r(self,
            f"Bot    : {name}\n"
            f"IMEI   :\n{imei}\n\n"
            f"zpw_sek:\n{zpw_sek}",
            data, threadId, type, userId, color="yl", title="ACCOUNT RAW")

    # ── qrl ───────────────────────────────────────────────────────────────────
    if action == "qrl":
        try:
            from app.module.apiQr import (
                init_session, verify_client, generate_qr_code,
                waiting_scan, waiting_confirm,
            )
        except ImportError:
            return _r(self, "Module apiQr not found.",
                      data, threadId, type, userId, color="r", title="ACCOUNT QRL")

        _r(self, "Đang tạo mã QR, vui lòng chờ...",
           data, threadId, type, userId, color="yl", title="ACCOUNT QRL")

        def _qr_flow():
            qr_msg_obj    = None
            countdown_key = f"qrl_{userId}"
            try:
                sessions = init_session()
                sessions = verify_client(sessions)

                result = generate_qr_code(sessions)
                if not result or not result[0]:
                    _r(self, "Tạo mã QR thất bại.",
                       data, threadId, type, userId, color="r", title="ACCOUNT QRL")
                    return
                code, sessions = result

                if os.path.exists(_QR_PATH):
                    try:
                        image_res = self._uploadImage(_QR_PATH, threadId, type)
                        image_url = None
                        if isinstance(image_res, dict):
                            image_url = image_res.get("normalUrl") or image_res.get("hdUrl")
                        elif isinstance(image_res, str) and image_res.startswith("http"):
                            image_url = image_res

                        if image_url:
                            name_str     = self.userName(userId) or str(userId)
                            mention_text = f"@{name_str}"
                            caption = (
                                f"[QR] {mention_text} Quét mã này từ thiết bị khác. "
                                f"Hết hạn sau {_QR_TIMEOUT}s."
                            )
                            qr_msg_obj = self.sendRemoteImage(
                                image_url, threadId, type,
                                width=2560, height=2560, ttl=0,
                                message=Message(
                                    text=caption,
                                    mention=Mention(userId, length=len(mention_text), offset=5)
                                )
                            )
                            if qr_msg_obj:
                                _start_countdown(self, qr_msg_obj, threadId, type, countdown_key)
                        else:
                            _r(self, "Upload QR thành công nhưng không lấy được URL.",
                               data, threadId, type, userId, color="yl", title="ACCOUNT QRL")
                    except Exception as e:
                        _r(self, f"Gửi ảnh QR thất bại: {e}",
                           data, threadId, type, userId, color="yl", title="ACCOUNT QRL")
                else:
                    _r(self, "File QR không tồn tại trên disk.",
                       data, threadId, type, userId, color="yl", title="ACCOUNT QRL")

                if not waiting_scan(code, sessions, max_wait=_QR_TIMEOUT):
                    _stop_countdown(self, countdown_key)
                    if qr_msg_obj:
                        try:
                            _qid, _cid = _extract_ids(qr_msg_obj)
                            self.deleteMessage(_qid, self.uid, _cid, threadId)
                        except Exception:
                            pass
                    _r(self, "Mã QR đã hết hạn. Không phát hiện lượt quét.",
                       data, threadId, type, userId, color="r", title="ACCOUNT QRL")
                    return

                _stop_countdown(self, countdown_key)
                if qr_msg_obj:
                    try:
                        _qid, _cid = _extract_ids(qr_msg_obj)
                        self.deleteMessage(_qid, self.uid, _cid, threadId)
                    except Exception:
                        pass

                result = waiting_confirm(code, sessions, max_wait=60)
                if not result:
                    _r(self, "Xác nhận thất bại hoặc hết giờ.",
                       data, threadId, type, userId, color="r", title="ACCOUNT QRL")
                    return

                uid_new  = result.get("uid") or "?"
                name_new = result.get("name") or uid_new

                if not hasattr(self, "_qr_pending"):
                    self._qr_pending = {}
                self._qr_pending[userId] = result

                _r(self,
                    f"Quét QR thành công!\n"
                    f"Tài khoản : {name_new}\n"
                    f"UID       : {uid_new}\n\n"
                    f"Để đăng ký bot, chạy:\n"
                    f"  {p}{c} account add <prefix> [nickname]",
                    data, threadId, type, userId, color="gr", title="ACCOUNT QRL")

            except Exception as e:
                _stop_countdown(self, countdown_key)
                _r(self, f"Lỗi luồng QR: {e}",
                   data, threadId, type, userId, color="r", title="ACCOUNT QRL")

        threading.Thread(target=_qr_flow, daemon=True).start()
        return

    # ── add ───────────────────────────────────────────────────────────────────
    if action == "add":
        prefix   = parts[3].strip() if len(parts) >= 4 else "!"
        nickname = parts[4].strip() if len(parts) >= 5 else None

        pending = getattr(self, "_qr_pending", {}).get(userId)
        if not pending:
            return _r(self,
                f"Không có phiên QR nào đang chờ.\n"
                f"Chạy '{p}{c} account qrl' trước.",
                data, threadId, type, userId, color="yl", title="ACCOUNT ADD")

        imei    = pending.get("imei")
        zpw_sek = pending.get("cookie", {}).get("zpw_sek")
        uid     = pending.get("uid")
        name    = pending.get("name") or uid

        if not imei or not zpw_sek or not uid:
            return _r(self, "Dữ liệu phiên không đầy đủ. Thử lại với account qrl.",
                      data, threadId, type, userId, color="r", title="ACCOUNT ADD")

        auto_nickname = False
        if not nickname:
            nickname      = _gen_nickname()
            auto_nickname = True

        cfg  = _load_login()
        bots = cfg.get("data", [])

        existing = _get_bot(cfg, uid)
        if existing:
            existing["imei"]            = imei
            existing["session_cookies"] = {"zpw_sek": zpw_sek}
            existing["status"]          = False
            existing["username"]        = name
            existing["nickname"]        = nickname
            _save_login(cfg)
            if hasattr(self, "_qr_pending"):
                self._qr_pending.pop(userId, None)
            note = f"\n(Biệt danh tự động: {nickname})" if auto_nickname else ""
            return _r(self,
                f"Cập nhật phiên cho bot đã tồn tại.\n"
                f"Biệt danh : {nickname}\n"
                f"UID       : {uid}{note}\n\n"
                f"Chờ developer duyệt để kích hoạt.",
                data, threadId, type, userId, color="gr", title="ACCOUNT ADD")

        new_bot = {
            "author_id":       uid,
            "username":        name,
            "nickname":        nickname,
            "prefix":          prefix,
            "imei":            imei,
            "session_cookies": {"zpw_sek": zpw_sek},
            "status":          False,
            "is_main_bot":     False,
            "het_han":         None,
            "kich_hoat":       None,
        }
        bots.append(new_bot)
        cfg["data"] = bots
        _save_login(cfg)
        if hasattr(self, "_qr_pending"):
            self._qr_pending.pop(userId, None)

        note = f"\n(Biệt danh tự động: {nickname} — bạn có thể đổi sau)" if auto_nickname else ""
        return _r(self,
            f"Đăng ký bot mới thành công!\n"
            f"Biệt danh : {nickname}\n"
            f"UID       : {uid}\n"
            f"Prefix    : {prefix}{note}\n\n"
            f"Chờ developer duyệt và kích hoạt bot.",
            data, threadId, type, userId, color="gr", title="ACCOUNT ADD")

    return _r(self, f"Không nhận ra action: '{action}'. Dùng: qrl | add",
              data, threadId, type, userId, color="r", title="ACCOUNT")


# ══════════════════════════════════════════════════════════════════════════════
#  EXECUTE
# ══════════════════════════════════════════════════════════════════════════════
def _handle_execute(self, p, c, parts, data, threadId, type, userId):
    if not _is_dev(self, userId, threadId):
        return _deny_dev(self, data, threadId, type, userId)

    if len(parts) < 3:
        return _r(self,
            f"Usage: {p}{c} execute <cmd>\n"
            f"Example: {p}{c} execute menu all",
            data, threadId, type, userId, color="yl", title="EXECUTE")

    cmd_text = " ".join(parts[2:])
    try:
        from app.login.client import clientlist, mainclient
        targets = {}
        if mainclient:
            targets[str(getattr(mainclient, "uid", "main"))] = mainclient
        for aid, cl in clientlist.items():
            targets[aid] = cl

        if not targets:
            return _r(self, "No bots available in runtime.",
                      data, threadId, type, userId, color="r", title="EXECUTE")

        sent = []
        for aid, cl in targets.items():
            try:
                prefix    = getattr(cl, "prefix", "") or ""
                full      = f"{prefix}{cmd_text}" if not cmd_text.startswith(prefix) else cmd_text
                fake_data = dict(data) if isinstance(data, dict) else {"content": full, "mentions": []}
                if isinstance(fake_data, dict):
                    fake_data["content"] = full
                cl.LoadCommands(Message(text=full), fake_data, userId, threadId, type)
                sent.append(getattr(cl, "bot", aid))
            except Exception as ex:
                logger.warning(f"[multibot execute] bot {aid}: {ex}")

        return _r(self,
            f"Command '{cmd_text}' dispatched to {len(sent)} bot(s):\n"
            + "\n".join(f"  - {n}" for n in sent),
            data, threadId, type, userId, color="gr", title="EXECUTE")

    except ImportError:
        return _r(self, "Could not load runtime clientlist.",
                  data, threadId, type, userId, color="r", title="EXECUTE")


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN ROUTER
# ══════════════════════════════════════════════════════════════════════════════
def MultibotCommand(this, message, data, userId, threadId, type):
    try:
        p    = this.prefix
        c    = this.rawCommand
        text = (message.text or "").strip()

        if p and text.startswith(p):
            text = text[len(p):].strip()

        parts = text.split()
        if not parts or parts[0].lower() != c:
            return

        if len(parts) == 1:
            return _handle_help(this, p, c, data, threadId, type, userId)

        sub = parts[1].lower()

        if sub == "emergency": return _handle_emergency(this, p, c, parts, data, threadId, type, userId)
        if sub == "global":    return _handle_global   (this, p, c, parts, data, threadId, type, userId)
        if sub == "config":    return _handle_config   (this, p, c, parts, data, threadId, type, userId)
        if sub == "bot":       return _handle_bot      (this, p, c, parts, data, threadId, type, userId)
        if sub == "current":   return _handle_current  (this, p, c, parts, data, threadId, type, userId)
        if sub == "account":   return _handle_account  (this, p, c, parts, data, threadId, type, userId)
        if sub == "execute":   return _handle_execute  (this, p, c, parts, data, threadId, type, userId)

        return _handle_help(this, p, c, data, threadId, type, userId)

    except Exception as e:
        import traceback
        logger.error(f"[multibotCore] {e}\n{traceback.format_exc()}")
        this.replyMessageStyle(f"Internal error: {e}", data, threadId, type,
                               color="r", title="ERROR", userId=userId)


# ── Reply interceptor (wire vào onReply dispatcher) ───────────────────────────
def MultibotReply(this, message, data, userId, threadId, type):
    try:
        return _handle_config_reply(this, message, data, userId, threadId, type)
    except Exception as e:
        logger.error(f"[multibotCore reply] {e}")
        return False


dependencies = {
    "name":        "multibot",
    "permission":  0,
    "cooldown":    2,
    "description": "Tạo bot hoặc quản lý bot.",
    "main":        MultibotCommand,
    "onReply":     MultibotReply,
}
