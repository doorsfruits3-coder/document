from api.app.event import GroupEventType
from api.util.msg import Message, Mention
from api.util.Enum import ThreadType
from src.services.utils.jsonio import read_settings, write_settings
from src.services.pillow.eventCard import draw_event_card
from src.command.antimanager.antiadd import handle_antiadd_event, is_antiadd_active
from src.command.chat_bot.approveMembers import handle_join_request_event
from PIL import Image
import os

SETTING_LABELS = {
    "blockName":        ("bật",   "tắt",  "chặn đổi tên nhóm"),
    "signAdminMsg":     ("bật",   "tắt",  "đánh dấu tin nhắn admin"),
    "addMemberOnly":    ("bật",   "tắt",  "chế độ chỉ admin được thêm thành viên"),
    "setTopicOnly":     ("bật",   "tắt",  "chế độ chỉ admin được đổi chủ đề"),
    "enableMsgHistory": ("bật",   "tắt",  "lịch sử trò chuyện"),
    "joinAppr":         ("bật",   "tắt",  "duyệt thành viên"),
    "lockCreatePost":   ("khóa",  "mở",   "đăng bài"),
    "lockCreatePoll":   ("chặn",  "mở",   "tạo bình chọn"),
    "lockSendMsg":      ("khóa",  "mở",   "trò chuyện"),
    "lockViewMember":   ("ẩn",    "mở",   "danh sách thành viên"),
}


def _cfg(uid, threadId: str) -> dict:
    s = read_settings(uid)
    return s.get("eventConfig", {}).get(threadId, {})


def _get_setting_store(uid):
    s     = read_settings(uid)
    store = s.get("groupSettingState", {})
    return s, (store if isinstance(store, dict) else {})


def _save_setting_store(uid, s: dict, store: dict):
    s["groupSettingState"] = store
    write_settings(uid, s)


def _find_changed(old: dict, new: dict):
    for key in SETTING_LABELS:
        if int(old.get(key, 0) or 0) != int(new.get(key, 0) or 0):
            return key, int(new.get(key, 0) or 0)
    return None, None


def _member_info(members: list) -> tuple:
    if not members:
        return "", "", ""
    m = members[0]
    if not isinstance(m, dict):
        m = getattr(m, "__dict__", {})
    return (
        str(m.get("id",     "") or ""),
        str(m.get("dName",  "") or ""),
        str(m.get("avatar", "") or ""),
    )


def _get_group_member_count(self, groupId: str) -> int:
    try:
        info  = self.fetchGroupInfo(str(groupId))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g     = gdata.get(str(groupId)) or {}
        return int(g.get("totalMember") or g.get("memberCount") or 0)
    except Exception:
        return 0


def _send_card(self, groupId: str, data: dict, mode: str):
    path = f"data/assets/cache/image/event_{groupId}_{mode}.jpg"
    try:
        draw_event_card(data, path, mode=mode)

        upload   = self._uploadImage(path, groupId, ThreadType.GROUP)
        image_hd = upload.get("hdUrl") or upload.get("normalUrl")
        if not image_hd:
            return

        with Image.open(path) as img:
            w, h = img.size

        self.sendRemoteImage(
            image_url=image_hd,
            threadId=groupId,
            type=ThreadType.GROUP,
            width=w,
            height=h,
            message=None,
            ttl=86000000,
        )
    except Exception as e:
        print(f"[zaloEvent._send_card] mode={mode} error: {e}")
    finally:
        try:
            os.remove(path)
        except Exception:
            pass


def _notify_text(self, groupId: str, text: str, mention_uid: str = ""):
    mention = None
    if mention_uid:
        n       = self.userName(mention_uid) or mention_uid
        mention = Mention(mention_uid, offset=0, length=len(n))
    self.send(Message(text=text, mention=mention), groupId, ThreadType.GROUP)


def _collect_member_ids(members: list) -> list[str]:
    ids = []
    for m in members:
        if not isinstance(m, dict):
            m = getattr(m, "__dict__", {})
        mid = str(m.get("id", "") or "")
        if mid:
            ids.append(mid)
    return ids


def ZaloEventHandle(self, eventData, eventType):
    groupId   = str(getattr(eventData, "groupId",   "") or "")
    groupName = str(getattr(eventData, "groupName", "") or "")
    sourceId  = str(getattr(eventData, "sourceId",  "") or "")
    members   = getattr(eventData, "updateMembers", []) or []
    setting   = getattr(eventData, "groupSetting",  {}) or {}
    if not isinstance(setting, dict):
        setting = {}

    if not groupId:
        return

    # ── AntiAdd: bot vừa được add vào nhóm / cộng đồng ────────────────
    if eventType == GroupEventType.JOIN:
        joined_ids = _collect_member_ids(members)
        if str(self.uid) in joined_ids and is_antiadd_active(self.uid):
            handle_antiadd_event(self, groupId)
            return

    # ── JOIN_REQUEST: xử lý auto approve/reject TRƯỚC gate cfg ───────────
    # eventConfig có thể không có cho nhóm này nhưng approve vẫn phải chạy
    if eventType == GroupEventType.JOIN_REQUEST:
        handle_join_request_event(self, groupId)
        _cfg_tmp = _cfg(self.uid, groupId)
        if _cfg_tmp.get("joinRequestOn"):
            _notify_text(self, groupId, f"Có yêu cầu tham gia nhóm {groupName} đang chờ duyệt.")
        return

    cfg = _cfg(self.uid, groupId)
    if not cfg:
        return

    uid, name, avatar = _member_info(members)
    actorName = self.userName(sourceId) if sourceId else ""

    if eventType == GroupEventType.JOIN and cfg.get("welcomeOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="welcome")

    elif eventType == GroupEventType.LEAVE and cfg.get("leaveOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="leave")

    elif eventType == GroupEventType.BLOCK_MEMBER and cfg.get("kickOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="kick_block")

    elif eventType == GroupEventType.REMOVE_MEMBER and cfg.get("kickOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="kick")

    elif eventType == GroupEventType.ADD_ADMIN and cfg.get("adminOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="add_admin")

    elif eventType == GroupEventType.REMOVE_ADMIN and cfg.get("adminOn"):
        count = _get_group_member_count(self, groupId)
        _send_card(self, groupId, {
            "name":         name,
            "avatar_url":   avatar,
            "member_count": count,
        }, mode="remove_admin")

    elif eventType == GroupEventType.UPDATE and cfg.get("updateOn"):
        newName = str(getattr(eventData, "groupName", "") or "")
        newAvt  = str(getattr(eventData, "avt", "") or "")
        if newName:
            _notify_text(self, groupId, f"{actorName} vừa đổi tên nhóm thành: {newName}")
        elif newAvt:
            _notify_text(self, groupId, f"{actorName} vừa đổi ảnh đại diện nhóm")
        else:
            _notify_text(self, groupId, f"{actorName} vừa cập nhật thông tin nhóm")

    elif eventType == GroupEventType.NEW_LINK and cfg.get("newLinkOn"):
        newLink = str(getattr(eventData, "link", "") or "")
        if newLink:
            _notify_text(self, groupId, f"{actorName} vừa tạo link mời mới: {newLink}")
        else:
            _notify_text(self, groupId, f"{actorName} vừa tạo link mới cho nhóm")

    elif eventType == GroupEventType.UPDATE_SETTING and cfg.get("settingOn"):
        if not setting:
            return

        s, store   = _get_setting_store(self.uid)
        oldSetting = store.get(groupId, {})
        oldSetting = oldSetting if isinstance(oldSetting, dict) else {}

        if not oldSetting:
            store[groupId] = dict(setting)
            _save_setting_store(self.uid, s, store)
            return

        changedKey, changedValue = _find_changed(oldSetting, setting)
        store[groupId] = dict(setting)
        _save_setting_store(self.uid, s, store)

        if not changedKey:
            return

        onText, offText, label = SETTING_LABELS[changedKey]
        action = onText if changedValue else offText
        _notify_text(self, groupId, f"{actorName} vừa {action} {label} ở {groupName}")
