"""
soundcloudListCard.py  –  danh sách tìm kiếm cho SoundCloud
Style: giống zingListCard (featured + grid 2 cột) nhưng palette cam/đen SoundCloud
Output: JPEG 2560×1440
"""
import os, threading
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 2560, 1440
PAD  = 60


def _resolve_font():
    try:
        base = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static" / "Opensans"
        bold = base / "OpenSans-Bold.ttf"
        reg  = base / "OpenSans-Regular.ttf"
        if bold.exists() and reg.exists():
            return str(bold), str(reg)
    except Exception:
        pass
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )


FONT_BOLD, FONT_REG = _resolve_font()

# ── SoundCloud palette ──────────────────────────────────────────────────────
GRAD_TL = ( 15,  15,  15)
GRAD_TR = ( 22,  14,   8)
GRAD_BL = ( 20,  16,  10)
GRAD_BR = ( 30,  15,   5)

SC_ORANGE      = (255,  85,   0)
SC_ORANGE_DIM  = (200,  65,   0)

C_FEAT_TITLE  = (255, 255, 255)
C_FEAT_ARTIST = SC_ORANGE           # artist nổi bật màu cam
C_FEAT_DUR    = (180, 180, 180)
C_NUM_FEAT    = SC_ORANGE
C_TITLE       = (235, 235, 235)
C_ARTIST      = (255, 120,  40)     # cam nhạt cho grid
C_DURATION    = (160, 160, 160)
C_CARD_BG     = (255, 255, 255, 15)
C_CARD_BORDER = (255,  85,   0,  50)  # viền cam mờ

ARTIST_LIFT = 18

_mask_cache: dict = {}


def _font(size, bold=False):
    path = FONT_BOLD if bold else FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _make_bg():
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), GRAD_TL)
    c.putpixel((1, 0), GRAD_TR)
    c.putpixel((0, 1), GRAD_BL)
    c.putpixel((1, 1), GRAD_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _rounded_mask(w, h, r, aa=4):
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w * aa, h * aa
        mr = int(min(r, w // 2, h // 2) * aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]


def _solid_card(canvas, box, radius=22):
    x1, y1, x2, y2 = box
    bw, bh = x2 - x1, y2 - y1
    layer = Image.new("RGBA", (bw, bh), (0, 0, 0, 0))
    mask  = _rounded_mask(bw, bh, radius)
    fill  = Image.new("RGBA", (bw, bh), C_CARD_BG)
    layer.paste(fill, (0, 0), mask)
    ImageDraw.Draw(layer).rounded_rectangle(
        (0, 0, bw - 1, bh - 1), radius, outline=C_CARD_BORDER, width=2
    )
    canvas.alpha_composite(layer, (x1, y1))


def _glass_card_feat(canvas, box, radius=36, alpha=25, blur=20):
    x1, y1, x2, y2 = box
    bw, bh = x2 - x1, y2 - y1
    # shadow
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle(
        (x1+6, y1+6, x2+6, y2+6), radius, fill=(0, 0, 0, 50)
    )
    canvas.alpha_composite(sh.filter(ImageFilter.GaussianBlur(12)))
    # glass
    region  = canvas.crop(box)
    blurred = region.filter(ImageFilter.GaussianBlur(blur))
    overlay = Image.new("RGBA", (bw, bh), (255, 255, 255, alpha))
    merged  = Image.alpha_composite(blurred, overlay)
    mask    = _rounded_mask(bw, bh, radius)
    canvas.paste(merged, (x1, y1), mask)
    # border cam mờ
    bd = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(bd).rounded_rectangle(box, radius, outline=(*SC_ORANGE, 80), width=2)
    canvas.alpha_composite(bd)


def _load_cover(url, size):
    blank = Image.new("RGBA", size, (25, 15, 5, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=8)
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        s   = min(w0, h0)
        img = img.crop(((w0-s)//2, (h0-s)//2, (w0+s)//2, (h0+s)//2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank


def _fit(draw, text, fnt, max_w):
    text = str(text or "")
    if draw.textlength(text, font=fnt) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=fnt)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=fnt) > room:
            break
        out += ch
    return out + ell


def _fmt_dur(t) -> str:
    if isinstance(t, str):
        return t
    t = int(t or 0)
    m, s = divmod(t, 60)
    return f"{m}:{s:02d}"


def _draw_small_card(canvas, songs, idx, cx1, cy1, cx2, cy2,
                     covers, THUMB, f_title, f_artist, f_dur, ip=24):
    ROW_H = cy2 - cy1
    _solid_card(canvas, (cx1, cy1, cx2, cy2), radius=22)

    th_y = cy1 + (ROW_H - THUMB) // 2
    canvas.paste(covers[idx], (cx1 + ip, th_y), _rounded_mask(THUMB, THUMB, 14))

    d  = ImageDraw.Draw(canvas)
    tx = cx1 + ip + THUMB + ip
    mx = cx2 - ip
    mw = mx - tx

    s   = songs[idx]
    num = idx + 1

    ty_title  = th_y
    ty_artist = th_y + THUMB - f_artist.size - ARTIST_LIFT

    title_str  = _fit(d, f"{num}. {s.get('title','?')}", f_title, mw)
    artist_str = _fit(d, s.get("artist", "?"), f_artist, int(mw * 0.65))
    dur_str    = str(s.get("duration_str") or _fmt_dur(s.get("duration", 0)))

    d.text((tx, ty_title),  title_str,  font=f_title,  fill=C_TITLE)
    d.text((tx, ty_artist), artist_str, font=f_artist, fill=C_ARTIST)
    dur_w = int(d.textlength(dur_str, font=f_dur))
    d.text((mx - dur_w, ty_artist), dur_str, font=f_dur, fill=C_DURATION)


def draw_soundcloud_list(songs, out_path, keyword=""):
    """
    Vẽ danh sách kết quả SoundCloud.

    songs: list dict với keys: title, artist, duration, cover (URL)
    """
    songs = songs[:10]
    n     = len(songs)

    FEAT_CARD_W = int(W * 0.265)
    FEAT_COVER  = FEAT_CARD_W - PAD * 2
    THUMB       = 130
    GRID_X      = PAD + FEAT_CARD_W + PAD
    GRID_W      = W - GRID_X - PAD
    COL_GAP     = PAD
    COL_W       = (GRID_W - COL_GAP) // 2
    ROWS        = 5
    CARD_GAP    = 22
    ROW_H       = (H - PAD * 2 - CARD_GAP * (ROWS - 1)) // ROWS
    ROW_GAP     = CARD_GAP

    # ── tải ảnh bìa song song ───────────────────────────────────────────────
    covers = [None] * n

    def _fetch(i, url, sz):
        covers[i] = _load_cover(url, sz)

    threads = []
    for i, s in enumerate(songs):
        sz = (FEAT_COVER, FEAT_COVER) if i == 0 else (THUMB, THUMB)
        # SoundCloud dùng key "thumb" thay "cover"
        url = s.get("cover") or s.get("thumb") or s.get("thumb2") or ""
        t   = threading.Thread(target=_fetch, args=(i, url, sz), daemon=True)
        threads.append(t); t.start()
    for t in threads:
        t.join(timeout=10)

    canvas = _make_bg()

    # ── Featured card trái ──────────────────────────────────────────────────
    fx1, fy1 = PAD, PAD
    fx2, fy2 = PAD + FEAT_CARD_W, H - PAD
    _glass_card_feat(canvas, (fx1, fy1, fx2, fy2), radius=36, alpha=25, blur=20)

    cov_x = fx1 + PAD
    cov_y = fy1 + PAD
    canvas.paste(covers[0], (cov_x, cov_y), _rounded_mask(FEAT_COVER, FEAT_COVER, 24))

    d = ImageDraw.Draw(canvas)

    # Featured text
    f_feat_num    = _font(int(H * 0.032), bold=True)
    f_feat_title  = _font(int(H * 0.050), bold=True)
    f_feat_artist = _font(int(H * 0.031), bold=False)
    f_feat_dur    = _font(int(H * 0.028), bold=False)

    mw_feat       = FEAT_CARD_W - PAD * 2
    feat_text_top = cov_y + FEAT_COVER + int(PAD * 0.7)
    feat_text_bot = fy2 - PAD

    d.text((cov_x, feat_text_top), "1.", font=f_feat_num, fill=C_NUM_FEAT)
    ty = feat_text_top + int(H * 0.032) + 12
    d.text((cov_x, ty),
           _fit(d, songs[0].get("title", "?"), f_feat_title, mw_feat),
           font=f_feat_title, fill=C_FEAT_TITLE)

    ty_a0   = feat_text_bot - int(H * 0.031) - ARTIST_LIFT
    artist0 = _fit(d, songs[0].get("artist", "?"), f_feat_artist, int(mw_feat * 0.65))
    dur0    = _fmt_dur(songs[0].get("duration", 0))
    d.text((cov_x, ty_a0), artist0, font=f_feat_artist, fill=C_FEAT_ARTIST)
    dur0_w  = int(d.textlength(dur0, font=f_feat_dur))
    d.text((fx2 - PAD - dur0_w, ty_a0), dur0, font=f_feat_dur, fill=C_FEAT_DUR)

    # Keyword header (nếu có)
    if keyword:
        f_kw = _font(int(H * 0.026), bold=False)
        kw_text = f'🔍  "{keyword}"'
        kw_x    = GRID_X
        kw_y    = PAD - int(H * 0.026) - 8
        if kw_y > 0:
            d.text((kw_x, kw_y), kw_text, font=f_kw, fill=(160, 160, 160))

    # ── Grid cards phải ─────────────────────────────────────────────────────
    f_title  = _font(int(ROW_H * 0.20), bold=True)
    f_artist = _font(int(ROW_H * 0.15), bold=False)
    f_dur    = _font(int(ROW_H * 0.14), bold=False)

    for idx in range(1, n):
        col = (idx - 1) % 2
        row = (idx - 1) // 2
        cx1 = GRID_X + col * (COL_W + COL_GAP)
        cy1 = PAD + row * (ROW_H + ROW_GAP)
        cx2 = cx1 + COL_W
        cy2 = cy1 + ROW_H
        _draw_small_card(canvas, songs, idx,
                         cx1, cy1, cx2, cy2,
                         covers, THUMB, f_title, f_artist, f_dur)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=92, optimize=False)
    return out_path
