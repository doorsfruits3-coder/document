from PIL import Image, ImageDraw, ImageFont
from io import BytesIO
from pathlib import Path
import requests, os

W, H      = 1200, 420
_FONT_DIR = Path("assets/font")

AV_RATIO = 0.40
TX_PAD   = 20


def _font(rel: str, size: int) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(_FONT_DIR / rel), size)

def _hl_font():  return _font("delaone.ttf", 96)
def _nm_font():  return _font("Sarabun/Sarabun-Bold.ttf", 56)
def _sub_font(): return _font("Opensans/static/OpenSans_Condensed-Bold.ttf", 32)


def _measure(font: ImageFont.FreeTypeFont, text: str):
    bb = font.getbbox(text)
    return bb[2]-bb[0], bb[3]-bb[1], bb[0], bb[1]


def _gradient(w: int, h: int, left: tuple, right: tuple) -> Image.Image:
    img = Image.new("RGB", (w, h))
    d   = ImageDraw.Draw(img)
    for x in range(w):
        t   = x / w
        col = tuple(int(left[i]*(1-t) + right[i]*t) for i in range(3))
        d.line([(x, 0), (x, h)], fill=col)
    return img.convert("RGBA")


def _rounded_mask(w: int, h: int, radius: int, aa: int = 4) -> Image.Image:
    mw, mh = w*aa, h*aa
    m = Image.new("L", (mw, mh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, mw-1, mh-1), radius*aa, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def _paste_rounded(canvas: Image.Image, img: Image.Image, pos: tuple, radius: int):
    img  = img.convert("RGBA")
    mask = _rounded_mask(img.width, img.height, radius)
    out  = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, mask=mask)
    canvas.alpha_composite(out, pos)


def _load_avatar(url: str, size: int) -> Image.Image:
    if url:
        try:
            r   = requests.get(url.strip(), timeout=8,
                               headers={"User-Agent": "Mozilla/5.0"})
            img = Image.open(BytesIO(r.content)).convert("RGBA")
            return img.resize((size, size), Image.LANCZOS)
        except Exception:
            pass
    return Image.new("RGBA", (size, size), (70, 70, 90, 255))


_MODES = {
    "welcome":        {"left": (30,  15,  65), "right": (10,  80,  65), "headline": "welcome"},
    "leave":          {"left": (60,  15,  80), "right": (10,  55,  90), "headline": "goodbye"},
    "kick":           {"left": (80,  18,  18), "right": (40,  10,  60), "headline": "kicked"},
    "kick_block":     {"left": (90,  12,  12), "right": (55,   8,   8), "headline": "blocked"},
    "add_admin":      {"left": (10,  45, 100), "right": (10,  80,  55), "headline": "promoted"},
    "remove_admin":   {"left": (65,  38,   8), "right": (80,  18,  42), "headline": "demoted"},
    "update":         {"left": (15,  55,  90), "right": (40,  20,  80), "headline": "updated"},
    "update_setting": {"left": (20,  20,  70), "right": (60,  40,  10), "headline": "settings"},
    "join_request":   {"left": (10,  60,  80), "right": (30,  90,  50), "headline": "requested"},
    "new_link":       {"left": (10,  50,  90), "right": (50,  10,  80), "headline": "new link"},
}


def draw_event_card(data: dict, out_path: str, mode: str = "leave") -> str:
    cfg = _MODES.get(mode, _MODES["leave"])

    canvas = _gradient(W, H, cfg["left"], cfg["right"])
    d      = ImageDraw.Draw(canvas)

    av_zone_w = int(W * AV_RATIO)
    av_size   = int(H * 0.75)
    border    = 5
    bw, bh    = av_size + border*2, av_size + border*2
    bx        = (av_zone_w - bw) // 2
    by        = (H - bh) // 2

    av = _load_avatar(data.get("avatar_url", ""), av_size)
    _paste_rounded(canvas, Image.new("RGBA", (bw, bh), (255, 255, 255, 70)), (bx, by), 32)
    _paste_rounded(canvas, av, (bx + border, by + border), 28)

    tx_start = av_zone_w + TX_PAD
    tx_end   = W - 40
    tc_x     = (tx_start + tx_end) // 2 - 30

    hl_font  = _hl_font()
    nm_font  = _nm_font()
    sub_font = _sub_font()

    hl_text  = cfg["headline"]
    nm_text  = data.get("name", "")
    sub_text = data.get("sub", "")

    if not sub_text:
        count = data.get("member_count", 0)
        sub_text = f"#{count} mem" if count else ""

    hl_w,  hl_h,  hl_lo,  hl_to  = _measure(hl_font,  hl_text)
    nm_w,  nm_h,  nm_lo,  nm_to  = _measure(nm_font,  nm_text)
    sub_w, sub_h, sub_lo, sub_to = _measure(sub_font, sub_text) if sub_text else (0, 0, 0, 0)

    gap     = 12
    total_h = (sub_h + gap if sub_text else 0) + hl_h + gap + nm_h
    start_y = (H - total_h) // 2

    def _shadow_text(draw, xy, text, font, fill, shadow=(0, 0, 0, 160), offset=3):
        draw.text((xy[0]+offset, xy[1]+offset), text, font=font, fill=shadow)
        draw.text(xy, text, font=font, fill=fill)

    cur_y = start_y

    if sub_text:
        sub_x = tc_x - sub_w // 2
        _shadow_text(d, (sub_x - sub_lo, cur_y - sub_to),
                     sub_text, sub_font, (220, 220, 255, 230))
        cur_y += sub_h + gap

    hl_x = tc_x - hl_w // 2
    _shadow_text(d, (hl_x - hl_lo, cur_y - hl_to),
                 hl_text, hl_font, (230, 235, 255))
    cur_y += hl_h + gap

    nm_x = tc_x - nm_w // 2
    _shadow_text(d, (nm_x - nm_lo, cur_y - nm_to),
                 nm_text, nm_font, (255, 255, 255))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=92)
    return out_path
