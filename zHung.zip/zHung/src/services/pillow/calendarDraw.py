import os, calendar, math
from datetime import date
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ── canvas ────────────────────────────────────────────────────────────────────
W, H = 1080, 1080

# ── palette ───────────────────────────────────────────────────────────────────
BG           = (235, 235, 240)
CARD_BG      = (255, 255, 255)
GRID_LINE    = (225, 225, 230)
SEP_LINE     = (205, 205, 212)
C_MONTH      = ( 17,  17,  17)
C_YEAR       = (150, 150, 158)
C_DOW        = (140, 140, 150)
C_NORMAL     = ( 17,  17,  17)
C_MUTED      = (205, 205, 212)
C_LUNAR      = (160, 160, 170)
C_TODAY_FILL = (255,  45,  85)
C_TODAY_TXT  = (255, 255, 255)
C_SUN        = (255,  55,  45)
C_SAT        = ( 48, 130, 246)
C_WEEKEND_BG = (252, 248, 248)    # tint đỏ rất nhạt cho cột CN
C_SAT_BG     = (248, 250, 255)    # tint xanh rất nhạt cho cột T7
C_HOLIDAY    = (255,  69,  58)    # màu ngày lễ = đỏ đậm hơn C_SUN

FONT_DIR = Path("assets/font")
_fc: dict = {}

VI_MONTHS_LONG = [
    "", "Tháng Một", "Tháng Hai", "Tháng Ba", "Tháng Tư",
    "Tháng Năm", "Tháng Sáu", "Tháng Bảy", "Tháng Tám",
    "Tháng Chín", "Tháng Mười", "Tháng Mười Một", "Tháng Mười Hai",
]
VI_DAYS = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]

# ngày lễ cố định VN (tháng, ngày)
VN_HOLIDAYS = {
    (1,  1): "Tết DL",
    (4, 30): "30/4",
    (5,  1): "1/5",
    (9,  2): "2/9",
}

# ── font ─────────────────────────────────────────────────────────────────────
def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (size, bold)
    if key in _fc:
        return _fc[key]
    paths = (
        [FONT_DIR / "Goldman/Goldman-Bold.ttf",
         FONT_DIR / "Opensans/static/Opensans/OpenSans-Bold.ttf"]
        if bold else
        [FONT_DIR / "Opensans/static/Opensans/OpenSans-Regular.ttf"]
    )
    for p in paths:
        if Path(p).exists():
            try:
                _fc[key] = ImageFont.truetype(str(p), size)
                return _fc[key]
            except Exception:
                pass
    _fc[key] = ImageFont.load_default()
    return _fc[key]

# ── draw helpers ──────────────────────────────────────────────────────────────
def _tw(d, t, f):      return int(d.textlength(t, font=f))
def _bb(f, t):
    b = f.getbbox(t);  return b[3] - b[1], b[1]

def _txt_center(d, t, f, cx, cy, fill):
    tw = _tw(d, t, f); h, top = _bb(f, t)
    d.text((cx - tw // 2, cy - h // 2 - top), t, font=f, fill=fill)

def _circle_aa(img, cx, cy, r, fill):
    s   = 4
    big = Image.new("RGBA", (r*2*s, r*2*s), (0,0,0,0))
    ImageDraw.Draw(big).ellipse((0, 0, r*2*s-1, r*2*s-1), fill=(*fill, 255))
    sm  = big.resize((r*2, r*2), Image.LANCZOS)
    img.paste(Image.new("RGB", (r*2, r*2), fill), (cx-r, cy-r), sm.split()[3])

# ── lunar — Jean Meeus ────────────────────────────────────────────────────────
def _jd(y, m, d):
    if m <= 2: y -= 1; m += 12
    A = y // 100; B = 2 - A + A // 4
    return int(365.25*(y+4716)) + int(30.6001*(m+1)) + d + B - 1524.5

_nm_cache: dict = {}
def _new_moon(k):
    if k in _nm_cache: return _nm_cache[k]
    T  = k / 1236.85; T2 = T*T; T3 = T2*T; T4 = T3*T
    JDE = (2451550.09766 + 29.530588861*k + 0.00015437*T2
           - 0.000000150*T3 + 0.00000000073*T4)
    M  = math.radians(2.5534  + 29.10535670*k - 0.0000014*T2)
    M1 = math.radians(201.5643 + 385.81693528*k + 0.0107582*T2)
    F  = math.radians(160.7108 + 390.67050284*k - 0.0016118*T2)
    O  = math.radians(124.7746 -  1.56375588*k + 0.0020672*T2)
    c  = (-0.40720*math.sin(M1) + 0.17241*math.sin(M)
          + 0.01608*math.sin(2*M1) + 0.01039*math.sin(2*F)
          + 0.00739*math.sin(M1-M) - 0.00514*math.sin(M1+M)
          + 0.00208*math.sin(2*M)  - 0.00111*math.sin(M1-2*F)
          - 0.00057*math.sin(M1+2*F) + 0.00056*math.sin(2*M1+M)
          - 0.00042*math.sin(3*M1) + 0.00042*math.sin(M+2*F)
          + 0.00038*math.sin(M-2*F) - 0.00024*math.sin(2*M1-M)
          - 0.00017*math.sin(O) - 0.00007*math.sin(M1+2*M))
    res = JDE + c + 7/24
    _nm_cache[k] = res
    return res

def _solar_to_lunar(y, m, d):
    jd = _jd(y, m, d) + 0.5
    k  = math.floor((jd - 2451550.1) / 29.530588861)
    nm = _new_moon(k)
    while nm > jd:      k -= 1; nm = _new_moon(k)
    while _new_moon(k+1) <= jd: k += 1; nm = _new_moon(k)
    l_day = int(jd - nm) + 1
    ws    = _jd(y if m >= 2 else y-1, 12, 22)
    k_ws  = math.floor((ws - 2451550.1) / 29.530588861)
    k11   = k_ws if _new_moon(k_ws) <= ws else k_ws - 1
    l_mon = (k - k11 + 11) % 12 + 1
    return max(1, min(l_day, 30)), l_mon

def _lunar_lbl(ld, lm):
    return f"1/{lm}" if ld == 1 else str(ld)

# ── shadow ────────────────────────────────────────────────────────────────────
def _card_shadow(img, x1, y1, x2, y2, r=28, blur=24):
    S = 4
    sw, sh_h = img.width // S, img.height // S
    small = Image.new("RGBA", (sw, sh_h), (0,0,0,0))
    ImageDraw.Draw(small).rounded_rectangle(
        ((x1+4)//S, (y1+10)//S, (x2-4)//S, (y2-2)//S),
        radius=max(1, r//S), fill=(0,0,0,50))
    small = small.filter(ImageFilter.GaussianBlur(blur//S))
    sh = small.resize(img.size, Image.BILINEAR)
    out = img.convert("RGBA"); out.alpha_composite(sh)
    return out.convert("RGB")

# ── main ─────────────────────────────────────────────────────────────────────
def draw_calendar(month: int, year: int, out_path: str,
                  events: list | None = None) -> str:
    today     = date.today()
    cal_weeks = calendar.monthcalendar(year, month)
    n_weeks   = len(cal_weeks)

    img = Image.new("RGB", (W, H), BG)
    cx1, cy1, cx2, cy2 = 26, 26, W-26, H-26
    img = _card_shadow(img, cx1, cy1, cx2, cy2)

    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle((cx1,cy1,cx2,cy2), radius=28, fill=255)
    img.paste(Image.new("RGB",(W,H),CARD_BG), mask=mask)
    d = ImageDraw.Draw(img, "RGBA")

    # ── layout ───────────────────────────────────────────────────────────────
    LEFT_PAD  = 48
    RIGHT_PAD = 36
    grid_x1   = cx1 + LEFT_PAD
    grid_x2   = cx2 - RIGHT_PAD
    grid_w    = grid_x2 - grid_x1
    col_w     = grid_w / 7

    HEADER_TOP = cy1 + 30
    HEADER_H   = 92
    DOW_H      = 42
    sep1_y     = HEADER_TOP + HEADER_H
    dow_y      = sep1_y + 8
    sep2_y     = dow_y + DOW_H + 6
    grid_y1    = sep2_y
    grid_y2    = cy2 - 18
    row_h      = (grid_y2 - grid_y1) / n_weeks

    # ── header ───────────────────────────────────────────────────────────────
    f_mo   = _font(62, bold=True)
    f_yr   = _font(38)
    f_pill = _font(22)

    mo_str = VI_MONTHS_LONG[month]
    yr_str = str(year)
    mh, mt = _bb(f_mo, mo_str)
    yh, yt = _bb(f_yr, yr_str)
    mo_w   = _tw(d, mo_str, f_mo)
    hcy    = HEADER_TOP + HEADER_H // 2

    d.text((grid_x1, hcy - mh//2 - mt), mo_str, font=f_mo, fill=C_MONTH)
    d.text((grid_x1 + mo_w + 12, hcy - yh//2 - yt + 10), yr_str,
           font=f_yr, fill=C_YEAR)

    if month == today.month and year == today.year:
        pl  = f"Hôm nay  {today.day}/{today.month}"
        plw = _tw(d, pl, f_pill) + 28
        plh = 34
        px1 = grid_x2 - plw
        py1 = hcy - plh // 2
        d.rounded_rectangle((px1, py1, px1+plw, py1+plh),
                             radius=17, fill=(255,45,85,20))
        ph, pt = _bb(f_pill, pl)
        d.text((px1+14, py1 + plh//2 - ph//2 - pt),
               pl, font=f_pill, fill=C_TODAY_FILL)

    d.line([(cx1, sep1_y),(cx2, sep1_y)], fill=SEP_LINE, width=1)

    # ── weekend column tint (rõ hơn) ─────────────────────────────────────────
    sat_x1 = int(grid_x1 + 5 * col_w)
    sat_x2 = int(grid_x1 + 6 * col_w)
    sun_x1 = int(grid_x1 + 6 * col_w)
    sun_x2 = int(grid_x2)
    d.rectangle((sat_x1, grid_y1, sat_x2, grid_y2), fill=C_SAT_BG)
    d.rectangle((sun_x1, grid_y1, sun_x2, grid_y2), fill=C_WEEKEND_BG)

    # ── DOW header ───────────────────────────────────────────────────────────
    f_dow = _font(24, bold=True)
    for i, lbl in enumerate(VI_DAYS):
        cx_d = int(grid_x1 + i * col_w + col_w / 2)
        cy_d = int(dow_y + DOW_H / 2)
        fill = C_SUN if lbl == "CN" else (C_SAT if lbl == "T7" else C_DOW)
        _txt_center(d, lbl, f_dow, cx_d, cy_d, fill)

    d.line([(cx1, sep2_y),(cx2, sep2_y)], fill=SEP_LINE, width=1)

    # ── grid lines ───────────────────────────────────────────────────────────
    for ri in range(1, n_weeks):
        ly = int(grid_y1 + ri * row_h)
        d.line([(cx1, ly),(cx2, ly)], fill=GRID_LINE, width=1)
    for ci in range(1, 7):
        lx = int(grid_x1 + ci * col_w)
        d.line([(lx, grid_y1),(lx, grid_y2)], fill=GRID_LINE, width=1)

    # ── build full grid (fill prev/next) ─────────────────────────────────────
    prev_m = month - 1 if month > 1 else 12
    prev_y = year  if month > 1 else year - 1
    days_prev = calendar.monthrange(prev_y, prev_m)[1]
    next_m = month + 1 if month < 12 else 1
    next_y = year  if month < 12 else year + 1

    full_grid = []
    first_col = next((ci for ci, v in enumerate(cal_weeks[0]) if v != 0), 0)
    p_ctr, n_ctr = days_prev - first_col + 1, 1
    for ri, week in enumerate(cal_weeks):
        row = []
        for ci, day in enumerate(week):
            if day == 0:
                if ri == 0: row.append(("prev", p_ctr)); p_ctr += 1
                else:       row.append(("next", n_ctr)); n_ctr += 1
            else:
                row.append(("cur", day))
        full_grid.append(row)

    # ── day cells ─────────────────────────────────────────────────────────────
    f_num     = _font(40, bold=True)
    f_num_sm  = _font(34, bold=True)
    f_num_mut = _font(34)
    f_lunar   = _font(18)
    f_hol     = _font(15, bold=True)
    today_r   = 30
    font_main = f_num if n_weeks <= 5 else f_num_sm

    for ri, row in enumerate(full_grid):
        for ci, (kind, day) in enumerate(row):
            cx1c = int(grid_x1 + ci * col_w)
            cy1c = int(grid_y1 + ri * row_h)
            cx2c = int(grid_x1 + (ci+1) * col_w)
            cy2c = int(grid_y1 + (ri+1) * row_h)
            cw   = cx2c - cx1c
            ch   = cy2c - cy1c

            # xác định ngày thật để lookup âm lịch + holiday
            if kind == "cur":
                ry, rm, rd = year, month, day
            elif kind == "prev":
                ry, rm, rd = prev_y, prev_m, day
            else:
                ry, rm, rd = next_y, next_m, day

            is_today   = (kind == "cur" and day == today.day
                          and month == today.month and year == today.year)
            is_muted   = kind != "cur"
            is_sun     = ci == 6
            is_sat     = ci == 5
            is_holiday = (kind == "cur" and (rm, rd) in VN_HOLIDAYS)

            txt   = str(day)
            font  = font_main if not is_muted else f_num_mut

            # vị trí số: top-center của ô
            NUM_TOP = int(row_h * 0.20)
            num_cx  = cx1c + cw // 2
            num_cy  = cy1c + NUM_TOP + today_r

            # màu số
            if is_today:
                _circle_aa(img, num_cx, num_cy, today_r, C_TODAY_FILL)
                d = ImageDraw.Draw(img, "RGBA")
                fill = C_TODAY_TXT
                font = font_main
            elif is_muted:
                fill = C_MUTED
            elif is_holiday or is_sun:
                fill = C_HOLIDAY
            elif is_sat:
                fill = C_SAT
            else:
                fill = C_NORMAL

            _txt_center(d, txt, font, num_cx, num_cy, fill)

            # holiday label nhỏ xíu dưới số
            if is_holiday and not is_muted:
                hol_name = VN_HOLIDAYS.get((rm, rd), "")
                if hol_name:
                    hw  = _tw(d, hol_name, f_hol)
                    hh, ht = _bb(f_hol, hol_name)
                    hx  = num_cx - hw // 2
                    hy  = num_cy + today_r + 4
                    if hy + hh < cy2c - 4:
                        d.text((hx, hy - ht), hol_name, font=f_hol,
                               fill=(*C_HOLIDAY, 200))

            # âm lịch — center-bottom ô (không đè số)
            if not is_muted:
                ld, lm = _solar_to_lunar(ry, rm, rd)
                lbl    = _lunar_lbl(ld, lm)
                lw     = _tw(d, lbl, f_lunar)
                lh, lt = _bb(f_lunar, lbl)
                lx     = cx1c + (cw - lw) // 2
                ly     = cy2c - 12 - lh
                d.text((lx, ly - lt), lbl, font=f_lunar, fill=C_LUNAR)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.save(out_path, "PNG")
    return out_path
