from PIL import Image, ImageDraw, ImageSequence, ImageFont, ImageFilter, ImageChops
from io import BytesIO
import os, subprocess, tempfile, requests, filetype, urllib, json, shutil, platform

MaxStickerSize = 700
WebpQuality    = 95
font_path      = "data/assets/font/ProtestGuerrilla-Regular.ttf"


def _find_ffmpeg() -> str:
    env = os.environ.get("FFMPEG_PATH")
    if env and os.path.isfile(env):
        return env
    found = shutil.which("ffmpeg")
    if found:
        return found
    _os = platform.system()
    if _os == "Windows":
        candidates = [
            r"D:\ffmpegnew\bin\ffmpeg.exe",
            r"C:\ffmpeg\bin\ffmpeg.exe",
            r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
            r"C:\Program Files (x86)\ffmpeg\bin\ffmpeg.exe",
            os.path.join(os.environ.get("LOCALAPPDATA", ""), "ffmpeg", "bin", "ffmpeg.exe"),
        ]
    elif _os == "Darwin":
        candidates = ["/usr/local/bin/ffmpeg", "/opt/homebrew/bin/ffmpeg", "/usr/bin/ffmpeg"]
    else:
        candidates = [
            "/usr/bin/ffmpeg",
            "/usr/local/bin/ffmpeg",
            "/data/data/com.termux/files/usr/bin/ffmpeg",
            "/snap/bin/ffmpeg",
        ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    raise FileNotFoundError(
        "[ffmpeg] Không tìm thấy ffmpeg!\n"
        "  • Windows : cài https://ffmpeg.org rồi thêm vào PATH, hoặc đặt FFMPEG_PATH=<đường dẫn>\n"
        "  • Termux   : pkg install ffmpeg\n"
        "  • Linux    : sudo apt install ffmpeg\n"
        "  • macOS    : brew install ffmpeg"
    )

ff = _find_ffmpeg()


def _run(cmd):
    subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

def _write_tmp(data, suffix):
    p = tempfile.NamedTemporaryFile(delete=False, suffix=suffix).name
    with open(p, "wb") as f:
        f.write(data)
    return p

def _guess_suffix(kind):
    if not kind:
        return ".bin"
    ext = kind.extension
    if ext in ("gif", "webp", "png", "mp4"):
        return f".{ext}"
    if ext in ("jpg", "jpeg"):
        return ".jpg"
    if kind.mime and kind.mime.startswith("video"):
        return ".mp4"
    return f".{ext}"

def _clamp(v, a, b):
    return a if v < a else b if v > b else v

def _clamp_scale(sf):
    return _clamp(float(sf or 1.0), 0.1, 1.0)


def ResizeKeepRatio(img: Image.Image, maxSize: int) -> Image.Image:
    w, h = img.size
    if max(w, h) <= maxSize:
        return img
    s = maxSize / max(w, h)
    return img.resize((max(1, int(w * s)), max(1, int(h * s))), Image.LANCZOS)

def CropSquare(img: Image.Image) -> Image.Image:
    w, h = img.size
    s = min(w, h)
    x0, y0 = (w - s) // 2, (h - s) // 2
    return img.crop((x0, y0, x0 + s, y0 + s))

def SquareCanvas(img: Image.Image, canvasSize: int, scaleFactor: float) -> Image.Image:
    canvasSize = int(canvasSize)
    sf = _clamp_scale(scaleFactor)
    inner = max(1, int(canvasSize * sf))
    w, h = img.size
    m = max(w, h)
    if m > inner:
        s = inner / m
        img = img.resize((max(1, int(w * s)), max(1, int(h * s))), Image.LANCZOS)
    out = Image.new("RGBA", (canvasSize, canvasSize), (0, 0, 0, 0))
    x = (canvasSize - img.size[0]) // 2
    y = (canvasSize - img.size[1]) // 2
    if img.mode not in ("RGBA", "LA"):
        img = img.convert("RGBA")
    out.paste(img, (x, y), img)
    return out

def ApplyRoundCorner(img: Image.Image, percent: int) -> Image.Image:
    if percent <= 0:
        return img
    if img.mode not in ("RGBA", "LA"):
        img = img.convert("RGBA")
    w, h = img.size
    r = int(min(w, h) * percent / 200)
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, w, h), radius=r, fill=255)
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out

def ProcessImage(img: Image.Image, maxSize=MaxStickerSize, radiusPercent=0, sqr=False, scaleFactor=1.0) -> Image.Image:
    img = ResizeKeepRatio(img, maxSize)
    if sqr:
        img = CropSquare(img)
        img = SquareCanvas(img, maxSize, scaleFactor)
    elif radiusPercent == 100:
        img = CropSquare(img)
    if radiusPercent > 0:
        img = ApplyRoundCorner(img, radiusPercent)
    return img


def gradient_text_mask(size):
    w, h = size
    base = Image.new("RGBA", size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(base)
    for i in range(w):
        r = int(128 + 127 * (i / w))
        g = int(255 * (i / w))
        b = int(255 - 200 * (i / w))
        draw.line((i, 0, i, h), fill=(r, g, b, 255))
    return base

def draw_text_on_image(img: Image.Image, text: str) -> Image.Image:
    img = img.convert("RGBA")
    w, h = img.size
    base = Image.new("RGBA", (w, h), (30, 50, 80, 255))
    grad = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd   = ImageDraw.Draw(grad)
    for i in range(h):
        r = int(40 + 40 * (i / h))
        g = int(80 + 80 * (i / h))
        b = int(140 + 80 * (i / h))
        gd.line((0, i, w, i), fill=(r, g, b, 255))
    bg   = Image.alpha_composite(base, grad)
    draw = ImageDraw.Draw(bg)
    max_w     = w - 40
    font_size = 64
    lines = []
    f     = None
    while font_size > 10:
        f     = ImageFont.truetype(font_path, font_size)
        words = text.split()
        lines = []
        cur   = ""
        for word in words:
            test = cur + " " + word if cur else word
            if draw.textbbox((0, 0), test, font=f)[2] <= max_w:
                cur = test
            else:
                lines.append(cur)
                cur = word
        if cur:
            lines.append(cur)
        total_h = len(lines) * (font_size + 10)
        if total_h < h - 40:
            break
        font_size -= 4
    total_h = len(lines) * (font_size + 10)
    y = (h - total_h) // 2
    for line in lines:
        tw = draw.textbbox((0, 0), line, font=f)[2]
        x  = (w - tw) // 2
        draw.text((x + 2, y + 2), line, font=f, fill=(0, 0, 0, 120))
        draw.text((x, y),         line, font=f, fill=(255, 255, 255, 255))
        y += font_size + 10
    return bg


def _decode_jxl(imageBytes: bytes) -> bytes:
    try:
        import pillow_jxl
        img = Image.open(BytesIO(imageBytes)).convert("RGB")
        buf = BytesIO()
        img.save(buf, format="JPEG", quality=95)
        return buf.getvalue()
    except ImportError:
        pass
    try:
        from jxlpy import JXLPyDecoder
        decoder = JXLPyDecoder(imageBytes)
        info    = decoder.get_info()
        w, h    = info["xsize"], info["ysize"]
        pixels, mode = decoder.get_frame()
        img = Image.frombytes(mode, (w, h), pixels)
        buf = BytesIO()
        img.save(buf, format="JPEG", quality=95)
        return buf.getvalue()
    except Exception as e:
        raise Exception(f"Không đọc được ảnh JXL: {e}")


def FfmpegToWebpAnim(inputPath, outputPath, fps=30, scale=MaxStickerSize, seconds=30, q=95, sqr=False, scaleFactor=1.0):
    fps, scale, seconds, q = int(fps), int(scale), int(seconds), int(q)
    if sqr:
        sf    = _clamp_scale(scaleFactor)
        inner = max(1, int(scale * sf))
        vf    = (
            f"fps={fps},"
            f"crop='min(iw,ih)':'min(iw,ih)',"
            f"scale={inner}:{inner}:flags=lanczos,"
            f"pad={scale}:{scale}:(ow-iw)/2:(oh-ih)/2:color=0x00000000"
        )
    else:
        vf = f"fps={fps},scale={scale}:-1:flags=lanczos"
    _run([
        ff, "-y", "-i", inputPath,
        "-t", str(seconds),
        "-vf", vf,
        "-q:v", str(q),
        "-loop", "0",
        "-threads", "0",
        "-an",
        outputPath
    ])

def RoundWebpFrames(inputPath, outputPath, radiusPercent):
    with Image.open(inputPath) as im:
        isAnim   = getattr(im, "is_animated", False)
        duration = max(10, int(getattr(im, "info", {}).get("duration", 66)))
        if isAnim:
            frames = []
            for frame in ImageSequence.Iterator(im):
                f = frame.convert("RGBA")
                f = ApplyRoundCorner(f, radiusPercent)
                frames.append(f)
            frames[0].save(outputPath, format="WEBP", save_all=True,
                           append_images=frames[1:], duration=duration,
                           loop=0, quality=WebpQuality, method=6)
            return
        f = im.convert("RGBA")
        f = ApplyRoundCorner(f, radiusPercent)
        f.save(outputPath, "WEBP", quality=WebpQuality, method=6)

def SpinWebp(inputPath, outputPath, fps=60, seconds=6, q=90):
    fps, seconds, q = int(fps), int(seconds), int(q)
    total_frames = max(1, fps * seconds)
    frame_ms     = max(10, 1000 // fps)

    with Image.open(inputPath) as src:
        src = src.convert("RGBA")
        w, h   = src.size
        # Canvas đủ chứa ảnh khi xoay (đường chéo)
        diag   = int((w ** 2 + h ** 2) ** 0.5) + 2
        canvas = (diag, diag)
        frames = []
        for i in range(total_frames):
            angle = 360 * i / total_frames
            bg    = Image.new("RGBA", canvas, (0, 0, 0, 0))
            rot   = src.rotate(angle, expand=False, resample=Image.BICUBIC)
            # Căn giữa
            x = (diag - rot.width)  // 2
            y = (diag - rot.height) // 2
            bg.paste(rot, (x, y), rot)
            # Resize về maxSize nếu cần
            if diag > MaxStickerSize:
                bg = bg.resize((MaxStickerSize, MaxStickerSize), Image.LANCZOS)
            frames.append(bg)

    os.makedirs(os.path.dirname(outputPath) or ".", exist_ok=True)
    frames[0].save(
        outputPath, format="WEBP", save_all=True,
        append_images=frames[1:],
        duration=frame_ms, loop=0,
        quality=int(q), method=4,
    )

def BytesCreate(imageBytes, outputPath, maxSize=MaxStickerSize, radiusPercent=0,
                isAnimation=False, sqr=False, scaleFactor=1.0):
    img = Image.open(BytesIO(imageBytes))
    os.makedirs(os.path.dirname(outputPath), exist_ok=True)
    if getattr(img, "is_animated", False) or isAnimation:
        frames   = []
        duration = max(10, int(getattr(img, "info", {}).get("duration", 66)))
        for frame in ImageSequence.Iterator(img):
            f = frame.convert("RGBA")
            f = ProcessImage(f, maxSize, radiusPercent, sqr=sqr, scaleFactor=scaleFactor)
            frames.append(f)
        frames[0].save(outputPath, format="WEBP", save_all=True,
                       append_images=frames[1:], duration=duration,
                       loop=0, quality=WebpQuality, method=6)
        return
    im = img.convert("RGBA")
    im = ProcessImage(im, maxSize, radiusPercent, sqr=sqr, scaleFactor=scaleFactor)
    im.save(outputPath, "WEBP", quality=WebpQuality, method=6)

def BytesCreateWithText(imageBytes, outputPath, text=None, **kwargs):
    BytesCreate(imageBytes, outputPath, **kwargs)
    if text:
        img = Image.open(outputPath).convert("RGBA")
        img = draw_text_on_image(img, text)
        img.save(outputPath, "WEBP", quality=WebpQuality, method=6)

def GetMediaWh(filePath):
    try:
        with Image.open(filePath) as im:
            return im.size
    except Exception:
        return 512, 512

def _apply_lego_frame(frame: Image.Image, blockSize: int = 16) -> Image.Image:
    """
    Lego 3D fast — thuần PIL (không numpy), ~0.02s cho 512×512.

    Pipeline:
      1. Pixelate: resize BOX↓ + NEAREST↑  (C-level)
      2. Height map: vẽ rãnh bevel + stud dome lên grayscale image
      3. SMOOTH_MORE → EMBOSS  (C-level Sobel+shading trong 1 pass)
      4. Remap shading curve → ImageChops.multiply lên color  (C-level)
      5. Paste specular highlight dot lên mỗi stud
    """
    img  = frame.convert("RGBA")
    W, H = img.size
    bs   = max(6, int(blockSize))
    GW   = (W + bs - 1) // bs
    GH   = (H + bs - 1) // bs
    PW, PH = GW * bs, GH * bs

    # ── 1. Pixelate (C-level resize) ─────────────────────────────────────
    small     = img.resize((GW, GH), Image.BOX)
    pixelated = small.resize((PW, PH), Image.NEAREST)

    # ── 2. Height map (grayscale): brick=148, gap=50~60, stud dome=230~248 ─
    gap    = max(1, bs // 8)
    stud_r = max(2, int(bs * 0.26))
    hmap   = Image.new("L", (PW, PH), 148)
    dh     = ImageDraw.Draw(hmap)

    for gy in range(GH):
        for gx in range(GW):
            x0, y0 = gx * bs, gy * bs
            x1, y1 = x0 + bs - 1, y0 + bs - 1
            # Rãnh viền 4 cạnh — top/left sáng hơn, bottom/right tối hơn
            # (tạo hiệu ứng bevel nhìn như cạnh vát)
            dh.rectangle([x0,    y0,    x1,         y0+gap-1], fill=72)  # top
            dh.rectangle([x0,    y1-gap+1, x1,      y1      ], fill=42)  # bottom
            dh.rectangle([x0,    y0,    x0+gap-1,   y1      ], fill=72)  # left
            dh.rectangle([x1-gap+1, y0, x1,         y1      ], fill=42)  # right
            # Stud: outer ring + inner dome peak
            scx, scy = x0 + bs // 2, y0 + bs // 2
            dh.ellipse([scx-stud_r,   scy-stud_r,
                        scx+stud_r,   scy+stud_r],   fill=228)
            ir = max(1, stud_r - 2)
            dh.ellipse([scx-ir, scy-ir, scx+ir, scy+ir], fill=250)

    # ── 3. EMBOSS shading (C-level: smooth → emboss) ─────────────────────
    hmap_s  = hmap.filter(ImageFilter.SMOOTH_MORE)
    shading = hmap_s.filter(ImageFilter.EMBOSS)
    # Remap: power curve → shadow sâu hơn, highlight sắc hơn
    shading = shading.point(lambda v: int(42 + (v / 255.0) ** 0.72 * 213))

    # ── 4. Multiply shading onto pixelated color (C-level) ───────────────
    px_crop  = pixelated.crop((0, 0, W, H))
    r, g, b, a = px_crop.split()
    shade_c  = shading.crop((0, 0, W, H))
    shade3   = Image.merge("RGB", (shade_c, shade_c, shade_c))
    color3   = Image.merge("RGB", (r, g, b))
    shaded   = ImageChops.multiply(color3, shade3)
    # Compensate darkening from multiply (factor ~1.52)
    shaded   = shaded.point(lambda v: min(255, int(v * 1.52)))

    # ── 5. Specular highlight dot trên mỗi stud ──────────────────────────
    spec = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ds   = ImageDraw.Draw(spec)
    hr   = max(1, stud_r - 2)
    off  = max(1, stud_r // 3)   # shift top-left
    for gy in range(GH):
        for gx in range(GW):
            scx = gx * bs + bs // 2
            scy = gy * bs + bs // 2
            if scx >= W or scy >= H:
                continue
            hx = scx - off - hr // 2
            hy = scy - off - hr // 2
            ds.ellipse([hx, hy, hx + hr, hy + hr], fill=(255, 255, 255, 120))

    result = Image.merge("RGBA", (*shaded.split(), a))
    return Image.alpha_composite(result, spec)


def PixelLegoImage(img: Image.Image, blockSize: int = 16) -> Image.Image:
    """Áp dụng hiệu ứng Lego 3D cho ảnh tĩnh PIL.Image. Không cần numpy."""
    return _apply_lego_frame(img, blockSize)


def PixelLegoBytes(imageBytes: bytes, outputPath: str,
                   blockSize: int = 16, maxSize: int = MaxStickerSize,
                   radiusPercent: int = 0) -> None:
    """
    Áp dụng hiệu ứng pixel Lego 3D từ bytes (ảnh tĩnh hoặc ảnh động GIF/WEBP).
    Lưu ra file WEBP (animated nếu input có nhiều frame).
    """
    img = Image.open(BytesIO(imageBytes))
    os.makedirs(os.path.dirname(outputPath) or ".", exist_ok=True)

    is_anim = getattr(img, "is_animated", False)

    if is_anim:
        duration = max(10, int(img.info.get("duration", 66)))
        frames = []
        for frame in ImageSequence.Iterator(img):
            f = frame.convert("RGBA")
            f = ResizeKeepRatio(f, maxSize)
            f = _apply_lego_frame(f, blockSize)
            if radiusPercent > 0:
                f = ApplyRoundCorner(f, radiusPercent)
            frames.append(f)
        frames[0].save(
            outputPath, format="WEBP", save_all=True,
            append_images=frames[1:], duration=duration,
            loop=0, quality=WebpQuality, method=6
        )
    else:
        frame = img.convert("RGBA")
        frame = ResizeKeepRatio(frame, maxSize)
        frame = _apply_lego_frame(frame, blockSize)
        if radiusPercent > 0:
            frame = ApplyRoundCorner(frame, radiusPercent)
        frame.save(outputPath, "WEBP", quality=WebpQuality, method=6)


def CreateStickerLegoUrl(imageUrl: str, outputPath: str,
                         blockSize: int = 16, maxSize: int = MaxStickerSize,
                         radiusPercent: int = 0,
                         fps: int = 30, scale: int = MaxStickerSize,
                         seconds: int = 30, q: int = 95) -> None:
    """
    Tải ảnh từ URL rồi áp dụng hiệu ứng pixel Lego 3D.
    Hỗ trợ: PNG, JPG, GIF, WEBP (animated), MP4/video.
    Kết quả lưu dạng WEBP (animated nếu cần).
    """
    resp = requests.get(imageUrl, headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
    resp.raise_for_status()
    data = resp.content
    kind = filetype.guess(data[:2048])
    if not kind:
        raise Exception("Unsupported file format")

    isGif   = kind.extension == "gif"
    isWebp  = kind.extension == "webp"
    isVideo = (kind.mime or "").startswith("video")
    isAnimated = isGif or isVideo

    os.makedirs(os.path.dirname(outputPath) or ".", exist_ok=True)

    if isVideo:
        # Video: chuyển qua WEBP animated trước, rồi áp lego
        tmpW = tempfile.NamedTemporaryFile(delete=False, suffix=".webp").name
        tmpIn = _write_tmp(data, _guess_suffix(kind))
        try:
            FfmpegToWebpAnim(tmpIn, tmpW, fps=fps, scale=scale, seconds=seconds, q=q)
            with open(tmpW, "rb") as f:
                PixelLegoBytes(f.read(), outputPath, blockSize=blockSize,
                               maxSize=maxSize, radiusPercent=radiusPercent)
        finally:
            for p in (tmpIn, tmpW):
                try: os.remove(p)
                except: pass
        return

    PixelLegoBytes(data, outputPath, blockSize=blockSize,
                   maxSize=maxSize, radiusPercent=radiusPercent)


def CreateStickerUrl(imageUrl, outputPath, maxSize=MaxStickerSize, radiusPercent=0,
                     spin=False, fps=30, scale=MaxStickerSize, seconds=30, q=95,
                     spinSeconds=6, spinFps=60, sqr=False, scaleFactor=1.0):
    resp = requests.get(imageUrl, headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
    resp.raise_for_status()
    data = resp.content
    kind = filetype.guess(data[:2048])
    if not kind:
        _hdr   = data[:12]
        _is_jxl = (_hdr[:2] == b'\xff\x0a' or _hdr == b'\x00\x00\x00\x0cJXL \r\n\x87\n')
        if _is_jxl:
            class JXL:
                extension = "jxl"; mime = "image/jxl"
            kind = JXL()
        else:
            raise Exception("Unsupported file format")
    if kind.extension == "jxl":
        data = _decode_jxl(data)
        kind = filetype.guess(data[:2048])
        if not kind:
            raise Exception("Unsupported file format after JXL decode")
    isGif   = kind.extension == "gif"
    isWebp  = kind.extension == "webp"
    isVideo = (kind.mime or "").startswith("video")
    isAnimated = isGif or isVideo
    os.makedirs(os.path.dirname(outputPath), exist_ok=True)
    if spin:
        tmpA = tempfile.NamedTemporaryFile(delete=False, suffix=".webp").name
        tmpB = tempfile.NamedTemporaryFile(delete=False, suffix=".webp").name
        try:
            if isAnimated and radiusPercent == 0:
                tmpIn = _write_tmp(data, _guess_suffix(kind))
                try:
                    FfmpegToWebpAnim(tmpIn, tmpA, fps=max(30, fps), scale=scale,
                                     seconds=seconds, q=q, sqr=sqr, scaleFactor=scaleFactor)
                finally:
                    try: os.remove(tmpIn)
                    except: pass
            else:
                rp = 0 if sqr else 100
                BytesCreate(data, tmpA, maxSize=maxSize, radiusPercent=rp,
                            isAnimation=isAnimated, sqr=sqr, scaleFactor=scaleFactor)
            if radiusPercent > 0:
                RoundWebpFrames(tmpA, tmpB, radiusPercent)
                SpinWebp(tmpB, outputPath, fps=spinFps, seconds=spinSeconds, q=min(95, q))
            else:
                SpinWebp(tmpA, outputPath, fps=spinFps, seconds=spinSeconds, q=min(95, q))
        finally:
            for p in (tmpA, tmpB):
                try: os.remove(p)
                except: pass
        return kind
    if isWebp and radiusPercent == 0 and not sqr and float(scaleFactor or 1.0) >= 0.999:
        with open(outputPath, "wb") as f:
            f.write(data)
        return kind
    if isAnimated and radiusPercent == 0:
        tmpIn = _write_tmp(data, _guess_suffix(kind))
        try:
            FfmpegToWebpAnim(tmpIn, outputPath, fps=fps, scale=scale,
                             seconds=seconds, q=q, sqr=sqr, scaleFactor=scaleFactor)
        finally:
            try: os.remove(tmpIn)
            except: pass
        return kind
    if isAnimated and radiusPercent > 0:
        tmpIn = _write_tmp(data, _guess_suffix(kind))
        tmpW  = tempfile.NamedTemporaryFile(delete=False, suffix=".webp").name
        try:
            FfmpegToWebpAnim(tmpIn, tmpW, fps=fps, scale=scale,
                             seconds=seconds, q=q, sqr=sqr, scaleFactor=scaleFactor)
            RoundWebpFrames(tmpW, outputPath, radiusPercent)
        finally:
            for p in (tmpIn, tmpW):
                try: os.remove(p)
                except: pass
        return kind
    BytesCreate(data, outputPath, maxSize=maxSize, radiusPercent=radiusPercent,
                isAnimation=isAnimated, sqr=sqr, scaleFactor=scaleFactor)
    return kind

def CreateStickerUrlWithText(imageUrl, outputPath, text=None, **kwargs):
    resp = requests.get(imageUrl, headers={"User-Agent": "Mozilla/5.0"}, timeout=12)
    resp.raise_for_status()
    BytesCreateWithText(resp.content, outputPath, text=text, **kwargs)
    