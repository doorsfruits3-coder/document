"""
capcutCard.py  –  Vẽ card thông tin template CapCut (single) cho zBot
Output: JPEG 2048×622  |  Clone y hệt tiktokCard.py, chỉ đổi màu + data fields
"""
import os
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 2048, 622


def _resolve_font():
    try:
        base = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static" / "Opensans"
        bold = base / "OpenSans-Bold.ttf"
        reg  = base / "OpenSans-Regular.ttf"
        if bold.exists() and reg.exists():
            return str(bold), str(reg)
    except Exception:
        pass
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )


FONT_BOLD, FONT_REG = _resolve_font()

# ── Màu CapCut (thay TK_PINK → CC_BLUE, TK_CYAN → CC_CYAN) ──────────────────
CC_BLUE = (0, 145, 255)       # thay TK_PINK  → màu chủ CapCut (xanh dương)
CC_CYAN = (0, 210, 230)       # thay TK_CYAN  → accent xanh ngọc


def _font(size, bold=False):
    path = FONT_BOLD if bold else FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _rounded_mask(w, h, r=28, aa=4):
    mw, mh = w * aa, h * aa
    mr = int(min(r, w // 2, h // 2) * aa)
    m  = Image.new("L", (mw, mh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def _fetch_img(url, size):
    try:
        if url:
            r = requests.get(url, timeout=7, headers={"User-Agent": "Mozilla/5.0"})
            if r.status_code == 200:
                img = Image.open(BytesIO(r.content)).convert("RGBA")
                tw, th = size
                iw, ih = img.size
                if iw / ih > tw / th:
                    new_w = int(ih * tw / th)
                    img = img.crop(((iw - new_w) // 2, 0, (iw + new_w) // 2, ih))
                else:
                    new_h = int(iw * th / tw)
                    img = img.crop((0, (ih - new_h) // 2, iw, (ih + new_h) // 2))
                return img.resize(size, Image.LANCZOS)
    except Exception:
        pass
    return Image.new("RGBA", size, (6, 12, 24, 255))


def _fmt_num(n):
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def draw_capcut_card(template, out_path):
    PAD   = 28
    COV_W = int(H * 0.56)
    COV_H = H - PAD * 2
    TX    = COV_W + PAD * 2 + 10
    TW    = W - TX - PAD

    # Cover — CapCut template thường là landscape nên crop 16:9
    cover_url = template.get("cover_url") or template.get("cover") or ""
    cov_img   = _fetch_img(cover_url, (COV_W, COV_H))

    # Background blur  (y hệt tiktokCard)
    bg_src = cov_img.resize((W, H), Image.BILINEAR).filter(ImageFilter.GaussianBlur(radius=30))
    dark   = Image.new("RGBA", (W, H), (0, 0, 0, 185))
    canvas = bg_src.copy()
    canvas.paste(dark, (0, 0), dark)

    draw = ImageDraw.Draw(canvas, "RGBA")

    # Dải tối phần text  (y hệt)
    fade = Image.new("RGBA", (TW + PAD + 20, H), (0, 0, 0, 0))
    fd   = ImageDraw.Draw(fade)
    for xi in range(fade.width):
        alpha = int(80 * xi / fade.width)
        fd.line([(xi, 0), (xi, H)], fill=(0, 0, 0, alpha))
    canvas.alpha_composite(fade, (TX - 20, 0))

    # Paste cover  (y hệt)
    mask = _rounded_mask(COV_W, COV_H, r=18)
    canvas.paste(cov_img, (PAD, PAD), mask)
    draw.rounded_rectangle(
        (PAD, PAD, PAD + COV_W, PAD + COV_H),
        radius=18, outline=(255, 255, 255, 40), width=2
    )

    # ── Data fields CapCut ────────────────────────────────────────────────────
    title    = str(template.get("title") or "CapCut Template")
    plays    = template.get("play_amount") or template.get("playAmount") or 0
    likes    = template.get("like_count")  or template.get("likeCount")  or 0
    collects = template.get("collect_count") or template.get("collectCount") or 0
    shares   = template.get("share_count") or template.get("shareCount") or 0

    # "author" CapCut: tên creator
    author_d  = template.get("author") or template.get("user_info") or {}
    nickname  = str(author_d.get("nickname") or author_d.get("name") or "").strip()
    uid       = str(author_d.get("uid") or author_d.get("user_id") or "").strip()

    if nickname and uid and nickname != uid:
        name_main   = nickname
        name_handle = f"#{uid}"
    elif nickname:
        name_main   = nickname
        name_handle = f"#{uid}" if uid else ""
    else:
        name_main   = "CapCut"
        name_handle = ""

    # "duration" = độ dài clip template (giây)
    duration = template.get("duration") or 0
    dur_sec  = int(duration) if duration < 10000 else int(duration) // 1000
    m, s     = divmod(dur_sec, 60)
    dur_str  = f"{m:02d}:{s:02d}" if dur_sec else ""

    # "music" = âm nhạc kèm theo
    music_d     = template.get("music_info") or template.get("music") or {}
    music_title = str(music_d.get("title") or music_d.get("name") or "")
    music_auth  = str(music_d.get("author") or music_d.get("author_name") or "")

    # ── Fonts  (y hệt tiktokCard) ─────────────────────────────────────────────
    fn_title  = _font(48, bold=True)
    fn_author = _font(34, bold=True)
    fn_handle = _font(27)
    fn_dur    = _font(32)
    fn_stat   = _font(30)
    fn_lbl    = _font(22)
    fn_music  = _font(27)

    def trunc(text, font, max_w):
        text = (text or "").strip()
        if draw.textlength(text, font=font) <= max_w:
            return text
        ell  = "…"
        room = max_w - draw.textlength(ell, font=font)
        out  = ""
        for ch in text:
            if draw.textlength(out + ch, font=font) > room:
                break
            out += ch
        return out + ell

    # Wrap title 2 dòng  (y hệt)
    words = title.split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if draw.textlength(test, font=fn_title) <= TW:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
            if len(lines) == 2:
                break
    if cur and len(lines) < 2:
        lines.append(cur)
    lines = lines[:2]

    LINE_H    = 58
    BLOCK_GAP = 12
    title_h   = len(lines) * LINE_H
    author_h  = 42
    dur_h     = 40 if dur_str else 0
    stat_h    = 68
    music_h   = 36 if music_title else 0

    total_h = (title_h + BLOCK_GAP
               + author_h + BLOCK_GAP
               + (dur_h + BLOCK_GAP if dur_str else 0)
               + stat_h
               + (BLOCK_GAP + music_h if music_title else 0))

    cy = (H - total_h) // 2 - 20

    # Title  (màu trắng, y hệt)
    for li in lines:
        draw.text((TX, cy), trunc(li, fn_title, TW), font=fn_title, fill=(255, 255, 255))
        cy += LINE_H
    cy += BLOCK_GAP

    # Author  (CC_BLUE thay TK_PINK)
    draw.text((TX, cy), name_main, font=fn_author, fill=CC_BLUE)
    if name_handle:
        nw = int(draw.textlength(name_main, font=fn_author))
        draw.text((TX + nw + 12, cy + 5), name_handle, font=fn_handle, fill=(145, 175, 210))
    cy += author_h + BLOCK_GAP

    # Duration (nếu có)
    if dur_str:
        draw.text((TX, cy), f"Duration  {dur_str}", font=fn_dur, fill=(200, 200, 215))
        cy += dur_h + BLOCK_GAP

    # Stats: Use | Like | Collect | Share  (y hệt Play/Like/Comment/Share TikTok)
    stats = [("Use", plays), ("Like", likes), ("Collect", collects), ("Share", shares)]
    sx = TX
    for label, val in stats:
        val_str = _fmt_num(val)
        vw = int(draw.textlength(val_str, font=fn_stat))
        lw = int(draw.textlength(label,   font=fn_lbl))
        draw.text((sx, cy),      val_str, font=fn_stat, fill=(240, 240, 255))
        draw.text((sx, cy + 34), label,   font=fn_lbl,  fill=(150, 150, 170))
        sx += max(vw, lw) + 36
    cy += stat_h + BLOCK_GAP

    # Music  (CC_CYAN thay TK_CYAN)
    if music_title:
        ml = music_title + (f"  —  {music_auth}" if music_auth else "")
        draw.text((TX, cy), trunc(ml, fn_music, TW), font=fn_music, fill=CC_CYAN)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=92)
    return out_path
