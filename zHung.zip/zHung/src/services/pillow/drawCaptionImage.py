"""
drawCaptionImage.py  –  Bộ xử lý ảnh Pillow cho imageCore.

Các hàm public:
    draw_caption_image()          – header caption trắng nằm trên ảnh
    draw_caption_image_grayscale()– chuyển trắng đen
    draw_rotate_image()           – xoay theo độ, fill trắng
    draw_resize_image()           – resize theo px (WxH) hoặc %
"""

import os
import math
import urllib.parse
from pathlib import Path
from io import BytesIO
from PIL import Image, ImageDraw, ImageFont

# ── Font ──────────────────────────────────────────────────────────────────────
_FONT_DIR  = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static"
_FONT_BOLD = str(_FONT_DIR / "OpenSans_Condensed-Bold.ttf")
_FONT_REG  = str(_FONT_DIR / "OpenSans_Condensed-Regular.ttf")

def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = _FONT_BOLD if bold else _FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()

# ── Caption constants ─────────────────────────────────────────────────────────
HEADER_BG      = (255, 255, 255)
HEADER_TEXT    = (30,  30,  30)
HEADER_PAD_X   = 40
HEADER_PAD_Y   = 30
LINE_SPACING   = 1.35
BORDER_COLOR   = (220, 220, 220)
BORDER_H       = 3

# ── Load helpers ──────────────────────────────────────────────────────────────
def _load_url(url: str) -> Image.Image:
    import requests
    url = urllib.parse.unquote(url.replace("\\/", "/"))
    r = requests.get(url, timeout=15, stream=True)
    r.raise_for_status()
    return Image.open(BytesIO(r.content)).convert("RGBA")

def _load(source: str, is_url: bool) -> Image.Image:
    return _load_url(source) if is_url else Image.open(source).convert("RGBA")

def _save(img: Image.Image, path: str) -> tuple[int, int]:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    img.convert("RGB").save(path, "PNG", optimize=True)
    return img.size

# ── Text wrap ─────────────────────────────────────────────────────────────────
def _calc_font_size(img_width: int) -> int:
    return max(32, min(72, int(img_width * 0.030)))

def _wrap_text(text: str, font: ImageFont.FreeTypeFont, max_w: int) -> list[str]:
    words   = text.split()
    lines: list[str] = []
    cur     = ""
    for word in words:
        test = (cur + " " + word).strip()
        if font.getbbox(test)[2] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]

# ─────────────────────────────────────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────────────────────────────────────

def draw_caption_image(
    caption: str,
    image_source: str,
    output_path: str,
    *,
    is_url: bool = False,
) -> tuple[int, int]:
    """
    Ghép header caption trắng lên TRÊN ảnh gốc (không đè).
    Header tự co giãn theo độ dài caption.
    """
    img      = _load(image_source, is_url)
    img_w, img_h = img.size

    fs       = _calc_font_size(img_w)
    font     = _font(fs, bold=True)
    lines    = _wrap_text(caption, font, img_w - HEADER_PAD_X * 2)
    line_h   = int(fs * LINE_SPACING)
    header_h = HEADER_PAD_Y + line_h * len(lines) + HEADER_PAD_Y + BORDER_H

    canvas = Image.new("RGBA", (img_w, header_h + img_h), (255, 255, 255, 255))
    draw   = ImageDraw.Draw(canvas)

    # header nền trắng
    draw.rectangle([(0, 0), (img_w, header_h - BORDER_H)], fill=HEADER_BG)
    # border
    draw.rectangle([(0, header_h - BORDER_H), (img_w, header_h)], fill=BORDER_COLOR)

    y = HEADER_PAD_Y
    for line in lines:
        draw.text((HEADER_PAD_X, y), line, font=font, fill=HEADER_TEXT)
        y += line_h

    canvas.paste(img, (0, header_h))
    return _save(canvas, output_path)


def draw_caption_image_grayscale(
    image_source: str,
    output_path: str,
    *,
    is_url: bool = False,
) -> tuple[int, int]:
    """Chuyển ảnh sang trắng đen."""
    img  = _load(image_source, is_url)
    gray = img.convert("L").convert("RGB")
    return _save(gray, output_path)


def draw_rotate_image(
    degrees: float,
    image_source: str,
    output_path: str,
    *,
    is_url: bool = False,
) -> tuple[int, int]:
    """
    Xoay ảnh ngược chiều kim đồng hồ `degrees` độ.
    Canvas mở rộng vừa đủ chứa ảnh sau xoay, vùng trống fill trắng.
    degrees: 1–360 (360 = không đổi).
    """
    img     = _load(image_source, is_url)
    w, h    = img.size
    rad     = math.radians(degrees % 360)

    # Tính kích thước canvas bounding box sau xoay
    new_w = int(abs(w * math.cos(rad)) + abs(h * math.sin(rad)))
    new_h = int(abs(w * math.sin(rad)) + abs(h * math.cos(rad)))

    # Pillow rotate: expand=True đủ để không cắt góc
    bg     = Image.new("RGBA", (new_w, new_h), (255, 255, 255, 255))
    rotated = img.rotate(degrees, resample=Image.BICUBIC, expand=True)

    # Căn giữa ảnh xoay lên bg
    ox = (new_w - rotated.width)  // 2
    oy = (new_h - rotated.height) // 2
    bg.paste(rotated, (ox, oy), rotated)

    return _save(bg, output_path)


def draw_resize_image(
    image_source: str,
    output_path: str,
    *,
    is_url: bool  = False,
    width: int    | None = None,   # px tuyệt đối
    height: int   | None = None,   # px tuyệt đối
    percent: float| None = None,   # 0–200 (%)
) -> tuple[int, int]:
    """
    Resize ảnh.
      - percent=50   → thu nhỏ còn 50%
      - width=800    → giữ tỷ lệ, chiều rộng = 800px
      - width=800, height=600 → stretch về đúng 800×600
    """
    img   = _load(image_source, is_url)
    iw, ih = img.size

    if percent is not None:
        scale = max(1, min(200, percent)) / 100.0
        nw    = max(1, int(iw * scale))
        nh    = max(1, int(ih * scale))
    elif width is not None and height is not None:
        nw, nh = max(1, width), max(1, height)
    elif width is not None:
        nw = max(1, width)
        nh = max(1, int(ih * nw / iw))
    elif height is not None:
        nh = max(1, height)
        nw = max(1, int(iw * nh / ih))
    else:
        return _save(img, output_path)

    resized = img.resize((nw, nh), Image.LANCZOS)
    return _save(resized, output_path)
