"""
drawTopChat.py  –  Vẽ card Top Chat (v4 – redesign đẹp hơn)

Cải tiến so với v3:
  • Header có icon trophy + underline gradient đẹp hơn
  • Top 1-3: crown/medal badge nổi bật góc trên phải card
  • Top 1 card cao hơn (podium effect)
  • Progress bar tương đối bên dưới tên ở row 4-15
  • Màu sắc tinh tế hơn: gold/silver/bronze accent cho top 3
  • Shadow nhẹ cho từng card
  • Số thứ hạng dạng pill badge cho row 4-15
"""

from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, math, re, unicodedata

FONT_DIR = Path("assets/font")

TOP3_CARD_W  = 310
TOP3_CARD_H  = 380  
TOP1_EXTRA   = 36   
ROW_H        = 88
ROW_AV       = 62
PAD          = 26
GAP          = 12
COLS         = 3
RADIUS       = 22

C_NAME    = (255, 255, 255)
C_RANK    = (220, 200, 255)
C_COUNT   = (200, 185, 245)
C_WHITE_A = (255, 255, 255, 235)
C_WHITE_L = (255, 255, 255,  50)
C_SEP     = (255, 255, 255,  30)

# Glassmorphism cards
C_TOP1_BG = ( 90,  55, 140, 195)
C_TOP2_BG = ( 75,  48, 118, 178)
C_TOP3_BG = ( 62,  42, 105, 160)
C_ROW_BG  = ( 52,  36,  92, 158)
C_BORDER  = (255, 255, 255,  45)

# Accent colors top 3
ACCENT = {
    1: (255, 215,   0, 230),   # gold
    2: (192, 192, 192, 210),   # silver
    3: (205, 127,  50, 200),   # bronze
}
ACCENT_TEXT = {
    1: (255, 230,  80),
    2: (230, 230, 230),
    3: (235, 165,  80),
}

# Progress bar
C_BAR_BG   = (255, 255, 255,  30)
C_BAR_FILL = (180, 140, 255, 180)


# ══════════════════════════════════════════════════════════════════════════════
#  FONT LOADER
# ══════════════════════════════════════════════════════════════════════════════
_fcache: dict = {}

def _font(sz: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (sz, bold)
    if key in _fcache:
        return _fcache[key]
    opensans_dir = FONT_DIR / "Opensans" / "static" / "Opensans"
    prefer_bold = ["OpenSans-Bold.ttf", "OpenSans-ExtraBold.ttf", "OpenSans-SemiBold.ttf"]
    prefer_reg  = ["OpenSans-Regular.ttf", "OpenSans-Medium.ttf", "OpenSans-Light.ttf"]
    names = prefer_bold if bold else prefer_reg
    for name in names:
        p = opensans_dir / name
        if p.exists():
            try:
                f = ImageFont.truetype(str(p), sz)
                _fcache[key] = f
                return f
            except Exception:
                pass
    for ext in ("*.ttf", "*.otf"):
        for p in sorted(FONT_DIR.rglob(ext)):
            try:
                f = ImageFont.truetype(str(p), sz)
                _fcache[key] = f
                return f
            except Exception:
                pass
    f = ImageFont.load_default()
    _fcache[key] = f
    return f


# ══════════════════════════════════════════════════════════════════════════════
#  EMOJI / TEXT SAFETY
# ══════════════════════════════════════════════════════════════════════════════
_EMOJI_RE = re.compile(
    "["
    "\U0001F600-\U0001F64F\U0001F300-\U0001F5FF\U0001F680-\U0001F6FF"
    "\U0001F1E0-\U0001F1FF\U00002500-\U00002BEF\U00002702-\U000027B0"
    "\U000024C2-\U0001F251\U0001f926-\U0001f937\U00010000-\U0010ffff"
    "\u2640-\u2642\u2600-\u2B55\u200d\u23cf\u23e9\u231a\ufe0f\u3030"
    "]+",
    flags=re.UNICODE,
)

def _safe_text(text: str) -> str:
    text = _EMOJI_RE.sub("", str(text))
    text = "".join(
        ch for ch in text
        if unicodedata.category(ch) not in ("Cc", "Cf") or ch in ("\n", "\t")
    ).strip()
    return text or "?"


# ══════════════════════════════════════════════════════════════════════════════
#  TEXT HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def _tw(d, text: str, font) -> int:
    try:
        bb = d.textbbox((0, 0), text, font=font)
        return max(0, bb[2] - bb[0])
    except Exception:
        try:
            return max(0, int(d.textlength(text, font=font)))
        except Exception:
            return len(text) * getattr(font, "size", 12) // 2

def _th(d, text: str, font) -> int:
    try:
        bb = d.textbbox((0, 0), text, font=font)
        return max(1, bb[3] - bb[1])
    except Exception:
        return getattr(font, "size", 12)

def _fit(d, text: str, font, maxw: int) -> str:
    if _tw(d, text, font) <= maxw:
        return text
    ell = "…"
    ew  = _tw(d, ell, font)
    out = ""
    for ch in text:
        if _tw(d, out + ch, font) > maxw - ew:
            break
        out += ch
    return out + ell

def _auto_fit(d, text: str, max_sz: int, min_sz: int, bold: bool, maxw: int):
    for sz in range(max_sz, min_sz - 1, -1):
        f = _font(sz, bold)
        if _tw(d, text, f) <= maxw:
            return text, f
    f = _font(min_sz, bold)
    return _fit(d, text, f, maxw), f


# ══════════════════════════════════════════════════════════════════════════════
#  DRAWING PRIMITIVES
# ══════════════════════════════════════════════════════════════════════════════
def _rrect(base: Image.Image, box, r, fill=None, outline=None, lw=1):
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    if w <= 0 or h <= 0:
        return
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    if fill:
        d.rounded_rectangle((0, 0, w-1, h-1), r, fill=fill)
    if outline:
        d.rounded_rectangle((0, 0, w-1, h-1), r, outline=outline, width=lw)
    base.alpha_composite(layer, (x1, y1))

def _hline(base: Image.Image, x1: int, x2: int, y: int, color=C_SEP):
    if x2 <= x1:
        return
    layer = Image.new("RGBA", (x2 - x1, 1), color)
    base.alpha_composite(layer, (x1, y))

def _hq_url(url: str) -> str:
    if not url:
        return url
    url = re.sub(r'[?&]w=\d+', '', url)
    url = re.sub(r'[?&]h=\d+', '', url)
    url = re.sub(r'[?&]s=\d+', '', url)
    url = re.sub(r'[?&]size=\d+', '', url)
    url = re.sub(r'/w\d+/', '/w2048/', url)
    return url.rstrip('?&')

def _fetch_avatar(url: str, size: int, circle: bool = False) -> "Image.Image | None":
    if not url:
        return None
    try:
        resp = requests.get(_hq_url(url), timeout=6,
                            headers={"User-Agent": "Mozilla/5.0"})
        resp.raise_for_status()
        raw = Image.open(BytesIO(resp.content)).convert("RGBA")
        iw, ih = raw.size
        s   = min(iw, ih)
        raw = raw.crop(((iw-s)//2, (ih-s)//2, (iw+s)//2, (ih+s)//2))
        raw = raw.resize((size, size), Image.LANCZOS)
        mask = Image.new("L", (size, size), 0)
        if circle:
            ImageDraw.Draw(mask).ellipse((0, 0, size-1, size-1), fill=255)
        else:
            ImageDraw.Draw(mask).rounded_rectangle(
                (0, 0, size-1, size-1), RADIUS, fill=255)
        out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        out.paste(raw, mask=mask)
        return out
    except Exception:
        return None

def _placeholder(size: int, circle: bool, rank: int) -> Image.Image:
    palette = [(120, 80, 180), (90, 60, 150), (70, 50, 130)]
    col = palette[min(rank - 1, len(palette) - 1)]
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d   = ImageDraw.Draw(img)
    if circle:
        d.ellipse((0, 0, size-1, size-1), fill=(*col, 220))
    else:
        d.rounded_rectangle((0, 0, size-1, size-1), RADIUS, fill=(*col, 220))
    d.text((size//2, size//2), "?",
           font=_font(size//2, True),
           fill=(255, 255, 255, 160), anchor="mm")
    return img


def _make_bg(w: int, h: int) -> Image.Image:
    img = Image.new("RGBA", (w, h), (60, 42, 128, 255))
    for y in range(h):
        t = y / h
        # tím → tím xanh: thêm xanh dương vào channel B và G nhẹ
        col = (int(60 + 40*t), int(42 + 10*t), int(128 + 20*t), 255)
        img.alpha_composite(Image.new("RGBA", (w, 1), col), (0, y))
    import random
    rng = random.Random(42)
    blobs = [
        (0.12, 0.20, 0.38, 0.40, ( 80,  80, 200),  90),   # xanh dương trái
        (0.88, 0.70, 0.32, 0.38, (160,  48, 130),  72),   # hồng tím phải
        (0.50, 0.50, 0.28, 0.32, ( 60,  80, 180),  68),   # xanh dương giữa
        (0.25, 0.80, 0.22, 0.25, (100,  70, 170),  50),
        (0.75, 0.15, 0.20, 0.22, (130,  60, 190),  50),
        (0.90, 0.10, 0.18, 0.20, ( 50, 100, 210),  55),   # xanh dương góc trên
    ]
    for cx_f, cy_f, rx_f, ry_f, col, alpha in blobs:
        cx = int(cx_f * w) + rng.randint(-8, 8)
        cy = int(cy_f * h) + rng.randint(-8, 8)
        rx, ry = int(rx_f * w), int(ry_f * h)
        blob = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        ImageDraw.Draw(blob).ellipse((cx-rx, cy-ry, cx+rx, cy+ry), fill=(*col, alpha))
        img.alpha_composite(blob.filter(ImageFilter.GaussianBlur(55)))
    return img


def _draw_rank_badge(canvas: Image.Image, cx: int, cy: int, rank: int, size: int = 32):
    """Vẽ badge hình tròn với số rank, màu accent theo hạng."""
    color = ACCENT.get(rank, (150, 130, 200, 210))
    layer = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    r = size // 2
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=color)
    # viền trắng mỏng
    d.ellipse((cx - r, cy - r, cx + r, cy + r), outline=(255, 255, 255, 180), width=2)
    canvas.alpha_composite(layer)
    # text rank
    medals = {1: "①", 2: "②", 3: "③"}
    label  = medals.get(rank, str(rank))
    fd = ImageDraw.Draw(canvas, "RGBA")
    ft = _font(size - 10, True)
    fd.text((cx, cy), label, font=ft, fill=(255, 255, 255, 255), anchor="mm")


def _draw_progress_bar(canvas: Image.Image, x: int, y: int, w: int, h: int,
                       ratio: float):
    """Vẽ progress bar, ratio ∈ [0, 1]."""
    _rrect(canvas, (x, y, x + w, y + h), h // 2, fill=C_BAR_BG)
    fill_w = max(0, int(w * min(ratio, 1.0)))
    if fill_w > 0:
        _rrect(canvas, (x, y, x + fill_w, y + h), h // 2, fill=C_BAR_FILL)


# ══════════════════════════════════════════════════════════════════════════════
#  TOP-3 CARD
# ══════════════════════════════════════════════════════════════════════════════
def _draw_top3_card(canvas: Image.Image, x: int, y: int, entry: dict,
                    card_h: int, max_count: int):
    cw   = TOP3_CARD_W
    ch   = card_h
    rank = entry["rank"]
    bg_map = {1: C_TOP1_BG, 2: C_TOP2_BG, 3: C_TOP3_BG}
    bg     = bg_map.get(rank, C_TOP3_BG)
    accent = ACCENT.get(rank, C_BORDER)

    # ── Card shadow (offset subtle) ────────────────────────────────────────
    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle(
        (x+4, y+4, x+cw+4, y+ch+4), RADIUS, fill=(0, 0, 0, 60)
    )
    canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(6)))

    # ── Card body ─────────────────────────────────────────────────────────
    _rrect(canvas, (x, y, x+cw, y+ch), RADIUS, fill=bg)

    # Accent border (màu theo rank)
    _rrect(canvas, (x, y, x+cw, y+ch), RADIUS, outline=accent, lw=2)

    # ── Top accent strip ──────────────────────────────────────────────────
    strip_h = 4
    strip = Image.new("RGBA", (cw - 4, strip_h), (0, 0, 0, 0))
    for i in range(cw - 4):
        t = i / (cw - 5)
        r_c, g_c, b_c, a_c = accent
        col = (r_c, g_c, b_c, int(a_c * (0.3 + 0.7 * (1 - abs(t - 0.5) * 2))))
        ImageDraw.Draw(strip).rectangle((i, 0, i, strip_h - 1), fill=col)
    canvas.alpha_composite(strip, (x + 2, y + RADIUS))

    # ── Avatar ────────────────────────────────────────────────────────────
    av_size = cw - 24
    av_img  = _fetch_avatar(entry.get("avatar", ""), av_size, circle=False)
    if av_img is None:
        av_img = _placeholder(av_size, False, rank)

    # mask bo trên, thẳng dưới
    mask = Image.new("L", (av_size, av_size), 0)
    md   = ImageDraw.Draw(mask)
    md.rounded_rectangle((0, 0, av_size-1, av_size-1), RADIUS, fill=255)
    md.rectangle((0, av_size-RADIUS-1, RADIUS, av_size-1), fill=255)
    md.rectangle((av_size-RADIUS-1, av_size-RADIUS-1, av_size-1, av_size-1), fill=255)
    av_out = Image.new("RGBA", (av_size, av_size), (0, 0, 0, 0))
    av_out.paste(av_img, mask=mask)
    canvas.alpha_composite(av_out, (x + 12, y + 12))

    # ── Text area ─────────────────────────────────────────────────────────
    d    = ImageDraw.Draw(canvas, "RGBA")
    tx   = x + 14
    maxw = cw - 28

    av_bottom   = y + 12 + av_size
    text_area_h = (y + ch) - av_bottom - 10
    SP          = 5

    name_raw = _safe_text(entry.get("name", "?"))
    cnt_raw  = f"{entry['count']:,} tin nhắn"

    cnt_txt, fc = _auto_fit(d, cnt_raw, 14, 9, bold=False, maxw=maxw)
    name_txt, fn = _auto_fit(d, name_raw, 21, 11, bold=True, maxw=maxw)

    nh = _th(d, name_txt, fn)
    ch_ = _th(d, cnt_txt, fc)

    # Progress bar height
    BAR_H    = 0
    total_h  = nh + SP + ch_
    ty = av_bottom + (text_area_h - total_h) // 2
    if ty < av_bottom + 6:
        ty = av_bottom + 6

    # Tên
    d.text((tx, ty), name_txt, font=fn, fill=C_NAME)

    # Count (thẳng dưới tên, không có progress bar)
    accent_text = ACCENT_TEXT.get(rank, C_COUNT)
    d.text((tx, ty + nh + SP), cnt_txt, font=fc, fill=accent_text)


# ══════════════════════════════════════════════════════════════════════════════
#  ROW (top 4-15)
# ══════════════════════════════════════════════════════════════════════════════
def _draw_row(canvas: Image.Image, x: int, y: int, w: int, entry: dict,
              max_count: int):
    rh   = ROW_H
    rank = entry["rank"]

    # shadow
    shadow = Image.new("RGBA", canvas.size, (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle(
        (x+3, y+3, x+w+3, y+rh+3), RADIUS, fill=(0, 0, 0, 45)
    )
    canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(4)))

    _rrect(canvas, (x, y, x+w, y+rh), RADIUS, fill=C_ROW_BG)
    _rrect(canvas, (x, y, x+w, y+rh), RADIUS, outline=C_BORDER, lw=1)

    # Rank pill badge
    badge_w, badge_h = 36, 22
    bx = x + 10
    by = y + (rh - badge_h) // 2
    _rrect(canvas, (bx, by, bx + badge_w, by + badge_h), 11,
           fill=(255, 255, 255, 35), outline=(255, 255, 255, 60), lw=1)
    d = ImageDraw.Draw(canvas, "RGBA")
    fb = _font(11, True)
    d.text((bx + badge_w // 2, by + badge_h // 2), f"{rank}",
           font=fb, fill=(255, 255, 255, 220), anchor="mm")

    # Avatar tròn
    av_img = _fetch_avatar(entry.get("avatar", ""), ROW_AV, circle=True)
    if av_img is None:
        av_img = _placeholder(ROW_AV, True, rank)
    av_x = bx + badge_w + 8
    av_y = y + (rh - ROW_AV) // 2
    canvas.alpha_composite(av_img, (av_x, av_y))

    tx   = av_x + ROW_AV + 10
    maxw = x + w - tx - 10

    name_raw = _safe_text(entry.get("name", "?"))
    name, fn = _auto_fit(d, name_raw, 18, 11, bold=True, maxw=maxw)
    nh = _th(d, name, fn)

    cnt_raw = f"{entry['count']:,} tin nhắn"
    cnt, fc = _auto_fit(d, cnt_raw, 13, 9, bold=False, maxw=maxw)
    sh = _th(d, cnt, fc)

    SP    = 5
    total = nh + SP + sh
    by2   = y + (rh - total) // 2

    d.text((tx, by2), name, font=fn, fill=C_NAME)
    d.text((tx, by2 + nh + SP), cnt, font=fc, fill=C_COUNT)


# ══════════════════════════════════════════════════════════════════════════════
#  HEADER
# ══════════════════════════════════════════════════════════════════════════════
def _draw_header(canvas: Image.Image, W: int, title: str, HEADER_H: int):
    d = ImageDraw.Draw(canvas, "RGBA")

    # Gradient underline
    ul_h = 3
    ul_y = PAD + HEADER_H - ul_h - 4
    ul = Image.new("RGBA", (W - PAD*2, ul_h), (0, 0, 0, 0))
    ul_w = W - PAD*2
    for i in range(ul_w):
        t = i / max(ul_w - 1, 1)
        alpha = int(220 * (1 - abs(t - 0.5) * 2))
        ImageDraw.Draw(ul).rectangle((i, 0, i, ul_h - 1),
                                     fill=(200, 160, 255, alpha))
    canvas.alpha_composite(ul, (PAD, ul_y))

    title_safe = _safe_text(title)
    fh  = _font(30, True)
    tw  = _tw(d, title_safe, fh)
    # subtle text shadow
    d.text(((W - tw) // 2 + 2, PAD + 16 + 2), title_safe,
           font=fh, fill=(0, 0, 0, 80))
    d.text(((W - tw) // 2, PAD + 16), title_safe,
           font=fh, fill=C_WHITE_A)


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════════
def draw_top_chat(entries: list, out_path: str,
                  title: str = "TOP CHAT") -> tuple:
    if not entries:
        entries = []

    top3 = entries[:3]
    rest = entries[3:]
    max_count = max((e["count"] for e in entries), default=1)

    HEADER_H  = 72
    top1_h    = TOP3_CARD_H + TOP1_EXTRA
    top23_h   = TOP3_CARD_H

    # Top3 row height = max card
    top3_row_h = top1_h if top3 else 0
    top3_row_w = len(top3) * TOP3_CARD_W + max(0, len(top3) - 1) * GAP

    ROW_W    = TOP3_CARD_W * 3 + GAP * 2
    cell_w   = (ROW_W - GAP * (COLS - 1)) // COLS
    rest_rows = math.ceil(len(rest) / COLS) if rest else 0
    rest_h    = rest_rows * ROW_H + max(0, rest_rows - 1) * GAP

    W = PAD * 2 + ROW_W
    H = (PAD
         + HEADER_H + GAP
         + top3_row_h + (GAP if top3_row_h else 0)
         + rest_h
         + PAD)

    canvas = _make_bg(W, H)
    _draw_header(canvas, W, title, HEADER_H)

    # Top 3
    y_base  = PAD + HEADER_H + GAP
    x_start = PAD + (ROW_W - top3_row_w) // 2
    for i, entry in enumerate(top3):
        cx = x_start + i * (TOP3_CARD_W + GAP)
        if entry["rank"] == 1:
            card_h = top1_h
            cy     = y_base  # top 1 aligned to top
        else:
            card_h = top23_h
            cy     = y_base + TOP1_EXTRA  # #2, #3 sink a bit (podium)
        _draw_top3_card(canvas, cx, cy, entry, card_h, max_count)

    # Rows top 4-15
    y_rest = y_base + (top1_h + GAP if top3 else 0)
    for i, entry in enumerate(rest):
        col = i % COLS
        row = i // COLS
        rx  = PAD + col * (cell_w + GAP)
        ry  = y_rest + row * (ROW_H + GAP)
        _draw_row(canvas, rx, ry, cell_w, entry, max_count)

    out_dir = os.path.dirname(out_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    canvas.convert("RGB").save(out_path, "JPEG", quality=95)
    return W, H
