import os, threading, random
import requests
from io import BytesIO
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageFont

W, H  = 2560, 1440
COLS  = 6
ROWS  = 2
PAD   = 40
GAP   = 16

# Nền tím-hồng-xanh pha nhau
GRAD = [
    (( 72,  18, 120), (180,  30, 120)),   # tím → hồng (top)
    (( 20,  40, 140), ( 90,  20, 140)),   # xanh → tím (bottom)
]

C_CARD_BG    = ( 20,  12,  35, 130)   # tối hơn, trong hơn — bớt nổi
C_GOLD       = (180, 145,  40, 160)   # viền vàng nhạt hơn
C_NUM        = (255, 255, 255, 255)
C_TITLE      = (240, 240, 255)
C_ARTIST     = (150, 190, 230)
C_DUR        = (160, 135, 200)

_mask_cache: dict = {}

def _resolve_font():
    try:
        base = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static" / "Opensans"
        b = base / "OpenSans-Bold.ttf"
        r = base / "OpenSans-Regular.ttf"
        if b.exists() and r.exists():
            return str(b), str(r)
    except Exception:
        pass
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )

FONT_BOLD, FONT_REG = _resolve_font()

def _font(size, bold=False):
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)
    except Exception:
        return ImageFont.load_default()

def _make_bg():
    # 4-corner gradient: tím-hồng-xanh
    img = Image.new("RGB", (W, H))
    px  = img.load()
    tl = ( 72,  18, 120)
    tr = ( 20,  60, 160)
    bl = (160,  20, 100)
    br = ( 40,  20, 140)
    for y in range(H):
        fy = y / H
        for x in range(W):
            fx = x / W
            r = int(tl[0]*(1-fx)*(1-fy) + tr[0]*fx*(1-fy) + bl[0]*(1-fx)*fy + br[0]*fx*fy)
            g = int(tl[1]*(1-fx)*(1-fy) + tr[1]*fx*(1-fy) + bl[1]*(1-fx)*fy + br[1]*fx*fy)
            b = int(tl[2]*(1-fx)*(1-fy) + tr[2]*fx*(1-fy) + bl[2]*(1-fx)*fy + br[2]*fx*fy)
            px[x, y] = (r, g, b)
    return img.convert("RGBA")

def _make_bg_fast():
    # Random pha giữa tone hồng và tone xanh — vẫn dùng 2x2 resize, siêu nhanh
    PINK_TONES = [
        (130,  40,  80),
        (120,  30,  70),
        (140,  50,  90),
        (125,  35,  75),
    ]
    BLUE_TONES = [
        ( 30,  55, 130),
        ( 20,  65, 120),
        ( 40,  45, 140),
        ( 25,  60, 115),
    ]
    PURPLE_TONES = [
        ( 70,  25, 110),
        ( 60,  18,  95),
        ( 80,  35, 120),
        ( 65,  22, 105),
    ]
    all_pools = [PINK_TONES, BLUE_TONES, PURPLE_TONES]
    def pick(): return random.choice(random.choice(all_pools))
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), pick())
    c.putpixel((1, 0), pick())
    c.putpixel((0, 1), pick())
    c.putpixel((1, 1), pick())
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")

def _rounded_mask(w, h, r, aa=3):
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w*aa, h*aa
        mr = int(min(r, w//2, h//2)*aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]

def _load_cover(url, size):
    blank = Image.new("RGBA", size, (35, 18, 60, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=6, headers={"User-Agent":"Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        s   = min(w0, h0)
        img = img.crop(((w0-s)//2, (h0-s)//2, (w0+s)//2, (h0+s)//2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank

def _fit(draw, text, fnt, max_w):
    text = str(text or "")
    if draw.textlength(text, font=fnt) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=fnt)
    out  = ""
    for ch in text:
        if draw.textlength(out+ch, font=fnt) > room:
            break
        out += ch
    return out + ell

def _wrap2(draw, text, fnt, max_w):
    """Wrap text vào tối đa 2 dòng, dòng 2 truncate nếu quá dài."""
    text = str(text or "")
    words = text.split()
    line1, line2 = [], []
    for w in words:
        trial = " ".join(line1 + [w])
        if draw.textlength(trial, font=fnt) <= max_w:
            line1.append(w)
        else:
            line2.append(w)
    l1 = " ".join(line1)
    l2 = " ".join(line2)
    if l2:
        l2 = _fit(draw, l2, fnt, max_w)
    return l1, l2

def _fmt_dur(ms):
    if isinstance(ms, str): return ms
    ms = int(ms or 0)
    sec = ms if ms < 10000 else ms // 1000
    m, s = divmod(sec, 60)
    return f"{m}:{s:02d}"

def _extract(item):
    author = item.get("author") or {}
    name   = (author.get("nickname") or author.get("unique_id")
              or author.get("uniqueId") or "")
    vid    = item.get("video") or {}
    cover  = vid.get("cover") or item.get("cover") or item.get("origin_cover") or ""
    dur    = vid.get("duration") or item.get("duration") or 0
    title  = item.get("desc") or item.get("title") or "TikTok"
    return title, name, dur, cover


def draw_tiktok_list(items, out_path, keyword=""):
    items = (items or [])[:COLS*ROWS]
    n     = len(items)

    CARD_W = (W - PAD*2 - GAP*(COLS-1)) // COLS
    CARD_H = (H - PAD*2 - GAP*(ROWS-1)) // ROWS
    THUMB  = CARD_W - 12
    TEXT_H = CARD_H - THUMB - 10

    # Font nhỏ hơn
    f_title  = _font(int(TEXT_H * 0.21), bold=True)
    f_artist = _font(int(TEXT_H * 0.16))
    f_dur    = _font(int(TEXT_H * 0.14))
    f_num    = _font(int(THUMB   * 0.085), bold=True)

    # Tải ảnh song song — ThreadPoolExecutor nhanh hơn Thread thủ công
    covers = [None] * n
    def _fetch(i):
        _, _, _, url = _extract(items[i])
        covers[i] = _load_cover(url, (THUMB, THUMB))

    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(_fetch, range(n)))

    canvas = _make_bg_fast()
    d      = ImageDraw.Draw(canvas, "RGBA")

    for idx in range(n):
        col = idx % COLS
        row = idx // COLS
        cx  = PAD + col*(CARD_W + GAP)
        cy  = PAD + row*(CARD_H + GAP)

        # Card bg
        layer = Image.new("RGBA", (CARD_W, CARD_H), (0,0,0,0))
        mask  = _rounded_mask(CARD_W, CARD_H, 20)
        layer.paste(Image.new("RGBA", (CARD_W, CARD_H), C_CARD_BG), (0,0), mask)
        # Viền vàng tất cả các card
        ImageDraw.Draw(layer).rounded_rectangle(
            (0, 0, CARD_W-1, CARD_H-1), 20,
            outline=C_GOLD, width=2
        )
        canvas.alpha_composite(layer, (cx, cy))

        # Thumbnail
        tx = cx + (CARD_W - THUMB) // 2
        ty = cy + 6
        if covers[idx]:
            canvas.paste(covers[idx], (tx, ty), _rounded_mask(THUMB, THUMB, 14))

        # Số thứ tự — góc dưới phải card, sáng rõ
        num_str = str(idx+1)
        nw = int(d.textlength(num_str, font=f_num))
        d.text(
            (cx + CARD_W - nw - 8, cy + CARD_H - f_num.size - 8),
            num_str, font=f_num, fill=C_NUM
        )

        # Text — title 2 dòng, rồi cách ra, rồi artist + duration
        title, artist, dur, _ = _extract(items[idx])
        lx  = cx + 7
        mw  = CARD_W - 14
        ty0 = ty + THUMB + 8

        line1, line2 = _wrap2(d, title, f_title, mw)
        d.text((lx, ty0), line1, font=f_title, fill=C_TITLE)
        title_h = f_title.size
        if line2:
            d.text((lx, ty0 + title_h + 2), line2, font=f_title, fill=C_TITLE)
            title_block_h = title_h * 2 + 2
        else:
            title_block_h = title_h

        ty1   = ty0 + title_block_h + 8   # cách ra 8px giữa title và artist
        dur_s = _fmt_dur(dur)
        dw    = int(d.textlength(dur_s, font=f_dur))
        d.text((lx, ty1), _fit(d, artist, f_artist, mw-dw-10), font=f_artist, fill=C_ARTIST)
        d.text((cx + CARD_W - 7 - dw, ty1), dur_s, font=f_dur, fill=C_DUR)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=90, optimize=False)
    return out_path
