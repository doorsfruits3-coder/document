from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os, random, io

try:
    import requests as _requests
    _HAS_REQUESTS = True
except ImportError:
    _HAS_REQUESTS = False
try:
    import numpy as np
    _HAS_NUMPY = True
except ImportError:
    _HAS_NUMPY = False

W      = 1400
H      = 980  
PAD    = 72
COLS   = 4
ROWS   = 4         
CARD_R = 18

GRADIENTS = [
    ((110, 70, 130), (160, 90, 120), (140, 80, 150)),
    (( 60, 80, 160), (130, 60, 140), ( 90, 90, 180)),
    ((130, 60,  90), ( 80, 60, 160), (110, 70, 130)),
    (( 50, 90, 130), (100, 70, 150), ( 70,100, 160)),
    ((100, 50, 110), (160, 80,  90), (130, 60, 120)),
    (( 70, 60, 150), (140, 70, 110), (100, 65, 140)),
]

PERM = {
    4: ("DEV",       (120,  40, 200, 230), (240, 210, 255)),   # Developer - tím
    3: ("HI ADMIN",  (210,  50,  50, 220), (255, 210, 210)),   # High admin - đỏ
    2: ("BOT ADMIN", (200, 170,  30, 220), (255, 248, 180)),   # Bot admin - vàng
    1: ("GRP ADMIN", ( 40, 180,  80, 220), (190, 255, 215)),   # Group admin - xanh
    0: ("USR",       ( 40, 110, 220, 210), (200, 225, 255)),   # User - xanh dương
}

_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT_DIR = os.path.abspath(os.path.join(_BASE_DIR, "..", "..", ".."))
f_regular = os.path.join(_ROOT_DIR, "assets", "font", "zendot.ttf")
f_bold    = os.path.join(_ROOT_DIR, "assets", "font", "Milker.otf")
_fc = {}

def font(sz, bold=False):
    k = (sz, bold)
    if k not in _fc:
        _fc[k] = ImageFont.truetype(f_bold if bold else f_regular, sz)
    return _fc[k]

def tsz(d, txt, f):
    b = d.textbbox((0, 0), txt, font=f)
    return b[2] - b[0], b[3] - b[1]

def wrap(d, txt, f, max_w, max_lines=2):
    words = txt.split()
    lines, cur = [], ""
    for w in words:
        test = (cur + " " + w).strip()
        if tsz(d, test, f)[0] <= max_w:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = w
            if len(lines) == max_lines:
                break
    if cur and len(lines) < max_lines:
        lines.append(cur)
    if lines and len(lines) == max_lines:
        last = lines[-1]
        while tsz(d, last + "…", f)[0] > max_w and last:
            last = last[:-1]
        lines[-1] = last + "…"
    return lines

def alpha_rounded(img, box, radius, color_rgba):
    x1, y1, x2, y2 = (int(v) for v in box)
    w, h = x2 - x1, y2 - y1
    if w <= 0 or h <= 0:
        return
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(
        (0, 0, w - 1, h - 1), radius, fill=color_rgba
    )
    img.alpha_composite(layer, (x1, y1))

def alpha_rect(img, box, color_rgba):
    x1, y1, x2, y2 = (int(v) for v in box)
    w, h = x2 - x1, y2 - y1
    if w <= 0 or h <= 0:
        return
    layer = Image.new("RGBA", (w, h), color_rgba)
    img.alpha_composite(layer, (x1, y1))

def rounded_border(img, box, radius, color_rgba, width=1):
    x1, y1, x2, y2 = (int(v) for v in box)
    w, h = x2 - x1, y2 - y1
    if w <= 0 or h <= 0:
        return
    layer = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(
        (0, 0, w - 1, h - 1), radius,
        outline=color_rgba, width=width
    )
    img.alpha_composite(layer, (x1, y1))

_BG_CACHE: dict = {}   # seed → Image (RGBA), tối đa 6 entry

def make_bg(seed):
    if seed in _BG_CACHE:
        return _BG_CACHE[seed].copy()

    rng = random.Random(seed)
    c1, c2, cmid = rng.choice(GRADIENTS)

    def lerp(a, b, t):
        return int(a + (b - a) * t)

    def corner(t):
        return (lerp(c1[0], c2[0], t), lerp(c1[1], c2[1], t),
                lerp(c1[2], c2[2], t), 255)

    tiny = Image.new("RGBA", (2, 2))
    tiny.putpixel((0, 0), corner(0.0))
    tiny.putpixel((1, 0), corner(0.5))
    tiny.putpixel((0, 1), corner(0.5))
    tiny.putpixel((1, 1), corner(1.0))
    img = tiny.resize((W, H), Image.BILINEAR)

    # Glow — blur nhỏ hơn (120 thay 300) vẫn đẹp mà nhanh ~6x
    glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(glow).ellipse(
        (W // 2 - 520, H // 2 - 460, W // 2 + 520, H // 2 + 460),
        fill=(*cmid, 55)
    )
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(120)))

    # Noise: numpy vectorized thay vì loop 175k lần
    if _HAS_NUMPY:
        rng_np = np.random.default_rng(seed + 7)
        alpha  = rng_np.integers(0, 15, size=(H, W), dtype=np.uint8)
        noise_arr = np.zeros((H, W, 4), dtype=np.uint8)
        noise_arr[..., :3] = 255
        noise_arr[..., 3]  = alpha
        img.alpha_composite(Image.fromarray(noise_arr, "RGBA"))
    else:
        # fallback nhẹ hơn: chỉ 4k điểm thay 175k
        rng2  = random.Random(seed + 7)
        noise = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        nd    = ImageDraw.Draw(noise)
        for _ in range(4000):
            nx = rng2.randint(0, W - 1)
            ny = rng2.randint(0, H - 1)
            a  = rng2.randint(0, 14)
            nd.point((nx, ny), fill=(255, 255, 255, a))
        img.alpha_composite(noise)

    # Cache — giữ tối đa 6 background khác nhau
    if len(_BG_CACHE) >= 6:
        _BG_CACHE.pop(next(iter(_BG_CACHE)))
    _BG_CACHE[seed] = img.copy()
    return img

def _decode_jxl_to_bytes(data: bytes) -> bytes:
    """Convert JXL bytes → JPEG bytes (giống stickerCore)."""
    try:
        import pillow_jxl
        img = Image.open(io.BytesIO(data)).convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=95)
        return buf.getvalue()
    except ImportError:
        pass
    try:
        from jxlpy import JXLPyDecoder
        decoder = JXLPyDecoder(data)
        info    = decoder.get_info()
        w, h    = info["xsize"], info["ysize"]
        pixels, mode = decoder.get_frame()
        img = Image.frombytes(mode, (w, h), pixels)
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=95)
        return buf.getvalue()
    except Exception as e:
        raise Exception(f"Không đọc được JXL: {e}")


def make_bg_from_url(url: str):
    """Download ảnh (hỗ trợ JXL) từ URL và resize về kích thước menu.
    Trả về (Image, None) nếu OK, (None, error_msg) nếu lỗi.
    """
    if not _HAS_REQUESTS:
        return None, "Thiếu thư viện requests"
    try:
        resp = _requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=10)
        resp.raise_for_status()
        data = resp.content

        # Detect JXL bằng magic bytes
        _is_jxl = (
            data[:2] == b'\xff\x0a' or
            data[:12] == b'\x00\x00\x00\x0cJXL \r\n\x87\n'
        )
        if _is_jxl:
            try:
                data = _decode_jxl_to_bytes(data)
            except Exception as e:
                return None, str(e)

        try:
            img = Image.open(io.BytesIO(data)).convert("RGBA")
        except Exception as e:
            fmt = url.split(".")[-1].split("?")[0].upper()
            return None, f"Pillow không hỗ trợ định dạng .{fmt.lower()} ({e})"

        # Crop-center rồi resize
        iw, ih = img.size
        scale  = max(W / iw, H / ih)
        nw, nh = int(iw * scale), int(ih * scale)
        img    = img.resize((nw, nh), Image.LANCZOS)
        left   = (nw - W) // 2
        top    = (nh - H) // 2
        img    = img.crop((left, top, left + W, top + H))
        # Overlay tối nhẹ để text dễ đọc
        overlay = Image.new("RGBA", (W, H), (0, 0, 0, 90))
        img.alpha_composite(overlay)
        return img, None
    except Exception as e:
        return None, str(e)

HEADER_H = 148

def draw_header(img, d, bot_name, page, total_page, prefix="."):
    part1   = f"Kefl - "
    part2   = bot_name
    f_title = font(68, False)
    w1, _   = tsz(d, part1, f_title)
    w2, _   = tsz(d, part2, f_title)
    tx      = (W - w1 - w2) // 2
    d.text((tx,      22), part1, font=f_title, fill=(255, 255, 255, 200))
    d.text((tx + w1, 22), part2, font=f_title, fill=(255, 255, 255, 248))

    if page == 1:
        if total_page > 1:
            page_txt = f"Page 1 /  {total_page}"
        else:
            page_txt = "Page 1"
    else:
        page_txt = f"Page {page} / {total_page}"

    pw, _ = tsz(d, page_txt, font(28))
    d.text(((W - pw) // 2, 106), page_txt,
           font=font(28), fill=(255, 255, 255, 160))

    alpha_rect(img, (PAD, HEADER_H - 1, W - PAD, HEADER_H), (255, 255, 255, 28))

def draw_cards(img, d, items, prefix):
    gap     = 18
    avail_w = W - PAD * 2
    cw      = (avail_w - gap * (COLS - 1)) // COLS

    avail_h = H - HEADER_H - 26 - PAD
    ch      = (avail_h - gap * (ROWS - 1)) // ROWS

    start_y = HEADER_H + 26
    start_x = PAD

    for i, it in enumerate(items):
        col_i = i % COLS
        row   = i // COLS
        x1 = start_x + col_i * (cw + gap)
        y1 = start_y + row   * (ch + gap)
        x2 = x1 + cw
        y2 = y1 + ch

        lvl = it.get("permission", 0)
        badge_lbl, badge_bg, badge_fg = PERM.get(lvl, PERM[0])

        alpha_rounded(img, (x1, y1, x2, y2), CARD_R, (255, 255, 255, 34))
        rounded_border(img, (x1, y1, x2, y2), CARD_R, (255, 255, 255, 20), width=1)

        inner = x1 + 18

        d.text((inner, y1 + 12), it["name"],
               font=font(30, True), fill=(255, 255, 255, 242))

        hint = f"{prefix}{it['name'].lower()}"
        d.text((inner, y1 + 50), hint,
               font=font(19), fill=(255, 255, 255, 108))

        desc = it.get("description", "")
        if desc:
            dlines = wrap(d, desc, font(17), cw - 36, 1)
            for j, ln in enumerate(dlines):
                d.text((inner, y1 + 78 + j * 22), ln,
                       font=font(17), fill=(255, 255, 255, 125))

        bw, bh = tsz(d, badge_lbl, font(15, True))
        bpad = 10
        bx1 = x2 - bw - bpad * 2 - 8
        by1 = y2 - bh - 14
        bx2 = bx1 + bw + bpad * 2
        by2 = by1 + bh + 8
        alpha_rounded(img, (bx1, by1, bx2, by2), 7, badge_bg)
        d.text((bx1 + bpad, by1 + 4), badge_lbl,
               font=font(15, True), fill=(*badge_fg, 235))

MAX_PER_PAGE = COLS * ROWS 

def draw_menu(
    cmds,
    out_path,
    page=1,
    total_page=1,
    prefix=".",
    user_level=0,
    bot_name="Bot",
    seed=None,
    bg_url=None,
):

    if seed is None:
        seed = random.randint(0, 99999)

    # Ưu tiên bg_url nếu có, fallback về gradient
    img = None
    if bg_url:
        img, err = make_bg_from_url(bg_url)
        # err bị bỏ qua ở đây — caller nên validate trước khi lưu
    if img is None:
        img = make_bg(seed)
    d   = ImageDraw.Draw(img, "RGBA")

    draw_header(img, d, bot_name, page, total_page, prefix=prefix)
    draw_cards(img, d, cmds, prefix)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=92, optimize=False)
    return img.size