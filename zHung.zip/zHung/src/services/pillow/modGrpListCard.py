import os, random
from io import BytesIO
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

import requests
from PIL import Image, ImageDraw, ImageFont

W, H     = 2560, 1440
COLS     = 5
ROWS     = 2
PAD      = 44
GAP      = 18
PER_PAGE = COLS * ROWS  # 10

C_CARD_BG = (12,  8,  30, 140)
C_BORDER  = (80, 130, 220, 170)
C_NUM     = (255, 255, 255, 255)
C_NAME    = (220, 235, 255)
C_MEMBERS = (140, 180, 230)
C_PAGE    = (100, 140, 200)

_mask_cache: dict = {}


# ── Font ──────────────────────────────────────────────────────────────────────
def _resolve_font():
    try:
        base = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static" / "Opensans"
        b = base / "OpenSans-Bold.ttf"
        r = base / "OpenSans-Regular.ttf"
        if b.exists() and r.exists():
            return str(b), str(r)
    except Exception:
        pass
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )

FONT_BOLD, FONT_REG = _resolve_font()

def _font(size, bold=False):
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)
    except Exception:
        return ImageFont.load_default()


# ── Nền ───────────────────────────────────────────────────────────────────────
_BG_TONES = [
    [(10, 20, 60), (30, 10, 80),  (5,  30, 70),  (20,  8, 55)],
    [(5,  15, 70), (20, 8,  60),  (15, 25, 55),  (25, 12, 75)],
    [(8,  18, 65), (28, 10, 72),  (10, 22, 60),  (22, 14, 68)],
]

def _make_bg():
    tl, tr, bl, br = random.choice(_BG_TONES)
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), tl); c.putpixel((1, 0), tr)
    c.putpixel((0, 1), bl); c.putpixel((1, 1), br)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


# ── Mask bo góc ───────────────────────────────────────────────────────────────
def _rounded_mask(w, h, r, aa=3):
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w * aa, h * aa
        mr = int(min(r, w // 2, h // 2) * aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]


# ── Load ảnh avatar ───────────────────────────────────────────────────────────
def _load_avatar(url, size):
    blank = Image.new("RGBA", size, (20, 15, 50, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        s   = min(w0, h0)
        img = img.crop(((w0 - s) // 2, (h0 - s) // 2, (w0 + s) // 2, (h0 + s) // 2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank


# ── Text helpers ──────────────────────────────────────────────────────────────
def _fit(draw, text, fnt, max_w):
    text = str(text or "")
    if draw.textlength(text, font=fnt) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=fnt)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=fnt) > room:
            break
        out += ch
    return out + ell

def _wrap2(draw, text, fnt, max_w):
    text  = str(text or "")
    words = text.split()
    l1, l2 = [], []
    for w in words:
        if draw.textlength(" ".join(l1 + [w]), font=fnt) <= max_w:
            l1.append(w)
        else:
            l2.append(w)
    return " ".join(l1), (_fit(draw, " ".join(l2), fnt, max_w) if l2 else "")


# ── Hàm chính ─────────────────────────────────────────────────────────────────
def draw_group_list(groups, out_path, page=1, total_pages=1):
    """
    groups: list[dict] – mỗi item: { name, id, avatar, totalMember }
    Vẽ tối đa PER_PAGE (10) nhóm / trang.
    """
    items = (groups or [])[:PER_PAGE]
    n     = len(items)

    CARD_W = (W - PAD * 2 - GAP * (COLS - 1)) // COLS
    CARD_H = (H - PAD * 2 - GAP * (ROWS - 1)) // ROWS
    THUMB  = CARD_W - 12
    TEXT_H = CARD_H - THUMB - 10

    f_name = _font(int(TEXT_H * 0.22), bold=True)
    f_mem  = _font(int(TEXT_H * 0.17))
    f_num  = _font(int(THUMB  * 0.09), bold=True)
    f_page = _font(38)

    # Tải avatar song song
    avatars = [None] * n
    def _fetch(i):
        avatars[i] = _load_avatar(items[i].get("avatar", ""), (THUMB, THUMB))
    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(_fetch, range(n)))

    canvas = _make_bg()
    d      = ImageDraw.Draw(canvas, "RGBA")

    for idx in range(n):
        col = idx % COLS
        row = idx // COLS
        cx  = PAD + col * (CARD_W + GAP)
        cy  = PAD + row * (CARD_H + GAP)

        # Card nền
        layer = Image.new("RGBA", (CARD_W, CARD_H), (0, 0, 0, 0))
        mask  = _rounded_mask(CARD_W, CARD_H, 20)
        layer.paste(Image.new("RGBA", (CARD_W, CARD_H), C_CARD_BG), (0, 0), mask)
        ImageDraw.Draw(layer).rounded_rectangle(
            (0, 0, CARD_W - 1, CARD_H - 1), 20, outline=C_BORDER, width=2
        )
        canvas.alpha_composite(layer, (cx, cy))

        # Avatar
        tx = cx + (CARD_W - THUMB) // 2
        ty = cy + 6
        if avatars[idx]:
            canvas.paste(avatars[idx], (tx, ty), _rounded_mask(THUMB, THUMB, 14))

        # Số thứ tự
        num_str = str(idx + 1)
        nw = int(d.textlength(num_str, font=f_num))
        d.text(
            (cx + CARD_W - nw - 8, cy + CARD_H - f_num.size - 8),
            num_str, font=f_num, fill=C_NUM,
        )

        # Tên nhóm
        name = items[idx].get("name") or "Nhóm không tên"
        lx   = cx + 7
        mw   = CARD_W - 14
        ty0  = ty + THUMB + 8

        line1, line2 = _wrap2(d, name, f_name, mw)
        d.text((lx, ty0), line1, font=f_name, fill=C_NAME)
        title_h = f_name.size
        if line2:
            d.text((lx, ty0 + title_h + 2), line2, font=f_name, fill=C_NAME)
            title_block_h = title_h * 2 + 2
        else:
            title_block_h = title_h

        # Số thành viên
        mem  = items[idx].get("totalMember") or items[idx].get("memberCount") or "?"
        mem_str = f"👥 {mem} thành viên"
        d.text((lx, ty0 + title_block_h + 6), _fit(d, mem_str, f_mem, mw),
               font=f_mem, fill=C_MEMBERS)

    # Số trang dưới cùng
    page_str = f"Trang {page}/{total_pages}"
    pw = int(d.textlength(page_str, font=f_page))
    d.text(((W - pw) // 2, H - PAD // 2 - f_page.size), page_str, font=f_page, fill=C_PAGE)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=88, optimize=False)
    return out_path
