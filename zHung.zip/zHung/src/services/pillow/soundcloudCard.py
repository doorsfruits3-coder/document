"""
soundcloudCard.py  –  single-song card cho SoundCloud
Style: giống zingCard nhưng dùng palette cam/đen SoundCloud
Output: JPEG 2048×622
"""
import os, math, random
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

W, H = 2048, 622
PAD  = 48

_ASSET_FONT = Path(__file__).resolve().parents[3] / "assets" / "font"
FONT_BOLD   = str(_ASSET_FONT / "Opensans" / "static" / "Opensans" / "OpenSans-Bold.ttf")
FONT_REG    = str(_ASSET_FONT / "Opensans" / "static" / "Opensans" / "OpenSans-Regular.ttf")

# ── SoundCloud palette ──────────────────────────────────────────────────────
GRAD_TL = ( 18,  18,  18)   # near-black
GRAD_TR = ( 30,  18,  10)   # dark brown-black
GRAD_BL = ( 28,  22,  12)
GRAD_BR = ( 40,  20,   5)   # hint of orange warmth

TEXT_TITLE  = (255, 255, 255)
TEXT_ARTIST = (200, 200, 200)
TEXT_TIME   = (180, 180, 180)

# SoundCloud orange waveform
WAVE_COLOR  = (255, 85, 0, 220)   # #FF5500


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    path = FONT_BOLD if bold else FONT_REG
    try:
        return ImageFont.truetype(path, size)
    except Exception:
        return ImageFont.load_default()


def _make_bg() -> Image.Image:
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), GRAD_TL)
    c.putpixel((1, 0), GRAD_TR)
    c.putpixel((0, 1), GRAD_BL)
    c.putpixel((1, 1), GRAD_BR)
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _rounded_mask(w: int, h: int, r: int, aa: int = 4) -> Image.Image:
    mw, mh = w * aa, h * aa
    mr = int(min(r, w // 2, h // 2) * aa)
    m  = Image.new("L", (mw, mh), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def _load_cover(url, size: tuple) -> Image.Image:
    blank = Image.new("RGBA", size, (30, 20, 10, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=8)
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        s   = min(w0, h0)
        img = img.crop(((w0-s)//2, (h0-s)//2, (w0+s)//2, (h0+s)//2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank


def _fmt_duration(t) -> str:
    if isinstance(t, str):
        return t
    t = int(t or 0)
    m, s = divmod(t, 60)
    return f"{m}:{s:02d}"


def _draw_waveform(draw: ImageDraw.ImageDraw,
                   x0: int, y_center: int, width: int, amp: int,
                   seed: int = 42):
    """Vẽ waveform giả màu cam SoundCloud."""
    rng  = random.Random(seed)
    bars = 52
    gap  = 4
    bar_w = max(4, (width - gap * (bars - 1)) // bars)
    total = bars * bar_w + gap * (bars - 1)
    off_x = x0 + (width - total) // 2

    for i in range(bars):
        t   = i / (bars - 1)
        h_f = 0.30 + 0.70 * abs(math.sin(math.pi * t * 3.2 + 0.5))
        h_f = h_f * (0.65 + 0.35 * rng.random())
        bh  = max(6, int(amp * h_f))

        bx1 = off_x + i * (bar_w + gap)
        bx2 = bx1 + bar_w
        by1 = y_center - bh // 2
        by2 = y_center + bh // 2
        # Gradient từ cam đậm → cam sáng theo vị trí
        alpha = int(140 + 100 * abs(math.sin(math.pi * t)))
        draw.rounded_rectangle(
            (bx1, by1, bx2, by2),
            radius=bar_w // 2,
            fill=(*WAVE_COLOR[:3], alpha)
        )


def draw_soundcloud_card(song: dict, out_path: str) -> str:
    """
    Vẽ card SoundCloud style.

    song dict keys:
        cover    – URL ảnh bìa
        title    – tên bài
        artist   – tên nghệ sĩ
        duration – số giây (int) hoặc chuỗi "M:SS"
    """
    img = _make_bg()

    cover_size = H - PAD * 2
    cover_img  = _load_cover(song.get("cover"), (cover_size, cover_size))

    # Viền ảnh bìa
    border_sz = cover_size + 6
    border    = Image.new("RGBA", (border_sz, border_sz), (0, 0, 0, 140))
    img.paste(border, (PAD - 3, PAD - 3), _rounded_mask(border_sz, border_sz, 34))
    img.paste(cover_img, (PAD, PAD), _rounded_mask(cover_size, cover_size, 32))

    # ── Text area ───────────────────────────────────────────────────────────
    tx    = PAD + cover_size + 60
    max_w = W - tx - PAD - 20
    d     = ImageDraw.Draw(img)

    title_sz  = int(H * 0.22)
    artist_sz = int(H * 0.10)
    time_sz   = int(H * 0.09)
    f_title   = _font(title_sz,  bold=True)
    f_artist  = _font(artist_sz, bold=False)
    f_time    = _font(time_sz,   bold=False)

    title_str  = song.get("title",  "Unknown")
    artist_str = song.get("artist", "Unknown")
    dur_str    = _fmt_duration(song.get("duration", 0))

    # Truncate title
    ell = "..."
    if d.textlength(title_str, font=f_title) > max_w:
        while len(title_str) > 1 and d.textlength(title_str + ell, font=f_title) > max_w:
            title_str = title_str[:-1]
        title_str += ell

    cover_top    = PAD
    cover_bottom = PAD + cover_size
    ty_title     = cover_top
    ty_artist    = cover_bottom - artist_sz - 28

    wave_top    = ty_title + title_sz + 16
    wave_bottom = ty_artist - 16
    wave_height = wave_bottom - wave_top
    wave_amp    = max(20, wave_height - 16)
    wave_y_ctr  = wave_top + wave_height // 2

    # Glow cam phía sau title
    if wave_height > 20:
        glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        ImageDraw.Draw(glow).text(
            (tx + 3, ty_title + 5), title_str,
            font=f_title, fill=(255, 85, 0, 18)
        )
        img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(10)))

    # Title
    d.text((tx, ty_title), title_str, font=f_title, fill=TEXT_TITLE)

    # Waveform
    if wave_height > 30:
        wave_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        _draw_waveform(
            ImageDraw.Draw(wave_layer),
            tx, wave_y_ctr, max_w, wave_amp,
            seed=hash(title_str) & 0xFFFF
        )
        img.alpha_composite(wave_layer)
        d = ImageDraw.Draw(img)

    # Artist + duration
    d.text((tx, ty_artist), artist_str, font=f_artist, fill=TEXT_ARTIST)
    dur_w = int(d.textlength(dur_str, font=f_time))
    d.text((W - PAD - dur_w, ty_artist), dur_str, font=f_time, fill=TEXT_TIME)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=92, optimize=False)
    return out_path
