import os
import requests
from io import BytesIO
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 2560, 1440
PAD  = 60

_mask_cache: dict = {}
_bg_cache: Image.Image | None = None


def _resolve_font() -> tuple[str, str]:
    base = Path(__file__).resolve().parents[3] / "assets" / "font"
    candidates = [
        (base / "Goldman" / "Goldman-Bold.ttf",   base / "Goldman" / "Goldman-Regular.ttf"),
        (base / "Opensans" / "static" / "OpenSans_Condensed-Bold.ttf",
         base / "Opensans" / "static" / "OpenSans_Condensed-Regular.ttf"),
    ]
    for bold, reg in candidates:
        if bold.exists() and reg.exists():
            return str(bold), str(reg)
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )


FONT_BOLD, FONT_REG = _resolve_font()

GRAD_TL = (10,  8, 22)
GRAD_TR = (18, 10, 36)
GRAD_BL = (14, 10, 28)
GRAD_BR = (24, 14, 44)

ACCENT        = (160, 100, 255)
ACCENT_DIM    = (100,  60, 200)
NUM_COLOR     = (255, 190,  80)
TITLE_COLOR   = (230, 220, 255)
SUB_COLOR     = (160, 140, 200)
CARD_BG       = (255, 255, 255, 14)
CARD_BORDER   = (130,  80, 220,  60)

_font_cache: dict = {}


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (size, bold)
    if key not in _font_cache:
        path = FONT_BOLD if bold else FONT_REG
        try:
            _font_cache[key] = ImageFont.truetype(path, size)
        except Exception:
            _font_cache[key] = ImageFont.load_default()
    return _font_cache[key]


def _make_bg() -> Image.Image:
    global _bg_cache
    if _bg_cache is None:
        c = Image.new("RGB", (2, 2))
        c.putpixel((0, 0), GRAD_TL)
        c.putpixel((1, 0), GRAD_TR)
        c.putpixel((0, 1), GRAD_BL)
        c.putpixel((1, 1), GRAD_BR)
        _bg_cache = c.resize((W, H), Image.BILINEAR).convert("RGBA")
    return _bg_cache.copy()


def _rounded_mask(w: int, h: int, r: int, aa: int = 2) -> Image.Image:
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w * aa, h * aa
        mr = int(min(r, w // 2, h // 2) * aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.BILINEAR)
    return _mask_cache[key]


def _glass_card(canvas: Image.Image, box: tuple, radius: int = 22, alpha: int = 18):
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    region = canvas.crop(box).convert("RGBA")
    blur   = region.filter(ImageFilter.GaussianBlur(6))
    over   = Image.new("RGBA", (w, h), (*CARD_BG[:3], alpha))
    merged = Image.alpha_composite(blur, over)
    mask   = _rounded_mask(w, h, radius)
    canvas.paste(merged, (x1, y1), mask)
    border = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(border).rounded_rectangle((0, 0, w, h), radius,
                                              outline=CARD_BORDER, width=2)
    canvas.paste(border, (x1, y1), border)


def _fetch_thumb(url: str, size: tuple) -> Image.Image:
    blank = Image.new("RGBA", size, (30, 20, 50, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=8)
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        s   = min(w0, h0)
        img = img.crop(((w0 - s) // 2, (h0 - s) // 2,
                        (w0 + s) // 2, (h0 + s) // 2))
        return img.resize(size, Image.BILINEAR)
    except Exception:
        return blank


def _fit(draw: ImageDraw.ImageDraw, text: str, fnt, max_w: int) -> str:
    text = str(text or "")
    if draw.textlength(text, font=fnt) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=fnt)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=fnt) > room:
            break
        out += ch
    return out + ell


def draw_meme_list(urls: list[str], out_path: str, keyword: str = "") -> None:
    urls = urls[:MAX_COLS * MAX_ROWS] if len(urls) > 50 else urls
    n    = len(urls)

    canvas = _make_bg()
    draw   = ImageDraw.Draw(canvas)

    f_header = _font(72, bold=True)
    f_sub    = _font(44)
    f_num    = _font(52, bold=True)

    header_text = f"🔍  {keyword or 'Meme / GIF'}"
    sub_text    = f"{n} kết quả  •  nhập số / 1,3 / 2-5 / all  •  120s"

    hw = draw.textlength(header_text, font=f_header)
    sw = draw.textlength(sub_text,    font=f_sub)
    draw.text(((W - hw) // 2, PAD - 10), header_text, font=f_header, fill=ACCENT)
    draw.text(((W - sw) // 2, PAD + 80), sub_text,    font=f_sub,    fill=SUB_COLOR)

    HEADER_H = PAD + 148
    COLS     = min(n, 5)
    ROWS     = (n + COLS - 1) // COLS
    GAP      = 28
    available_w = W - PAD * 2 - GAP * (COLS - 1)
    available_h = H - HEADER_H - PAD - GAP * (ROWS - 1)
    CW = available_w // COLS
    CH = available_h // ROWS

    thumb_h = CH - 68
    thumb_w = CW - 20

    import threading as _thr
    thumbs  = [None] * n
    threads = []

    def _load(i, url):
        thumbs[i] = _fetch_thumb(url, (thumb_w, thumb_h))

    for i, url in enumerate(urls):
        t = _thr.Thread(target=_load, args=(i, url), daemon=True)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()

    for i, url in enumerate(urls):
        row, col = divmod(i, COLS)
        x1 = PAD + col * (CW + GAP)
        y1 = HEADER_H + row * (CH + GAP)
        x2 = x1 + CW
        y2 = y1 + CH

        _glass_card(canvas, (x1, y1, x2, y2), radius=20)

        thumb = thumbs[i]
        if thumb:
            tx = x1 + (CW - thumb.width)  // 2
            ty = y1 + 8
            canvas.paste(thumb, (tx, ty), _rounded_mask(thumb.width, thumb.height, 12))

        num = str(i + 1)
        nw  = draw.textlength(num, font=f_num)
        draw.text((x1 + (CW - nw) // 2, y2 - 58), num,
                  font=f_num, fill=NUM_COLOR)

    canvas.convert("RGB").save(out_path, "JPEG", quality=88)


MAX_COLS = 5
MAX_ROWS = 10

