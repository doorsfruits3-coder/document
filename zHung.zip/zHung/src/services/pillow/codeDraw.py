from PIL import Image, ImageDraw, ImageFont, ImageFilter
import os

try:
    from pygments import lex
    from pygments.lexers import get_lexer_for_filename, TextLexer
    from pygments.token import Token
    _HAS_PYGMENTS = True
except ImportError:
    _HAS_PYGMENTS = False

# ── Theme: One Dark Pro ───────────────────────────────────────────────────────

GUTTER_FG = (80, 85, 105, 255)
BORDER     = (50, 52,  65, 200)

TOKEN_COLORS = {
    Token.Keyword:               (198, 120, 221),
    Token.Keyword.Constant:      (209, 154,  93),
    Token.Keyword.Namespace:     (198, 120, 221),
    Token.Name.Builtin:          (224, 108, 117),
    Token.Name.Builtin.Pseudo:   (209, 154,  93),
    Token.Name.Function:         ( 97, 175, 239),
    Token.Name.Class:            (229, 192, 123),
    Token.Name.Decorator:        (209, 154,  93),
    Token.Name.Exception:        (224, 108, 117),
    Token.String:                (152, 195, 121),
    Token.String.Doc:            (106, 153,  85),
    Token.Comment:               (106, 153,  85),
    Token.Comment.Single:        (106, 153,  85),
    Token.Literal.Number:        (209, 154,  93),
    Token.Literal.Number.Integer:(209, 154,  93),
    Token.Literal.Number.Float:  (209, 154,  93),
    Token.Operator:              (171, 178, 191),
    Token.Operator.Word:         (198, 120, 221),
    Token.Punctuation:           (171, 178, 191),
    Token.Name.Attribute:        (224, 108, 117),
    Token.Name:                  (224, 108, 117),
    Token.Text:                  (171, 178, 191),
    Token.Error:                 (224, 108, 117),
}
DEFAULT_FG = (171, 178, 191)

def _token_color(ttype):
    while ttype:
        if ttype in TOKEN_COLORS:
            return TOKEN_COLORS[ttype]
        ttype = ttype.parent
    return DEFAULT_FG

# ── Font & char-width cache ───────────────────────────────────────────────────

_BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
_ROOT_DIR  = os.path.abspath(os.path.join(_BASE_DIR, "..", "..", ".."))
_MONO_PATH = os.path.join(_ROOT_DIR, "assets", "font", "zendot.ttf")
_FALLBACK  = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"

_fc:  dict = {}   # size → ImageFont
_cwc: dict = {}   # size → {char: width}

def _font(sz):
    if sz not in _fc:
        path = _MONO_PATH if os.path.exists(_MONO_PATH) else _FALLBACK
        _fc[sz] = ImageFont.truetype(path, sz)
        _dummy = Image.new("RGBA", (10, 10))
        _dd    = ImageDraw.Draw(_dummy)
        f      = _fc[sz]
        cache  = {}
        printable = (
            "abcdefghijklmnopqrstuvwxyz"
            "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
            "0123456789"
            " _.,=()[]{}:\"'#!@$%^&*-+/<>\\|`~?;!"
        )
        for ch in printable:
            b = _dd.textbbox((0, 0), ch, font=f)
            cache[ch] = b[2] - b[0]
        b1 = _dd.textbbox((0, 0), "a a", font=f)
        b2 = _dd.textbbox((0, 0), "aa", font=f)
        space_w = (b1[2] - b1[0]) - (b2[2] - b2[0])
        if space_w > 0:
            cache[' '] = space_w
        _cwc[sz] = cache
    return _fc[sz]

def _char_w(ch: str, sz: int) -> int:
    cache = _cwc.get(sz, {})
    if ch == '\t':
        return cache.get(' ', 14) * 4
    return cache.get(ch, cache.get(' ', 14))

def _text_width_fast(text: str, sz: int) -> int:
    return sum(_char_w(c, sz) for c in text)

# ── Tokenize ──────────────────────────────────────────────────────────────────

def _tokenize(code: str, filename: str):
    if not _HAS_PYGMENTS:
        return [(Token.Text, code)]
    try:
        lexer = get_lexer_for_filename(filename, stripall=False)
    except Exception:
        lexer = TextLexer()
    return list(lex(code, lexer))

def _split_lines(tokens):
    lines = [[]]
    for ttype, value in tokens:
        parts = value.split("\n")
        for i, part in enumerate(parts):
            if part:
                lines[-1].append((ttype, part))
            if i < len(parts) - 1:
                lines.append([])
    return lines

# ── Word-wrap một dòng token xuống nhiều visual lines ────────────────────────

def _wrap_line(line_tokens, max_w: int, sz: int, indent_w: int):
    visual_lines = []
    current      = []
    cur_x        = 0
    is_cont      = False

    for ttype, txt in line_tokens:
        buf      = ""
        buf_ttype = ttype
        for ch in txt:
            cw = _char_w(ch, sz)
            if cur_x + cw > max_w and current:
                if buf:
                    current.append((buf_ttype, buf))
                    buf = ""
                visual_lines.append((is_cont, current))
                current  = []
                cur_x    = indent_w
                is_cont  = True
            buf   += ch
            cur_x += cw
        if buf:
            current.append((buf_ttype, buf))

    if current:
        visual_lines.append((is_cont, current))
    elif not visual_lines:
        visual_lines.append((False, []))

    return visual_lines

# ── Canvas gradient (numpy-accelerated) ──────────────────────────────────────

def _make_canvas_bg(W: int, H: int) -> Image.Image:
    COLORS = [
        (80,  10, 140),
        (220, 40, 160),
        (10,  40, 120),
        (160, 20, 210),
    ]
    try:
        import numpy as np
        xs = np.linspace(0, 1, W, dtype=np.float32)
        ys = np.linspace(0, 1, H, dtype=np.float32)
        gx, gy = np.meshgrid(xs, ys)
        tl, tr, bl, br = [np.array(c, dtype=np.float32) for c in COLORS]
        gx3 = gx[:, :, np.newaxis]
        gy3 = gy[:, :, np.newaxis]
        top = tl * (1 - gx3) + tr * gx3
        bot = bl * (1 - gx3) + br * gx3
        rgb = (top * (1 - gy3) + bot * gy3).clip(0, 255).astype(np.uint8)
        cx  = (np.abs(xs - 0.5) * 2)
        cy  = (np.abs(ys - 0.5) * 2)
        vx, vy = np.meshgrid(cx, cy)
        vig = np.clip(vx ** 2 + vy ** 2, 0, 1)[:, :, np.newaxis] * 0.4
        rgb = (rgb * (1 - vig)).clip(0, 255).astype(np.uint8)
        return Image.fromarray(rgb, "RGB").convert("RGBA")
    except ImportError:
        bg = Image.new("RGBA", (W, H), (40, 8, 70, 255))
        return bg

# ── Layout ────────────────────────────────────────────────────────────────────

FONT_SZ      = 26
LINE_H       = 38
PAD_X        = 28
PAD_Y        = 28
GUTTER_W     = 72
HEADER_H     = 56
POPUP_RADIUS = 18
MAX_LINES    = None
MAX_LINE_W   = 1200
MARGIN       = 60

POPUP_BG_COLOR    = (18, 18, 26, 215)
POPUP_BORDER_CLR  = (160, 80, 220, 90)
HEADER_CLR        = (22, 23, 30, 220)
GUTTER_BG_CLR     = (20, 21, 28, 190)
CODE_BG_CLR       = (16, 16, 24, 205)


def draw_code_image(code: str, filename: str, out_path: str) -> tuple[int, int]:
    tokens     = _tokenize(code, filename)
    raw_lines  = _split_lines(tokens)
    if MAX_LINES:
        raw_lines = raw_lines[:MAX_LINES]

    _font(FONT_SZ)
    _font(20)
    _font(22)

    def _indent_px(line_tokens):
        px = 0
        for _, txt in line_tokens:
            for ch in txt:
                if ch in (' ', '\t'):
                    px += _char_w(ch, FONT_SZ)
                else:
                    return px
        return 0

    max_cw = 0
    for lt in raw_lines:
        cw = sum(_text_width_fast(txt, FONT_SZ) for _, txt in lt)
        if cw > max_cw:
            max_cw = cw

    content_w = min(max_cw, MAX_LINE_W)
    POP_W     = GUTTER_W + PAD_X + content_w + PAD_X * 2
    POP_W     = max(POP_W, 600)

    visual_lines = []
    for src_i, lt in enumerate(raw_lines):
        ind_px  = _indent_px(lt)
        wrapped = _wrap_line(lt, content_w, FONT_SZ, ind_px)
        for is_cont, vl in wrapped:
            visual_lines.append((src_i, is_cont, vl))

    n_visual = len(visual_lines)
    POP_H    = HEADER_H + PAD_Y + n_visual * LINE_H + PAD_Y

    W = POP_W + MARGIN * 2
    H = POP_H + MARGIN * 2

    canvas = _make_canvas_bg(W, H)

    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd     = ImageDraw.Draw(shadow)
    sd.rounded_rectangle(
        (MARGIN + 10, MARGIN + 14, MARGIN + POP_W + 10, MARGIN + POP_H + 14),
        radius=POPUP_RADIUS, fill=(0, 0, 0, 140)
    )
    shadow = shadow.filter(ImageFilter.GaussianBlur(radius=20))
    canvas.alpha_composite(shadow)

    popup = Image.new("RGBA", (POP_W, POP_H), (0, 0, 0, 0))
    pd    = ImageDraw.Draw(popup)

    pd.rounded_rectangle(
        (0, 0, POP_W - 1, POP_H - 1),
        radius=POPUP_RADIUS, fill=POPUP_BG_COLOR
    )

    pd.rounded_rectangle(
        (0, 0, POP_W - 1, HEADER_H + POPUP_RADIUS),
        radius=POPUP_RADIUS, fill=HEADER_CLR
    )
    pd.rectangle(
        (0, HEADER_H, POP_W - 1, HEADER_H + POPUP_RADIUS),
        fill=HEADER_CLR
    )
    pd.line([(0, HEADER_H), (POP_W, HEADER_H)], fill=BORDER, width=1)

    dot_y = HEADER_H // 2
    for dx, dc in [(16, (255, 95, 87)), (36, (255, 189, 46)), (56, (39, 201, 63))]:
        pd.ellipse((dx - 6, dot_y - 6, dx + 6, dot_y + 6), fill=dc)

    f_ui  = _font(22)
    fname = os.path.basename(filename)
    fb    = pd.textbbox((0, 0), fname, font=f_ui)
    fw    = fb[2] - fb[0]
    pd.text(
        ((POP_W - fw) // 2, (HEADER_H - (fb[3] - fb[1])) // 2),
        fname, font=f_ui, fill=(171, 178, 191, 200)
    )

    pd.rectangle((0, HEADER_H, GUTTER_W, POP_H - 1), fill=GUTTER_BG_CLR)
    pd.line([(GUTTER_W, HEADER_H), (GUTTER_W, POP_H)], fill=BORDER, width=1)
    pd.rectangle((GUTTER_W + 1, HEADER_H, POP_W - 1, POP_H - 1), fill=CODE_BG_CLR)

    pd.rounded_rectangle(
        (0, 0, POP_W - 1, POP_H - 1),
        radius=POPUP_RADIUS, outline=POPUP_BORDER_CLR, width=1
    )

    f_gutter = _font(20)
    f_code   = _font(FONT_SZ)
    start_x  = GUTTER_W + PAD_X

    _bboxc: dict = {}

    def _bbox(txt):
        if txt not in _bboxc:
            _bboxc[txt] = pd.textbbox((0, 0), txt, font=f_code)
        return _bboxc[txt]

    prev_src = -1
    for vi, (src_i, is_cont, line_tokens) in enumerate(visual_lines):
        y = HEADER_H + PAD_Y + vi * LINE_H

        # ── Gutter: chỉ hiện số dòng ở dòng đầu, continuation để trống ──────
        if not is_cont:
            num = str(src_i + 1)
            nb  = pd.textbbox((0, 0), num, font=f_gutter)
            nw  = nb[2] - nb[0]
            pd.text(
                (GUTTER_W - nw - 10, y + (LINE_H - (nb[3] - nb[1])) // 2),
                num, font=f_gutter, fill=GUTTER_FG
            )
            prev_src = src_i

        x = start_x
        if is_cont:
            x += _indent_px(raw_lines[src_i])

        for ttype, txt in line_tokens:
            color = _token_color(ttype)
            seg   = ""
            seg_x = x
            for ch in txt:
                if ch in (' ', '\t'):
                    if seg:
                        pd.text((seg_x, y), seg, font=f_code, fill=(*color, 255))
                        seg = ""
                    x     += _char_w(ch, FONT_SZ)
                    seg_x  = x
                else:
                    seg   += ch
                    x     += _char_w(ch, FONT_SZ)
            if seg:
                pd.text((seg_x, y), seg, font=f_code, fill=(*color, 255))

    canvas.alpha_composite(popup, dest=(MARGIN, MARGIN))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=94, optimize=False)
    return W, H
    