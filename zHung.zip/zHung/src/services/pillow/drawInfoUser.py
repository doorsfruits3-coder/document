from PIL import Image, ImageDraw, ImageFont, ImageFilter
from pathlib import Path
from io import BytesIO
import requests, os, time, random, math

W, H     = 1080, 1350
FONT_DIR = Path("assets/font")
_fc: dict = {}
_bg_cache: dict = {}


def _font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (size, bold)
    if key in _fc:
        return _fc[key]
    paths = (
        [FONT_DIR / "Goldman/Goldman-Bold.ttf",
         FONT_DIR / "Opensans/static/Opensans/OpenSans-Bold.ttf"]
        if bold else
        [FONT_DIR / "Opensans/static/Opensans/OpenSans-Regular.ttf"]
    )
    for p in paths:
        if Path(p).exists():
            try:
                _fc[key] = ImageFont.truetype(str(p), size)
                return _fc[key]
            except Exception:
                pass
    _fc[key] = ImageFont.load_default()
    return _fc[key]


def _tw(d, t, f):   return int(d.textlength(t, font=f))
def _bb(f, t):
    b = f.getbbox(t); return b[3]-b[1], b[1]

def _txt_c(d, t, f, cx, cy, fill):
    tw = _tw(d, t, f); h, top = _bb(f, t)
    d.text((cx - tw//2, cy - h//2 - top), t, font=f, fill=fill)

def _fit(d, text, font, maxw):
    text = str(text)
    if d.textlength(text, font=font) <= maxw: return text
    ell = "…"
    mw2 = maxw - d.textlength(ell, font=font)
    out = ""
    for ch in text:
        if d.textlength(out+ch, font=font) <= mw2: out += ch
        else: break
    return out + ell


def _make_bg(seed=7) -> Image.Image:
    key = seed
    if key in _bg_cache:
        return _bg_cache[key].copy()

    S   = 4
    sw, sh = W//S, H//S
    rng = random.Random(seed)

    img = Image.new("RGBA", (sw, sh), (12, 10, 26, 255))
    blobs = [
        (0.15, 0.20, 0.50, 0.35, ( 80,  40, 160), 180),
        (0.85, 0.15, 0.45, 0.30, (160,  40, 100), 160),
        (0.50, 0.55, 0.40, 0.30, ( 50,  30, 140), 140),
        (0.10, 0.80, 0.35, 0.25, (120,  50, 160), 120),
        (0.90, 0.75, 0.30, 0.22, ( 60,  20, 120), 100),
    ]
    for cx_f, cy_f, rx_f, ry_f, col, alpha in blobs:
        cx = int(cx_f*sw) + rng.randint(-3, 3)
        cy = int(cy_f*sh) + rng.randint(-3, 3)
        rx, ry = int(rx_f*sw), int(ry_f*sh)
        b = Image.new("RGBA", (sw, sh), (0,0,0,0))
        ImageDraw.Draw(b).ellipse((cx-rx, cy-ry, cx+rx, cy+ry), fill=(*col, alpha))
        img.alpha_composite(b.filter(ImageFilter.GaussianBlur(rng.randint(10, 18))))

    img = img.resize((W, H), Image.BILINEAR)
    _bg_cache[key] = img.copy()
    return img


def _circle_aa(img, cx, cy, r, fill):
    s   = 4
    big = Image.new("RGBA", (r*2*s, r*2*s), (0,0,0,0))
    ImageDraw.Draw(big).ellipse((0, 0, r*2*s-1, r*2*s-1), fill=(*fill, 255))
    sm  = big.resize((r*2, r*2), Image.LANCZOS)
    img.paste(Image.new("RGB", (r*2, r*2), fill), (cx-r, cy-r), sm.split()[3])


def _glass(img, box, radius=20, fill=(255,255,255,18), outline=(255,255,255,30)):
    x1, y1, x2, y2 = map(int, box)
    bw, bh = x2-x1, y2-y1
    if bw <= 0 or bh <= 0: return
    layer = Image.new("RGBA", (bw, bh), (0,0,0,0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle((0,0,bw-1,bh-1), radius, fill=fill)
    if outline:
        d.rounded_rectangle((0,0,bw-1,bh-1), radius, outline=outline, width=1)
    img.alpha_composite(layer, (x1, y1))


def draw_user_info(profile: dict, out_path: str, bg_seed: int | None = None) -> tuple:
    seed  = bg_seed if bg_seed is not None else random.randint(0, 999)
    img   = _make_bg(seed)
    d     = ImageDraw.Draw(img, "RGBA")

    PAD   = 40
    CX    = W // 2

    # ── avatar ────────────────────────────────────────────────────────────────
    AV_R   = 130
    AV_CY  = PAD + 60 + AV_R
    AV_CX  = CX

    avatar_url = profile.get("avatar", "")
    av_ok = False
    if avatar_url:
        try:
            resp  = requests.get(avatar_url, timeout=8,
                                 headers={"User-Agent": "Mozilla/5.0"})
            raw   = Image.open(BytesIO(resp.content)).convert("RGBA")
            raw   = raw.resize((AV_R*2, AV_R*2), Image.LANCZOS)
            mask  = Image.new("L", (AV_R*2, AV_R*2), 0)
            ImageDraw.Draw(mask).ellipse((0,0,AV_R*2-1,AV_R*2-1), fill=255)
            av_img = Image.new("RGBA", (AV_R*2, AV_R*2), (0,0,0,0))
            av_img.paste(raw, mask=mask)
            # ring
            ring_r = AV_R + 5
            ring = Image.new("RGBA", (ring_r*2, ring_r*2), (0,0,0,0))
            ImageDraw.Draw(ring).ellipse(
                (0,0,ring_r*2-1,ring_r*2-1),
                outline=(255,255,255,60), width=3)
            img.alpha_composite(ring, (AV_CX-ring_r, AV_CY-ring_r))
            img.alpha_composite(av_img, (AV_CX-AV_R, AV_CY-AV_R))
            av_ok = True
        except Exception:
            pass

    if not av_ok:
        ph = Image.new("RGBA", (AV_R*2, AV_R*2), (0,0,0,0))
        ImageDraw.Draw(ph).ellipse((0,0,AV_R*2-1,AV_R*2-1), fill=(55,40,80,200))
        f_q = _font(90, bold=True)
        name0 = (profile.get("displayName") or "?")[0].upper()
        ImageDraw.Draw(ph).text((AV_R, AV_R), name0, font=f_q,
                                fill=(200,180,240,220), anchor="mm")
        img.alpha_composite(ph, (AV_CX-AV_R, AV_CY-AV_R))

    # ── platform badges ───────────────────────────────────────────────────────
    plats = [("MOBILE", profile.get("isActive")),
             ("WEB",    profile.get("isActiveWeb")),
             ("PC",     profile.get("isActivePC"))]
    f_badge = _font(18, bold=True)
    BADGE_H = 30
    badge_y = AV_CY + AV_R + 16
    total_bw = sum(_tw(d, p, f_badge)+28 for p,_ in plats) + 12*2
    bx = CX - total_bw//2
    for pname, is_act in plats:
        fw = _tw(d, pname, f_badge) + 28
        fc = (100, 70, 180, 200) if is_act else (40, 32, 60, 160)
        oc = (180, 140, 255, 180) if is_act else (80, 65, 110, 120)
        tc = (230, 215, 255, 255) if is_act else (140, 120, 170, 200)
        layer = Image.new("RGBA", (fw, BADGE_H), (0,0,0,0))
        ld = ImageDraw.Draw(layer)
        ld.rounded_rectangle((0,0,fw-1,BADGE_H-1), BADGE_H//2, fill=fc)
        ld.rounded_rectangle((0,0,fw-1,BADGE_H-1), BADGE_H//2, outline=oc, width=1)
        img.alpha_composite(layer, (bx, badge_y))
        ph2, pt2 = _bb(f_badge, pname)
        d.text((bx + fw//2 - _tw(d,pname,f_badge)//2,
                badge_y + BADGE_H//2 - ph2//2 - pt2),
               pname, font=f_badge, fill=tc)
        bx += fw + 12

    # ── name + subtitle ───────────────────────────────────────────────────────
    name    = profile.get("displayName") or profile.get("zaloName") or "Unknown"
    f_name  = _font(54, bold=True)
    f_sub   = _font(24)
    name_y  = badge_y + BADGE_H + 24
    nh, nt  = _bb(f_name, name)
    # shadow
    d.text((CX - _tw(d,name,f_name)//2 + 2, name_y - nt + 2),
           name, font=f_name, fill=(0,0,0,80))
    d.text((CX - _tw(d,name,f_name)//2, name_y - nt),
           name, font=f_name, fill=(245, 240, 255, 255))
    sub_y = name_y + nh + 8
    uid_str = f"UID  {profile.get('userId','N/A')}"
    sh2, st2 = _bb(f_sub, uid_str)
    d.text((CX - _tw(d,uid_str,f_sub)//2, sub_y - st2),
           uid_str, font=f_sub, fill=(160, 148, 200, 200))

    # ── status caption ────────────────────────────────────────────────────────
    status = str(profile.get("status","") or "")
    if status:
        f_cap  = _font(22)
        cap_y  = sub_y + sh2 + 20
        cap_x1 = PAD + 20
        cap_x2 = W - PAD - 20
        cap_w  = cap_x2 - cap_x1
        words  = status.split()
        lines, cur = [], ""
        for w2 in words:
            test = (cur+" "+w2).strip()
            if _tw(d, test, f_cap) <= cap_w - 32: cur = test
            else:
                if cur: lines.append(cur)
                cur = w2
                if len(lines) >= 3: break
        if cur and len(lines) < 3: lines.append(cur)
        if lines: lines[-1] = _fit(d, lines[-1], f_cap, cap_w - 32)
        cap_h = len(lines)*30 + 20
        _glass(img, (cap_x1, cap_y, cap_x2, cap_y+cap_h), radius=14,
               fill=(255,255,255,12), outline=(255,255,255,20))
        ty = cap_y + 10
        for ln in lines:
            lw2 = _tw(d, ln, f_cap)
            d.text((cap_x1 + (cap_w-lw2)//2, ty), ln, font=f_cap,
                   fill=(200, 192, 230, 210))
            ty += 30
        info_top = cap_y + cap_h + 24
    else:
        info_top = sub_y + sh2 + 24

    # ── info grid ─────────────────────────────────────────────────────────────
    gender_map = {0: "Nam", 1: "Nữ", 2: "Khác"}
    last_ts = profile.get("lastActionTime", 0)
    if last_ts:
        diff = int(time.time()) - last_ts // 1000
        if   diff <    120: act = "Vừa truy cập"
        elif diff <   3600: act = f"{diff//60} phút trước"
        elif diff <  86400: act = f"{diff//3600} giờ trước"
        else:               act = f"{diff//86400} ngày trước"
    else:
        act = "Không rõ"

    created = profile.get("createdTs", 0)
    ct_str  = (time.strftime("%d/%m/%Y", time.localtime(created))
               if created else "N/A")

    biz     = profile.get("bizPkg") or {}
    biz_lbl = (biz.get("label") or {}).get("VI","") or "Thường"

    fields = [
        ("Username",       str(profile.get("username","N/A"))),
        ("Giới tính",      gender_map.get(profile.get("gender"), "N/A")),
        ("Sinh nhật",      str(profile.get("sdob","N/A") or "N/A")),
        ("Số điện thoại",  str(profile.get("phoneNumber","") or "Ẩn")),
        ("Hoạt động",      act),
        ("Tài khoản",      biz_lbl),
        ("Trạng thái",     "Bình thường" if profile.get("accountStatus",0)==0 else "Bị khoá"),
        ("Ngày tạo",       ct_str),
    ]

    f_lbl  = _font(19)
    f_val  = _font(26, bold=True)
    COLS   = 2
    ROWS   = math.ceil(len(fields)/COLS)
    GAP    = 10
    gx1    = PAD
    gx2    = W - PAD
    gw     = gx2 - gx1
    gy1    = info_top
    gy2    = H - PAD - 20
    gh     = gy2 - gy1
    cell_w = (gw - GAP*(COLS-1)) // COLS
    cell_h = (gh - GAP*(ROWS-1)) // ROWS

    for i, (lbl, val) in enumerate(fields):
        col = i % COLS
        row = i // COLS
        cx1 = gx1 + col*(cell_w+GAP)
        cy1 = gy1 + row*(cell_h+GAP)
        cx2 = cx1 + cell_w
        cy2 = cy1 + cell_h

        _glass(img, (cx1,cy1,cx2,cy2), radius=16,
               fill=(255,255,255,14), outline=(255,255,255,22))

        lh, lt = _bb(f_lbl, lbl)
        d.text((cx1+16, cy1+14-lt), lbl, font=f_lbl,
               fill=(160, 148, 200, 200))

        val_str = _fit(d, val, f_val, cell_w-28)
        vh, vt  = _bb(f_val, val_str)
        d.text((cx1+16, cy1+14+lh+10-vt), val_str, font=f_val,
               fill=(240, 235, 255, 255))

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    img.convert("RGB").save(out_path, quality=95)
    return W, H
