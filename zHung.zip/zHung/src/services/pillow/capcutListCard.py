"""
capcutListCard.py  –  Vẽ card danh sách template CapCut cho zBot
Output: JPEG 2560×1440  |  Clone y hệt tiktokListCard.py, chỉ đổi màu + data fields
"""
import os, random
import requests
from io import BytesIO
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from PIL import Image, ImageDraw, ImageFont

W, H  = 2560, 1440
COLS  = 5          # CapCut dùng 5 cột (TikTok 6), template landscape rộng hơn
ROWS  = 2
PAD   = 40
GAP   = 16

# ── Màu CapCut (clone C_* của tiktokListCard, đổi palette sang xanh dương) ───
C_CARD_BG = ( 10,  16,  35, 130)   # glass dark  (giống TikTok)
C_BORDER  = (  0, 145, 220, 160)   # xanh CapCut  (thay C_GOLD vàng TikTok)
C_NUM     = (255, 255, 255, 255)   # số thứ tự trắng
C_TITLE   = (240, 242, 255)        # tiêu đề trắng nhạt
C_ARTIST  = (120, 195, 235)        # tên creator  (thay C_ARTIST xanh TikTok)
C_DUR     = (155, 135, 200)        # plays/likes phụ  (thay C_DUR tím TikTok)

_mask_cache: dict = {}


def _resolve_font():
    try:
        base = Path(__file__).resolve().parents[3] / "assets" / "font" / "Opensans" / "static" / "Opensans"
        b = base / "OpenSans-Bold.ttf"
        r = base / "OpenSans-Regular.ttf"
        if b.exists() and r.exists():
            return str(b), str(r)
    except Exception:
        pass
    return (
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    )


FONT_BOLD, FONT_REG = _resolve_font()


def _font(size, bold=False):
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, size)
    except Exception:
        return ImageFont.load_default()


def _make_bg_fast():
    """
    Clone y hệt _make_bg_fast() của tiktokListCard.
    Chỉ đổi palette: hồng-tím-xanh → xanh đậm-navy-teal (màu CapCut).
    """
    NAVY_TONES = [
        ( 5, 12, 30),
        ( 4, 10, 26),
        ( 6, 14, 34),
        ( 5, 11, 28),
    ]
    BLUE_TONES = [
        ( 0, 40, 90),
        ( 0, 35, 80),
        ( 0, 45, 100),
        ( 0, 38, 85),
    ]
    TEAL_TONES = [
        ( 0, 60, 80),
        ( 0, 55, 75),
        ( 0, 65, 88),
        ( 0, 58, 78),
    ]
    all_pools = [NAVY_TONES, BLUE_TONES, TEAL_TONES]
    def pick(): return random.choice(random.choice(all_pools))
    c = Image.new("RGB", (2, 2))
    c.putpixel((0, 0), pick())
    c.putpixel((1, 0), pick())
    c.putpixel((0, 1), pick())
    c.putpixel((1, 1), pick())
    return c.resize((W, H), Image.BILINEAR).convert("RGBA")


def _rounded_mask(w, h, r, aa=3):
    key = (w, h, r)
    if key not in _mask_cache:
        mw, mh = w * aa, h * aa
        mr = int(min(r, w // 2, h // 2) * aa)
        m  = Image.new("L", (mw, mh), 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, mw, mh), mr, fill=255)
        _mask_cache[key] = m.resize((w, h), Image.LANCZOS)
    return _mask_cache[key]


def _load_cover(url, size):
    """
    Clone _load_cover TikTok nhưng crop 16:9 (template CapCut landscape)
    thay vì square crop như TikTok.
    """
    blank = Image.new("RGBA", size, (8, 14, 30, 255))
    if not url or not str(url).startswith("http"):
        return blank
    try:
        r   = requests.get(url, timeout=6, headers={"User-Agent": "Mozilla/5.0"})
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        w0, h0 = img.size
        tw, th = size
        if w0 / h0 > tw / th:
            new_w = int(h0 * tw / th)
            img   = img.crop(((w0 - new_w) // 2, 0, (w0 + new_w) // 2, h0))
        else:
            new_h = int(w0 * th / tw)
            img   = img.crop((0, (h0 - new_h) // 2, w0, (h0 + new_h) // 2))
        return img.resize(size, Image.LANCZOS)
    except Exception:
        return blank


def _fit(draw, text, fnt, max_w):
    text = str(text or "")
    if draw.textlength(text, font=fnt) <= max_w:
        return text
    ell  = "..."
    room = max_w - draw.textlength(ell, font=fnt)
    out  = ""
    for ch in text:
        if draw.textlength(out + ch, font=fnt) > room:
            break
        out += ch
    return out + ell


def _wrap2(draw, text, fnt, max_w):
    """Clone y hệt _wrap2 của tiktokListCard."""
    text = str(text or "")
    words = text.split()
    line1, line2 = [], []
    for w in words:
        trial = " ".join(line1 + [w])
        if draw.textlength(trial, font=fnt) <= max_w:
            line1.append(w)
        else:
            line2.append(w)
    l1 = " ".join(line1)
    l2 = " ".join(line2)
    if l2:
        l2 = _fit(draw, l2, fnt, max_w)
    return l1, l2


def _fmt_num(n):
    try:
        n = int(n)
    except Exception:
        return "0"
    if n >= 1_000_000:
        return f"{n/1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n/1_000:.1f}K"
    return str(n)


def _extract(item):
    """
    Tương đương _extract() của tiktokListCard nhưng cho CapCut.
    title   → template title        (≈ desc TikTok)
    creator → nickname creator      (≈ nickname TikTok)
    plays   → play_amount           (≈ duration TikTok — hiển thị cùng vị trí)
    cover   → cover_url
    """
    author  = item.get("author") or item.get("user_info") or {}
    creator = (author.get("nickname") or author.get("name") or "").strip()
    cover   = item.get("cover_url") or item.get("cover") or ""
    plays   = item.get("play_amount") or item.get("playAmount") or 0
    title   = str(item.get("title") or "CapCut")
    return title, creator, plays, cover


def draw_capcut_list(templates, out_path, keyword=""):
    """
    Vẽ card danh sách template CapCut.
    Clone y hệt draw_tiktok_list(), chỉ đổi màu, data fields và crop ảnh.
    """
    templates = (templates or [])[:COLS * ROWS]
    n         = len(templates)
    if n == 0:
        return out_path

    CARD_W = (W - PAD * 2 - GAP * (COLS - 1)) // COLS
    CARD_H = (H - PAD * 2 - GAP * (ROWS - 1)) // ROWS

    # Thumbnail 16:9 landscape (CapCut) thay vì square (TikTok)
    THUMB_W = CARD_W - 12
    THUMB_H = int(THUMB_W * 9 / 16)
    TEXT_H  = CARD_H - THUMB_H - 10

    # Fonts — y hệt tiktokListCard
    f_title   = _font(int(TEXT_H * 0.21), bold=True)
    f_creator = _font(int(TEXT_H * 0.16))   # thay f_artist
    f_plays   = _font(int(TEXT_H * 0.14))   # thay f_dur
    f_num     = _font(int(THUMB_W * 0.085), bold=True)

    # Tải ảnh song song — y hệt tiktokListCard
    covers = [None] * n
    def _fetch(i):
        _, _, _, url = _extract(templates[i])
        covers[i] = _load_cover(url, (THUMB_W, THUMB_H))

    with ThreadPoolExecutor(max_workers=12) as ex:
        list(ex.map(_fetch, range(n)))

    canvas = _make_bg_fast()
    d      = ImageDraw.Draw(canvas, "RGBA")

    for idx in range(n):
        col = idx % COLS
        row = idx // COLS
        cx  = PAD + col * (CARD_W + GAP)
        cy  = PAD + row * (CARD_H + GAP)

        # Card bg  (y hệt)
        layer = Image.new("RGBA", (CARD_W, CARD_H), (0, 0, 0, 0))
        mask  = _rounded_mask(CARD_W, CARD_H, 20)
        layer.paste(Image.new("RGBA", (CARD_W, CARD_H), C_CARD_BG), (0, 0), mask)
        # Viền xanh CapCut  (thay viền vàng TikTok)
        ImageDraw.Draw(layer).rounded_rectangle(
            (0, 0, CARD_W - 1, CARD_H - 1), 20,
            outline=C_BORDER, width=2
        )
        canvas.alpha_composite(layer, (cx, cy))

        # Thumbnail
        tx = cx + (CARD_W - THUMB_W) // 2
        ty = cy + 6
        if covers[idx]:
            canvas.paste(covers[idx], (tx, ty), _rounded_mask(THUMB_W, THUMB_H, 14))

        # Số thứ tự — góc dưới phải  (y hệt tiktokListCard)
        num_str = str(idx + 1)
        nw = int(d.textlength(num_str, font=f_num))
        d.text(
            (cx + CARD_W - nw - 8, cy + CARD_H - f_num.size - 8),
            num_str, font=f_num, fill=C_NUM
        )

        # Text block — y hệt tiktokListCard
        title, creator, plays, _ = _extract(templates[idx])
        likes = _fmt_num(templates[idx].get("like_count") or templates[idx].get("likeCount") or 0)
        lx    = cx + 7
        mw    = CARD_W - 14
        ty0   = ty + THUMB_H + 8

        line1, line2 = _wrap2(d, title, f_title, mw)
        d.text((lx, ty0), line1, font=f_title, fill=C_TITLE)
        title_h = f_title.size
        if line2:
            d.text((lx, ty0 + title_h + 2), line2, font=f_title, fill=C_TITLE)
            title_block_h = title_h * 2 + 2
        else:
            title_block_h = title_h

        # Dòng dưới: creator trái | plays phải  (≈ artist | duration TikTok)
        ty1      = ty0 + title_block_h + 8
        plays_s  = _fmt_num(plays)
        pw       = int(d.textlength(plays_s, font=f_plays))
        d.text((lx, ty1), _fit(d, creator, f_creator, mw - pw - 10), font=f_creator, fill=C_ARTIST)
        d.text((cx + CARD_W - 7 - pw, ty1), plays_s, font=f_plays, fill=C_DUR)

    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    canvas.convert("RGB").save(out_path, quality=90, optimize=False)
    return out_path
