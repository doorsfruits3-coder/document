"""
var_core.py  –  Listener engine cho tính năng VAR
Đặt tại: src/services/utils/var_core.py

Flow:
  - var on  @user1 @user2   → thêm user vào var list của group đó
  - var stop @user / 1 2 3  → xoá user khỏi var list
  - var list                 → xem danh sách đang var
  - varListener()            → gọi từ handleListenAnti mỗi tin nhắn
      + Nếu userId trong var list → lấy dòng tiếp theo từ file txt → mention reply
      + Cooldown 1s / user để tránh spam (chỉ reply tin đầu trong window 1s)
"""

from app.core.index import *

# ── helpers ──────────────────────────────────────────────────────────────────

def _var_root(s: dict, threadId) -> dict:
    """Lấy (tạo nếu chưa có) dict var theo group."""
    return (
        s
        .setdefault("var", {})
        .setdefault("group", {})
        .setdefault(str(threadId), {})
    )


def _load_lines(path: str) -> list[str]:
    """Đọc file txt, trả về list dòng không rỗng."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [l.rstrip("\n") for l in f if l.strip()]
    except Exception:
        return []


def _next_line(lines: list[str], index: int) -> tuple[str, int]:
    """Lấy dòng tại index, vòng lại đầu nếu hết."""
    if not lines:
        return "", 0
    idx  = index % len(lines)
    text = lines[idx]
    return text, (idx + 1) % len(lines)


# ── public API (dùng trong var.py) ───────────────────────────────────────────

def var_on(self, uids: list[str], threadId, data, type, userId, txt_path: str):
    """Thêm danh sách uid vào var list của group."""
    s      = read_settings(self.uid)
    varMap = _var_root(s, threadId)

    added = []
    for uid in uids:
        if uid not in varMap:
            varMap[uid] = {"index": 0, "by": str(userId), "at": time.time()}
            added.append(uid)

    write_settings(self.uid, s)

    if not added:
        return self.replyMessageStyle(
            "Tất cả user đã được var rồi..!",
            data, threadId, type, color="yl", title="VAR", userId=userId
        )

    names = ", ".join(self.userName(u) for u in added)
    self.replyMessageStyle(
        f"Đã bật var cho: {names}",
        data, threadId, type, color="gr", title="VAR ON", userId=userId
    )


def var_stop(self, uids: list[str], indices: list[int], threadId, data, type, userId):
    """Xoá uid (hoặc theo số thứ tự) khỏi var list."""
    s      = read_settings(self.uid)
    varMap = _var_root(s, threadId)

    # resolve số thứ tự → uid
    if indices:
        sorted_uids = sorted(varMap.keys())
        for i in indices:
            idx = i - 1
            if 0 <= idx < len(sorted_uids):
                uids.append(sorted_uids[idx])

    uids = list(dict.fromkeys(uids))   # dedup

    removed = []
    for uid in uids:
        if uid in varMap:
            del varMap[uid]
            removed.append(uid)

    write_settings(self.uid, s)

    if not removed:
        return self.replyMessageStyle(
            "Không tìm thấy user trong var list..!",
            data, threadId, type, color="yl", title="VAR", userId=userId
        )

    names = ", ".join(self.userName(u) for u in removed)
    self.replyMessageStyle(
        f"Đã tắt var cho: {names}",
        data, threadId, type, color="r", title="VAR STOP", userId=userId
    )


def var_list(self, threadId, data, type, userId):
    """Hiển thị danh sách đang được var trong group."""
    s      = read_settings(self.uid)
    varMap = _var_root(s, threadId)

    if not varMap:
        return self.replyMessageStyle(
            "Var list: trống.",
            data, threadId, type, color="or", title="VAR LIST", userId=userId
        )

    lines = ["Danh sách đang var:\n"]
    for i, (uid, meta) in enumerate(sorted(varMap.items(),
                                           key=lambda x: x[1].get("at", 0)), 1):
        by   = self.userName(meta.get("by", "")) if meta.get("by") else "?"
        name = self.userName(uid)
        lines.append(f"{i}. {name}  [by {by}]")

    self.replyMessageStyle(
        "\n".join(lines),
        data, threadId, type, color="gr", title="VAR LIST", userId=userId
    )


# ── listener (gọi từ handleListenAnti) ───────────────────────────────────────

# cache dòng txt để không đọc đĩa mỗi lần
_txt_cache: dict[str, list[str]] = {}
_txt_mtime: dict[str, float]    = {}

def _get_lines_cached(path: str) -> list[str]:
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return []
    if _txt_mtime.get(path) != mtime:
        _txt_cache[path] = _load_lines(path)
        _txt_mtime[path] = mtime
    return _txt_cache.get(path, [])


# cooldown: {(botUid, threadId, userId): last_reply_ts}
_var_cooldown: dict[tuple, float] = {}
_VAR_COOLDOWN_SEC = 1.0   # 1 giây


def varListener(self, message, data, userId, threadId, type, txt_path: str = ""):
    """
    Gọi từ handleListenAnti.
    Nếu userId đang bị var → reply 1 dòng từ file txt, có mention.
    Cooldown 1s / user.
    """
    s      = read_settings(self.uid)
    varMap = _var_root(s, threadId)

    if not varMap:
        return

    uid_str = str(userId)
    if uid_str not in varMap:
        return

    # Cooldown check
    key = (self.uid, str(threadId), uid_str)
    now = time.time()
    if now - _var_cooldown.get(key, 0) < _VAR_COOLDOWN_SEC:
        return
    _var_cooldown[key] = now

    # Lấy file txt – fallback mặc định
    if not txt_path:
        txt_path = "data/config/var_messages.txt"

    lines = _get_lines_cached(txt_path)
    if not lines:
        lines = ["Hú~"]   # fallback nếu file rỗng / không tồn tại

    meta  = varMap[uid_str]
    index = meta.get("index", 0)
    text, next_index = _next_line(lines, index)

    # Cập nhật index (không block – dùng thread)
    meta["index"] = next_index
    write_settings(self.uid, s)

    # Gửi mention reply (không dùng style, plain mention)
    name    = self.userName(userId) or str(userId)
    mention = Mention(uid_str, offset=0, length=len(name))
    full    = f"{name}\n{text}"
    self.replyMessage(
        Message(text=full, mention=mention),
        data, threadId, type
    )
