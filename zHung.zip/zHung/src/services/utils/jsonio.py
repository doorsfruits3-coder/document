from app.library.packages import *
import threading
from threading import Lock
sf = 'Data'
luong = 10
sm = threading.Semaphore(luong)
file_lock = Lock()
def read_settings(uid):
    data_file_path = f"data/config/bot/{sf}-{uid}.json"
    try:
        with file_lock:
            with open(data_file_path, 'r', encoding='utf-8') as file:
                return json.load(file)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def write_settings(uid, settings):
    def write_task():
        try:
            data_file_path = f"data/config/bot/{sf}-{uid}.json"
            with file_lock:
                with open(data_file_path, 'w', encoding='utf-8') as file:
                    json.dump(settings, file, ensure_ascii=False, indent=4)
        finally:
            sm.release()
    sm.acquire()
    thread = threading.Thread(target=write_task)
    thread.start()
    time.sleep(0.4)

def load_json(path, default=None):
    if not os.path.exists(path):
        return default if default is not None else {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}

def save_json(path, data):
    ensure_dir(os.path.dirname(path))
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def ensure_dir(path: str):
    os.makedirs(path, exist_ok=True)