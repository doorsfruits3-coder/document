import os, uuid, time, threading, re
from app.core.index import *
from app.module.commandLoader import removeMention

try:
    from src.services.pillow.modGrpListCard import draw_group_list, PER_PAGE
    _PILLOW_OK = True
except Exception:
    _PILLOW_OK = False
    PER_PAGE   = 10

SESSION_TIMEOUT = 120


class ModGrpSession:
    def __init__(self, user_id, thread_id, thread_type, groups):
        self.user_id     = str(user_id)
        self.thread_id   = str(thread_id)
        self.thread_type = thread_type
        self.groups      = groups
        self.page        = 1
        self.list_msg_id = None
        self.list_cli_id = None
        self._cooldown_on = False
        self.in_find      = False
        self.find_results = None
        self.find_msg_id  = None
        self.find_cli_id  = None
        self.in_find_grp      = False
        self.find_grp_results = None
        self.find_grp_msg_id  = None
        self.find_grp_cli_id  = None
        self.updated_at   = time.time()

    def touch(self):
        self.updated_at = time.time()

    def total_pages(self):
        return max(1, (len(self.groups) + PER_PAGE - 1) // PER_PAGE)

    def page_groups(self, p=None):
        p = (p or self.page) - 1
        return self.groups[p * PER_PAGE:(p + 1) * PER_PAGE]


class _Store:
    _s: dict = {}

    @classmethod
    def get(cls, uid):
        return cls._s.get(str(uid))

    @classmethod
    def set(cls, uid, sess):
        cls._s[str(uid)] = sess

    @classmethod
    def remove(cls, uid):
        cls._s.pop(str(uid), None)

    @classmethod
    def cleanup(cls):
        now = time.time()
        for uid in list(cls._s):
            if now - cls._s[uid].updated_at > SESSION_TIMEOUT + 30:
                cls._s.pop(uid, None)


def _undo(ctx, msg_id, cli_id, thread_id, thread_type):
    if msg_id and cli_id:
        try:
            ctx.undoMessage(msg_id, cli_id, thread_id, thread_type)
        except Exception:
            pass


def _undo_all(ctx, sess):
    _undo(ctx, sess.list_msg_id, sess.list_cli_id, sess.thread_id, sess.thread_type)
    sess.list_msg_id = sess.list_cli_id = None
    if sess.find_msg_id:
        _undo(ctx, sess.find_msg_id, sess.find_cli_id, sess.thread_id, sess.thread_type)
        sess.find_msg_id = sess.find_cli_id = None
    if sess.find_grp_msg_id:
        _undo(ctx, sess.find_grp_msg_id, sess.find_grp_cli_id, sess.thread_id, sess.thread_type)
        sess.find_grp_msg_id = sess.find_grp_cli_id = None


def _stop_countdown(sess):
    sess._cooldown_on = False


def _react(ctx, data, thread_id, thread_type, emoji, icon_id=100000000):
    try:
        ctx.sendReaction(data, emoji, thread_id, thread_type, icon_id)
    except Exception:
        pass


def _unreact(ctx, data, thread_id, thread_type):
    try:
        ctx.sendReaction(data, "", thread_id, thread_type, -1)
    except Exception:
        pass


def _start_countdown(ctx, sess, msg_obj):
    if not msg_obj:
        return
    mid = getattr(msg_obj, "msgId",    None)
    cid = getattr(msg_obj, "clientId", None)
    if not mid:
        return

    sess._cooldown_on = True
    react_msg = MessageObject(msgId=mid, cliMsgId=cid, msgType="webchat")

    def _loop():
        for i in range(SESSION_TIMEOUT, 0, -1):
            if not sess._cooldown_on:
                break
            try:
                ctx.sendMultiReaction(react_msg, "🕑",
                                      sess.thread_id, sess.thread_type, 102229, numreact=i)
                time.sleep(1)
                ctx.sendMultiReaction(react_msg, "",
                                      sess.thread_id, sess.thread_type, -1, numreact=i)
            except Exception:
                time.sleep(1)
        sess._cooldown_on = False

    threading.Thread(target=_loop, daemon=True).start()


def _similarity(a, b):
    a, b = a.lower(), b.lower()
    if not a or not b:
        return 0.0
    return sum(1 for c in a if c in b) / max(len(a), len(b))


def _parse_indices(token):
    token = token.strip()
    try:
        if "-" in token and "," not in token:
            a, b = token.split("-", 1)
            return list(range(int(a), int(b) + 1))
        if "," in token:
            return [int(x) for x in token.split(",") if x.strip().isdigit()]
        return [int(token)]
    except Exception:
        return []


def _clean_mem_ver_list(raw):
    out = []
    seen = set()
    for x in raw or []:
        if not x:
            continue
        s = str(x)
        if s.endswith("_0"):
            s = s[:-2]
        if s not in seen:
            seen.add(s)
            out.append(s)
    return out


def _get_admin_ids(info):
    for k in ("adminIds", "adminIdList", "admins", "adminList",
              "adminIdMap", "adminMap", "adminUidList", "adminUidMap"):
        if k not in info:
            continue
        v = info.get(k)
        if isinstance(v, dict):
            return [x for x in v.keys() if x]
        if isinstance(v, (list, tuple, set)):
            return [x for x in v if x]
        if isinstance(v, str):
            return [x for x in v.replace(" ", "").split(",") if x]
        return []
    return []


def _fetch_user_avatar(ctx, uid):
    try:
        info     = ctx.fetchUserInfo(str(uid))
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        return profile.get("avatar") or ""
    except Exception:
        return ""


def _fetch_all_groups(ctx):
    try:
        g       = ctx.fetchAllGroups()
        ver_map = dict(getattr(g, "gridVerMap", {}) or {})
        gids    = list(ver_map.keys())
    except Exception:
        return []

    result = []
    for gid in gids:
        try:
            info_obj = ctx.fetchGroupInfo(str(gid))
            gdata    = getattr(info_obj, "gridInfoMap", {}) or {}
            g_info   = gdata.get(str(gid)) or gdata.get(gid) or {}
            name     = g_info.get("name") or f"Nhóm {gid}"
            avatar   = (
                g_info.get("avt")       or
                g_info.get("avatar")    or
                g_info.get("fullAvt")   or
                g_info.get("avatarUrl") or ""
            )
            creator_id = str(g_info.get("creatorId") or "")
            total      = int(g_info.get("totalMember") or g_info.get("memberCount") or 0)
            if not avatar and creator_id:
                avatar = _fetch_user_avatar(ctx, creator_id)
            result.append({
                "id":          str(gid),
                "name":        name,
                "avatar":      avatar,
                "totalMember": total,
                "creatorId":   creator_id,
            })
        except Exception:
            result.append({
                "id":          str(gid),
                "name":        f"Nhóm {gid}",
                "avatar":      "",
                "totalMember": 0,
                "creatorId":   "",
            })
    return result


def _fetch_group_members(ctx, group_id):
    try:
        info_obj = ctx.fetchGroupInfo(str(group_id))
        gdata    = getattr(info_obj, "gridInfoMap", {}) or {}
        g_info   = gdata.get(str(group_id)) or gdata.get(group_id) or {}
        if not isinstance(g_info, dict):
            g_info = dict(g_info)
        uids = _clean_mem_ver_list(g_info.get("memVerList") or [])
        if not uids:
            return []
    except Exception:
        return []

    BATCH    = 50
    name_map = {}
    for i in range(0, len(uids), BATCH):
        batch = uids[i:i + BATCH]
        try:
            info     = ctx.fetchUserInfo(batch)
            profiles = dict(getattr(info, "changed_profiles", {}) or {})
            for uid, p in profiles.items():
                if isinstance(p, dict):
                    name = (p.get("zName") or p.get("displayName") or
                            p.get("name")  or str(uid))
                else:
                    name = str(
                        getattr(p, "zName", None) or
                        getattr(p, "displayName", None) or uid
                    )
                name_map[str(uid)] = str(name)
        except Exception:
            pass

    return [{"uid": uid, "name": name_map.get(uid, uid)} for uid in uids]


def _send_group_list(ctx, sess, data, *, replace=False):
    if replace:
        _stop_countdown(sess)
        _undo(ctx, sess.list_msg_id, sess.list_cli_id,
              sess.thread_id, sess.thread_type)
        sess.list_msg_id = sess.list_cli_id = None

    uid   = sess.user_id
    items = sess.page_groups()
    tp    = sess.total_pages()

    _react(ctx, data, sess.thread_id, sess.thread_type, "💅")

    msg_obj = None

    if _PILLOW_OK and items:
        card_path = card_url = None
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_group_list(items, card_path, page=sess.page, total_pages=tp)
            res = ctx._uploadImage(card_path, sess.thread_id, sess.thread_type)
            if isinstance(res, dict):
                card_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                card_url = res
        except Exception as e:
            print(f"[ModGrp] card error: {e}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        if card_url:
            name         = ctx.userName(uid) or uid
            mention_text = f"@{name}"
            try:
                msg_obj = ctx.sendRemoteImage(
                    card_url, sess.thread_id, sess.thread_type,
                    width=2560, height=1440,
                    message=Message(
                        text=mention_text,
                        mention=Mention(uid, length=len(mention_text), offset=0),
                    )
                )
            except Exception as e:
                print(f"[ModGrp] sendRemoteImage: {e}")

    # xoá 💅 → reaction 👀 trước khi gửi list
    _unreact(ctx, data, sess.thread_id, sess.thread_type)
    _react(ctx, data, sess.thread_id, sess.thread_type, "👀")

    if msg_obj is None:
        name  = ctx.userName(uid) or uid
        lines = [f"📋 @{name} Danh sách nhóm — Trang {sess.page}/{tp}\n"]
        for i, g in enumerate(items, (sess.page - 1) * PER_PAGE + 1):
            lines.append(f"{i}. {g['name']}  (👥 {g.get('totalMember','?')})")
        lines.append("\n💬 next/back/(số) điều hướng  •  ok thoát")
        msg_obj = ctx.sendMentionStyle("\n".join(lines), uid,
                                       sess.thread_id, sess.thread_type)

    # xoá 👀 sau khi đã gửi xong
    _unreact(ctx, data, sess.thread_id, sess.thread_type)

    if msg_obj:
        sess.list_msg_id = getattr(msg_obj, "msgId",    None)
        sess.list_cli_id = getattr(msg_obj, "clientId", None)
        _start_countdown(ctx, sess, msg_obj)

    sess.touch()


def _do_kick_all(ctx, sess, data, grp, user_id, thread_id, thread_type):
    gid = grp["id"]
    try:
        info_obj = ctx.fetchGroupInfo(gid)
        gdata    = getattr(info_obj, "gridInfoMap", {}) or {}
        g_info   = gdata.get(str(gid)) or gdata.get(gid) or {}
        if not isinstance(g_info, dict):
            g_info = dict(g_info)
    except Exception:
        g_info = {}

    mem_list   = _clean_mem_ver_list(g_info.get("memVerList") or [])
    admin_ids  = {str(x) for x in _get_admin_ids(g_info) if x}
    creator_id = str(g_info.get("creatorId", "") or "")
    bot_id     = str(
        getattr(ctx, "uid", "") or
        getattr(getattr(ctx, "user", None), "id", "") or ""
    )
    protect = {str(user_id), bot_id, creator_id} | admin_ids
    targets = [x for x in mem_list if x and x not in protect]

    if not targets:
        ctx.replyMessageStyle(
            f"Không có thành viên nào để kick trong '{grp['name']}'",
            data, thread_id, thread_type,
            color="yl", title="WARNING", userId=user_id,
        )
        return

    try:
        ctx.kickUsers(targets, gid)
    except Exception as e:
        print(f"[ModGrp] kickUsers all: {e}")
    ctx.replyMessageStyle(
        f"Đã kick {len(targets)} thành viên khỏi '{grp['name']}'",
        data, thread_id, thread_type,
        color="gr", title="SUCCESS", userId=user_id,
    )


def handle_grp_input(ctx, raw_text, data, user_id, thread_id, thread_type):
    if handle_own_input(ctx, raw_text, data, user_id, thread_id, thread_type):
        return True

    sess = _Store.get(str(user_id))
    if not sess or sess.thread_id != str(thread_id):
        return False

    sess.touch()
    uid  = str(user_id)
    text = raw_text.strip()

    if text.lower() == "ok":
        _react(ctx, data, thread_id, thread_type, "💅")
        _stop_countdown(sess)
        _undo_all(ctx, sess)
        _Store.remove(uid)
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "Success",
            data, thread_id, thread_type,
            color="gr", title="SUCCESS", userId=user_id,
        )
        return True

    if sess.in_find_grp:
        t = text.lower()

        if t == "out":
            sess.in_find_grp      = False
            sess.find_grp_results = None
            _stop_countdown(sess)
            _undo(ctx, sess.find_grp_msg_id, sess.find_grp_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_grp_msg_id = sess.find_grp_cli_id = None
            _send_group_list(ctx, sess, data, replace=False)
            return True

        m = re.match(r'^([0-9,\-]+)\s+leave$', t)
        if m and sess.find_grp_results:
            indices = _parse_indices(m.group(1))
            targets = []
            for num in indices:
                if 1 <= num <= len(sess.find_grp_results):
                    targets.append(sess.find_grp_results[num - 1])
            if not targets:
                ctx.replyMessageStyle(
                    "Số không hợp lệ",
                    data, thread_id, thread_type,
                    color="r", title="ERROR", userId=user_id,
                )
                return True
            done, fail = [], []
            for grp in targets:
                try:
                    ctx.leaveGroup(grp["id"], True)
                    done.append(grp["name"])
                except Exception as e:
                    print(f"[ModGrp] leaveGroup {grp['id']}: {e}")
                    fail.append(grp["name"])
            lines = []
            if done:
                lines.append(f"Đã leave {len(done)} nhóm: {', '.join(done)}")
            if fail:
                lines.append(f"Lỗi: {', '.join(fail)}")
            ctx.replyMessageStyle(
                "\n".join(lines),
                data, thread_id, thread_type,
                color="gr" if not fail else "yl", title="SUCCESS" if not fail else "WARNING", userId=user_id,
            )
            if done:
                left_ids = {g["id"] for g in targets if g["name"] in done}
                sess.groups           = [g for g in sess.groups if g["id"] not in left_ids]
                sess.find_grp_results = [g for g in sess.find_grp_results if g["id"] not in left_ids]
            return True

        m = re.match(r'^([0-9,\-]+)\s+kick\s+all$', t)
        if m and sess.find_grp_results:
            indices = _parse_indices(m.group(1))
            targets = []
            for num in indices:
                if 1 <= num <= len(sess.find_grp_results):
                    targets.append(sess.find_grp_results[num - 1])
            if not targets:
                ctx.replyMessageStyle(
                    "Số không hợp lệ",
                    data, thread_id, thread_type,
                    color="r", title="ERROR", userId=user_id,
                )
                return True
            for grp in targets:
                _do_kick_all(ctx, sess, data, grp, user_id, thread_id, thread_type)
            return True

        m = re.match(r'^(\d+)\s+info$', t)
        if m and sess.find_grp_results:
            num = int(m.group(1))
            if not (1 <= num <= len(sess.find_grp_results)):
                ctx.replyMessageStyle(
                    f"Số {num} không hợp lệ",
                    data, thread_id, thread_type,
                    color="r", title="ERROR", userId=user_id,
                )
                return True
            grp          = sess.find_grp_results[num - 1]
            creator_name = "?"
            total        = grp.get("totalMember", 0)
            try:
                info_obj   = ctx.fetchGroupInfo(grp["id"])
                gdata      = getattr(info_obj, "gridInfoMap", {}) or {}
                g_info     = gdata.get(str(grp["id"])) or {}
                creator_id = str(g_info.get("creatorId") or "")
                total      = int(g_info.get("totalMember") or total)
                if creator_id:
                    creator_name = ctx.userName(creator_id) or creator_id
            except Exception:
                pass
            ctx.replyMessageStyle(
                f"Nhóm #{num}\n\nTên    : {grp['name']}\nID     : {grp['id']}\nTrưởng : {creator_name}\nMem    : {total}",
                data, thread_id, thread_type,
                color="or", title="CAUTION", userId=user_id,
            )
            return True

        return True

    if sess.in_find:
        t = text.lower()

        if t == "out":
            sess.in_find      = False
            sess.find_results = None
            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            _send_group_list(ctx, sess, data, replace=False)
            return True

        if t == "kick all" and sess.find_results:
            gid     = (sess.find_results[0] or {}).get("_group_id")
            targets = [m["uid"] for m in sess.find_results]
            if gid and targets:
                try:
                    ctx.kickUsers(targets, gid)
                except Exception as e:
                    print(f"[ModGrp] kick all find: {e}")
                ctx.replyMessageStyle(
                    f"Đã kick {len(targets)} thành viên tìm được",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )
            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            sess.in_find      = False
            sess.find_results = None
            return True

        m = re.match(r'^([0-9,\-]+)\s+(kick|block)$', t)
        if m and sess.find_results:
            indices = _parse_indices(m.group(1))
            action  = m.group(2)
            gid     = (sess.find_results[0] or {}).get("_group_id")
            if not gid:
                return True

            targets = []
            for num in indices:
                if 1 <= num <= len(sess.find_results):
                    targets.append(sess.find_results[num - 1]["uid"])

            if not targets:
                ctx.replyMessageStyle(
                    "Số không hợp lệ",
                    data, thread_id, thread_type,
                    color="r", title="ERROR", userId=user_id,
                )
                return True

            if action == "kick":
                try:
                    ctx.kickUsers(targets, gid)
                except Exception as e:
                    print(f"[ModGrp] kickUsers: {e}")
                ctx.replyMessageStyle(
                    f"Đã kick {len(targets)} thành viên",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )
            else:
                try:
                    ctx.blockUsers(targets, gid)
                except Exception as e:
                    print(f"[ModGrp] blockUsers: {e}")
                ctx.replyMessageStyle(
                    f"Đã block {len(targets)} thành viên",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )

            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            sess.in_find      = False
            sess.find_results = None
            return True

        return True

    m = re.match(r'^next(?:\s+(\d+))?$', text, re.IGNORECASE)
    if m:
        target = int(m.group(1)) if m.group(1) else sess.page + 1
        if not (1 <= target <= sess.total_pages()):
            ctx.replyMessageStyle(
                f"Trang {target} không tồn tại (1–{sess.total_pages()})",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        sess.page = target
        _send_group_list(ctx, sess, data, replace=True)
        return True

    if text.lower() == "back":
        if sess.page <= 1:
            ctx.replyMessageStyle(
                "Đang ở trang đầu rồi",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        sess.page -= 1
        _send_group_list(ctx, sess, data, replace=True)
        return True

    if text.lower() == "update list":
        _react(ctx, data, thread_id, thread_type, "💅")
        groups = _fetch_all_groups(ctx)
        _unreact(ctx, data, thread_id, thread_type)
        if not groups:
            ctx.replyMessageStyle(
                "Không tải được danh sách nhóm",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        sess.groups = groups
        sess.page   = 1
        _send_group_list(ctx, sess, data, replace=True)
        return True

    m = re.match(r'^([0-9,\-]+)\s+kick\s+all$', text, re.IGNORECASE)
    if m:
        indices = _parse_indices(m.group(1))
        targets = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append(sess.groups[offset])
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        for grp in targets:
            _do_kick_all(ctx, sess, data, grp, user_id, thread_id, thread_type)
        return True

    m = re.match(r'^([0-9,\-]+)\s+run\s+stg\s+(.+)$', text, re.IGNORECASE)
    if m:
        indices  = _parse_indices(m.group(1))
        stg_tail = m.group(2).strip()
        targets  = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append(sess.groups[offset])
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        try:
            from src.command.groupBot.settingGroup import settingGroupCommand
        except ImportError:
            _unreact(ctx, data, thread_id, thread_type)
            ctx.replyMessageStyle(
                "Không tải được module stg",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        p    = getattr(ctx, "prefix", "/")
        done, fail = [], []
        for grp in targets:
            fake_msg = Message(text=f"{p}stg {stg_tail}")
            try:
                # Bọc ctx để chặn settingGroupCommand tự gửi tin riêng
                class _SilentCtx:
                    def __getattr__(self, name):
                        attr = getattr(ctx, name)
                        if name in ("replyMessageStyle", "sendMessage",
                                    "sendMentionStyle", "sendRemoteImage"):
                            return lambda *a, **kw: None
                        return attr
                settingGroupCommand(_SilentCtx(), fake_msg, data, uid, grp["id"], thread_type)
                done.append(grp["name"])
            except Exception as e:
                print(f"[ModGrp] stg {grp['id']}: {e}")
                fail.append(grp["name"])
        lines = [f"stg {stg_tail}"]
        if done:
            lines.append(f"OK   : {', '.join(done)}")
        if fail:
            lines.append(f"Lỗi  : {', '.join(fail)}")
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "\n".join(lines),
            data, thread_id, thread_type,
            color="gr" if not fail else "yl",
            title="SUCCESS" if not fail else "WARNING",
            userId=user_id,
        )
        return True

    m = re.match(r'^(\d+)\s+info$', text, re.IGNORECASE)
    if m:
        num    = int(m.group(1))
        offset = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        grp          = sess.groups[offset]
        creator_name = "?"
        total        = grp.get("totalMember", 0)
        try:
            info_obj   = ctx.fetchGroupInfo(grp["id"])
            gdata      = getattr(info_obj, "gridInfoMap", {}) or {}
            g_info     = gdata.get(str(grp["id"])) or {}
            creator_id = str(g_info.get("creatorId") or "")
            total      = int(g_info.get("totalMember") or total)
            if creator_id:
                creator_name = ctx.userName(creator_id) or creator_id
        except Exception:
            pass
        ctx.replyMessageStyle(
            f"Nhóm #{num}\n\n"
            f"Tên    : {grp['name']}\n"
            f"ID     : {grp['id']}\n"
            f"Trưởng : {creator_name}\n"
            f"Mem    : {total}",
            data, thread_id, thread_type,
            color="or", title="CAUTION", userId=user_id,
        )
        return True

    m = re.match(r'^(\d+)\s+find\s+mem\s+(.+)$', text, re.IGNORECASE)
    if m:
        num     = int(m.group(1))
        keyword = m.group(2).strip()
        offset  = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        grp = sess.groups[offset]
        _react(ctx, data, thread_id, thread_type, "💅")
        members = _fetch_group_members(ctx, grp["id"])
        _unreact(ctx, data, thread_id, thread_type)
        if not members:
            ctx.replyMessageStyle(
                f"Không lấy được thành viên nhóm '{grp['name']}'",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        matched = [mem for mem in members if _similarity(keyword, mem["name"]) >= 0.7]
        if not matched:
            ctx.replyMessageStyle(
                f"Không tìm thấy ai khớp '{keyword}' trong '{grp['name']}'",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        for mem in matched:
            mem["_group_id"] = grp["id"]
        lines = [f"'{keyword}' trong {grp['name']}\n"]
        for i, mem in enumerate(matched, 1):
            lines.append(f"{i}. {mem['name']}  ({mem['uid']})")
        find_msg = ctx.sendMentionStyle("\n".join(lines), uid, thread_id, thread_type)
        sess.in_find      = True
        sess.find_results = matched
        sess.find_msg_id  = getattr(find_msg, "msgId",    None)
        sess.find_cli_id  = getattr(find_msg, "clientId", None)
        return True

    m = re.match(r'^find\s+group\s+(.+)$', text, re.IGNORECASE)
    if m:
        keywords = [kw.strip().lower() for kw in re.split(r'[,\s]+', m.group(1).strip()) if kw.strip()]
        matched  = [
            g for g in sess.groups
            if any(kw in g["name"].lower() for kw in keywords)
        ]
        if not matched:
            ctx.replyMessageStyle(
                f"Không tìm thấy nhóm nào khớp '{m.group(1).strip()}'",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        lines = [f"Tìm '{m.group(1).strip()}' — {len(matched)} nhóm\n"]
        for i, g in enumerate(matched, 1):
            lines.append(f"{i}. {g['name']}  (👥 {g.get('totalMember', '?')})")
        lines.append("\n(số/range) leave  •  (số/range) kick all  •  (số) info  •  out")
        find_grp_msg = ctx.sendMentionStyle("\n".join(lines), uid, thread_id, thread_type)
        _unreact(ctx, data, sess.thread_id, sess.thread_type)
        sess.in_find_grp      = True
        sess.find_grp_results = matched
        sess.find_grp_msg_id  = getattr(find_grp_msg, "msgId",    None)
        sess.find_grp_cli_id  = getattr(find_grp_msg, "clientId", None)
        return True

    m = re.match(r'^([0-9,\-]+)\s+leave$', text, re.IGNORECASE)
    if m:
        indices = _parse_indices(m.group(1))
        targets = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append(sess.groups[offset])
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        done, fail = [], []
        for grp in targets:
            try:
                ctx.leaveGroup(grp["id"], True)
                done.append(grp["name"])
            except Exception as e:
                print(f"[ModGrp] leaveGroup {grp['id']}: {e}")
                fail.append(grp["name"])
        lines = []
        if done:
            lines.append(f"Đã leave {len(done)} nhóm: {', '.join(done)}")
        if fail:
            lines.append(f"Lỗi: {', '.join(fail)}")
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "\n".join(lines),
            data, thread_id, thread_type,
            color="gr" if not fail else "yl",
            title="SUCCESS" if not fail else "WARNING",
            userId=user_id,
        )
        if done:
            sess.groups = [g for g in sess.groups if g["name"] not in done]
            if sess.page > sess.total_pages():
                sess.page = max(1, sess.total_pages())
            _send_group_list(ctx, sess, data, replace=True)
        return True

    if re.match(r'^\d+$', text):
        p = int(text)
        if 1 <= p <= sess.total_pages():
            _react(ctx, data, thread_id, thread_type, "💅")
            sess.page = p
            _send_group_list(ctx, sess, data, replace=True)
        else:
            ctx.replyMessageStyle(
                f"Trang {p} không tồn tại (1–{sess.total_pages()})",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
        return True

    if re.match(r'^management\s+ownership\s+groups?$', text, re.IGNORECASE):
        _stop_countdown(sess)
        _undo_all(ctx, sess)
        _Store.remove(uid)
        start_own_session(ctx, data, user_id, thread_id, thread_type)
        return True

    return True
    uid = str(user_id)
    _react(ctx, data, thread_id, thread_type, "💅")
    loading_msg = ctx.sendMentionStyle("⏳ Đang tải danh sách nhóm...", uid, thread_id, thread_type)
    groups = _fetch_all_groups(ctx)
    if loading_msg:
        try:
            ctx.deleteMessage(
                getattr(loading_msg, "msgId",    None),
                ctx.uid,
                getattr(loading_msg, "clientId", None),
                thread_id,
            )
        except Exception:
            pass
    if not groups:
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "Không tải được danh sách nhóm",
            data, thread_id, thread_type,
            color="r", title="ERROR", userId=user_id,
        )
        return
    sess = ModGrpSession(uid, thread_id, thread_type, groups)
    _Store.set(uid, sess)
    _unreact(ctx, data, thread_id, thread_type)
    _send_group_list(ctx, sess, data)


def start_grp_session(ctx, data, user_id, thread_id, thread_type):
    uid = str(user_id)
    _react(ctx, data, thread_id, thread_type, "💅")
    loading_msg = ctx.sendMentionStyle("⏳ Đang tải danh sách nhóm...", uid, thread_id, thread_type)
    groups = _fetch_all_groups(ctx)
    if loading_msg:
        try:
            ctx.deleteMessage(
                getattr(loading_msg, "msgId",    None),
                ctx.uid,
                getattr(loading_msg, "clientId", None),
                thread_id,
            )
        except Exception:
            pass
    if not groups:
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "Không tải được danh sách nhóm",
            data, thread_id, thread_type,
            color="r", title="ERROR", userId=user_id,
        )
        return
    sess = ModGrpSession(uid, thread_id, thread_type, groups)
    _Store.set(uid, sess)
    _unreact(ctx, data, thread_id, thread_type)
    _send_group_list(ctx, sess, data)


def start_cleanup():
    def _loop():
        while True:
            time.sleep(60)
            _Store.cleanup()
    threading.Thread(target=_loop, daemon=True).start()

class OwnGrpSession:
    def __init__(self, user_id, thread_id, thread_type, groups):
        self.user_id      = str(user_id)
        self.thread_id    = str(thread_id)
        self.thread_type  = thread_type
        self.groups       = groups
        self.page         = 1
        self.list_msg_id  = None
        self.list_cli_id  = None
        self._cooldown_on = False
        self.in_find      = False
        self.find_results = None
        self.find_msg_id  = None
        self.find_cli_id  = None
        self.updated_at   = time.time()

    def touch(self):
        self.updated_at = time.time()

    def total_pages(self):
        return max(1, (len(self.groups) + PER_PAGE - 1) // PER_PAGE)

    def page_groups(self, p=None):
        p = (p or self.page) - 1
        return self.groups[p * PER_PAGE:(p + 1) * PER_PAGE]


class _OwnStore:
    _s: dict = {}

    @classmethod
    def get(cls, uid):
        return cls._s.get(str(uid))

    @classmethod
    def set(cls, uid, sess):
        cls._s[str(uid)] = sess

    @classmethod
    def remove(cls, uid):
        cls._s.pop(str(uid), None)

    @classmethod
    def cleanup(cls):
        now = time.time()
        for uid in list(cls._s):
            if now - cls._s[uid].updated_at > SESSION_TIMEOUT + 30:
                cls._s.pop(uid, None)


def _fetch_owned_groups(ctx):
    bot_id = str(getattr(ctx, "uid", "") or "")
    try:
        g       = ctx.fetchAllGroups()
        ver_map = dict(getattr(g, "gridVerMap", {}) or {})
        gids    = list(ver_map.keys())
    except Exception:
        return []

    result = []
    for gid in gids:
        try:
            info_obj = ctx.fetchGroupInfo(str(gid))
            gdata    = getattr(info_obj, "gridInfoMap", {}) or {}
            g_info   = gdata.get(str(gid)) or gdata.get(gid) or {}
            creator_id = str(g_info.get("creatorId") or "")
            admin_ids  = {str(x) for x in _get_admin_ids(g_info) if x}
            if bot_id and (bot_id != creator_id and bot_id not in admin_ids):
                continue
            name   = g_info.get("name") or f"Nhóm {gid}"
            avatar = (
                g_info.get("avt")       or
                g_info.get("avatar")    or
                g_info.get("fullAvt")   or
                g_info.get("avatarUrl") or ""
            )
            total = int(g_info.get("totalMember") or g_info.get("memberCount") or 0)
            if not avatar and creator_id:
                avatar = _fetch_user_avatar(ctx, creator_id)
            result.append({
                "id":          str(gid),
                "name":        name,
                "avatar":      avatar,
                "totalMember": total,
                "creatorId":   creator_id,
            })
        except Exception:
            pass
    return result


def _send_own_list(ctx, sess, data, *, replace=False):
    if replace:
        _stop_countdown(sess)
        _undo(ctx, sess.list_msg_id, sess.list_cli_id,
              sess.thread_id, sess.thread_type)
        sess.list_msg_id = sess.list_cli_id = None

    uid   = sess.user_id
    items = sess.page_groups()
    tp    = sess.total_pages()

    _react(ctx, data, sess.thread_id, sess.thread_type, "💅")

    msg_obj = None

    if _PILLOW_OK and items:
        card_path = card_url = None
        try:
            os.makedirs("data/assets/cache/cards", exist_ok=True)
            card_path = f"data/assets/cache/cards/{uuid.uuid4().hex}.jpg"
            draw_group_list(items, card_path, page=sess.page, total_pages=tp)
            res = ctx._uploadImage(card_path, sess.thread_id, sess.thread_type)
            if isinstance(res, dict):
                card_url = res.get("normalUrl") or res.get("hdUrl")
            elif isinstance(res, str) and res.startswith("http"):
                card_url = res
        except Exception as e:
            print(f"[OwnGrp] card error: {e}")
        finally:
            if card_path and os.path.exists(card_path):
                try:
                    os.remove(card_path)
                except Exception:
                    pass

        if card_url:
            name         = ctx.userName(uid) or uid
            mention_text = f"@{name}"
            try:
                msg_obj = ctx.sendRemoteImage(
                    card_url, sess.thread_id, sess.thread_type,
                    width=2560, height=1440,
                    message=Message(
                        text=mention_text,
                        mention=Mention(uid, length=len(mention_text), offset=0),
                    )
                )
            except Exception as e:
                print(f"[OwnGrp] sendRemoteImage: {e}")

    _unreact(ctx, data, sess.thread_id, sess.thread_type)
    _react(ctx, data, sess.thread_id, sess.thread_type, "👀")

    if msg_obj is None:
        name  = ctx.userName(uid) or uid
        lines = [f"👑 @{name} Nhóm đang quản trị — Trang {sess.page}/{tp}\n"]
        for i, g in enumerate(items, (sess.page - 1) * PER_PAGE + 1):
            lines.append(f"{i}. {g['name']}  (👥 {g.get('totalMember','?')})")
        lines.append("\nnext/back/(số) trang  •  ok thoát")
        msg_obj = ctx.sendMentionStyle("\n".join(lines), uid,
                                       sess.thread_id, sess.thread_type)

    _unreact(ctx, data, sess.thread_id, sess.thread_type)

    if msg_obj:
        sess.list_msg_id = getattr(msg_obj, "msgId",    None)
        sess.list_cli_id = getattr(msg_obj, "clientId", None)
        _start_countdown(ctx, sess, msg_obj)

    sess.touch()


def _undo_own_all(ctx, sess):
    _undo(ctx, sess.list_msg_id, sess.list_cli_id, sess.thread_id, sess.thread_type)
    sess.list_msg_id = sess.list_cli_id = None
    if sess.find_msg_id:
        _undo(ctx, sess.find_msg_id, sess.find_cli_id, sess.thread_id, sess.thread_type)
        sess.find_msg_id = sess.find_cli_id = None


def handle_own_input(ctx, raw_text, data, user_id, thread_id, thread_type):
    sess = _OwnStore.get(str(user_id))
    if not sess or sess.thread_id != str(thread_id):
        return False

    sess.touch()
    uid  = str(user_id)
    text = raw_text.strip()

    if text.lower() == "ok":
        _react(ctx, data, thread_id, thread_type, "💅")
        _stop_countdown(sess)
        _undo_own_all(ctx, sess)
        _OwnStore.remove(uid)
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "Success",
            data, thread_id, thread_type,
            color="gr", title="SUCCESS", userId=user_id,
        )
        return True

    if sess.in_find:
        t = text.lower()

        if t == "out":
            sess.in_find      = False
            sess.find_results = None
            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            _send_own_list(ctx, sess, data, replace=False)
            return True

        if t == "kick all" and sess.find_results:
            gid     = (sess.find_results[0] or {}).get("_group_id")
            targets = [mem["uid"] for mem in sess.find_results]
            if gid and targets:
                try:
                    ctx.kickUsers(targets, gid)
                except Exception as e:
                    print(f"[OwnGrp] kick all find: {e}")
                ctx.replyMessageStyle(
                    f"Đã kick {len(targets)} thành viên tìm được",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )
            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            sess.in_find      = False
            sess.find_results = None
            return True

        m = re.match(r'^([0-9,\-]+)\s+(kick|block)$', t)
        if m and sess.find_results:
            indices = _parse_indices(m.group(1))
            action  = m.group(2)
            gid     = (sess.find_results[0] or {}).get("_group_id")
            if not gid:
                return True
            targets = []
            for num in indices:
                if 1 <= num <= len(sess.find_results):
                    targets.append(sess.find_results[num - 1]["uid"])
            if not targets:
                ctx.replyMessageStyle(
                    "Số không hợp lệ",
                    data, thread_id, thread_type,
                    color="r", title="ERROR", userId=user_id,
                )
                return True
            if action == "kick":
                try:
                    ctx.kickUsers(targets, gid)
                except Exception as e:
                    print(f"[OwnGrp] kickUsers: {e}")
                ctx.replyMessageStyle(
                    f"Đã kick {len(targets)} thành viên",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )
            else:
                try:
                    ctx.blockUsers(targets, gid)
                except Exception as e:
                    print(f"[OwnGrp] blockUsers: {e}")
                ctx.replyMessageStyle(
                    f"Đã block {len(targets)} thành viên",
                    data, thread_id, thread_type,
                    color="gr", title="SUCCESS", userId=user_id,
                )
            _stop_countdown(sess)
            _undo(ctx, sess.find_msg_id, sess.find_cli_id,
                  sess.thread_id, sess.thread_type)
            sess.find_msg_id = sess.find_cli_id = None
            sess.in_find      = False
            sess.find_results = None
            return True

        return True

    m = re.match(r'^next(?:\s+(\d+))?$', text, re.IGNORECASE)
    if m:
        target = int(m.group(1)) if m.group(1) else sess.page + 1
        if not (1 <= target <= sess.total_pages()):
            ctx.replyMessageStyle(
                f"Trang {target} không tồn tại (1–{sess.total_pages()})",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        sess.page = target
        _send_own_list(ctx, sess, data, replace=True)
        return True

    if text.lower() == "back":
        if sess.page <= 1:
            ctx.replyMessageStyle(
                "Đang ở trang đầu rồi",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        sess.page -= 1
        _send_own_list(ctx, sess, data, replace=True)
        return True

    if re.match(r'^\d+$', text):
        p = int(text)
        if 1 <= p <= sess.total_pages():
            _react(ctx, data, thread_id, thread_type, "💅")
            sess.page = p
            _send_own_list(ctx, sess, data, replace=True)
        else:
            ctx.replyMessageStyle(
                f"Trang {p} không tồn tại (1–{sess.total_pages()})",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
        return True

    if text.lower() == "update list":
        _react(ctx, data, thread_id, thread_type, "💅")
        groups = _fetch_owned_groups(ctx)
        if not groups:
            _unreact(ctx, data, thread_id, thread_type)
            ctx.replyMessageStyle(
                "Không tải được danh sách nhóm",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        sess.groups = groups
        sess.page   = 1
        _send_own_list(ctx, sess, data, replace=True)
        return True

    m = re.match(r'^(\d+)\s+find\s+mem\s+(.+)$', text, re.IGNORECASE)
    if m:
        num     = int(m.group(1))
        keyword = m.group(2).strip()
        offset  = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        grp = sess.groups[offset]
        _react(ctx, data, thread_id, thread_type, "💅")
        members = _fetch_group_members(ctx, grp["id"])
        _unreact(ctx, data, thread_id, thread_type)
        if not members:
            ctx.replyMessageStyle(
                f"Không lấy được thành viên nhóm '{grp['name']}'",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        matched = [mem for mem in members if _similarity(keyword, mem["name"]) >= 0.7]
        if not matched:
            ctx.replyMessageStyle(
                f"Không tìm thấy ai khớp '{keyword}' trong '{grp['name']}'",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        for mem in matched:
            mem["_group_id"] = grp["id"]
        lines = [f"'{keyword}' trong {grp['name']}\n"]
        for i, mem in enumerate(matched, 1):
            lines.append(f"{i}. {mem['name']}  ({mem['uid']})")
        find_msg = ctx.sendMentionStyle("\n".join(lines), uid, thread_id, thread_type)
        sess.in_find      = True
        sess.find_results = matched
        sess.find_msg_id  = getattr(find_msg, "msgId",    None)
        sess.find_cli_id  = getattr(find_msg, "clientId", None)
        return True

    m = re.match(r'^(\d+)\s+kick\s+all$', text, re.IGNORECASE)
    if m:
        num    = int(m.group(1))
        offset = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        grp = sess.groups[offset]
        _do_kick_all(ctx, sess, data, grp, user_id, thread_id, thread_type)
        return True

    m = re.match(r'^([0-9,\-]+)\s+kick\s+all$', text, re.IGNORECASE)
    if m:
        indices = _parse_indices(m.group(1))
        targets = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append(sess.groups[offset])
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        for grp in targets:
            _do_kick_all(ctx, sess, data, grp, user_id, thread_id, thread_type)
        return True

    m = re.match(r'^([0-9,\-]+)\s+change\s+name\s+(.+)$', text, re.IGNORECASE)
    if m:
        indices  = _parse_indices(m.group(1))
        new_name = m.group(2).strip()
        targets  = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append((offset, sess.groups[offset]))
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        done, fail = [], []
        for offset, grp in targets:
            try:
                ctx.changeGroupName(new_name, grp["id"])
                sess.groups[offset]["name"] = new_name
                done.append(grp["name"])
            except Exception as e:
                print(f"[OwnGrp] changeGroupName {grp['id']}: {e}")
                fail.append(grp["name"])
        lines = [f"change name → {new_name}"]
        if done:
            lines.append(f"OK   : {', '.join(done)}")
        if fail:
            lines.append(f"Lỗi  : {', '.join(fail)}")
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "\n".join(lines),
            data, thread_id, thread_type,
            color="gr" if not fail else "yl",
            title="SUCCESS" if not fail else "WARNING",
            userId=user_id,
        )
        return True

    m = re.match(r'^([0-9,\-]+)\s+dislink$', text, re.IGNORECASE)
    if m:
        indices = _parse_indices(m.group(1))
        targets = []
        for num in indices:
            offset = (sess.page - 1) * PER_PAGE + num - 1
            if 0 <= offset < len(sess.groups):
                targets.append(sess.groups[offset])
        if not targets:
            ctx.replyMessageStyle(
                "Số không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        _react(ctx, data, thread_id, thread_type, "💅")
        done, fail = [], []
        for grp in targets:
            try:
                res = ctx.dislink(grp["id"])
                if isinstance(res, dict) and res.get("success"):
                    done.append(grp["name"])
                else:
                    err = res.get("error_message", "lỗi") if isinstance(res, dict) else "lỗi"
                    fail.append(f"{grp['name']} ({err})")
            except Exception as e:
                print(f"[OwnGrp] dislink {grp['id']}: {e}")
                fail.append(grp["name"])
        lines = ["dislink nhóm"]
        if done:
            lines.append(f"OK   : {', '.join(done)}")
        if fail:
            lines.append(f"Lỗi  : {', '.join(fail)}")
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "\n".join(lines),
            data, thread_id, thread_type,
            color="gr" if not fail else "yl",
            title="SUCCESS" if not fail else "WARNING",
            userId=user_id,
        )
        return True

    m = re.match(r'^(\d+)\s+newlink$', text, re.IGNORECASE)
    if m:
        num    = int(m.group(1))
        offset = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        grp = sess.groups[offset]
        _react(ctx, data, thread_id, thread_type, "💅")
        try:
            res = ctx.newlink(grp["id"])
        except Exception as e:
            print(f"[OwnGrp] newlink {grp['id']}: {e}")
            res = {"success": False, "error_message": str(e)}
        _unreact(ctx, data, thread_id, thread_type)
        if isinstance(res, dict) and res.get("success"):
            ctx.replyMessageStyle(
                f"newlink {grp['name']}\n\n{res.get('new_link', '')}",
                data, thread_id, thread_type,
                color="gr", title="SUCCESS", userId=user_id,
            )
        else:
            err = res.get("error_message", "lỗi") if isinstance(res, dict) else "lỗi"
            ctx.replyMessageStyle(
                f"newlink {grp['name']}\nLỗi: {err}",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
        return True

    m = re.match(r'^(\d+)\s+info$', text, re.IGNORECASE)
    if m:
        num    = int(m.group(1))
        offset = (sess.page - 1) * PER_PAGE + num - 1
        if not (0 <= offset < len(sess.groups)):
            ctx.replyMessageStyle(
                f"Số {num} không hợp lệ trong trang này",
                data, thread_id, thread_type,
                color="r", title="ERROR", userId=user_id,
            )
            return True
        grp          = sess.groups[offset]
        creator_name = "?"
        total        = grp.get("totalMember", 0)
        try:
            info_obj   = ctx.fetchGroupInfo(grp["id"])
            gdata      = getattr(info_obj, "gridInfoMap", {}) or {}
            g_info     = gdata.get(str(grp["id"])) or {}
            creator_id = str(g_info.get("creatorId") or "")
            total      = int(g_info.get("totalMember") or total)
            if creator_id:
                creator_name = ctx.userName(creator_id) or creator_id
        except Exception:
            pass
        ctx.replyMessageStyle(
            f"Nhóm #{num}\n\n"
            f"Tên    : {grp['name']}\n"
            f"ID     : {grp['id']}\n"
            f"Trưởng : {creator_name}\n"
            f"Mem    : {total}",
            data, thread_id, thread_type,
            color="or", title="CAUTION", userId=user_id,
        )
        return True

    return True


def start_own_session(ctx, data, user_id, thread_id, thread_type):
    uid = str(user_id)
    _react(ctx, data, thread_id, thread_type, "💅")
    loading_msg = ctx.sendMentionStyle("⏳ Đang tải nhóm đang quản trị...", uid, thread_id, thread_type)
    groups = _fetch_owned_groups(ctx)
    if loading_msg:
        try:
            ctx.deleteMessage(
                getattr(loading_msg, "msgId",    None),
                ctx.uid,
                getattr(loading_msg, "clientId", None),
                thread_id,
            )
        except Exception:
            pass
    if not groups:
        _unreact(ctx, data, thread_id, thread_type)
        ctx.replyMessageStyle(
            "Bot không làm quản trị nhóm nào",
            data, thread_id, thread_type,
            color="r", title="ERROR", userId=user_id,
        )
        return
    sess = OwnGrpSession(uid, thread_id, thread_type, groups)
    _OwnStore.set(uid, sess)
    _unreact(ctx, data, thread_id, thread_type)
    _send_own_list(ctx, sess, data)
