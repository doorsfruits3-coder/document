"""
lazy_undo.py  –  Tính năng "lazy": thả /-heart để thu hồi tin nhắn bot gửi
Đặt tại: src/services/utils/lazy_undo.py

Port từ:
  zBug/src/events/automations/eventReaction.py  (trigger logic)
  zBug/functions/engine/bot/chatMessage.py       (GhostFunctions – ghost mode)

Cách hoạt động:
  1. Mỗi khi bot gửi tin nhắn, gọi push_bot_message() để lưu msgId/cliMsgId.
  2. Khi có reaction /-heart vào bất kỳ tin nào của bot, gọi handle_reaction_undo().
  3. Ghost mode (ghostStatus=True): tự động xoá tin bot sau ghostDelay giây.
"""

import threading
import time

from src.services.utils.jsonio import read_settings

GHOST_DELAY = 60  # giây trước khi ghost xoá tin


# ── Lưu / truy xuất tin nhắn đã gửi của bot ──────────────────────────────────

def push_bot_message(self, sent, threadId):
    """
    Gọi sau mỗi lần bot gửi tin thành công.
    Lưu vào self._botMessages dict: key = "msgId:cliId:threadId"
    """
    if not sent or not threadId:
        return

    msgId  = getattr(sent, "msgId",    None)
    cliId  = getattr(sent, "clientId", None) or getattr(sent, "cliMsgId", None)
    if not msgId or not cliId:
        return

    if not hasattr(self, "_botMessages") or not isinstance(self._botMessages, dict):
        self._botMessages = {}

    k = f"{msgId}:{cliId}:{threadId}"
    self._botMessages[k] = {
        "msgId":    msgId,
        "cliId":    cliId,
        "threadId": threadId,
        "ts":       time.time(),
    }

    # Khởi ghost loop nếu cần
    _init_ghost_loop(self)


# ── Handler reaction /-heart → undo ──────────────────────────────────────────

def handle_reaction_undo(self, message, data, userId, threadId, type):
    """
    Gọi từ onMessage khi msgType == "chat.reaction".
    Nếu icon là /-heart và undoMode bật → thu hồi tin nhắn bị react.
    """
    if getattr(data, "msgType", None) != "chat.reaction":
        return

    content = getattr(data, "content", None) or {}
    if not isinstance(content, dict):
        return

    rIcon = content.get("rIcon") or getattr(message, "rIcon", None)
    if rIcon != "/-heart":
        return

    s = read_settings(self.uid) or {}
    if not s.get("undoMode", False):
        return

    # Lấy msgId + cliMsgId của tin bị react
    rMsg = content.get("rMsg") or getattr(message, "rMsg", None) or []
    if not rMsg:
        return

    msg    = rMsg[0] if isinstance(rMsg, list) else rMsg
    gMsgId = None
    cMsgId = None

    if isinstance(msg, dict):
        gMsgId = msg.get("gMsgID") or msg.get("msgId")
        cMsgId = msg.get("cMsgID") or msg.get("cliMsgId")
    else:
        gMsgId = getattr(msg, "gMsgID", None) or getattr(msg, "msgId",    None)
        cMsgId = getattr(msg, "cMsgID", None) or getattr(msg, "cliMsgId", None)

    if not gMsgId or not cMsgId:
        return

    # threadId truyền trực tiếp từ onMessage để đúng với cả USER lẫn GROUP
    if not threadId:
        threadId = getattr(data, "idTo", None) or getattr(data, "threadId", None)
    if not threadId:
        return

    # Chỉ thu hồi nếu tin đó là của bot (kiểm tra _botMessages)
    k = f"{gMsgId}:{cMsgId}:{threadId}"
    store = getattr(self, "_botMessages", {})
    if k not in store:
        return

    try:
        self.undoMessage(gMsgId, cMsgId, threadId, type)
    except Exception:
        pass
    finally:
        store.pop(k, None)


# ── Ghost mode: tự xoá tin sau ghostDelay giây ───────────────────────────────

def _init_ghost_loop(self):
    """Khởi thread nền xoá tin ghost (chỉ chạy 1 lần / bot)."""
    if getattr(self, "_ghostLoop", False):
        return
    self._ghostLoop = True

    if not hasattr(self, "_botMessages") or not isinstance(self._botMessages, dict):
        self._botMessages = {}

    def loop():
        while True:
            time.sleep(GHOST_DELAY)
            s = read_settings(self.uid) or {}
            if not s.get("ghostStatus", False):
                continue

            now = time.time()
            for k, v in list(self._botMessages.items()):
                if not isinstance(v, dict):
                    self._botMessages.pop(k, None)
                    continue
                try:
                    ts = float(v.get("ts") or 0)
                except Exception:
                    ts = 0
                if ts <= 0 or (now - ts) < GHOST_DELAY:
                    continue

                msgId    = v.get("msgId")
                cliId    = v.get("cliId")
                threadId = v.get("threadId")
                try:
                    if msgId and cliId and threadId:
                        self.deleteMessage(msgId, self.uid, cliId, threadId)
                except Exception:
                    pass
                finally:
                    self._botMessages.pop(k, None)

    threading.Thread(target=loop, daemon=True).start()
    