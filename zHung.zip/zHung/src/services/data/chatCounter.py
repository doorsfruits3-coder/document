"""
chatCounter.py  –  Đếm & lưu tin nhắn theo group và global, tách riêng theo bot_uid.

Data structure:
  data/config/chat_count/<bot_uid>/group_<threadId>.json
    { "userId": { "count": N }, ... }

  data/config/chat_count/<bot_uid>/global.json
    { "threadId": { "count": N }, ... }

Lưu ý:
  - Chỉ lưu count + UID, KHÔNG lưu name/avatar (lấy live khi cần).
  - Mỗi bot có thư mục riêng → không bao giờ nhầm data giữa các bot.
"""

import os, json, threading
from pathlib import Path

_DATA_BASE = Path("data/config/chat_count")
_lock      = threading.Lock()

def _bot_dir(bot_uid: str) -> Path:
    p = _DATA_BASE / str(bot_uid)
    p.mkdir(parents=True, exist_ok=True)
    return p


def _path_group(bot_uid: str, threadId: str) -> Path:
    return _bot_dir(bot_uid) / f"group_{threadId}.json"


def _path_global(bot_uid: str) -> Path:
    return _bot_dir(bot_uid) / "global.json"


def _load(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _save(path: Path, data: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ══════════════════════════════════════════════════════════════════════════════
#  PUBLIC API
# ══════════════════════════════════════════════════════════════════════════════

def record_message(bot_uid: str, userId: str, threadId: str, **_ignored):
    """
    Gọi mỗi khi có tin nhắn mới trong group.
    Không dedup ở đây — đã được dedup bởi cliMsgId trong main.py.
    """
    tid = str(threadId)
    uid = str(userId)

    with _lock:
        # ── Per-group (userId → count) ────────────────────────────────────
        gp = _load(_path_group(bot_uid, tid))
        entry = gp.setdefault(uid, {"count": 0})
        entry["count"] += 1
        _save(_path_group(bot_uid, tid), gp)

        # ── Global (threadId → count) ─────────────────────────────────────
        gl = _load(_path_global(bot_uid))
        gentry = gl.setdefault(tid, {"count": 0})
        gentry["count"] += 1
        _save(_path_global(bot_uid), gl)


def get_top_group(bot_uid: str, threadId: str, n: int = 15) -> list:
    """
    Trả list top N user trong group theo count desc.
    Mỗi item: { userId, count, rank }
    """
    data = _load(_path_group(str(bot_uid), str(threadId)))
    rows = [{"userId": uid, "count": info.get("count", 0)} for uid, info in data.items()]
    rows.sort(key=lambda x: x["count"], reverse=True)
    for i, r in enumerate(rows[:n]):
        r["rank"] = i + 1
    return rows[:n]


def get_top_global(bot_uid: str, n: int = 15) -> list:
    """
    Trả list top N group theo count desc.
    Mỗi item: { groupId, count, rank }
    """
    data = _load(_path_global(str(bot_uid)))
    rows = [{"groupId": gid, "count": info.get("count", 0)} for gid, info in data.items()]
    rows.sort(key=lambda x: x["count"], reverse=True)
    for i, r in enumerate(rows[:n]):
        r["rank"] = i + 1
    return rows[:n]


def reset_data(bot_uid: str = None):
    """
    Reset data chat.
    - bot_uid=None  → xoá toàn bộ thư mục data/config/chat_count/
    - bot_uid=str   → chỉ xoá thư mục data/config/chat_count/<bot_uid>/
    Trả về số file đã xoá.
    """
    import shutil
    with _lock:
        if bot_uid is None:
            target = _DATA_BASE
        else:
            target = _bot_dir(str(bot_uid))
        if not target.exists():
            return 0
        count = sum(1 for _ in target.rglob("*.json"))
        shutil.rmtree(target, ignore_errors=True)
        return count
