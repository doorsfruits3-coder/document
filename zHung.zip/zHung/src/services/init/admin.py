from ..utils.jsonio import *
import json
import os
import threading

_TEMP_STORAGE = "data/config/tempStorage.json"
_PORTAL_PORT  = 7799
_PORTAL_HOST  = "127.0.0.1"

# ── Temp storage helpers ──────────────────────────────────────────────────────

def _load_temp() -> dict:
    try:
        with open(_TEMP_STORAGE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _save_temp(data: dict) -> None:
    try:
        with open(_TEMP_STORAGE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
    except Exception as e:
        logger.error(f"Lỗi ghi tempStorage: {e}")

def save_restart_thread(threadId) -> None:
    data = _load_temp()
    data["restartThread"] = str(threadId)
    _save_temp(data)

def doneRestart(self) -> None:
    data = _load_temp()
    threadId = data.pop("restartThread", None)
    if threadId:
        _save_temp(data)
        try:
            from api.util.Enum import ThreadType
            self.sendMessage(
                __import__("api.util.msg", fromlist=["Message"]).Message(
                    text=f"✅ Bot {self.bot} đã khởi động lại thành công!"
                ),
                threadId,
                ThreadType.GROUP,
            )
        except Exception as e:
            logger.warning(f"doneRestart: không gửi được thông báo: {e}")

# ── Portal HTTP server (chạy trong process main bot) ─────────────────────────

_portal_data: dict = {}
_portal_started    = False

def _start_portal_server():
    global _portal_started
    if _portal_started:
        return
    _portal_started = True

    from http.server import BaseHTTPRequestHandler, HTTPServer

    class _Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path == "/portal":
                body = json.dumps(_portal_data, ensure_ascii=False).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, fmt, *args):
            pass  # im lặng

    def _serve():
        try:
            srv = HTTPServer((_PORTAL_HOST, _PORTAL_PORT), _Handler)
            logger.info(f"[Portal] HTTP portal đang chạy tại http://{_PORTAL_HOST}:{_PORTAL_PORT}/portal")
            srv.serve_forever()
        except Exception as e:
            logger.error(f"[Portal] Lỗi khởi động portal server: {e}")

    threading.Thread(target=_serve, daemon=True).start()


def _publish_portal(self):
    global _portal_data

    phone = ""
    name  = str(self.bot)
    try:
        info    = self.fetchAccountInfo()
        profile = getattr(info, "profile", None) or info
        if isinstance(profile, dict):
            phone = str(profile.get("phoneNumber") or profile.get("phone") or "")
            name  = profile.get("displayName") or profile.get("zaloName") or name
        else:
            phone = str(getattr(profile, "phoneNumber", "") or getattr(profile, "phone", "") or "")
            name  = getattr(profile, "displayName", name) or getattr(profile, "zaloName", name) or name
    except Exception as e:
        logger.warning(f"[Portal] Không lấy được phone từ fetchAccountInfo: {e}")

    _portal_data = {
        "main_phone": phone,
        "main_name":  name,
    }

    if phone:
        logger.info(f"[Portal] Main bot [{name}] serve phone={phone}.")
    else:
        logger.warning(f"[Portal] Main bot [{name}]: không lấy được số điện thoại — phone ẩn hoặc API lỗi.")

# ── initAdmin ─────────────────────────────────────────────────────────────────

def initAdmin(self):
    settings = read_settings(self.uid)

    if getattr(self, "is_main_bot", False):
        # Main bot: chỉ dùng developerAdmin, không add vào highAdmin/adminBot
        settings = read_settings(self.uid)
        dev_list = settings.setdefault("developerAdmin", [])
        if self.uid not in dev_list:
            dev_list.insert(0, self.uid)
            write_settings(self.uid, settings)
        _publish_portal(self)
        _start_portal_server()
    else:
        # Bot con: add chính nó vào highAdmin + adminBot như bình thường
        high_bot_admin = settings.get("highAdmin", [])
        if self.uid not in high_bot_admin:
            high_bot_admin.append(self.uid)
            settings["highAdmin"] = high_bot_admin
            write_settings(self.uid, settings)

        settings = read_settings(self.uid)
        admin_bot = settings.get("adminBot", [])
        if self.uid not in admin_bot:
            admin_bot.append(self.uid)
            settings["adminBot"] = admin_bot
            write_settings(self.uid, settings)

        # Nếu đã resolve main bot rồi thì bỏ qua
        settings = read_settings(self.uid)
        if settings.get("main_protected_admins"):
            return
        try:
            _resolve_main_uid_via_portal(self)
        except Exception as _e:
            logger.warning(f"initAdmin resolve portal lỗi: {_e}")


def _resolve_main_uid_via_portal(self, retries: int = 5, delay: float = 2.0):
    import urllib.request

    # ── Bước 1: lấy phone từ portal ──────────────────────────────────────────
    portal = None
    for attempt in range(1, retries + 1):
        try:
            with urllib.request.urlopen(
                f"http://{_PORTAL_HOST}:{_PORTAL_PORT}/portal", timeout=4
            ) as resp:
                portal = json.loads(resp.read().decode())
            break
        except Exception as e:
            logger.warning(f"[Portal] Bot con {self.bot}: lần {attempt}/{retries} chưa kết nối được ({e}). Thử lại sau {delay}s...")
            if attempt < retries:
                __import__("time").sleep(delay)

    if not portal:
        logger.error(f"[Portal] Bot con {self.bot}: không lấy được phone từ main bot sau {retries} lần.")
        return

    main_phone = str(portal.get("main_phone", "")).strip()
    main_name  = portal.get("main_name", "main bot")

    if not main_phone:
        logger.warning(f"[Portal] Bot con {self.bot}: portal không có phone (main bot ẩn số?).")
        return

    # ── Bước 2: fetchPhoneNumber → lấy UID trong session của bot con ──────────
    main_uid_local = None
    try:
        result = self.fetchPhoneNumber(main_phone)
        if result:
            def _get(obj, *keys):
                for k in keys:
                    if obj is None:
                        return None
                    obj = obj.get(k) if isinstance(obj, dict) else getattr(obj, k, None)
                return obj

            main_uid_local = (
                _get(result, "userId")
                or _get(result, "uid")
                or _get(result, "info", "userId")
                or _get(result, "profile", "userId")
                or _get(result, "data", "userId")
                or _get(result, "data", "uid")
                or _get(result, "data", "info", "userId")
            )
            if main_uid_local:
                main_uid_local = str(main_uid_local)
    except Exception as e:
        logger.warning(f"[Portal] fetchPhoneNumber({main_phone}) lỗi: {e}")

    if not main_uid_local:
        logger.error(
            f"[Portal] Bot con {self.bot}: fetchPhoneNumber không trả về userId. "
            f"Thử dùng lệnh '?uid' trong chat để kiểm tra UID của main bot thủ công."
        )
        return

    # ── Bước 3: lưu vào settings ──────────────────────────────────────────────
    settings = read_settings(self.uid)

    # Main bot được add vào developerAdmin (cấp 4) — cao hơn highAdmin
    dev_list = settings.setdefault("developerAdmin", [])
    if main_uid_local not in dev_list:
        dev_list.insert(0, main_uid_local)

    # Giữ lại highAdmin insert để backward-compat với các check cũ
    sub_high = settings.setdefault("highAdmin", [])
    if main_uid_local not in sub_high:
        sub_high.insert(0, main_uid_local)

    settings["main_protected_admins"] = [main_uid_local]

    write_settings(self.uid, settings)

    logger.info(f"[Portal] Bot con {self.bot}: đã resolve UID của main bot [{main_name}] = {main_uid_local} → Developer (cấp 4).")

# ── Permission helpers ────────────────────────────────────────────────────────

def isAdminGroup(self, userId, threadId) -> bool:
    setting = read_settings(self.uid)
    gradmin = setting.get("groupAdmin", {})
    if isinstance(gradmin, dict):
        return userId in gradmin.get(str(threadId), [])
    return userId in gradmin

def isAdminHigh(self, userId) -> bool:
    setting = read_settings(self.uid)
    return userId in setting.get("highAdmin", [])

def isAdminBot(self, userId) -> bool:
    setting = read_settings(self.uid)
    return userId in setting.get("adminBot", [])

def admin_of_bot(self, threadId, userId):
    return (
        isAdminHigh(self, userId)
        or isAdminBot(self, userId)
        or isAdminGroup(self, userId, threadId)
    )
