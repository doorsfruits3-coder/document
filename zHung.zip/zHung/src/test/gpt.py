from openai import OpenAI
import os
from dotenv import load_dotenv
load_dotenv()
client = OpenAI(api_key=os.getenv("GptApiKey"))

response = client.responses.create(
    model="gpt-5-nano",
    input="Xin chào"
)

print(response.output_text)