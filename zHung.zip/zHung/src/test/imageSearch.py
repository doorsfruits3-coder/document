from PIL import Image, ImageDraw, ImageFont, ImageFilter
import requests, os, random, emoji
from io import BytesIO

Width = 2048
Pad = 96
CardHeight = 220
Gap = 36

BgTop = (16, 20, 32)
BgBot = (10, 12, 20)

GlassBg = (255, 255, 255, 22)
GlassBorder = (255, 255, 255, 80)
GlassInner = (255, 255, 255, 45)

TextColor = (246, 248, 255)
SubColor = (175, 182, 205)
MutedColor = (130, 140, 170)

FontReg = "data/assets/font/gesco.ttf"
FontBold = "data/assets/font/milker.otf"
FontEmoji = "data/assets/font/emoji3.ttf"

def GetFont(size, bold=False):
    return ImageFont.truetype(FontBold if bold else FontReg, size)

def GetFontEmoji(size):
    return ImageFont.truetype(FontEmoji, size)

def IsEmojiChar(ch: str) -> bool:
    return ch in emoji.EMOJI_DATA

def CanRenderChar(draw, ch, font) -> bool:
    try:
        draw.textbbox((0, 0), ch, font=font)
        return True
    except:
        return False

def Gradient(width, height):
    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)
    for y in range(height):
        t = y / height
        draw.line(
            (0, y, width, y),
            fill=(
                int(BgTop[0] * (1 - t) + BgBot[0] * t),
                int(BgTop[1] * (1 - t) + BgBot[1] * t),
                int(BgTop[2] * (1 - t) + BgBot[2] * t),
            ),
        )
    return img.convert("RGBA")

def AddBlobs(base):
    w, h = base.size
    layer = Image.new("RGBA", base.size)
    draw = ImageDraw.Draw(layer)
    for _ in range(7):
        r = random.randint(420, 720)
        x = random.randint(-200, w)
        y = random.randint(-200, h)
        draw.ellipse(
            (x, y, x + r, y + r),
            fill=random.choice([
                (120, 170, 255, 60),
                (190, 120, 255, 55),
                (120, 255, 200, 50)
            ])
        )
    base.alpha_composite(layer.filter(ImageFilter.GaussianBlur(140)))

def AddNoise(base):
    w, h = base.size
    noiseLayer = Image.new("L", (w, h))
    px = noiseLayer.load()
    for y in range(h):
        for x in range(w):
            px[x, y] = random.randint(120, 136)
    base.alpha_composite(
        Image.merge(
            "RGBA",
            (noiseLayer, noiseLayer, noiseLayer, Image.new("L", (w, h), 18))
        )
    )

def DrawGlass(canvas, box, radius=30):
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    crop = canvas.crop(box)
    blur = crop.filter(ImageFilter.GaussianBlur(16))
    for _ in range(2):
        blur = blur.filter(ImageFilter.GaussianBlur(16))
    base = Image.new("RGBA", (w, h), GlassBg)
    base = Image.alpha_composite(blur, base)

    highlight = Image.new("RGBA", (w, h))
    ImageDraw.Draw(highlight).rectangle((0, 0, w, h // 2), fill=(255, 255, 255, 18))
    highlight = highlight.filter(ImageFilter.GaussianBlur(32))
    base = Image.alpha_composite(base, highlight)

    mask = Image.new("L", (w, h), 0)
    drawMask = ImageDraw.Draw(mask)
    drawMask.rounded_rectangle((0, 0, w, h), radius, fill=255)
    mask = mask.filter(ImageFilter.GaussianBlur(4))
    canvas.paste(base, box, mask)

    draw = ImageDraw.Draw(canvas)
    draw.rounded_rectangle(box, radius, outline=GlassBorder, width=1)
    innerBox = (x1 + 1, y1 + 1, x2 - 1, y2 - 1)
    draw.rounded_rectangle(innerBox, radius - 2, outline=GlassInner, width=1)

def TextWidth(draw, text, fontNormal, fontEmoji):
    width = 0
    for ch in text:
        f = fontEmoji if IsEmojiChar(ch) else fontNormal
        if not CanRenderChar(draw, ch, f):
            continue
        width += draw.textbbox((0, 0), ch, font=f)[2]
    return width

def EllipsisEmoji(draw, text, fontNormal, fontEmoji, maxWidth):
    if TextWidth(draw, text, fontNormal, fontEmoji) <= maxWidth:
        return text
    out = ""
    for ch in text:
        f = fontEmoji if IsEmojiChar(ch) else fontNormal
        if not CanRenderChar(draw, ch, f):
            continue
        if TextWidth(draw, out + ch + "…", fontNormal, fontEmoji) > maxWidth:
            break
        out += ch
    return out + "…"

def DrawTextEmoji(draw, x, y, text, fontNormal, fontEmoji, fill):
    cx = x
    for ch in text:
        f = fontEmoji if IsEmojiChar(ch) else fontNormal
        if not CanRenderChar(draw, ch, f):
            continue
        draw.text((cx, y), ch, font=f, fill=fill)
        cx += draw.textbbox((0, 0), ch, font=f)[2]

def FormatNumber(n):
    return f"{n/1_000_000:.1f}M" if n >= 1_000_000 else f"{n:,}"

def LoadThumb(url, size):
    try:
        r = requests.get(url, timeout=6)
        r.raise_for_status()
        img = Image.open(BytesIO(r.content)).convert("RGBA")
        return img.resize((size, size))
    except:
        return Image.new("RGBA", (size, size), (40, 44, 60, 255))

def DrawSearchImage(songs, outPath):
    height = Pad * 2 + 260 + len(songs) * (CardHeight + Gap)
    img = Gradient(Width, height)
    AddBlobs(img)
    AddNoise(img)
    draw = ImageDraw.Draw(img)

    title = "AUDIOMACK SEARCH"
    fontTitle = GetFont(100, True)
    fontTitleEmoji = GetFontEmoji(100)
    titleWidth = TextWidth(draw, title, fontTitle, fontTitleEmoji)
    DrawTextEmoji(draw, (Width - titleWidth) // 2, 96, title, fontTitle, fontTitleEmoji, TextColor)

    y0 = 260
    for i, s in enumerate(songs, start=1):
        y1 = y0 + (i - 1) * (CardHeight + Gap)
        x1, x2 = Pad, Width - Pad
        y2 = y1 + CardHeight

        DrawGlass(img, (x1, y1, x2, y2))
        idxBox = (x1 + 20, y1 + 16, x1 + 84, y1 + 80)
        DrawGlass(img, idxBox, radius=18)
        DrawTextEmoji(
            draw,
            idxBox[0] + 22,
            idxBox[1] + 14,
            str(i),
            GetFont(34, True),
            GetFontEmoji(34),
            TextColor
        )

        tSize = 160
        tx = x1 + 32
        ty = y1 + (CardHeight - tSize) // 2
        thumb = LoadThumb(s["thumb"], tSize)
        avatarBox = (tx - 4, ty - 4, tx + tSize + 4, ty + tSize + 4)
        DrawGlass(img, avatarBox, radius=30)
        mask = Image.new("L", (tSize, tSize), 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, tSize, tSize), 26, fill=255)
        img.paste(thumb, (tx, ty), mask)

        infoX = tx + tSize + 36
        maxWidth = x2 - infoX - 48
        fn = GetFont(36, True)
        fe = GetFontEmoji(36)
        titleText = EllipsisEmoji(draw, s["title"], fn, fe, maxWidth)
        DrawTextEmoji(draw, infoX, y1 + 42, titleText, fn, fe, TextColor)
        DrawTextEmoji(draw, infoX, y1 + 88, s["artist"], GetFont(26), GetFontEmoji(26), SubColor)
        meta = f"⏱ {s['duration']}   ▶ {FormatNumber(s['listen'])}   ❤ {FormatNumber(s['like'])}"
        DrawTextEmoji(draw, infoX, y1 + 132, meta, GetFont(28), GetFontEmoji(32), MutedColor)

    os.makedirs(os.path.dirname(outPath), exist_ok=True)
    img.save(outPath)
    return outPath

if __name__ == "__main__":
    songs = [
        {"title": "Miss It 🎧🔥 (Very Long Title To Test Emoji Ellipsis)", "artist": "Yung Bleu", "thumb": "https://i.audiomack.com/boosie/3a576e6486.webp", "duration": "4:02", "listen": 18395470, "like": 65660},
        {"title": "Another Song Chill Vibes", "artist": "Demo Artist", "thumb": "https://i.audiomack.com/boosie-55/561122d7bc.webp", "duration": "3:41", "listen": 923456, "like": 23122},
    ]
    DrawSearchImage(songs, "./audiomackSearch.png")