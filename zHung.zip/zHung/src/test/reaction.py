import emoji
from typing import Tuple


def split_emoji_and_text(content: str) -> Tuple[str, str]:
    emojis = []
    texts = []

    for char in content:
        if char in emoji.EMOJI_DATA:
            emojis.append(char)
        else:
            texts.append(char)

    return "".join(emojis), "".join(texts).strip()


if __name__ == "__main__":
    msg = "Nguyên Hello 👋😀 PYYYYYYYYYYYYYY 🐍❤️"

    emoji_part, text_part = split_emoji_and_text(msg)

    print("Emoji :", emoji_part)
    print("Text  :", text_part)