from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import json
import os
import base64
from datetime import datetime, timedelta
import uuid

app = Flask(__name__, template_folder='public/site', static_folder='public/static')
CORS(app)
cf = 'config/login.json'

qr_sessions = {}

def load_config():
    try:
        with open(cf, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        return {"data": [], "error": str(e)}

def save_config(data):
    try:
        os.makedirs(os.path.dirname(cf), exist_ok=True)
        with open(cf, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return True, "Đã lưu cấu hình"
    except Exception as e:
        return False, f"Lỗi: {str(e)}"

@app.route('/')
def admin_dashboard():
    config = load_config()
    bots = config.get('data', [])
    return render_template('admin_dashboard.html', bots=bots)

@app.route('/api/admin/bots', methods=['GET'])
def get_all_bots():
    config = load_config()
    bots = config.get('data', [])
    return jsonify({'success': True, 'bots': bots})

@app.route('/api/admin/bot/create', methods=['POST'])
def admin_create_bot():
    """Admin tạo bot mới"""
    try:
        data = request.get_json() or {}
        bot_id = data.get('author_id', '').strip()
        
        
        if not bot_id:
            bot_id = str(uuid.uuid4())
        
        config = load_config()
        
        
        existing_bot = next((b for b in config.get('data', []) if b.get('author_id') == bot_id), None)
        if existing_bot:
            return jsonify({'success': False, 'message': 'Bot ID already exists'}), 400
        
        new_bot = {
            "username": data.get('username') or 'Bot_' + bot_id[:8],
            "author_id": bot_id,
            "imei": data.get('imei', str(uuid.uuid4())),
            "prefix": data.get('prefix', '?'),
            "session_cookies": {
                "zpw_sek": data.get('zpw_sek', '')
            },
            "is_main_bot": data.get('is_main_bot', False),
            "status": False,
            "kich_hoat": None,
            "het_han": None,
            "created_at": datetime.now().isoformat()
        }
        
        config.setdefault('data', []).append(new_bot)
        success, message = save_config(config)
        
        if success:
            return jsonify({
                'success': True, 
                'message': 'Bot created successfully',
                'bot_id': bot_id,
                'bot': new_bot
            })
        else:
            return jsonify({'success': False, 'message': message}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/bot/<bot_id>/activate', methods=['POST'])
def activate_bot(bot_id):
    try:
        data = request.get_json()
        
        config = load_config()
        bot = next((b for b in config['data'] if b.get('author_id') == bot_id), None)
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        
        kich_hoat = data.get('kich_hoat')
        het_han = data.get('het_han')
        
        if not kich_hoat:
            
            now = datetime.now()
            kich_hoat = now.strftime("%H:%M:%S/%d/%m/%Y")
        
        if not het_han:
            
            days = data.get('days', 30)
            if days > 0:
                now = datetime.now()
                expiry = now + timedelta(days=days)
                het_han = expiry.strftime("%H:%M:%S/%d/%m/%Y")
            else:
                het_han = 'Unlimited'
        
        
        bot['status'] = True
        bot['kich_hoat'] = kich_hoat
        bot['het_han'] = het_han
        
        success, message = save_config(config)
        
        return jsonify({
            'success': success,
            'message': message,
            'kich_hoat': kich_hoat,
            'het_han': het_han,
            'bot': bot
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/bot/<bot_id>/deactivate', methods=['POST'])
def deactivate_bot(bot_id):
    try:
        config = load_config()
        bot = next((b for b in config['data'] if b.get('author_id') == bot_id), None)
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        bot['status'] = False
        
        success, message = save_config(config)
        
        return jsonify({
            'success': success,
            'message': message,
            'bot': bot
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/users', methods=['GET'])
def admin_users():
    config = load_config()
    bots = config.get('data', [])
    
    users_dict = {}
    for bot in bots:
        author_id = bot.get('author_id')
        if author_id not in users_dict:
            users_dict[author_id] = {
                'user_id': author_id,
                'total_bots': 0,
                'active_bots': 0
            }
        users_dict[author_id]['total_bots'] += 1
        if bot.get('status'):
            users_dict[author_id]['active_bots'] += 1
    
    return jsonify({
        'success': True,
        'users': list(users_dict.values())
    })

@app.route('/api/admin/bot/<bot_id>/toggle', methods=['POST'])
def toggle_bot(bot_id):
    try:
        config = load_config()
        bot = next((b for b in config.get('data', []) if b.get('author_id') == bot_id), None)
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        data = request.get_json()
        if data and 'status' in data:
            bot['status'] = data['status']
        else:
            bot['status'] = not bot.get('status', False)
        
        success, message = save_config(config)
        
        return jsonify({
            'success': success,
            'message': message,
            'status': bot['status']
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/bot/<bot_id>/delete', methods=['POST'])
def delete_bot(bot_id):
    try:
        config = load_config()
        original_length = len(config['data'])
        config['data'] = [b for b in config['data'] if b.get('author_id') != bot_id]
        
        if len(config['data']) == original_length:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        success, message = save_config(config)
        
        return jsonify({
            'success': success,
            'message': 'Bot deleted successfully'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/stats', methods=['GET'])
def get_stats():
    config = load_config()
    bots = config.get('data', [])
    
    active_bots = len([b for b in bots if b.get('status', False)])
    inactive_bots = len(bots) - active_bots
    expired_bots = 0
    
    
    now = datetime.now()
    for bot in bots:
        het_han = bot.get('het_han')
        if het_han and bot.get('status'):
            try:
                expiry_date = datetime.strptime(het_han, "%H:%M:%S/%d/%m/%Y")
                if now > expiry_date:
                    expired_bots += 1
            except:
                pass
    
    
    total_users = len(set(b.get('author_id') for b in bots if b.get('author_id')))
    
    return jsonify({
        'success': True,
        'total_bots': len(bots),
        'active_bots': active_bots,
        'inactive_bots': inactive_bots,
        'expired_bots': expired_bots,
        'total_users': total_users
    })

@app.route('/api/admin/config', methods=['GET'])
def get_config():
    try:
        config = load_config()
        return jsonify({
            'success': True,
            'config': config
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/logs', methods=['GET'])
def get_admin_logs():
    try:
        logs = []
        try:
            with open('assets/log/message.txt', 'r', encoding='utf-8') as f:
                messages = f.readlines()
                for msg in messages[-100:]:  
                    if msg.strip():
                        logs.append({
                            'type': 'Message',
                            'message': msg.strip(),
                            'timestamp': datetime.now().isoformat()
                        })
        except FileNotFoundError:
            pass
        except Exception as e:
            logs.append({
                'type': 'Error',
                'message': f'Cannot read message.txt: {str(e)}',
                'timestamp': datetime.now().isoformat()
            })
        
        
        try:
            with open('assets/log/error.txt', 'r', encoding='utf-8') as f:
                errors = f.readlines()
                for err in errors[-50:]:  
                    if err.strip():
                        logs.append({
                            'type': 'Error',
                            'message': err.strip(),
                            'timestamp': datetime.now().isoformat()
                        })
        except FileNotFoundError:
            pass
        except Exception as e:
            logs.append({
                'type': 'Error',
                'message': f'Cannot read error.txt: {str(e)}',
                'timestamp': datetime.now().isoformat()
            })
        
        
        logs.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return jsonify({
            'success': True,
            'logs': logs[:100]  
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/admin/bot/<bot_id>/start', methods=['POST'])
def start_bot(bot_id):
    try:
        from flask import current_app
        
        
        with open('config/login.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        
        bot = None
        for b in config.get('data', []):
            if b.get('author_id') == bot_id:
                bot = b
                break
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        
        try:
            
            from main import mainclient, clientlist
            
            client = None
            if bot.get('is_main_bot'):
                client = mainclient
            else:
                client = clientlist.get(bot_id)
            
            if client and hasattr(client, '_listen'):
                client._listen()
        except Exception as e:
            
            pass
        
        
        bot['status'] = True
        
        
        with open('config/login.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        return jsonify({'success': True, 'message': 'Bot started'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/bot/<bot_id>/stop', methods=['POST'])
def stop_bot(bot_id):
    try:
        from flask import current_app
        
        
        with open('config/login.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        
        bot = None
        for b in config.get('data', []):
            if b.get('author_id') == bot_id:
                bot = b
                break
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        
        try:
            
            from main import mainclient, clientlist
            
            client = None
            if bot.get('is_main_bot'):
                client = mainclient
            else:
                client = clientlist.get(bot_id)
            
            if client and hasattr(client, 'stop_listening'):
                client.stop_listening()
        except Exception as e:
            
            pass
        
        
        bot['status'] = False
        
        
        with open('config/login.json', 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        return jsonify({'success': True, 'message': 'Bot stopped'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/json-files', methods=['GET'])
def get_json_files():
    try:
        json_dir = 'config'
        files = []
        
        if not os.path.exists(json_dir):
            return jsonify({'success': True, 'files': []})
        
        for filename in os.listdir(json_dir):
            if filename.endswith('.json'):
                filepath = os.path.join(json_dir, filename)
                try:
                    size = os.path.getsize(filepath)
                    files.append({
                        'name': filename,
                        'size': size,
                        'path': filepath
                    })
                except:
                    pass
        
        return jsonify({
            'success': True,
            'files': files
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'message': str(e)
        }), 500

@app.route('/api/admin/json-file/<filename>', methods=['GET'])
def get_json_file(filename):
    try:
        
        if '..' in filename or '/' in filename or '\\' in filename:
            return jsonify({'success': False, 'message': 'Invalid filename'}), 400
        
        filepath = os.path.join('assets/client', filename)
        
        if not os.path.exists(filepath):
            return jsonify({'success': False, 'message': 'File not found'}), 404
        
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        return jsonify(data)
    except json.JSONDecodeError:
        return jsonify({'success': False, 'message': 'Invalid JSON file'}), 400
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/bot/<bot_id>/update-config', methods=['POST'])
def update_bot_config(bot_id):
    try:
        data = request.get_json()
        imei = data.get('imei')
        session_cookies = data.get('session_cookies')
        
        if not session_cookies:
            return jsonify({'success': False, 'message': 'Session cookies required'}), 400
        
        config = load_config()
        bot = next((b for b in config.get('data', []) if b.get('author_id') == bot_id), None)
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        
        if imei:
            bot['imei'] = imei
        
        
        bot['session_cookies'] = session_cookies
        
        
        bot['updated_at'] = datetime.now().isoformat()
        
        success, message = save_config(config)
        
        return jsonify({
            'success': success,
            'message': message or 'Config updated successfully',
            'bot': bot
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/qr/generate', methods=['POST'])
def admin_qr_generate():
    try:
        session_id = str(uuid.uuid4())
        
        from app.module.apiQr import init_session, verify_client, generate_qr_code
        
        sessions = init_session()
        if not sessions:
            return jsonify({'success': False, 'message': ''}), 400
        
        sessions = verify_client(sessions)
        code, sessions = generate_qr_code(sessions)
        
        if not code:
            return jsonify({'success': False, 'message': ''}), 400
        
        qr_sessions[session_id] = {
            'code': code,
            'sessions': sessions,
            'status': 'waiting_scan',
            'created_at': datetime.now().isoformat(),
            'qr_data': None
        }
        
        qr_image_path = 'assets/cache/image/qr_code.png'
        if os.path.exists(qr_image_path):
            with open(qr_image_path, 'rb') as f:
                qr_base64 = base64.b64encode(f.read()).decode()
            
            return jsonify({
                'success': True,
                'session_id': session_id,
                'qr_code': qr_base64,
                'code': code
            })
        else:
            return jsonify({'success': False, 'message': ''}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 400

@app.route('/api/admin/qr/status/<session_id>', methods=['GET'])
def admin_qr_status(session_id):
    try:
        from app.module.apiQr import waiting_scan, waiting_confirm
        
        if session_id not in qr_sessions:
            return jsonify({'success': False, 'message': 'Session not found'}), 404
        
        qr_session = qr_sessions[session_id]
        code = qr_session['code']
        sessions = qr_session['sessions']
        status = qr_session['status']
        
        if status == 'confirmed':
            return jsonify({
                'success': True,
                'status': 'confirmed',
                'qr_data': qr_session['qr_data']
            })
        
        if status == 'waiting_scan':
            try:
                result = waiting_scan(code, sessions)
                if result:
                    qr_session['status'] = 'waiting_confirm'
                    return jsonify({
                        'success': True,
                        'status': 'scanned'
                    })
                else:
                    return jsonify({
                        'success': True,
                        'status': 'waiting_scan'
                    })
            except:
                return jsonify({
                    'success': True,
                    'status': 'waiting_scan'
                })
        
        if status == 'waiting_confirm':
            try:
                qr_data = waiting_confirm(code, sessions)
                if qr_data:
                    qr_session['status'] = 'confirmed'
                    qr_session['qr_data'] = qr_data
                    return jsonify({
                        'success': True,
                        'status': 'confirmed',
                        'qr_data': qr_data
                    })
                else:
                    return jsonify({
                        'success': True,
                        'status': 'waiting_confirm'
                    })
            except:
                return jsonify({
                    'success': True,
                    'status': 'waiting_confirm'
                })
        
        return jsonify({
            'success': True,
            'status': status
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ── Override admin_create_bot để tự động sync main highAdmins cho bot con ──
_original_admin_create_bot = admin_create_bot

def _patched_create_bot():
    pass  # placeholder – patch được thực hiện qua after_request hook bên dưới


@app.after_request
def after_create_bot_sync(response):
    """Sau khi tạo bot con thành công, tự động sync highAdmin của main bot."""
    if (
        request.method == 'POST'
        and request.path == '/api/admin/bot/create'
        and response.status_code == 200
    ):
        try:
            resp_data = response.get_json(silent=True) or {}
            if resp_data.get('success'):
                new_bot_id = resp_data.get('bot_id', '')
                new_bot = resp_data.get('bot', {})
                if new_bot_id and not new_bot.get('is_main_bot'):
                    # Gọi nội bộ sync
                    with app.test_request_context(f'/api/admin/bot/{new_bot_id}/sync-main-admins', method='POST'):
                        try:
                            sync_main_admins_to_sub_bot(new_bot_id)
                        except Exception:
                            pass
        except Exception:
            pass
    return response


if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=8000)