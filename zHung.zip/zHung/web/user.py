from flask import Flask, render_template, request, jsonify, redirect, url_for, send_file
from flask_cors import CORS
import json
import os
from datetime import datetime
from pathlib import Path
import uuid
import threading
import time
import base64
from io import BytesIO


import sys
sys.path.insert(0, os.path.dirname(__file__))
from app.module.apiQr import (
    init_session, verify_client, generate_qr_code,
    waiting_scan, waiting_confirm, generate_zalo_uuid
)

app = Flask(__name__, template_folder='public/site', static_folder='public/static')
CORS(app)
cf = 'config/login.json'
dbb = 'assets/client'
logc = 'assets/log'
qr_sessions = {}  

def load_config():
    try:
        with open(cf, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return {"data": []}

def save_config(data):
    try:
        os.makedirs(os.path.dirname(cf), exist_ok=True)
        with open(cf, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
        return True, "Đã lưu cấu hình"
    except:
        return False, "Lỗi khi lưu"

def get_bot_status(bot_id):
    try:
        bot_file = os.path.join(dbb, f"{bot_id}.json")
        if os.path.exists(bot_file):
            with open(bot_file, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_bot_status(bot_id, status_data):
    try:
        os.makedirs(dbb, exist_ok=True)
        bot_file = os.path.join(dbb, f"{bot_id}.json")
        with open(bot_file, 'w', encoding='utf-8') as f:
            json.dump(status_data, f, indent=4, ensure_ascii=False)
        return True
    except:
        return False

def get_bot_logs(bot_id):
    logs = {}
    try:
        error_logc = os.path.join(logc, 'error.txt')
        message_logc = os.path.join(logc, 'message.txt')
        
        if os.path.exists(error_logc):
            with open(error_logc, 'r', encoding='utf-8') as f:
                logs['errors'] = f.readlines()[-50:]
        else:
            logs['errors'] = []
            
        if os.path.exists(message_logc):
            with open(message_logc, 'r', encoding='utf-8') as f:
                logs['messages'] = f.readlines()[-50:]
        else:
            logs['messages'] = []
    except:
        logs['error'] = ''
    
    return logs





@app.route('/admin')
def admin_dashboard():
    config = load_config()
    bots = config.get('data', [])
    total_bots = len(bots)
    active_bots = len([b for b in bots if b.get('status', False)])
    inactive_bots = total_bots - active_bots
    
    
    users_dict = {}
    for bot in bots:
        author_id = bot.get('author_id')
        if author_id not in users_dict:
            users_dict[author_id] = {
                'author_id': author_id,
                'bot_count': 0,
                'active_count': 0
            }
        users_dict[author_id]['bot_count'] += 1
        if bot.get('status'):
            users_dict[author_id]['active_count'] += 1
    
    return render_template('admin_dashboard.html', 
                          total_bots=total_bots,
                          active_bots=active_bots,
                          inactive_bots=inactive_bots,
                          users=list(users_dict.values()),
                          bots=bots)

@app.route('/api/admin/stats')
def admin_stats():
    config = load_config()
    bots = config.get('data', [])
    
    total = len(bots)
    active = len([b for b in bots if b.get('status')])
    inactive = total - active
    expired = len([b for b in bots if b.get('het_han') and b.get('het_han') != 'Unlimited'])
    
    return jsonify({
        'total_bots': total,
        'active_bots': active,
        'inactive_bots': inactive,
        'expired_bots': expired,
        'total_users': len(set(b.get('author_id') for b in bots if b.get('author_id')))
    })

@app.route('/api/admin/bots')
def admin_bots():
    config = load_config()
    bots = config.get('data', [])
    
    return jsonify({
        'success': True,
        'bots': bots
    })

@app.route('/api/admin/users')
def admin_users():
    config = load_config()
    bots = config.get('data', [])
    
    users_dict = {}
    for bot in bots:
        author_id = bot.get('author_id')
        if author_id not in users_dict:
            users_dict[author_id] = {
                'user_id': author_id,
                'bots': []
            }
        users_dict[author_id]['bots'].append(bot)
    
    return jsonify({
        'success': True,
        'users': list(users_dict.values())
    })

@app.route('/api/admin/bot/<author_id>/toggle', methods=['POST'])
def admin_toggle_bot(author_id):
    config = load_config()
    bot = next((b for b in config.get('data', []) if b.get('author_id') == author_id), None)
    
    if not bot:
        return jsonify({'success': False, 'message': ''}), 404
    
    data = request.get_json()
    if data and 'status' in data:
        bot['status'] = data['status']
    else:
        bot['status'] = not bot.get('status', False)
    
    save_config(config)
    
    return jsonify({'success': True, 'status': bot['status']})

@app.route('/api/admin/bot/<author_id>/activate', methods=['POST'])
def admin_activate_bot(author_id):
    config = load_config()
    bot = next((b for b in config.get('data', []) if b.get('author_id') == author_id), None)
    
    if not bot:
        return jsonify({'success': False, 'message': 'Bot not found'}), 404
    
    data = request.get_json()
    if data:
        if 'het_han' in data:
            bot['het_han'] = data['het_han']
        if 'kich_hoat' in data:
            bot['kich_hoat'] = data['kich_hoat']
    
    save_config(config)
    
    return jsonify({'success': True, 'message': 'Bot activated'})

@app.route('/api/admin/bot/<author_id>/delete', methods=['POST'])
def admin_delete_bot(author_id):
    config = load_config()
    original_len = len(config.get('data', []))
    config['data'] = [b for b in config.get('data', []) if b.get('author_id') != author_id]
    
    if len(config['data']) == original_len:
        return jsonify({'success': False, 'message': ''}), 404
    
    save_config(config)
    return jsonify({'success': True})





@app.route('/')
def index():
    config = load_config()
    bots = config.get('data', [])
    
    for bot in bots:
        bot_id = bot.get('author_id')
        status_data = get_bot_status(bot_id)
        bot['status_info'] = status_data or {}
    
    return render_template('user_dashboard.html', bots=bots, total_bots=len(bots))

@app.route('/bot/<bot_id>')
def bot_detail(bot_id):
    config = load_config()
    bots = config.get('data', [])
    
    bot = next((b for b in bots if b.get('author_id') == bot_id), None)
    if not bot:
        return redirect(url_for('index'))
    
    logs = get_bot_logs(bot_id)
    status_data = get_bot_status(bot_id)
    
    return render_template('bot_detail.html', 
                         bot=bot, 
                         logs=logs,
                         status_data=status_data or {})

@app.route('/create')
@app.route('/create', methods=['POST'])
@app.route('/api/bot/create', methods=['POST'])
def create_bot():
    if request.method == 'GET':
        return render_template('create_bot.html')
    
    
    try:
        data = request.get_json() or {}
        author_id = data.get('author_id', '').strip()
        
        
        if not author_id:
            author_id = str(uuid.uuid4())
        
        config = load_config()
        
        
        existing_bot = next((b for b in config.get('data', []) if b.get('author_id') == author_id), None)
        if existing_bot:
            return jsonify({'success': False, 'message': 'This ID already has a bot. One ID = One bot only.'}), 400
        
        new_bot = {
            "username": None,  
            "author_id": author_id,
            "imei": data.get('imei', str(uuid.uuid4())),
            "prefix": data.get('prefix', '?'),
            "session_cookies": {
                "zpw_sek": data.get('zpw_sek', '')
            },
            "is_main_bot": False,
            "status": False,
            "kich_hoat": None,
            "het_han": None,
            "created_at": datetime.now().isoformat()
        }
        
        config.setdefault('data', []).append(new_bot)
        success, message = save_config(config)
        
        if success:
            save_bot_status(author_id, {
                'created_at': datetime.now().isoformat(),
                'status': 'created',
                'commands_loaded': 0
            })
            return jsonify({'success': True, 'message': 'Bot created', 'bot_id': author_id})
        else:
            return jsonify({'success': False, 'message': message}), 400
            
    except Exception as e:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/user/bot/<author_id>/rename', methods=['POST'])
def user_rename_bot(author_id):
    try:
        data = request.get_json()
        new_name = data.get('username', '').strip()
        
        if not new_name:
            return jsonify({'success': False, 'message': 'Name required'}), 400
        
        config = load_config()
        bot = next((b for b in config.get('data', []) if b.get('author_id') == author_id), None)
        
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        
        bot['username'] = new_name
        save_config(config)
        
        return jsonify({'success': True, 'message': 'Renamed'})
    except:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/bot/<bot_id>/update', methods=['POST'])
def update_bot(bot_id):
    try:
        data = request.get_json()
        config = load_config()
        
        bot = next((b for b in config['data'] if b.get('author_id') == bot_id), None)
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        bot['username'] = data.get('username', bot['username'])
        bot['prefix'] = data.get('prefix', bot['prefix'])
        
        if 'zpw_sek' in data and data['zpw_sek']:
            bot['session_cookies']['zpw_sek'] = data['zpw_sek']
        
        save_config(config)
        return jsonify({'success': True, 'message': 'Updated'})
    except:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/bot/<bot_id>/delete', methods=['DELETE', 'POST'])
def delete_bot(bot_id):
    try:
        config = load_config()
        original_length = len(config['data'])
        config['data'] = [b for b in config['data'] if b.get('author_id') != bot_id]
        
        if len(config['data']) == original_length:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        
        save_config(config)
        return jsonify({'success': True, 'message': 'Deleted'})
    except:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/bot/<bot_id>/status', methods=['GET'])
def get_bot_status_api(bot_id):
    status = get_bot_status(bot_id)
    if status:
        return jsonify(status)
    return jsonify({'status': 'unknown'}), 404

@app.route('/api/bot/<bot_id>/logs', methods=['GET'])
def get_logs(bot_id):
    logs = get_bot_logs(bot_id)
    return jsonify(logs)

@app.route('/api/stats')
def get_stats():
    config = load_config()
    bots = config.get('data', [])
    
    active_bots = len([b for b in bots if b.get('status', False)])
    
    return jsonify({
        'total_bots': len(bots),
        'active_bots': active_bots,
        'inactive_bots': len(bots) - active_bots
    })

@app.route('/logs')
def logs_page():
    logs = {}
    try:
        error_logc = os.path.join(logc, 'error.txt')
        message_logc = os.path.join(logc, 'message.txt')
        
        if os.path.exists(error_logc):
            with open(error_logc, 'r', encoding='utf-8') as f:
                logs['errors'] = f.read()
        else:
            logs['errors'] = ''
            
        if os.path.exists(message_logc):
            with open(message_logc, 'r', encoding='utf-8') as f:
                logs['messages'] = f.read()
        else:
            logs['messages'] = ''
    except:
        logs['error'] = ''
    
    return render_template('logs.html', logs=logs)

@app.route('/settings')
def settings():
    config = load_config()
    return render_template('settings.html', config=config)

@app.route('/api/settings/save', methods=['POST'])
def save_settings():
    try:
        data = request.get_json()
        success, message = save_config(data)
        return jsonify({'success': success, 'message': message})
    except:
        return jsonify({'success': False, 'message': ''}), 400


@app.route('/api/qr/generate', methods=['POST'])
def qr_generate():
    try:
        session_id = str(uuid.uuid4())
        
        sessions = init_session()
        if not sessions:
            return jsonify({'success': False, 'message': ''}), 400
        
        sessions = verify_client(sessions)
        code, sessions = generate_qr_code(sessions)
        
        if not code:
            return jsonify({'success': False, 'message': ''}), 400
        
        qr_sessions[session_id] = {
            'code': code,
            'sessions': sessions,
            'status': 'waiting_scan',
            'created_at': datetime.now().isoformat(),
            'qr_data': None
        }
        
        qr_image_path = 'assets/cache/image/qr_code.png'
        if os.path.exists(qr_image_path):
            with open(qr_image_path, 'rb') as f:
                qr_base64 = base64.b64encode(f.read()).decode()
            
            return jsonify({
                'success': True,
                'session_id': session_id,
                'qr_code': qr_base64,
                'code': code
            })
        else:
            return jsonify({'success': False, 'message': ''}), 400
            
    except:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/qr/status/<session_id>', methods=['GET'])
def qr_status(session_id):
    try:
        if session_id not in qr_sessions:
            return jsonify({'success': False, 'message': 'Session not found'}), 404
        
        qr_session = qr_sessions[session_id]
        code = qr_session['code']
        sessions = qr_session['sessions']
        status = qr_session['status']
        
        if status == 'confirmed':
            return jsonify({
                'success': True,
                'status': 'confirmed',
                'qr_data': qr_session['qr_data']
            })
        
        if status == 'waiting_scan':
            try:
                result = waiting_scan(code, sessions)
                if result:
                    qr_session['status'] = 'waiting_confirm'
                    return jsonify({
                        'success': True,
                        'status': 'scanned'
                    })
                else:
                    return jsonify({
                        'success': True,
                        'status': 'waiting_scan'
                    })
            except:
                return jsonify({
                    'success': True,
                    'status': 'waiting_scan'
                })
        
        if status == 'waiting_confirm':
            try:
                qr_data = waiting_confirm(code, sessions)
                if qr_data:
                    qr_session['status'] = 'confirmed'
                    qr_session['qr_data'] = qr_data
                    return jsonify({
                        'success': True,
                        'status': 'confirmed',
                        'qr_data': qr_data
                    })
                else:
                    return jsonify({
                        'success': True,
                        'status': 'waiting_confirm'
                    })
            except:
                return jsonify({
                    'success': True,
                    'status': 'waiting_confirm'
                })
        
        return jsonify({
            'success': True,
            'status': status
        })
        
    except:
        return jsonify({'success': False, 'message': ''}), 400

@app.route('/api/qr/cancel/<session_id>', methods=['POST'])
def qr_cancel(session_id):
    try:
        if session_id in qr_sessions:
            del qr_sessions[session_id]
        
        qr_image_path = 'assets/cache/image/qr_code.png'
        if os.path.exists(qr_image_path):
            os.remove(qr_image_path)
        
        return jsonify({'success': True, 'message': ''})
    except:
        return jsonify({'success': False, 'message': ''}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=2109)
