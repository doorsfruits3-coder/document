/* Bot Management — shared helpers (jQuery optional) */
(function () {
  'use strict';

  // ---------- Toast ----------
  function ensureStack() {
    var stack = document.querySelector('.toast-stack');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    return stack;
  }

  window.toast = function (message, type) {
    type = type || 'info';
    var stack = ensureStack();
    var el = document.createElement('div');
    el.className = 'toast ' + type;
    var icons = { success: 'fa-check-circle', error: 'fa-times-circle', warning: 'fa-exclamation-circle', info: 'fa-info-circle' };
    el.innerHTML = '<i class="fas ' + (icons[type] || icons.info) + ' toast-icon"></i><span>' + message + '</span>';
    stack.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .3s, transform .3s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(20px)';
      setTimeout(function () { el.remove(); }, 320);
    }, 3200);
  };

  // ---------- Confirm replacement (nicer alert if available) ----------
  // Keeping native confirm() for templates; this is just a hook.

  // ---------- Auto-active nav link based on URL ----------
  document.addEventListener('DOMContentLoaded', function () {
    var path = window.location.pathname;
    document.querySelectorAll('.nav-link, .nav-item a, .nav-item').forEach(function (link) {
      var href = link.getAttribute('href');
      if (!href) return;
      if (href === path || (href !== '/' && path.indexOf(href) === 0)) {
        link.classList.add('active');
      } else if (href === '/' && path !== '/') {
        link.classList.remove('active');
      }
    });

    // Smooth click ripple feel for buttons (simple scale)
    document.querySelectorAll('.btn').forEach(function (btn) {
      btn.addEventListener('mousedown', function () { btn.style.transform = 'translateY(1px)'; });
      btn.addEventListener('mouseup',   function () { btn.style.transform = ''; });
      btn.addEventListener('mouseleave',function () { btn.style.transform = ''; });
    });
  });
})();