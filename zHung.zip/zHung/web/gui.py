"""
guiFlask.py – Flask GUI Manager cho zBot.
Chạy song song với bot, cung cấp dashboard quản lý full-featured.
Port mặc định: 5005
"""
from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_cors import CORS
import json
import os
import base64
import threading
import time
import uuid
from datetime import datetime

# ── Flask app ────────────────────────────────────────────────────────────────
gui_app = Flask(
    __name__,
    template_folder='public/site',
    static_folder='public/static',
)
CORS(gui_app)

# ── Config paths ──────────────────────────────────────────────────────────────
LOGIN_DB = 'data/config/login.json'
BOT_CFG    = 'config/bot'
LOG_MSG    = 'assets/log/message.txt'
LOG_ERR    = 'assets/log/error.txt'

_file_lock = threading.Lock()

# ── Reference to runtime clients (filled by main.py) ─────────────────────────
_runtime = {
    'mainclient': None,
    'clientlist': {},      # author_id -> client object
}

def set_runtime(mainclient, clientlist):
    """Called from main.py after bots are started."""
    _runtime['mainclient'] = mainclient
    _runtime['clientlist'] = clientlist

# ── JSON helpers ──────────────────────────────────────────────────────────────
def _load(path, default=None):
    try:
        with _file_lock:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        return default if default is not None else {}

def _save(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
        with _file_lock:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        return True, 'OK'
    except Exception as e:
        return False, str(e)

def load_login():
    return _load(LOGIN_DB, {'data': []})

def save_login(data):
    return _save(LOGIN_DB, data)

# ── Routes ────────────────────────────────────────────────────────────────────

@gui_app.route('/')
@gui_app.route('/gui')
def index():
    return render_template('dashboard.html')

# ── Bot list ──────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bots', methods=['GET'])
def api_bots():
    cfg = load_login()
    bots = cfg.get('data', [])
    # Attach live status from runtime
    for bot in bots:
        aid = bot.get('author_id')
        client = _get_client(aid, bot.get('is_main_bot'))
        if client:
            bot['_live'] = getattr(client, 'listening', False)
    return jsonify({'success': True, 'bots': bots, 'count': len(bots)})

def _get_client(author_id, is_main=False):
    if is_main:
        return _runtime.get('mainclient')
    return _runtime['clientlist'].get(str(author_id))

# ── Create bot ────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot', methods=['POST'])
def api_create_bot():
    try:
        data = request.get_json() or {}
        author_id = data.get('author_id', '').strip()
        imei      = data.get('imei', '').strip()
        zpw_sek   = data.get('zpw_sek', '').strip()
        if not author_id:
            return jsonify({'success': False, 'message': 'author_id is required'}), 400
        if not imei:
            return jsonify({'success': False, 'message': 'IMEI is required'}), 400
        if not zpw_sek:
            return jsonify({'success': False, 'message': 'Session cookie (zpw_sek) is required'}), 400

        cfg = load_login()
        existing = next((b for b in cfg['data'] if b.get('author_id') == author_id), None)
        if existing:
            return jsonify({'success': False, 'message': 'Bot with this author_id already exists'}), 400

        new_bot = {
            'username':       data.get('username') or f'Bot_{author_id[:8]}',
            'author_id':      author_id,
            'imei':           imei,
            'prefix':         data.get('prefix', '.') or '.',
            'session_cookies': {'zpw_sek': zpw_sek},
            'is_main_bot':    bool(data.get('is_main_bot', False)),
            'status':         bool(data.get('status', False)),
            'het_han':        data.get('het_han') or None,
            'created_at':     datetime.now().isoformat(),
        }
        cfg['data'].append(new_bot)
        ok, msg = save_login(cfg)
        if ok:
            return jsonify({'success': True, 'message': 'Bot created', 'bot': new_bot})
        return jsonify({'success': False, 'message': msg}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Update bot ────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot/<bot_id>', methods=['PUT'])
def api_update_bot(bot_id):
    try:
        data = request.get_json() or {}
        cfg  = load_login()
        bot  = next((b for b in cfg['data'] if b.get('author_id') == bot_id), None)
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404

        if 'username' in data:    bot['username']    = data['username']
        if 'imei'    in data:     bot['imei']        = data['imei']
        if 'prefix'  in data:     bot['prefix']      = data['prefix']
        if 'het_han' in data:     bot['het_han']     = data['het_han'] or None
        if 'is_main_bot' in data: bot['is_main_bot'] = bool(data['is_main_bot'])
        if 'status'  in data:     bot['status']      = bool(data['status'])
        if 'zpw_sek' in data and data['zpw_sek']:
            bot['session_cookies'] = {'zpw_sek': data['zpw_sek']}
        bot['updated_at'] = datetime.now().isoformat()

        ok, msg = save_login(cfg)
        if ok:
            return jsonify({'success': True, 'message': 'Bot updated', 'bot': bot})
        return jsonify({'success': False, 'message': msg}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Delete bot ────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot/<bot_id>', methods=['DELETE'])
def api_delete_bot(bot_id):
    try:
        cfg = load_login()
        before = len(cfg['data'])
        cfg['data'] = [b for b in cfg['data'] if b.get('author_id') != bot_id]
        if len(cfg['data']) == before:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404
        ok, msg = save_login(cfg)
        if ok:
            return jsonify({'success': True, 'message': 'Bot deleted'})
        return jsonify({'success': False, 'message': msg}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Start / Stop bot ──────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot/<bot_id>/start', methods=['POST'])
def api_start_bot(bot_id):
    try:
        cfg = load_login()
        bot = next((b for b in cfg['data'] if b.get('author_id') == bot_id), None)
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404

        client = _get_client(bot_id, bot.get('is_main_bot'))
        if client:
            bot['status'] = True
            save_login(cfg)
            # If stopped, relaunch listen in background
            if not getattr(client, 'listening', False):
                def _do_listen():
                    try:
                        client.listen(thread=True)
                    except Exception as e:
                        pass
                threading.Thread(target=_do_listen, daemon=True).start()
            return jsonify({'success': True, 'message': 'Bot started'})
        else:
            # Not running yet – mark active so next restart picks it up
            bot['status'] = True
            save_login(cfg)
            return jsonify({'success': True, 'message': 'Status set to active (will start on next restart)'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@gui_app.route('/gui/api/bot/<bot_id>/stop', methods=['POST'])
def api_stop_bot(bot_id):
    try:
        cfg = load_login()
        bot = next((b for b in cfg['data'] if b.get('author_id') == bot_id), None)
        if not bot:
            return jsonify({'success': False, 'message': 'Bot not found'}), 404

        client = _get_client(bot_id, bot.get('is_main_bot'))
        if client and hasattr(client, 'stop_listening'):
            client.stop_listening()
        bot['status'] = False
        save_login(cfg)
        return jsonify({'success': True, 'message': 'Bot stopped'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Commands ──────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot/<bot_id>/commands', methods=['GET'])
def api_commands(bot_id):
    try:
        path = os.path.join(BOT_CFG, f'Data-{bot_id}.json')
        cfg  = _load(path, {})
        cmds = cfg.get('command', [])
        return jsonify({'success': True, 'commands': cmds, 'count': len(cmds)})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@gui_app.route('/gui/api/bot/<bot_id>/command/<cmd_name>/toggle', methods=['POST'])
def api_toggle_command(bot_id, cmd_name):
    try:
        data   = request.get_json() or {}
        status = bool(data.get('status', True))
        path   = os.path.join(BOT_CFG, f'Data-{bot_id}.json')
        cfg    = _load(path, {})
        cmds   = cfg.get('command', [])
        cmd    = next((c for c in cmds if c.get('name') == cmd_name), None)
        if not cmd:
            return jsonify({'success': False, 'message': 'Command not found'}), 404
        cmd['status'] = status
        ok, msg = _save(path, cfg)
        if ok:
            return jsonify({'success': True, 'message': f'{cmd_name} {"enabled" if status else "disabled"}'})
        return jsonify({'success': False, 'message': msg}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Logs ──────────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/logs', methods=['GET'])
def api_logs():
    log_type = request.args.get('type', 'all')
    logs = []
    try:
        if log_type in ('all', 'message'):
            with open(LOG_MSG, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f.readlines()[-200:]:
                    line = line.strip()
                    if line:
                        logs.append(_parse_log_line(line, 'info'))
        if log_type in ('all', 'error'):
            with open(LOG_ERR, 'r', encoding='utf-8', errors='ignore') as f:
                for line in f.readlines()[-100:]:
                    line = line.strip()
                    if line:
                        logs.append(_parse_log_line(line, 'err'))
    except FileNotFoundError:
        pass
    except Exception as e:
        logs.append({'time': _now(), 'level': 'err', 'message': str(e)})

    logs.sort(key=lambda x: x.get('time', ''), reverse=True)
    return jsonify({'success': True, 'logs': logs[:300]})

def _parse_log_line(line, default_level='info'):
    """Parse a log line into {time, level, message}."""
    level = default_level
    msg   = line
    time  = _now()
    # Try to extract time at start: [HH:MM:SS] or HH:MM:SS
    import re
    m = re.match(r'[\[\(]?(\d{2}:\d{2}:\d{2})[\]\)]?\s*', line)
    if m:
        time = m.group(1)
        msg  = line[m.end():]
    # Detect level keywords
    upper = msg.upper()
    if 'ERROR' in upper or 'ERR' in upper or 'CRITICAL' in upper:
        level = 'err'
    elif 'WARN' in upper or 'WARNING' in upper:
        level = 'warn'
    elif 'SUCCESS' in upper or 'OK' in upper or 'DONE' in upper:
        level = 'ok'
    else:
        level = 'info'
    return {'time': time, 'level': level, 'message': msg}

def _now():
    return datetime.now().strftime('%H:%M:%S')

# ── QR login ──────────────────────────────────────────────────────────────────
# Mỗi session lưu: code, sessions, status, qr_data, error
# status: generating | waiting_scan | waiting_confirm | confirmed | failed
_qr_sessions = {}
_qr_lock = threading.Lock()


def _qr_worker(session_id):
    """Background thread: chạy toàn bộ flow QR, cập nhật _qr_sessions."""
    from app.module.apiQr import (
        init_session, verify_client, generate_qr_code,
        waiting_scan, waiting_confirm
    )
    s = _qr_sessions.get(session_id)
    if not s:
        return
    try:
        # 1. Tạo session
        sessions = init_session()
        if not sessions:
            s['status'] = 'failed'
            s['error']  = 'Không khởi tạo được session'
            return
        sessions = verify_client(sessions)

        # 2. Tạo QR
        result = generate_qr_code(sessions)
        if not result or not result[0]:
            s['status'] = 'failed'
            s['error']  = 'Không tạo được mã QR'
            return
        code, sessions = result

        # Đọc ảnh QR
        qr_image_path = 'assets/cache/image/qr_code.png'
        if os.path.exists(qr_image_path):
            with open(qr_image_path, 'rb') as f:
                s['qr_b64'] = base64.b64encode(f.read()).decode()

        s['code']     = code
        s['sessions'] = sessions
        s['status']   = 'waiting_scan'

        # 3. Chờ scan (tối đa 120s)
        scanned = waiting_scan(code, sessions, max_wait=120)
        if not scanned:
            s['status'] = 'failed'
            s['error']  = 'QR hết hạn hoặc không được quét'
            return

        s['status'] = 'waiting_confirm'

        # 4. Chờ confirm (tối đa 60s)
        qr_data = waiting_confirm(code, sessions, max_wait=60)
        if qr_data:
            s['status']  = 'confirmed'
            s['qr_data'] = qr_data
        else:
            s['status'] = 'failed'
            s['error']  = 'Xác nhận thất bại hoặc hết thời gian'

    except Exception as e:
        s['status'] = 'failed'
        s['error']  = str(e)
        import traceback as tb
        tb.print_exc()


@gui_app.route('/gui/api/qr/generate', methods=['POST'])
def api_qr_generate():
    try:
        session_id = str(uuid.uuid4())
        _qr_sessions[session_id] = {
            'status': 'generating',
            'code': None,
            'sessions': None,
            'qr_b64': None,
            'qr_data': None,
            'error': None,
        }
        # Chạy flow QR trong background thread
        t = threading.Thread(target=_qr_worker, args=(session_id,), daemon=True)
        t.start()
        return jsonify({'success': True, 'session_id': session_id})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@gui_app.route('/gui/api/qr/status/<session_id>', methods=['GET'])
def api_qr_status(session_id):
    """Polling endpoint – trả trạng thái hiện tại, không blocking."""
    with _qr_lock:
        s = _qr_sessions.get(session_id)
    if not s:
        return jsonify({'success': False, 'message': 'Session không tồn tại'}), 404

    resp = {'success': True, 'status': s['status']}
    if s.get('qr_b64'):
        resp['qr_code'] = s['qr_b64']      # trả ảnh QR khi đã có
    if s['status'] == 'confirmed':
        resp['qr_data'] = s['qr_data']
    if s['status'] == 'failed':
        resp['message'] = s.get('error', 'Lỗi không xác định')
    return jsonify(resp)


@gui_app.route('/gui/api/qr/cancel/<session_id>', methods=['POST'])
def api_qr_cancel(session_id):
    _qr_sessions.pop(session_id, None)
    try:
        p = 'assets/cache/image/qr_code.png'
        if os.path.exists(p):
            os.remove(p)
    except Exception:
        pass
    return jsonify({'success': True})

@gui_app.route('/gui/api/bot/from-qr', methods=['POST'])
def api_bot_from_qr():
    """Lưu bot sau khi quét QR thành công.

    Nhận payload:
      {
        imei, cookie: {zpw_sek},      # từ waiting_confirm
        uid, name,                     # từ get_user_info (có thể rỗng)
        username, prefix,              # do người dùng nhập trước khi quét
        is_main_bot
      }
    """
    try:
        data = request.get_json() or {}

        # ── IMEI & cookie ─────────────────────────────────────────
        imei = (data.get('imei') or '').strip()
        cookie_raw = data.get('cookie') or data.get('session_cookies') or {}
        if isinstance(cookie_raw, str):
            cookie_raw = {'zpw_sek': cookie_raw}
        session_cookies = cookie_raw
        zpw_sek = session_cookies.get('zpw_sek', '').strip()

        if not imei:
            return jsonify({'success': False, 'message': 'Thiếu IMEI'}), 400
        if not zpw_sek:
            return jsonify({'success': False, 'message': 'Thiếu cookie zpw_sek'}), 400

        # ── Author ID: ưu tiên uid từ Zalo, fallback sang author_id ──
        uid = (data.get('uid') or data.get('author_id') or '').strip()

        # ── Tên hiển thị: ưu tiên nhập tay, fallback sang tên Zalo ──
        username = (
            data.get('username')        # nhập tay từ form
            or data.get('name')         # từ get_user_info
            or (f'Bot_{uid[:8]}' if uid else 'Bot_QR')
        ).strip()

        # ── Prefix: từ form hoặc mặc định '.' ──────────────────────
        prefix = (data.get('prefix') or '.').strip() or '.'

        is_main = bool(data.get('is_main_bot', False))

        cfg = load_login()

        # Nếu chưa có bot nào → bot này là main
        if not cfg.get('data'):
            is_main = True

        # Tìm bot hiện có theo uid hoặc imei để update thay vì tạo mới
        existing = None
        if uid:
            existing = next((b for b in cfg['data'] if b.get('author_id') == uid), None)
        if not existing and imei:
            existing = next((b for b in cfg['data'] if b.get('imei') == imei), None)

        if existing:
            existing['imei']            = imei
            existing['session_cookies'] = session_cookies
            if uid:
                existing['author_id']   = uid
            if username:
                existing['username']    = username
            existing['prefix']          = prefix
            existing['status']          = True
            existing['updated_at']      = datetime.now().isoformat()
            msg_out = f'Bot "{username}" đã được cập nhật'
        else:
            new_bot = {
                'username':        username,
                'author_id':       uid or None,
                'imei':            imei,
                'prefix':          prefix,
                'session_cookies': session_cookies,
                'is_main_bot':     is_main,
                'status':          True,
                'created_at':      datetime.now().isoformat(),
            }
            cfg['data'].append(new_bot)
            msg_out = f'Bot "{username}" đã được thêm'

        ok, err = save_login(cfg)
        if ok:
            return jsonify({
                'success':  True,
                'message':  msg_out,
                'author_id': uid,
                'username':  username,
            })
        return jsonify({'success': False, 'message': err}), 500
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# ── Bot Avatar ────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/bot/<bot_id>/avatar', methods=['GET'])
def api_bot_avatar(bot_id):
    """Lấy avatar của bot từ Zalo API."""
    try:
        client = None
        cfg = load_login()
        bot = next((b for b in cfg.get('data', []) if b.get('author_id') == bot_id), None)
        if bot:
            client = _get_client(bot_id, bot.get('is_main_bot'))

        if client and hasattr(client, 'fetchAccountInfo'):
            try:
                info = client.fetchAccountInfo()
                avatar_url = None
                if hasattr(info, 'profile'):
                    avatar_url = getattr(info.profile, 'avatar', None) or getattr(info.profile, 'avatarUrl', None)
                if avatar_url:
                    return jsonify({'success': True, 'avatar_url': avatar_url})
            except Exception as e:
                pass

        # Fallback: lấy từ Zalo public API nếu có uid
        uid = bot_id if bot_id else None
        if uid:
            try:
                resp = requests.get(
                    f"https://avatar.zalo.me/picture/{uid}",
                    timeout=10,
                    allow_redirects=True
                )
                if resp.status_code == 200 and 'image' in resp.headers.get('Content-Type', ''):
                    img_b64 = base64.b64encode(resp.content).decode()
                    ct = resp.headers.get('Content-Type', 'image/jpeg').split(';')[0]
                    return jsonify({'success': True, 'avatar_b64': img_b64, 'mime': ct})
            except Exception:
                pass

        return jsonify({'success': False, 'message': 'Không lấy được avatar'}), 404
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# ── Misc ──────────────────────────────────────────────────────────────────────
@gui_app.route('/gui/api/reload', methods=['POST'])
def api_reload():
    return jsonify({'success': True, 'message': 'Config reloaded (bots restart required to apply)'})

@gui_app.route('/gui/api/stats', methods=['GET'])
def api_stats():
    cfg    = load_login()
    bots   = cfg.get('data', [])
    online = sum(1 for b in bots if b.get('status'))
    main   = next((b for b in bots if b.get('is_main_bot')), None)
    return jsonify({
        'success': True,
        'total':   len(bots),
        'online':  online,
        'offline': len(bots) - online,
        'main':    main.get('username') if main else None,
    })

# ── Runner ─────────────────────────────────────────────────────────────────────
def start_gui(port=5005, debug=False):
    """Start the Flask GUI in a daemon thread."""
    def _run():
        gui_app.run(host='0.0.0.0', port=port, debug=debug, use_reloader=False)
    t = threading.Thread(target=_run, daemon=True, name='zBot-GUI')
    t.start()
    return t

if __name__ == '__main__':
    start_gui(port=5005, debug=True)
    # Keep alive
    while True:
        time.sleep(1)
