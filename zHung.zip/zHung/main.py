from app.login.client import *
from app.helpers.methods import *
from app.module.commandLoader import *
from app.helpers.message import *
from src.command.antimanager.index import handleListenAnti
from src.services.utils.im_core import DontcareMessage
from src.services.utils.lazy_undo import handle_reaction_undo, push_bot_message
from src.services.init.index import *
from app.module.message import *
from src.command.music.timeout import *
from src.command.groupBot.ckg import handle_ckg_mention
from src.command.music.nhaccuatui import InitTimeoutNct
from src.command.bot_services.bot_manager.menu import InitTimeoutMenu
from src.command.bot_services.bot_manager.download import DownloadAutoLink
from src.command.chat_bot.meme import InitTimeoutMeme
from src.command.groupBot.blockBot import is_bot_blocked
from api.util.Enum import ThreadType

class zrcapis(ZaloAPI, Methods, Utilsmodule, commandHandles, MessageHelper, Listen, MediaCache):

    def __init__(self, api_key, secret_key, imei=None, session_cookies=None,
                 prefix="", is_main_bot=None):
        super().__init__(api_key, secret_key, imei, session_cookies)

        self.audiomackStates:  dict[str, dict] = {}
        self.soundcloudStates: dict[str, dict] = {}
        self.zingStates:       dict[str, dict] = {}
        self.nctStates:        dict[str, dict] = {}
        self.menuStates:       dict[str, dict] = {}
        self.memeStates:       dict[str, dict] = {}
        InitTimeoutAudiomack(self)
        InitTimeoutSoundCloud(self)
        InitTimeoutZing(self)
        InitTimeoutNct(self)
        InitTimeoutMenu(self)
        InitTimeoutMeme(self)
        self.is_main_bot     = is_main_bot
        self.prefix          = prefix
        self.imei            = imei
        self.session_cookies = session_cookies
        self.secret_key      = secret_key
        self.api_key         = api_key
        self.bot             = self.fetchAccountInfo().profile.displayName
        self.msgUser:      dict[str, str]  = {}
        self._botMessages: dict[str, dict] = {}
        self.clicc:        set[str]        = set()
        self.commands = loader(self, "src/command")
        initAdmin(self)
        doneRestart(self)
        clearpyc(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

    def send(self, message, threadId, type=ThreadType.USER, mark_message=None, ttl=0):
        sent = super().send(message, threadId, type, mark_message, ttl)
        push_bot_message(self, sent, threadId)
        return sent

    def replyMessageStyle(self, message, replyMsg, threadId, threadType, ttl=0,
                          color=None, title=None, mention=None, userId=None):
        sent = super().replyMessageStyle(message, replyMsg, threadId, threadType, ttl,
                                         color, title, mention, userId)
        push_bot_message(self, sent, threadId)
        return sent

    def onEvent(self, EventData, EventType):
        from src.events.zaloEvent import ZaloEventHandle
        try:
            ZaloEventHandle(self, EventData, EventType)
        except Exception as e:
            import traceback
            print(f"[ERROR onEvent] {e}\n{traceback.format_exc()}")

    def onMessage(self, mid, userId, message, data, threadId, type):
        try:
            if not self._dedup(data):
                return

            msgType = getattr(data, "msgType", None) or ""

            if self._is_ignored(msgType):
                return

            if msgType == "chat.reaction":
                handle_reaction_undo(self, message, data, userId, threadId, type)
                return

            message, msg = self._normalize_message(message, msgType, data)

            self._record_chat(userId, threadId, type)

            self._handle_no_auth(message, data, userId, threadId, type)

            if not self._has_permission(userId, threadId):
                return

            self._handle_authed(message, msg, data, userId, threadId, type)

        except Exception as e:
            import traceback
            print(f"[ERROR onMessage] {e}\n{traceback.format_exc()}")

    def _record_chat(self, userId, threadId, type):
        try:
            is_group = (
                type == ThreadType.GROUP
                or getattr(type, "name", "") == "GROUP"
                or str(type) in ("1", "GROUP")
            )
            if not is_group:
                return
            from src.services.data.chatCounter import record_message
            record_message(
                bot_uid  = str(self.uid),
                userId   = str(userId),
                threadId = str(threadId),
            )
        except Exception:
            pass

    def _dedup(self, data) -> bool:
        cliId = getattr(data, "cliMsgId", None)
        if cliId is None:
            return True
        if cliId in self.clicc:
            return False
        self.clicc.add(cliId)
        return True

    def _is_ignored(self, msgType: str) -> bool:
        return msgType in ("chat.delete", "chat.revoke")

    def _normalize_message(self, message, msgType: str, data) -> tuple:
        if isinstance(message, Message):
            msg = message.text or ""
        elif isinstance(message, str):
            msg     = message
            message = Message(text=msg)
        else:
            msg = (
                getattr(message, "title", None)
                or getattr(message, "text",  None)
                or getattr(message, "href",  None)
                or ""
            )
            if not isinstance(msg, str):
                msg = ""
            message = Message(text=msg)

        if msgType == "chat.recommended":
            title   = getattr(getattr(data, "content", None), "title", "") or ""
            message = Message(text=title + " ")
            msg     = message.text

        return message, msg

    def _has_permission(self, userId, threadId) -> bool:
        settings    = read_settings(self.uid)
        all_admins  = (
            set(settings.get("highAdmin",       []))
            | set(settings.get("adminBot",      []))
            | set(settings.get("developerAdmin", []))
        )
        return (
            userId   in all_admins
            or threadId in settings.get("allowGroup",  [])
            or userId   in settings.get("listenUsers", [])
        )

    def _is_group(self, type) -> bool:
        return (
            type == ThreadType.GROUP
            or getattr(type, "name", "") == "GROUP"
            or str(type) in ("1", "GROUP")
        )

    def _handle_no_auth(self, message, data, userId, threadId, type):
        name = self.userName(userId)
        self.msgUser[name] = message

        DownloadAutoLink(self, message, data, userId, threadId, type)
        handleListenAnti(self, message, data, userId, threadId, type)
        DontcareMessage(self, message, data, userId, threadId, type)

        if self._is_group(type) and str(self.uid) in extractUids(data):
            handle_ckg_mention(self, data, userId, threadId, type)

        from src.command.multibotManager.multibotCore import MultibotReply as _MBReply
        _MBReply(self, message, data, userId, threadId, type)

    def _handle_authed(self, message, msg, data, userId, threadId, type):
        if is_bot_blocked(self, userId):
            return
        self.loadcommands(message, data, userId, threadId, type)
        self.listenReply(message, data, userId, threadId, type)
        self._handle_prefix_query(msg, data, threadId, type, userId)

    def _handle_prefix_query(self, msg, data, threadId, type, userId):
        stripped = msg.strip()
        if stripped.lower() == "prefix":
            self.replyMessageStyle(
                f"Prefix của bot {self.bot} hiện tại là: {self.prefix}",
                data, threadId, type,
                color="gr", title="SUCCESS", userId=userId,
            )
        elif self.prefix and stripped == self.prefix:
            self.replyMessageStyle(
                f"Use {self.prefix}menu to check all commands to use my bot",
                data, threadId, type,
                color="gr", title="SUCCESS", userId=userId,
            )

if __name__ == "__main__":
    main()
