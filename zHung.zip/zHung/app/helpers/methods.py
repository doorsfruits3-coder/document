from api.models import *
from api import *

class Methods:
    def groupInfo(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId)
            return info.gridInfoMap.get(threadId, {}).get("name", "Group không xác định")
        except Exception as e:
            # logger.errorw(f"Lỗi lấy thông tin nhóm {threadId}: {e}")
            return "Null"

    def getGroupTypes(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId)
            if not info:
                return "Null"
            return "cộng đồng" if info.type == 2 else "nhóm"
        except Exception as e:
            # logger.errorw(f"Lỗi lấy loại nhóm {threadId}: {e}")
            return "Null"
        
    def getGroupTypesE(self, threadId: str) -> str:
        try:
            info = self.fetchGroupInfo(threadId).gridInfoMap.get(threadId)
            if not info:
                return "Null"
            return "community" if info.type == 2 else "group"
        except Exception as e:
            # logger.errorw(f"Lỗi lấy loại nhóm {threadId}: {e}")
            return "Null"

    def userName(self, userId: str) -> str:
        try:
            info = self.fetchUserInfo(userId)
            return info.changed_profiles.get(userId, {}).get(
                "zaloName", "Người dùng không xác định"
            )
        except Exception as e:
            logger.errorw(f"Lỗi khi lấy thông tin người dùng {userId}: {e}")
            return "Null"

    def get_platform(self, data) -> str:
        try:
            if data.msgType == "chat.reaction":
                return
            raw = data if isinstance(data, dict) else data.__dict__
            platform_type = raw.get("paramsExt", {}).get("platformType")
            return {
                0: "App",
                1: "Web",
                2: "PC"
            }.get(platform_type, "Null")
        except Exception:
            return