from .data import *
from .qr import *

def main():
    try:
        try:
            from web.gui import start_gui
            gui_port = int(os.environ.get('GUI_PORT', 5005))
            start_gui(port=gui_port)
            logger.info(f"Manager đang chạy tại http://0.0.0.0:{gui_port}")
        except Exception as _ge:
            logger.warning(f"Manager không khởi động được: {_ge}")

        if not check():
            logger.warning("Chưa có dữ liệu đăng nhập")
            choice = input("1. Quét QR / 2. Thoát: ").strip()
            if choice == "1":
                success = qr()
                if not success:
                    logger.error("Đăng nhập thất bại")
                    return
                logger.info("Đang khởi động bot...")
                time.sleep(2)
            elif choice == "2":
                logger.info("Tạm biệt")
                return
            else:
                logger.error("Lựa chọn không hợp lệ")
                return

        data = load_json(logindb)
        if "data" not in data or not isinstance(data["data"], list):
            logger.error("Không tìm thấy trường dữ liệu nào trong JSON")
            return

        valid_items = []
        for item in data["data"]:
            if item.get("imei") and isinstance(item.get("session_cookies"), dict) and item.get("session_cookies") and item.get("status") is True:
                if check_bot_expiration(item):
                    valid_items.append(item)

        save_config(data)
        if not valid_items:
            logger.warning("Dữ liệu rỗng.")
            return
        start_threads(valid_items)

        try:
            from web.gui import set_runtime
            global mainclient
            set_runtime(
                mainclient if 'mainclient' in globals() else None,
                clientlist
            )
        except Exception:
            pass

        while not shutdown_event.is_set():
            time.sleep(1)
    except KeyboardInterrupt:
        logger.info("Đang dừng bot...")
        clean()
    except Exception as e:
        logger.error(f"Lỗi trong quá trình khởi động: {e}")
        import traceback
        traceback.print_exc()
    finally:
        clean()

if __name__ == "__main__":
    import atexit
    atexit.register(clean)
    main()