from .index import *

def check() -> bool:
    try:
        if not os.path.exists(logindb):
            return False
        data = load_json(logindb)
        if "data" not in data or not data["data"]:
            return False
        valid_items = [
            item for item in data["data"]
            if item.get("imei")
            and isinstance(item.get("session_cookies"), dict)
            and item.get("session_cookies")
            and item.get("status") is True
        ]
        return len(valid_items) > 0
    except Exception as e:
        logger.error(f"Lỗi khi kiểm tra dữ liệu đăng nhập: {e}")
        return False

def addcf(qr_data: Dict) -> bool:
    try:
        data = load_json(logindb)
        if "data" not in data:
            data["data"] = []
        session_cookies = qr_data.get("cookie", {})
        new_entry = {
            "username": None,
            "author_id": None,
            "imei": qr_data.get("imei"),
            "prefix": qr_data.get("prefix", "?"),
            "session_cookies": session_cookies,
            "is_main_bot": len(data["data"]) == 0,
            "status": True
        }
        data["data"].append(new_entry)
        save_json(logindb, data)
        logger.info("Đã thêm tài khoản vào config")
        return True
    except Exception as e:
        logger.error(f"Lỗi khi thêm tài khoản vào config: {e}")
        return False

def qr():
    qr_path = "data/assets/cache/image/qr_code.png"
    try:
        logger.info("Đang tạo mã QR code...")
        sessions = init_session()
        if not sessions:
            logger.error("Không thể khởi tạo session")
            return False

        sessions = verify_client(sessions)

        result = generate_qr_code(sessions)
        if not result or not result[0]:
            logger.error("Không thể tạo QR code")
            return False
        code, sessions = result

        logger.info(f"QR code đã được tạo: {qr_path}")
        logger.info(f"Mã QR: {code}")

        # Chờ scan – tối đa 120 giây
        scanned = waiting_scan(code, sessions, max_wait=120)
        if not scanned:
            logger.error("QR hết hạn hoặc không được quét")
            if os.path.exists(qr_path):
                os.remove(qr_path)
            return False

        logger.info("Đang chờ xác nhận đăng nhập trên điện thoại...")

        # Chờ confirm – tối đa 60 giây
        qr_data = waiting_confirm(code, sessions, max_wait=60)
        if qr_data:
            logger.info("Xác thực thành công")
            if os.path.exists(qr_path):
                os.remove(qr_path)
                logger.info("Đã xóa QR code")
            if addcf(qr_data):
                logger.info("Đã lưu thông tin đăng nhập vào config")
                return True
            else:
                logger.error("Không thể lưu thông tin đăng nhập")
                return False
        else:
            logger.error("Xác thực thất bại")
            if os.path.exists(qr_path):
                os.remove(qr_path)
            return False

    except Exception as e:
        logger.error(f"Lỗi trong quá trình đăng nhập QR: {e}")
        if os.path.exists(qr_path):
            try:
                os.remove(qr_path)
            except Exception:
                pass
        import traceback
        traceback.print_exc()
        return False
