from .index import *

def run_bot(imei: str, session_cookies: Dict, prefix: str, is_main_bot: bool, username: Optional[str] = None, author_id: Optional[str] = None, status: Optional[bool] = None) -> None:
    try:
        if not session_cookies:
            logger.error(f"Lỗi: Cookie phiên không hợp lệ cho Tên: {username}")
            return
        global mainclient
        if not prefix:
            pass
        if is_main_bot:
            mainclient = zrcapis("</>", "</>", imei=imei, session_cookies=session_cookies, prefix=prefix, is_main_bot=is_main_bot)
            if status is False:
                return
            
            if hasattr(mainclient, 'bot') and hasattr(mainclient, 'uid'):
                save_username_to_config(mainclient.bot, mainclient.uid, imei)
            def listen_wrapper():
                try:
                    mainclient.listen(thread=True)
                except Exception as e:
                    if not shutdown_event.is_set():
                        logger.error(f"Lỗi khi listen main bot: {e}")
            threading.Thread(target=listen_wrapper, daemon=True).start()
            return
        client = zrcapis("</>", "</>", imei=imei, session_cookies=session_cookies, prefix=prefix, is_main_bot=is_main_bot)
        if status is False:
            return
        clientlist[str(author_id)] = client
        
        if hasattr(client, 'bot') and hasattr(client, 'uid'):
            save_username_to_config(client.bot, client.uid, imei)
        def listen_wrapper():
            try:
                client.listen(thread=True)
            except Exception as e:
                if not shutdown_event.is_set():
                    logger.error(f"Lỗi khi listen bot {username}: {e}")
        threading.Thread(target=listen_wrapper, daemon=True).start()
        time.sleep(0.88)
    except Exception as e:
        if "#102" in str(e):
            logger.critical(f"{username} Was has expired Imei Cookies and Get failed Login")
        else:
            logger.error(f"Lỗi khi chạy bot {username}: {e}")

def start_threads(data: List[Dict]) -> None:
    threads = []
    for item in data:
        imei = item.get("imei", "Unknown_IMEI")
        session_cookies = item.get("session_cookies", {})
        prefix = item.get("prefix", "")
        is_main_bot = item.get("is_main_bot", False)
        username = item.get("username")
        author_id = item.get("author_id")
        status = item.get("status", False)
        if not isinstance(session_cookies, dict) or not session_cookies:
            logger.error(f"Lỗi: Cookie không hợp lệ cho Tên: {username}")
            continue
        thread = threading.Thread(target=run_bot, args=(imei, session_cookies, prefix, is_main_bot, username, author_id, status))
        if is_main_bot:
            thread.start()
            thread.join()
            time.sleep(2.5)
            continue
        threads.append(thread)
        thread.start()
    for thread in threads:
        thread.join()

def clean():
    global mainclient
    try:
        shutdown_event.set()
        time.sleep(1)
        if 'mainclient' in globals() and mainclient:
            if hasattr(mainclient, 'bools'):
                mainclient.bools.shutdown(wait=False)
            if hasattr(mainclient, 'listening'):
                mainclient.listening = False
        for client_id, client in list(clientlist.items()):
            if hasattr(client, 'bools'):
                client.bools.shutdown(wait=False)
            if hasattr(client, 'listening'):
                client.listening = False
    except Exception as e:
        logger.error(f"Lỗi khi cleanup: {e}")

def check_bot_expiration(bot_item):
    het_han = bot_item.get("het_han")
    if not het_han:
        return True
    try:
        from datetime import datetime
        expiry_date = datetime.strptime(het_han, "%H:%M:%S/%d/%m/%Y")
        current_date = datetime.now()
        
        if current_date > expiry_date:
            bot_item["status"] = False
            username = bot_item.get("username", "Unknown")
            logger.warning(f"Bot {username} đã hết hạn ({het_han}). Tự động tắt.")
            return False
        return True
    except Exception as e:
        logger.error(f"Lỗi kiểm tra hạn sử dụng: {e}")
        return True  