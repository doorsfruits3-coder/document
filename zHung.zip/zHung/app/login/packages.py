from app.library.packages import *
from main import zrcapis
from app.module.apiQr import *

logindb = "data/config/login.json"

clientlist: Dict[str, object] = {}
lock = threading.Lock()
shutdown_event = threading.Event()