from .packages import *

# Get methods

def get_clientlist() -> Dict[str, object]:
    return clientlist

# IO - Json methods
    
def save_json(filename: str, data: Dict) -> None:
    with lock:
        try:
            with open(filename, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
        except Exception as e:
            logger.error(f"Lỗi khi lưu dữ liệu vào {filename}: {e}")

def load_json(filename: str) -> Dict:
    try:
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        logger.error(f"Lỗi: Không tìm thấy tệp {filename}")
        return {"data": []}
    except json.JSONDecodeError:
        logger.error(f"Lỗi: Không thể giải mã JSON từ {filename}")
        return {"data": []}
    
def save_config(data: Dict) -> None:
    save_json(logindb, data)

def save_username_to_config(username: str, author_id: str, imei: str) -> None:
    with lock:
        try:
            data = load_json(logindb)
            if "data" not in data:
                data["data"] = []
            updated = False
            for user in data["data"]:
                if user.get("imei") == imei or user.get("author_id") == author_id:
                    user["username"] = username
                    user["author_id"] = author_id
                    with open(logindb, "w", encoding="utf-8") as file:
                        json.dump(data, file, indent=4, ensure_ascii=False)
                    updated = True
                    break
            
            if not updated:
                logger.warning(f"Không tìm thấy bot với imei={imei} hoặc author_id={author_id} để update username")
        except Exception as e:
            logger.error(f"Lỗi khi cập nhật username vào login.json: {e}")