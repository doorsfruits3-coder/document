"""
packages.py – Import tập trung cho toàn bộ bot.
Mọi module command chỉ cần: from app.library.packages import *
"""
import json
import os
import time
import sys
import threading
import random
import requests
import difflib
import filetype
import subprocess
import string
import importlib.util
import re
import platform
import tempfile
import asyncio
import emoji
import hashlib
import hmac
import httpx                          # ← thêm cho TikTok (tikwm.com)
from threading import Lock
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
from io import BytesIO
from urllib.parse import quote

from bs4 import BeautifulSoup
from PIL import Image, ImageDraw
from requests_oauthlib import OAuth1

from api.models import *
from api import ZaloAPI, logger
from api.util.Enum import PermissionLevel, MsgStyle, CommandStatus, ThreadType

timeNow = time.strftime("%H:%M:%S - %d/%m/%Y", time.localtime())
