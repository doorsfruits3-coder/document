from ..library.packages import *
from src.services.init.admin import *

class Utilsmodule:
    def checkperm(self, level: int, userId, threadId) -> bool:
        setting = read_settings(self.uid)
        if level == 0:
            return True
        elif level == 1:
            gradmin = setting.get("groupAdmin", {})
            if isinstance(gradmin, dict):
                return userId in gradmin.get(str(threadId), [])
            return userId in gradmin
        elif level == 2:
            adminbot = setting.get("adminBot", [])
            if userId in adminbot:
                return True
        elif level == 3:
            highadmin = setting.get("highAdmin", [])
            if userId in highadmin:
                return True
        else:
            return False

class MediaCache:
    def __init__(self, path="data/config/storage-link.json"):
        self.path = path
        self.data = self._load()

    def _load(self):
        if not os.path.exists(self.path):
            return {}
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {}

    def _save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)

    def get(self, platform, sid):
        return self.data.get(platform, {}).get(str(sid))

    def set(self, platform, sid, meta, fileUrl):
        self.data.setdefault(platform, {})[str(sid)] = {
            **meta,
            "fileUrl": fileUrl,
            "timestamp": int(time.time() * 1000)
        }
        self._save()

    def remove(self, platform, sid):
        try:
            self.data.get(platform, {}).pop(str(sid), None)
            self._save()
        except:
            pass

    def isAlive(self, url, timeout=5):
        try:
            r = requests.head(url, timeout=timeout, allow_redirects=True)
            return r.status_code == 200
        except:
            return False


# ══════════════════════════════════════════════════════════════════════════════
#  LIVE FETCH HELPERS  (vẫn export để event.py, kick.py, key-as.py import được)
# ══════════════════════════════════════════════════════════════════════════════

def _get_user_avatar(self, uid: str) -> str:
    try:
        info     = self.fetchUserInfo(str(uid))
        profiles = getattr(info, "changed_profiles", {}) or {}
        profile  = profiles.get(str(uid)) or {}
        url = profile.get("avatar") or ""
        if not url:
            return ""
        import re
        url = re.sub(r'[?&]w=\d+',    '', url)
        url = re.sub(r'[?&]h=\d+',    '', url)
        url = re.sub(r'[?&]s=\d+',    '', url)
        url = re.sub(r'[?&]size=\d+', '', url)
        url = re.sub(r'/w\d+/',        '/w2048/', url)
        return url.rstrip('?&')
    except Exception:
        return ""


def _get_group_info(self, threadId: str) -> tuple:
    try:
        info  = self.fetchGroupInfo(str(threadId))
        gdata = getattr(info, "gridInfoMap", {}) or {}
        g = gdata.get(str(threadId)) or {}
        name = g.get("name") or ""
        avatar = (
            g.get("avt")    or
            g.get("avatar") or
            g.get("fullAvt") or
            g.get("avatarUrl") or
            ""
        )
        if avatar:
            import re
            avatar = re.sub(r'[?&]w=\d+',    '', avatar)
            avatar = re.sub(r'[?&]h=\d+',    '', avatar)
            avatar = re.sub(r'[?&]s=\d+',    '', avatar)
            avatar = re.sub(r'[?&]size=\d+', '', avatar)
            avatar = re.sub(r'/w\d+/',        '/w2048/', avatar)
            avatar = avatar.rstrip('?&')
        return name, avatar
    except Exception:
        return "", ""


# ── Lazy imports để tránh circular import ────────────────────────────────────
def _lazy_imports():
    global AudiomackReply, SoundcloudReply, ZingReply, NctReply
    global DownloadAutoLink, CaroReply, MenuReply, MultibotReply
    global record_message, MemeReply, TikTokReply, CapCutReply, ModReply
    from src.command.music.audiomack import AudiomackReply
    from src.command.music.soundcloud import SoundcloudReply
    from src.command.music.zingmp3 import ZingReply
    from src.command.music.nhaccuatui import NctReply
    from src.command.bot_services.bot_manager.download import DownloadAutoLink
    from src.command.games.caro import CaroReply
    from src.command.multibotManager.multibotCore import MultibotReply
    from src.services.data.chatCounter import record_message
    from src.command.chat_bot.meme import MemeReply
    from src.command.chat_bot.tiktok import TikTokReply
    from src.command.chat_bot.capcut import CapCutReply
    from src.command.bot_services.bot_manager.mod import ModReply
    from src.command.bot_services.bot_manager.menu import MenuReply

# Placeholder globals
AudiomackReply = SoundcloudReply = ZingReply = NctReply = None
DownloadAutoLink = CaroReply = MenuReply = MultibotReply = None
record_message = MemeReply = TikTokReply = CapCutReply = ModReply = None


class Listen:
    def listenReply(self, message, data, userId, threadId, type):
        if TikTokReply is None:
            _lazy_imports()

        # ── Đếm tin nhắn — LUÔN đếm, bất kể allowGroup hay không ─────────
        # listenReply được gọi sau _has_permission → chỉ đếm user trong
        # allowGroup/listenUsers/admins.  Để đếm TOÀN BỘ, xem ghi chú dưới.
        try:
            is_group = getattr(type, "name", "") == "GROUP"
            if is_group:
                record_message(
                    bot_uid  = str(self.uid),
                    userId   = str(userId),
                    threadId = str(threadId),
                )
        except Exception:
            pass

        MenuReply(self, message, data, userId, threadId, type)
        SoundcloudReply(self, message, data, userId, threadId, type)
        ZingReply(self, message, data, userId, threadId, type)
        NctReply(self, message, data, userId, threadId, type)
        MemeReply(self, message, data, userId, threadId, type)
        DownloadAutoLink(self, message, data, userId, threadId, type)
        CaroReply(self, message, data, userId, threadId, type)
        TikTokReply(self, message, data, userId, threadId, type)
        CapCutReply(self, message, data, userId, threadId, type)
        ModReply(self, message, data, userId, threadId, type)
