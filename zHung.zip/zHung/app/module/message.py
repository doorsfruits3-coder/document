from app.core.index import *
from api.util.Enum import MsgStyle


class MessageHelper:
    max_len = 2000

    # ── Internal helpers ──────────────────────────────────────────────────

    def _splitText(self, text: str, limit: int = None) -> list[str]:
        limit = limit or self.max_len
        return [text[i:i + limit] for i in range(0, len(text), limit)]

    def _buildStyled(self, title: str, body: str, style: "MsgStyle"):
        """Tạo text + style JSON cho kiểu SUCCESS / WARNING / ERROR."""
        import json
        color_map = {"gr": "15a85f", "r": "db342e", "yl": "f7b503", "or": "f27806"}
        color_hex = color_map.get(style.value, "ffffff")
        nl        = chr(10)
        full_text = f"{title}{nl}{body}"
        tag_len   = len(title)
        styles    = [
            {"start": 0,            "len": tag_len,                   "st": f"c_{color_hex},b,f_12"},
            {"start": tag_len + 1,  "len": len(full_text) - tag_len - 1, "st": "f_11"},
        ]
        style_str = json.dumps({"styles": styles, "ver": 0})
        return full_text, style_str

    # ── Public send helpers ───────────────────────────────────────────────

    def sendSuccess(self, text: str, threadId, type, data=None, mention=None):
        """Gửi tin nhắn kiểu SUCCESS (xanh lá)."""
        full, style_str = self._buildStyled(MsgStyle.SUCCESS.title, text, MsgStyle.SUCCESS)
        msg = Message(text=full, style=style_str, mention=str(mention) if mention else None)
        if data:
            return self.replyMessage(msg, data, threadId, type)
        return self.send(msg, threadId, type)

    def sendWarning(self, text: str, threadId, type, data=None, mention=None):
        """Gửi tin nhắn kiểu WARNING (vàng)."""
        full, style_str = self._buildStyled(MsgStyle.WARNING.title, text, MsgStyle.WARNING)
        msg = Message(text=full, style=style_str, mention=str(mention) if mention else None)
        if data:
            return self.replyMessage(msg, data, threadId, type)
        return self.send(msg, threadId, type)

    def sendError(self, text: str, threadId, type, data=None, mention=None):
        """Gửi tin nhắn kiểu ERROR (đỏ)."""
        full, style_str = self._buildStyled(MsgStyle.ERROR.title, text, MsgStyle.ERROR)
        msg = Message(text=full, style=style_str, mention=str(mention) if mention else None)
        if data:
            return self.replyMessage(msg, data, threadId, type)
        return self.send(msg, threadId, type)

    def sendInfo(self, text: str, threadId, type, data=None, mention=None):
        """Gửi tin nhắn kiểu INFO (cam)."""
        full, style_str = self._buildStyled(MsgStyle.INFO.title, text, MsgStyle.INFO)
        msg = Message(text=full, style=style_str, mention=str(mention) if mention else None)
        if data:
            return self.replyMessage(msg, data, threadId, type)
        return self.send(msg, threadId, type)

    # ── Mention wrappers ──────────────────────────────────────────────────

    def sendMention(self, text: str, userId: str, threadId, type):
        name    = self.userName(userId)
        mention = Mention(userId, offset=0, length=len(name))
        parts   = self._splitText(f"{name}\n{text}")
        for i, part in enumerate(parts):
            msg = self.send(
                Message(text=part, mention=mention if i == 0 else None),
                threadId, type
            )
        return msg

    def sendReplyMention(self, text: str, userId: str, data, threadId, type):
        name    = self.userName(userId)
        mention = Mention(userId, offset=0, length=len(name))
        parts   = self._splitText(f"{name}\n{text}")
        for i, part in enumerate(parts):
            msgr = self.replyMessage(
                Message(text=part, mention=mention if i == 0 else None),
                data if i == 0 else None,
                threadId, type
            )
        return msgr

    def sendImage(self, imagePath: str, text: str, userId: str, threadId, type):
        upload   = self._uploadImage(imagePath, threadId, type)
        imagehd  = upload.get("hdUrl")
        name     = self.userName(userId)
        mention  = Mention(userId, offset=0, length=len(name))
        with Image.open(imagehd) as img:
            width, height = img.size
        tinnhan = f"{name}\n{text}"
        self.sendRemoteImage(
            image_url=imagehd,
            message=Message(text=tinnhan, mention=mention),
            threadId=threadId,
            type=type,
            width=width,
            height=height,
            ttl=86000000
        )

    def sendMentionStyle(self, text: str, userId: str, threadId, type):
        def dem_ki_tu_utf16_units(chuoi: str) -> int:
            """Đếm theo số code unit UTF-16 (mỗi unit = 2 byte)"""
            return len(chuoi.encode("utf-16-le")) // 2

        name       = self.userName(userId)
        name_len   = dem_ki_tu_utf16_units(name)
        mention    = Mention(userId, offset=0, length=name_len)
        full_text  = f"{name}\n{text}"
        parts      = self._splitText(full_text)
        for i, part in enumerate(parts):
            part_len = dem_ki_tu_utf16_units(part)
            style = (
                MultiMsgStyle([
                    MessageStyle(offset=0, length=part_len, auto_format=False),
                    MessageStyle(offset=0, length=part_len, style="font", size="10", auto_format=False),
                ])
                if i == 0 else None
            )
            msgs = self.send(
                Message(text=part, mention=mention if i == 0 else None, style=style),
                threadId, type
            )
        return msgs
