from app.library.packages import *
from src.services.utils.jsonio import *
from api.util.Enum import PermissionLevel, MsgStyle


def load_command_config(uid: str) -> dict:
    path = f"data/config/bot/Data-{uid}.json"
    data = load_json(path, {"command": []})
    return {c["name"]: c for c in data.get("command", [])}


def write_command_config(uid: str, commands: dict):
    path = f"data/config/bot/Data-{uid}.json"
    ensure_dir(os.path.dirname(path))
    data = load_json(path, {"command": []})
    existed = {c["name"] for c in data["command"]}
    for name, deps in commands.items():
        if name in existed:
            continue
        data["command"].append({
            "name":        name,
            "permission":  deps.get("permission", PermissionLevel.USER.value),
            "description": deps.get("description", ""),
            "alias":       list(deps.get("alias", [])),
            "cooldown":    deps.get("cooldown", 0),
            "status":      deps.get("status", True),
        })
    save_json(path, data)


def removeMention(self, data) -> str:
    try:
        content = data.get("content", "")
        if isinstance(content, dict):
            content = content.get("title", content)
        mentions = data.get("mentions") or []
        if not isinstance(content, str):
            return ""
        # mentions có thể là JSON string từ API → parse trước khi dùng
        if isinstance(mentions, str):
            try:
                import json as _json
                mentions = _json.loads(mentions)
            except Exception:
                mentions = []
        if not isinstance(mentions, list):
            mentions = []
        mentions = sorted(mentions, key=lambda x: x.get("pos", 0), reverse=True)
        for m in mentions:
            pos    = m.get("pos", 0)
            length = m.get("len", 0)
            content = content[:pos] + content[pos + length:]
        return " ".join(content.split()).strip()
    except Exception:
        return ""


def loader(self, command_dir: str) -> dict:
    commands: dict = {}
    if command_dir not in sys.path:
        sys.path.insert(0, command_dir)

    for root, _, files in os.walk(command_dir):
        for file in sorted(files):
            if not file.endswith(".py") or file.startswith("__"):
                continue

            path        = os.path.join(root, file)
            module_name = (
                os.path.relpath(path, command_dir)
                .replace(os.sep, ".")
                .replace(".py", "")
            )

            try:
                spec = importlib.util.spec_from_file_location(module_name, path)
                if not spec or not spec.loader:
                    continue

                module = importlib.util.module_from_spec(spec)
                module.__package__ = module_name.rpartition(".")[0]
                sys.modules[module_name] = module
                spec.loader.exec_module(module)

                if not hasattr(module, "dependencies"):
                    continue

                deps = dict(module.dependencies)
                deps.setdefault("permission", PermissionLevel.USER.value)
                deps.setdefault("noPrefix",   False)
                deps.setdefault("is_main",    False)
                deps.setdefault("alias",      [])
                deps.setdefault("cooldown",   0)
                deps.setdefault("status",     True)

                if deps["is_main"] and not self.is_main_bot:
                    continue

                name = deps.get("name")
                main = deps.get("main")
                if not name or not callable(main):
                    continue

                # Gọi onLoad hook nếu module có khai báo
                on_load = deps.get("onLoad")
                if callable(on_load):
                    try:
                        on_load(self)
                    except Exception as _ol_e:
                        logger.error(f"onLoad thất bại: {name} | {_ol_e}")

                commands[name] = deps

            except Exception as e:
                logger.error(f"Load thất bại: {path} | {e}")

    write_command_config(self.uid, commands)
    return commands


class commandHandles:
    _cooldown_cache: dict = {}

    def permissionLevel(self, userId: str, threadId: str) -> int:
        settings = read_settings(self.uid)
        if userId in settings.get("developerAdmin", []):
            return PermissionLevel.DEVELOPER.value
        if userId in settings.get("highAdmin", []):
            return PermissionLevel.HIGH_ADMIN.value
        if userId in settings.get("adminBot", []):
            return PermissionLevel.BOT_ADMIN.value
        if userId in settings.get("groupAdmin", {}).get(threadId, []):
            return PermissionLevel.GROUP_ADMIN.value
        return PermissionLevel.USER.value

    def checkPermission(self, userId: str, threadId: str, level: int) -> bool:
        return level == 0 or self.permissionLevel(userId, threadId) >= level

    def _sendNoPermission(self, data, userId, threadId, type, required_level: int):
        from api.util.msg import Mention
        _level_name = {0: "Người dùng", 1: "Group admin", 2: "Bot admin", 3: "High admin", 4: "Developer"}
        user_level   = self.permissionLevel(userId, threadId)
        user_label   = _level_name.get(user_level, str(user_level))
        needed_label = _level_name.get(required_level, str(required_level))
        name         = self.userName(userId)
        mention_obj  = Mention(userId, offset=0, length=len(name))
        
        msg = (
            f"Quyền hạn của bạn hiện tại là: {user_label}, lệnh yêu cầu quyền: {needed_label}"
        )
        self.sendReaction(data, "🔒", threadId, type, 100000000)
        self.replyMessageStyle(
            msg,
            data,
            threadId,
            type,
            color="r",
            title="IGNORE",
            userId=userId
        )

    def checkCooldown(self, userId: str, cmd: str, seconds: int) -> float:
        if seconds <= 0:
            return 0.0
        key  = (userId, cmd)
        now  = time.time()
        last = self._cooldown_cache.get(key)
        if last is None:
            self._cooldown_cache[key] = now
            return 0.0
        remain = seconds - (now - last)
        if remain > 0:
            return remain
        self._cooldown_cache[key] = now
        return 0.0

    def loadcommands(self, message, data, userId: str, threadId: str, type):
        text = removeMention(self, data)
        if not text:
            return

        tokens = text.split()
        if not tokens:
            return

        has_prefix = text.startswith(self.prefix)
        if has_prefix and not text[len(self.prefix):].strip():
            return
        raw_cmd    = (
            text[len(self.prefix):].split()[0].lower()
            if has_prefix else tokens[0].lower()
        )

        config  = load_command_config(self.uid)
        command = self.commands.get(raw_cmd)
        real_cmd = raw_cmd

        if not command:
            for name, conf in config.items():
                if raw_cmd in conf.get("alias", []):
                    command  = self.commands.get(name)
                    real_cmd = name
                    break

        if not command:
            if text.strip() == self.prefix:
                self.sendSuccess(
                    f"Use {self.prefix}menu to check all commands to use my bot",
                    threadId, type, data
                )
            return

        self.rawCommand  = raw_cmd
        self.commandName = real_cmd
        self.hasPrefix   = has_prefix

        if not has_prefix and not command.get("noPrefix", False):
            return

        conf = config.get(real_cmd, {})
        if not conf.get("status", command.get("status", True)):
            return

        # ── Kiểm tra bảo trì ──────────────────────────────────────────────
        # Lệnh trong danh sách maintenance chỉ Super Admin (level 3) mới dùng được.
        _maintenance = read_settings(self.uid).get("maintenance", [])
        if real_cmd in _maintenance:
            user_level_check = self.permissionLevel(userId, threadId)
            if user_level_check < PermissionLevel.HIGH_ADMIN.value:
                self.replyMessageStyle(
                    f"Lệnh {real_cmd} hiện đang trong chế độ bảo trì.\n"
                    f"Vui lòng quay lại sử dụng sau khi lệnh đã hoàn thiện!",
                    data, threadId, type,
                    color="yl",
                    title="WARNING",
                    userId=userId
                )
                return

        level      = conf.get("permission", command.get("permission", 0))
        user_level = self.permissionLevel(userId, threadId)

        if not self.checkPermission(userId, threadId, level):
            self._sendNoPermission(data, userId, threadId, type, level)
            return

        cooldown = conf.get("cooldown", command.get("cooldown", 0))

        if user_level == PermissionLevel.USER.value:
            remain = self.checkCooldown(userId, real_cmd, cooldown)
            if remain > 0:
                try:
                    for i in range(int(min(remain, 1000)), 0, -1):
                        self.sendMultiReaction(data, "🕑", threadId, type, 102229, numreact=i)
                        time.sleep(1)
                        self.sendMultiReaction(data, "", threadId, type, -1, numreact=i)
                except Exception as cd:
                    logger.errorw(f"Cooldown err {cd}")
                return
        else:
            self._cooldown_cache[(userId, real_cmd)] = time.time()

        if raw_cmd != real_cmd:
            if has_prefix:
                text = text.replace(f"{self.prefix}{raw_cmd}", f"{self.prefix}{real_cmd}", 1)
            else:
                text = text.replace(raw_cmd, real_cmd, 1)

        from api.util.msg import Message
        try:
            self.sendReaction(data, "👌", threadId, type, 100000000)
            command["main"](self, Message(text=text), data, userId, threadId, type)
        except Exception as e:
            logger.errorw(f"Lỗi lệnh {real_cmd}: {e}")