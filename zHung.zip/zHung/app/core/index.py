from app.library.packages import *
from app.module.utils import *
from src.services.utils.jsonio import *
from api.util.Enum import PermissionLevel, MsgStyle, ThreadType

from api.util.msg import (
    Message,
    MessageStyle,
    MultiMsgStyle,
    MessageReaction,
    Mention,
    MultiMention,
)
from app.module.commandLoader import load_command_config, write_command_config

def extractUids(data) -> list:

    try:
        mentions = None
        if isinstance(data, dict):
            mentions = data.get("mentions")
        else:
            mentions = getattr(data, "mentions", None)
        if not mentions:
            return []
        if isinstance(mentions, str):
            import json
            mentions = json.loads(mentions)
        return [str(m["uid"]) for m in mentions if m.get("uid") and str(m.get("uid")) != "-1"]
    except Exception:
        return []