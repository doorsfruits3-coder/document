import re
def Parse(text, styles=None, parse_mode=None):
	parse_mode = parse_mode or "Markdown"
	styles = styles or []
	if parse_mode == "Markdown":
		return parse_markdown(text)
	elif parse_mode == "HTML":
		return parse_html(text)
	else:
		return markdown_message(text)
def parse_markdown(text):
	markdown_map = {"**": "bold", "__": "underline", "_": "italic", "~~": "strike"}
	elements, temp_text = [], text
	while any(temp_text.count(tag) >= 2 for tag in markdown_map):
		for tag in sorted(markdown_map, key=lambda k: temp_text.find(k)):
			start = temp_text.find(tag)
			end = temp_text.rfind(tag, start + len(tag))
			if start < 0 or end < 0 or end <= start:
				continue
			inner = temp_text[start + len(tag):end]
			if inner.count(tag) >= 2:
				end = temp_text.find(tag, start + len(tag))
				if end < 0:
					continue
			elements.append({
				"start": start,
				"end": end,
				"length": end - start - len(tag) + 1,
				"text": inner,
				"char_len": len(tag),
				"type": markdown_map[tag]
			})
			temp_text = temp_text[:start] + inner + temp_text[end + len(tag):]
			break
	for e in elements:
		text = text[:e["start"]] + text[e["start"] + e["char_len"]:e["end"]] + text[e["end"] + e["char_len"]:]
		e["start"] -= 1
		e["end"] += 2
	return text, sorted(elements, key=lambda e: e["start"])
def markdown_message(text):
	tags = {"<b>": "bold", "<i>": "italic", "<u>": "underline", "<s>": "strike"}
	results = []
	for tag, typ in tags.items():
		start = 0
		while True:
			start = text.find(tag, start)
			if start == -1:
				break
			end = text.find(f"</{tag[1:]}", start)
			if end == -1:
				break
			length = len(text[start + len(tag):end])
			text = text[:start] + text[start + len(tag):end] + text[end + len(tag) + 1:]
			results.append({
				"start": start - 1,
				"end": end + len(typ),
				"length": length,
				"type": typ
			})
			start = 0  # reset for next loop
	return text, results
def parse_html(text):
	tags = {"<b>": "bold", "<u>": "underline", "<i>": "italic", "<s>": "strike"}
	elements, temp_text = [], text

	while any(temp_text.count(t) and temp_text.count(f"</{t[1:]}") for t in tags):
		for tag in sorted(tags, key=lambda k: temp_text.find(k)):
			start = temp_text.find(tag)
			end = temp_text.rfind(f"</{tag[1:]}", start + len(tag))
			if start < 0 or end < 0 or end <= start:
				continue
			inner = temp_text[start + len(tag):end]
			elements.append({
				"start": start,
				"end": end,
				"length": end - start - len(tag),
				"text": inner,
				"char_len": len(tag),
				"type": tags[tag]
			})
			temp_text = temp_text[:start] + inner + temp_text[end + len(tag) + 1:]
			break
	for e in elements:
		text = text[:e["start"]] + text[e["start"] + e["char_len"]:e["end"]] + text[e["end"] + e["char_len"] + 1:]
		e["start"] -= 1
	return text, sorted(elements, key=lambda e: e["start"])