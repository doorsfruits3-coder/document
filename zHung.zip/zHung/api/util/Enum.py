import enum


class Enum(enum.Enum):
    def __repr__(self):
        return "{}.{}".format(type(self).__name__, self.name)


class PermissionLevel(Enum):
    """Cấp bậc quyền hạn của người dùng trong bot."""
    USER        = 0  # Người dùng thường
    GROUP_ADMIN = 1  # Admin nhóm
    BOT_ADMIN   = 2  # Admin bot
    HIGH_ADMIN  = 3  # Admin Super
    DEVELOPER   = 4  # Developer 

    @classmethod
    def label(cls, level: int) -> str:
        _map = {
            0: "Người dùng",
            1: "Admin Nhóm",
            2: "Admin Bot",
            3: "Super Admin",
            4: "Developer",
        }
        return _map.get(level, "Không xác định")

    @classmethod
    def from_int(cls, level: int) -> "PermissionLevel":
        try:
            return cls(level)
        except ValueError:
            return cls.USER


class MsgStyle(Enum):
    """Kiểu style cho tin nhắn gửi ra."""
    SUCCESS = "gr"  # Xanh lá
    WARNING = "yl"  # Vàng
    ERROR   = "r"   # Đỏ
    INFO    = "or"  # Cam

    @property
    def title(self) -> str:
        return self.name  # SUCCESS / WARNING / ERROR / INFO


class CommandStatus(Enum):
    """Trạng thái của lệnh."""
    ENABLED  = True
    DISABLED = False


class ThreadType(Enum):
    """Loại thread: nhóm hay cá nhân."""
    USER  = 0
    GROUP = 1