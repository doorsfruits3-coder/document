import json

from ..util import utilzone
from ..app import appstate
from ..models import *

class FetchAPi:
    def fetchAccountInfo(self):
        """fetch account information of the client 
        
        Returns:
            object: `User` client info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "avatar_size": 120,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "os": 8,
            "browser": 0
        }
        
        response = self._get("https://tt-profile-wpa.chat.zalo.me/api/social/profile/me-v2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def fetchPhoneNumber(self, phoneNumber, language="vi"):
        """Fetch user info by Phone Number.
        
        Not available with hidden phone numbers
        
        Args:
            phoneNumber (int | str): Phone number to fetch information
            language (str): Language for response (not sure | Default: vi)
        
        Returns:
            object: `User` user(s) info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        _p = str(phoneNumber).strip().lstrip("+").replace(" ", "").replace("-", "")
        if _p.startswith("84"):
            phone = _p
        elif _p.startswith("0"):
            phone = "84" + _p[1:]
        else:
            phone = "84" + _p
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "phone": phone,
                "avatar_size": 240,
                "language": language,
                "imei": self._imei,
                "reqSrc": 85
            })
        }
        
        response = self._get("https://tt-friend-wpa.chat.zalo.me/api/friend/profile/get", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def fetchUserInfo(self, userId):
        """Fetch user info by ID.
        
        Args:
            userId (int | str | list): User(s) ID to get info
        
        Returns:
            object: `User` user(s) info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "phonebook_version": int(utilzone.now() / 1000),
                "friend_pversion_map": [],
                "avatar_size": 120,
                "language": "vi",
                "show_online_status": 1,
                "imei": self._imei
            }
        }
        
        if isinstance(userId, list):
            for i in range(len(userId)):
                userId[i] = str(userId[i]) + "_0"
            payload["params"]["friend_pversion_map"] = userId
            
        else:
            payload["params"]["friend_pversion_map"].append(str(userId) + "_0")
            
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/friend/getprofiles/v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def fetchGroupInfo(self, groupId):
        """Fetch group info by ID.
        
        Args:
            groupId (int | str | dict): Group(s) ID to get info
        
        Returns:
            object: `Group` group info
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "gridVerMap": {}
            }
        }
        
        if isinstance(groupId, dict):
            for i in groupId:
                payload["params"]["gridVerMap"][str(i)] = 0
        else:
            payload["params"]["gridVerMap"][str(groupId)] = 0
            
        payload["params"]["gridVerMap"] = json.dumps(payload["params"]["gridVerMap"])
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/getmg-v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
        
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def fetchAllFriends(self):
        """Fetch all users the client is currently chatting with (only friends).
        
        Returns:
            object: `User` all friend IDs
            any: If response is not list friends
            
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "params": self._encode({
                "incInvalid": 0,
                "page": 1,
                "count": 20000,
                "avatar_size": 120,
                "actiontime": 0
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0
        }
        
        response = self._get("https://profile-wpa.chat.zalo.me/api/social/friend/getfriends", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            datas = []
            if results.get("data"):
                for data in results.get("data"):
                    datas.append(User(**data))
            
            return datas
                    
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def fetchAllGroups(self):
        """Fetch all group IDs are joining and chatting.
        
        Returns:
            object: `Group` all group IDs
            any: If response is not all group IDs
        
        Raises:
            ZaloAPIException: If request failed
        """
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/getlg/v4", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")