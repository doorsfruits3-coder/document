import json
import os
import time

from ..util import utilzone
from ..app import appstate
from ..models import *

class GroupAPi:    
    def createGroup(self, name=None, description=None, members=[], nameChanged=1, createLink=1):
        """Create a new group.
            
        Args:
            name (str): The new group name
            description (str): Description of the new group
            members (str | list): List/String member IDs add to new group
            nameChanged (int - auto): Will use default name if disabled (0), else (1)
            createLink (int - default): Create a group link? Default = 1 (True)
            
        Returns:
            object: `Group` new group response
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        memberTypes = []
        nameChanged = 1 if name else 0
        name = name or "Default Group Name"
        
        if members and isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        if members:
            for i in members:
                memberTypes.append(-1)
            
        params = {
            "params": self._encode({
                "clientId": utilzone.now(),
                "gname": name,
                "gdesc": description,
                "members": members,
                "memberTypes": memberTypes,
                "nameChanged": nameChanged,
                "createLink": createLink,
                "clientLang": "vi",
                "imei": self._imei,
                "zsource": 601
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/create/v2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return results
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def upgradeComunity(self, groupId):
        params = {
            "zpw_ver": 655,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                'grId': str(groupId), 
                'language': 'vi'
            })
        }
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/upgrade/community", params=params)
        data = response.json()
        print(data)
        results = data.get("data") if data.get("error_code") == 0 else None
        print(results)
        if results:
            results = self._decode(results)
            print(results)
            return Group.fromDict(results, None)

        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupAvatar(self, filePath, groupId):
        """Upload/Change group avatar by ID.
        
        Client must be the Owner of the group
        (If the group does not allow members to upload/change)
            
        Args:
            filePath (str): A path to the image to upload/change avatar
            groupId (int | str): Group ID to upload/change avatar
            
        Returns:
            object: `Group` Group avatar change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
            
            
        files = [("fileContent", open(filePath, "rb"))]
        
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "avatarSize": 120,
                "clientId": "g" + str(groupId) + utilzone.formatTime("%H:%M %d/%m/%Y"),
                "originWidth": 640,
                "originHeight": 640,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._post("https://tt-files-wpa.chat.zalo.me/api/group/upavatar", params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupName(self, groupName, groupId):
        """Set/Change group name by ID.
        
        Client must be the Owner of the group
        (If the group does not allow members to change group name)
            
        Args:
            groupName (str): Group name to change
            groupId (int | str): Group ID to change name
            
        Returns:
            object: `Group` Group name change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "gname": groupName,
                "grid": str(groupId)
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/updateinfo", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupDesc(self, groupDesc, groupId):
        """Not Available Yet"""
    
    def changeGroupSetting(self, groupId, defaultMode="default", **kwargs):
        """Update group settings by ID.
        
        Client must be the Owner/Admin of the group.
        
        Warning:
            Other settings will default value if not set. See `defaultMode`
        
        Args:
            groupId (int | str): Group ID to update settings
            defaultMode (str): Default mode of settings
            
                default: Group default settings
                anti-raid: Group default settings for anti-raid
            
            **kwargs: Group settings kwargs, Value: (1 = True, 0 = False)
            
                blockName: Không cho phép user đổi tên & ảnh đại diện nhóm
                signAdminMsg: Đánh dấu tin nhắn từ chủ/phó nhóm
                addMemberOnly: Chỉ thêm members (Khi tắt link tham gia nhóm)
                setTopicOnly: Cho phép members ghim (tin nhắn, ghi chú, bình chọn)
                enableMsgHistory: Cho phép new members đọc tin nhắn gần nhất
                lockCreatePost: Không cho phép members tạo ghi chú, nhắc hẹn
                lockCreatePoll: Không cho phép members tạo bình chọn
                joinAppr: Chế độ phê duyệt thành viên
                bannFeature: Default (No description)
                dirtyMedia: Default (No description)
                banDuration: Default (No description)
                lockSendMsg: Không cho phép members gửi tin nhắn
                lockViewMember: Không cho phép members xem thành viên nhóm
                blocked_members: Danh sách members bị chặn
        
        Returns:
            object: `Group` Group settings change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if defaultMode == "anti-raid":
            defSetting = {
                "blockName": 1,
                "signAdminMsg": 1,
                "addMemberOnly": 0,
                "setTopicOnly": 1,
                "enableMsgHistory": 1,
                "lockCreatePost": 1,
                "lockCreatePoll": 1,
                "joinAppr": 1,
                "bannFeature": 0,
                "dirtyMedia": 0,
                "banDuration": 0,
                "lockSendMsg": 0,
                "lockViewMember": 0,
            }
        else:
            defSetting = self.fetchGroupInfo(groupId).gridInfoMap
            defSetting = defSetting[str(groupId)]["setting"]
            
        blockName = kwargs.get("blockName", defSetting.get("blockName", 1))
        signAdminMsg = kwargs.get("signAdminMsg", defSetting.get("signAdminMsg", 1))
        addMemberOnly = kwargs.get("addMemberOnly", defSetting.get("addMemberOnly", 0))
        setTopicOnly = kwargs.get("setTopicOnly", defSetting.get("setTopicOnly", 1))
        enableMsgHistory = kwargs.get("enableMsgHistory", defSetting.get("enableMsgHistory", 1))
        lockCreatePost = kwargs.get("lockCreatePost", defSetting.get("lockCreatePost", 1))
        lockCreatePoll = kwargs.get("lockCreatePoll", defSetting.get("lockCreatePoll", 1))
        joinAppr = kwargs.get("joinAppr", defSetting.get("joinAppr", 1))
        bannFeature = kwargs.get("bannFeature", defSetting.get("bannFeature", 0))
        dirtyMedia = kwargs.get("dirtyMedia", defSetting.get("dirtyMedia", 0))
        banDuration = kwargs.get("banDuration", defSetting.get("banDuration", 0))
        lockSendMsg = kwargs.get("lockSendMsg", defSetting.get("lockSendMsg", 0))
        lockViewMember = kwargs.get("lockViewMember", defSetting.get("lockViewMember", 0))
        blocked_members = kwargs.get("blocked_members", [])
        
        params = {
            "params": self._encode({
                "blockName": blockName,
                "signAdminMsg": signAdminMsg,
                "addMemberOnly": addMemberOnly,
                "setTopicOnly": setTopicOnly,
                "enableMsgHistory": enableMsgHistory,
                "lockCreatePost": lockCreatePost,
                "lockCreatePoll": lockCreatePoll,
                "joinAppr": joinAppr,
                "bannFeature": bannFeature,
                "dirtyMedia": dirtyMedia,
                "banDuration": banDuration,
                "lockSendMsg": lockSendMsg,
                "lockViewMember": lockViewMember,
                "blocked_members": blocked_members,
                "grid": str(groupId),
                "imei":self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/setting/update", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeGroupOwner(self, newAdminId, groupId):
        """Change group owner (yellow key) by ID.
        
        Client must be the Owner of the group.
            
        Args:
            newAdminId (int | str): members ID to changer owner
            groupId (int | str): ID of the group to changer owner
            
        Returns:
            object: `Group` Group owner change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "newAdminId": str(newAdminId),
                "imei": self._imei,
                "language": "vi"
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/change-owner", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def addUsersToGroup(self, user_ids, groupId):
        """Add friends/users to a group.
            
        Args:
            user_ids (str | list): One or more friend/user IDs to add
            groupId (int | str): Group ID to add friend/user to
        
        Returns:
            object: `Group` add friend/user data
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        memberTypes = []
        
        if user_ids and isinstance(user_ids, list):
            members = [str(user) for user in user_ids]
        else:
            members = [str(user_ids)]
            
        if members:
            for i in members:
                memberTypes.append(-1)
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "memberTypes": memberTypes,
                "imei": self._imei,
                "clientLang": "vi"
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/invite/v2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def kickUsers(self, members, groupId):
        """Kickout members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to kickout
            groupId (int | str): Group ID to kick member from
            
        Returns:
            object: `Group` kick data
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/kickout", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def blockUsers(self, members, groupId):
        """Blocked members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to block
            groupId (int | str): Group ID to block member from
            
        Returns:
            object: `Group` block members response
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/add", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unblockUsers(self, members, groupId):
        """unblock members in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to unblock
            groupId (int | str): Group ID to unblock member from
            
        Returns:
            object: `Group` unblock members response
            dict: A dictionary/object containing error responses
            
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "grid": str(groupId),
                "members": members
            })
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/remove", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def addGroupAdmins(self, members, groupId):
        """Add admins to the group (white key).
        
        Client must be the Owner of the group.
            
        Args:
            members (str | list): One or More member IDs to add
            groupId (int | str): Group ID to add admins
            
        Returns:
            object: `Group` Group admins add status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/admins/add", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
        
    def removeGroupAdmins(self, members, groupId):
        """Remove admins in the group (white key) by ID.
        
        Client must be the Owner of the group.
            
        Args:
            members (str | list): One or More admin IDs to remove
            groupId (int | str): Group ID to remove admins
            
        Returns:
            object: `Group` Group admins remove status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
            
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/admins/remove", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def pinGroupMsg(self, pinMsg, groupId):
        """Pin message in group by ID.
        
        Args:
            pinMsg (Message): Message Object to pin
            groupId (int | str): Group ID to pin message
        
        Returns:
            object: `Group` pin message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "grid": str(groupId),
                "type": 2,
                "color": -14540254,
                "emoji": "📌",
                "startTime": -1,
                "duration": -1,
                "repeat": 0,
                "src": -1,
                "imei": self._imei,
                "pinAct": 1
            }
        }
        
        if pinMsg.msgType == "webchat":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "title": pinMsg.content,
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.voice":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType in ["chat.photo", "chat.video.msg"]:
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "thumb": pinMsg.content.thumb,
                "title": pinMsg.content.description,
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.sticker":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "extra": json.dumps({
                    "id": pinMsg.content.id,
                    "catId": pinMsg.content.catId,
                    "type": pinMsg.content.type
                }),
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType in ["chat.recommended", "chat.link"]:
            
            extra = json.loads(pinMsg.content.params)
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "href": pinMsg.content.href,
                "thumb": pinMsg.content.thumb or "",
                "title": pinMsg.content.title,
                "linkCaption": "https://vrxx1337.vercel.app",
                "redirect_url": extra.get("redirect_url", ""),
                "streamUrl": extra.get("streamUrl", ""),
                "artist": extra.get("artist", ""),
                "stream_icon": extra.get("stream_icon", ""),
                "type": 2,
                "extra": json.dumps({
                    "action": pinMsg.content.action,
                    "params": json.dumps({
                        "mediaTitle": extra.get("mediaTitle", ""),
                        "artist": extra.get("artist", ""),
                        "src": extra.get("src", ""),
                        "stream_icon": extra.get("stream_icon", ""),
                        "streamUrl": extra.get("streamUrl", ""),
                        "type": 2
                    })
                }),
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.location.new":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType),
                "title": pinMsg.content.title or pinMsg.content.description
            })
        
        elif pinMsg.msgType == "share.file":
            
            extra = json.loads(pinMsg.content.params)
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "title": pinMsg.content.title,
                "extra": json.dumps({
                    "fileSize": "7295",
                    "checksum": extra.get("checksum", ""),
                    "fileExt": extra.get("fileExt", ""),
                    "tWidth": extra.get("tWidth", 0),
                    "tHeight": extra.get("tHeight", 0),
                    "duration": extra.get("duration", 0),
                    "fType": extra.get("fType", 0),
                    "fdata": extra.get("fdata", ""),
                }),
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        elif pinMsg.msgType == "chat.gif":
            
            payload["params"]["params"] = json.dumps({
                "client_msg_id": pinMsg.cliMsgId,
                "global_msg_id": pinMsg.msgId,
                "senderUid": str(int(pinMsg.uidFrom) or self.uid),
                "senderName": pinMsg.dName,
                "thumb": pinMsg.content.thumb,
                "msg_type": utilzone.getClientMessageType(pinMsg.msgType)
            })
        
        payload["params"] = self._encode(payload["params"])
        response = self._post("https://groupboard-wpa.chat.zalo.me/api/board/topic/createv2", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def unpinGroupMsg(self, pinId, pinTime, groupId):
        """Unpin message in group by ID.
        
        Args:
            pinId (int | str): Pin ID to unpin
            pinTime (int): Pin start time
            groupId (int | str): Group ID to unpin message
        
        Returns:
            object: `Group` unpin message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei,
                "topic": {
                    "topicId": str(pinId),
                    "topicType": 2
                },
                "boardVersion": int(pinTime)
            })
        }
        
        response = self._get("https://groupboard-wpa.chat.zalo.me/api/board/unpinv2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def deleteMessage(self, msgId, ownerId, clientMsgId, groupId):
        """Delete message in group by ID.
        
        Args:
            groupId (int | str): Group ID to delete message
            msgId (int | str): Message ID to delete
            ownerId (int | str): Owner ID of the message to delete
            clientMsgId (int | str): Client message ID to delete message
        
        Returns:
            object: `Group` delete message status
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "cliMsgId": utilzone.now(),
                "msgs": [{
                    "cliMsgId": str(clientMsgId),
                    "globalMsgId": str(msgId),
                    "ownerId": str(ownerId),
                    "destId": str(groupId)
                }],
                "onlyMe": 0
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/deletemsg", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def setNotifyGroup(self, groupId, action=1):
        """
        Enable or disable notifications for a Zalo group.

        Args:
            groupId (int | str): The ID of the group to modify.
            action (int): 
                - `1` to **disable notifications**
                - `3` to **enable notifications**

        Returns:
            dict | None: The response data if successful.

        Raises:
            ZaloAPIException: If the request fails.
        """

        params = {
            "zpw_ver": 664,
            "zpw_type": self.apiLogintype
        }

        payload = {
            "params": self._encode({
                "toid": str(groupId),
                "duration": -1,
                "action": action,
                "startTime": int(time.time()),
                "muteType": 2,
                "imei": self._imei 
            })
        }

        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/profile/setmute", params=params, data=payload)
        data = response.json()

        if data.get("error_code") == 0:
            return data.get("data")  
        else:
            raise ZaloAPIException(f"Error #{data.get('error_code')} - {data.get('error_message') or data.get('data')}")

    def listInviteBox(self, page=0, invPerPage=12, mcount=10, lastGroupId=None):
        """
        Retrieve the list of invited Zalo groups (Invite Box).

        Args:
            page (int): Page index (default: 0).
            invPerPage (int): Number of invites per page (default: 12).
            mcount (int): Member count to retrieve (default: 10).
            lastGroupId (str | None): ID of the last group fetched (for pagination, default: None).

        Returns:
            dict | None: List of invited groups and related metadata.

        Raises:
            ZaloAPIException: If the request fails.
        """

        params = {
            "zpw_ver": 664,
            "zpw_type": self.apiLogintype
        }

        payload_data = {
            "mpage": 1,
            "page": page,
            "invPerPage": invPerPage,
            "mcount": mcount,
            "lastGroupId": lastGroupId,
            "avatar_size": 120,
            "member_avatar_size": 120
        }

        payload = {
            "params": self._encode(payload_data)
        }

        response = self._post(
            "https://tt-group-wpa.chat.zalo.me/api/group/inv-box/list",
            params=params,
            data=payload
        )

        data = response.json()

        if data.get("error_code") == 0:
            return data.get("data")
        else:
            raise ZaloAPIException(f"Error #{data.get('error_code')} - {data.get('error_message') or data.get('data')}")

    def boxInvAccept(self, groupId: int | str, lang="vi"):
        """
        Accept an invitation to join a Zalo group from the Invite Box.

        Args:
            groupId (int | str): The group ID to join.
            lang (str): Language code (default: "vi").

        Returns:
            dict | None: The response data if successful.

        Raises:
            ZaloAPIException: If the request fails.
        """

        params = {
            "zpw_ver": 664,
            "zpw_type": self.apiLogintype
        }

        payload = {
            "params": self._encode({
                "grid": int(groupId),
                "lang": lang
            })
        }

        response = self._post(
            "https://tt-group-wpa.chat.zalo.me/api/group/inv-box/join",
            params=params,
            data=payload
        )

        data = response.json()

        if data.get("error_code") == 0:
            return data.get("data")
        else:
            raise ZaloAPIException(f"Error #{data.get('error_code')} - {data.get('error_message') or data.get('data')}")

    def createReminder(
    self,
    groupId: int | str,
    title: str,
    emoji: str = "⏰",
    color: int = -16245706,
    start_time: int = None,
    repeat: int = 0,
    pinAct: int = 0
):
        """
        Tạo nhắc hẹn (topic reminder) trong nhóm Zalo.

        Args:
            groupId (int | str): ID nhóm cần tạo nhắc hẹn.
            title (str): Tiêu đề nhắc hẹn.
            emoji (str): Emoji hiển thị. Mặc định: ⏰
            color (int): Mã màu nền. Mặc định: -16245706
            start_time (int): Thời gian bắt đầu (epoch mili giây). Mặc định: now + 5 phút.
            repeat (int): Lặp lại. 0 = không lặp.
            pinAct (int): Ghim bài viết. 0 = không ghim.

        Returns:
            dict | None: Thông tin phản hồi nếu thành công.

        Raises:
            ZaloAPIException: Nếu yêu cầu thất bại.
        """

        import time

        if start_time is None:
            start_time = int((time.time() + 300) * 1000)  # now + 5 phút

        params = {
            "zpw_ver": 664,
            "zpw_type": self.apiLogintype
        }

        payload_data = {
            "grid": int(groupId),
            "type": 0,
            "color": color,
            "emoji": emoji,
            "startTime": start_time,
            "duration": -1,
            "params": {
                "title": title
            },
            "repeat": repeat,
            "src": 1,
            "imei": self._imei,
            "pinAct": pinAct
        }

        payload = {
            "params": self._encode(payload_data)
        }

        response = self._post(
            "https://groupboard-wpa.chat.zalo.me/api/board/topic/createv2",
            params=params,
            data=payload
        )

        data = response.json()
        if data.get("error_code") == 0:
            return data.get("data")
        else:
            raise ZaloAPIException(
                f"Error #{data.get('error_code')} - {data.get('error_message') or data.get('data')}"
            )

    def newlink(self, grid):
            params_data = {
                "grid": grid
            }

            params = {
                "zpw_ver": 650,
                "zpw_type": self.apiLogintype,
                "params": self._encode(params_data)
            }

            response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/link/new", data=params)
            data = response.json()

            if data.get("error_code") == 0:
                new_link_info = self._decode(data.get("data"))
                if new_link_info and new_link_info.get("link"):
                    return {"success": True, "new_link": new_link_info.get("link")}
                else:
                    return {"success": False, "error_code": 1337, "error_message": "Không tìm thấy liên kết mới."}
            else:
                error_code = data.get("error_code")
                error_message = data.get("error_message", "Lỗi không xác định từ API.")
                return {"success": False, "error_code": error_code, "error_message": error_message}

    def dislink(self, grid):
            params_data = {
                "grid": grid
            }

            params = {
                "zpw_ver": 650,
                "zpw_type": self.apiLogintype,
                "params": self._encode(params_data)
            }

            response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/link/disable", data=params)
            data = response.json()

            if data.get("error_code") == 0:
                return {"success": True, "message": "Đã vô hiệu hóa liên kết nhóm thành công."}
            else:
                error_code = data.get("error_code")
                error_message = data.get("error_message", "Lỗi không xác định từ API.")
                return {"success": False, "error_code": error_code, "error_message": error_message}

    def listFriendRequests(self):
        """
        Lấy danh sách người gửi lời mời kết bạn tới bot nhưng chưa được chấp nhận.

        Returns:
            dict | None: Danh sách lời mời kết bạn (nếu thành công).

        Raises:
            ZaloAPIException: Nếu có lỗi xảy ra.
        """
        params = {
            "zpw_ver": 664,
            "zpw_type": self.apiLogintype
        }

        payload = {
            "params": self._encode({
                "imei": self._imei
            })
        }

        response = self._post(
            "https://tt-friend-wpa.chat.zalo.me/api/friend/recommendsv2/list",
            params=params,
            data=payload
        )

        data = response.json()
        if data.get("error_code") == 0:
            return data.get("data")
        else:
            raise ZaloAPIException(
                f"Error #{data.get('error_code')} - {data.get('error_message') or data.get('data')}"
            )

    
    def viewGroupPending(self, groupId):
        """See list of people pending approval in group by ID.
        
        Args:
            groupId (int | str): Group ID to view pending members
            
        Returns:
            object: `Group` pending responses
            dict: A dictionary containing error_code & responses if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/pending-mems/list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def handleGroupPending(self, members, groupId, isApprove=True):
        """Approve/Deny pending users to the group from the group's approval.
        
        Client must be the Owner of the group.
        
        Args:
            members (str | list): One or More member IDs to handle
            groupId (int | str): ID of the group to handle pending members
            isApprove (bool): Approve/Reject pending members (True | False)
            
        Returns:
            object: `Group` handle pending responses
            dict: A dictionary/object containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if isinstance(members, list):
            members = [str(member) for member in members]
        else:
            members = [str(members)]
        
        params = {
            "params": self._encode({
                "grid": str(groupId),
                "members": members,
                "isApprove": 1 if isApprove else 0
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/pending-mems/review", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
                
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def viewPollDetail(self, pollId):
        """View poll data by ID.
        
        Args:
            pollId (int | str): Poll ID to view detail
            
        Returns:
            object: `Group` poll data
            dict: A dictionary containing error_code & response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "poll_id": int(pollId),
                "imei":self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://tt-group-wpa.chat.zalo.me/api/poll/detail", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def createPoll(
        self,
        question,
        options,
        groupId,
        expiredTime=0,
        pinAct=False,
        multiChoices=True,
        allowAddNewOption=True,
        hideVotePreview=False,
        isAnonymous=False
    ):
        """Create poll in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            question (str): Question for poll
            options (str | list): List options for poll
            groupId (int | str): Group ID to create poll from
            expiredTime (int): Poll expiration time (0 = no expiration)
            pinAct (bool): Pin action (pin poll)
            multiChoices (bool): Allows multiple poll choices
            allowAddNewOption (bool): Allow members to add new options
            hideVotePreview (bool): Hide voting results when haven't voted
            isAnonymous (bool): Hide poll voters
            
        Returns:
            object: `Group` poll create data
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": {
                "group_id": str(groupId),
                "question": question,
                "options": [],
                "expired_time": expiredTime,
                "pinAct": pinAct,
                "allow_multi_choices": multiChoices,
                "allow_add_new_option": allowAddNewOption,
                "is_hide_vote_preview": hideVotePreview,
                "is_anonymous": isAnonymous,
                "poll_type": 0,
                "src": 1,
                "imei": self._imei
            }
        }
        
        if isinstance(options, list):
            payload["params"]["options"] = options
        else:
            payload["params"]["options"].append(str(options))
        
        payload["params"] = self._encode(payload["params"])
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/poll/create", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def lockPoll(self, pollId):
        """Lock/end poll in group by ID.
        
        Client must be the Owner of the group.
        
        Args:
            pollId (int | str): Poll ID to lock
            
        Returns:
            None: If requet success
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "poll_id": int(pollId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/poll/end", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def disperseGroup(self, groupId):
        """Disperse group by ID.
        
        Client must be the Owner of the group.
            
        Args:
            groupId (int | str): Group ID to disperse
            
        Returns:
            None: If requet success
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "grid": str(groupId),
                "imei": self._imei
            })
        }
        
        response = self._post("https://tt-group-wpa.chat.zalo.me/api/group/disperse", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def getGroupLink(self, chatID):
        if not chatID:
            raise ValueError("chatID is required")

        payload = {
            'params': {
            'grid': chatID,
            'imei': self._imei,
            }
        }
        payload['params'] = self._encode(payload['params'])

        try:
            response = self._get(
                f'https://tt-group-wpa.chat.zalo.me/api/group/link/detail?zpw_ver=645&zpw_type={self.apiLogintype}',
                params=payload
            )
            data = response.json()

            if data.get("error_code") == 0:
                data = data.get("data")
            else:
                data = None

            if isinstance(data, str):
                try:
                    data = self._decode(data)
                    if isinstance(data, str):
                        data = json.loads(data)
                except json.JSONDecodeError:
                    return {'error': 'Could not decode data'}

            if isinstance(data, dict):
                return data
            else:
                return {'error': 'Invalid response format'}

        except ZaloAPIException as e:
            return {'error': str(e)}
        except Exception as e:
            return {'error': f'An unexpected error occurred: {str(e)}'}