import json
import os

from ..util import utilzone
from ..app import appstate
from ..models import *
class AccAPi:
    def changeAccountSetting(self, name, dob, gender, biz={}, language="vi"):
        """Change account information.
        
        Args:
            name (str): The new account name
            dob (str): Date of birth wants to change (format: year-month-day)
            gender (int | str): Gender wants to change (0 = Male, 1 = Female)
            biz (unknown): idk this
            language (str): Zalo language wants to change (default = vn)
        
        Returns:
            object: `User` change account setting status
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        payload = {
            "params": self._encode({
                "profile": json.dumps({
                    "name": name,
                    "dob": dob,
                    "gender": int(gender)
                }),
                "biz": json.dumps(biz),
                "language": language
            })
        }
        
        response = self._post("https://tt-profile-wpa.chat.zalo.me/api/social/profile/update", params=params, data=payload)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def changeAccountAvatar(self, filePath, width=500, height=500, language="vn", size=None):
        """Upload/Change account avatar.
        
        Args:
            filePath (str): A path to the image to upload/change avatar
            size (int): Avatar image size (default = auto)
            width (int): Width of avatar image
            height (int): height of avatar image
            language (int | str): Zalo Website language ? (idk)
            
        Returns:
            object: `User` Account avatar change status
            None: If requet success/failed depending on the case
            dict: A dictionary containing error responses
        
        Raises:
            ZaloAPIException: If request failed
        """
        if not os.path.exists(filePath):
            raise ZaloUserError(f"{filePath} not found")
        
        size = os.stat(filePath).st_size if not size else size
        files = [("fileContent", open(filePath, "rb"))]
        
        params = {
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "avatarSize": 120,
                "clientId": str(self.uid) + utilzone.formatTime("%H:%M %d/%m/%Y"),
                "language": language,
                "metaData": json.dumps({
                    "origin": {
                        "width": width,
                        "height": height
                    },
                    "processed": {
                        "width": width,
                        "height": height,
                        "size": size
                    }
                })
            })
        }
        
        response = self._post("https://tt-files-wpa.chat.zalo.me/api/profile/upavatar", params=params, files=files)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("data") else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")