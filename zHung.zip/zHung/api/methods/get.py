import json

from ..util import utilzone
from ..app import appstate
from ..models import *
class GetAPi:    
    def checkGroup(self, link):
        params = {
        "params": self._encode({
        "link": link,
        "avatar_size": 120,
        "member_avatar_size": 120,
        "mpage": 1
        }),
        "zpw_ver": 650,
        "zpw_type": self.apiLogintype
        }

        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/link/ginfo", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            decoded_data = self._decode(data.get("data"))
            if decoded_data and decoded_data.get("data"):
                return decoded_data.get("data")
            else:
                return {"error_code": 1337, "error_message": "Không tìm thấy dữ liệu nhóm."}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
        return {"error_code": error_code, "error_message": error_message}
    
    def getQRLink(self, userId):
            """Lấy Link QR của người dùng.
            
            Args:
                userId (int | str): ID người dùng cần lấy QR code
                
            Returns:
                dict: Dictionary chứa QR code URL của người dùng
                dict: Dictionary chứa error_code và response nếu thất bại
                
            Raises:
                ZaloAPIException: Nếu request thất bại
            """
            params = {
                "zpw_ver": 641,
                "zpw_type": self.apiLogintype
            }
            
            payload = {
                "params": self._encode({
                    "fids": [str(userId)]
                })
            }
            
            response = self._post("https://tt-friend-wpa.chat.zalo.me/api/friend/mget-qr", params=params, data=payload)
            data = response.json()
            results = data.get("data") if data.get("error_code") == 0 else None
            if results:
                results = self._decode(results)
                results = results.get("data") if results.get("data") else results
                if results == None:
                    results = {"error_code": 1337, "error_message": "Data is None"}
                
                if isinstance(results, str):
                    try:
                        results = json.loads(results)
                    except:
                        results = {"error_code": 1337, "error_message": results}
                
                return results
                
            error_code = data.get("error_code")
            error_message = data.get("error_message") or data.get("data")
            raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")

    def get_blocked_members(self, grid, page=1, count=50):
        params_data = {
            "grid": grid,
            "page": page,
            "count": count
        }

        params = {
            "zpw_ver": 650,
            "zpw_type": self.apiLogintype,
            "params": self._encode(params_data)
        }

        response = self._get("https://tt-group-wpa.chat.zalo.me/api/group/blockedmems/list", params=params)
        data = response.json()

        if data.get("error_code") == 0:
            blocked_list = self._decode(data.get("data"))
            return {"success": True, "blocked_members": blocked_list}
        else:
            error_code = data.get("error_code")
            error_message = data.get("error_message", "Lỗi không xác định từ API.")
            return {"success": False, "error_code": error_code, "error_message": error_message}
    
    def getLastMsgs(self):
        """Get last message the client's friends/group chat room.
            
        Returns:
            object: `User` last msg data
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "zpw_ver": "645",
            "zpw_type": self.apiLogintype,
            "params": self._encode({
                "threadIdLocalMsgId": json.dumps({}),
                "imei": self._imei
            })
        }
        
        response = self._get("https://tt-convers-wpa.chat.zalo.me/api/preloadconvers/get-last-msgs", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = results.get("data") if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return User.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def getRecentGroup(self, groupId):
        """Get recent messages in group by ID.
            
        Args:
            groupId (int | str): Group ID to get recent msgs
            
        Returns:
            object: `Group` List msg data in groupMsgs
            dict: A dictionary containing error_code, response if failed
        
        Raises:
            ZaloAPIException: If request failed
        """
        params = {
            "params": self._encode({
                "groupId": str(groupId),
                "globalMsgId": 10000000000000000,
                "count": 50,
                "msgIds": [],
                "imei": self._imei,
                "src": 1
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype,
            "nretry": 0,
        }
        
        response = self._get("https://tt-group-cm.chat.zalo.me/api/cm/getrecentv2", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = json.loads(results.get("data")) if results.get("error_code") == 0 else results
            if results == None:
                results = {"error_code": 1337, "error_message": "Data is None"}
            
            if isinstance(results, str):
                try:
                    results = json.loads(results)
                except:
                    results = {"error_code": 1337, "error_message": results}
            
            return Group.fromDict(results, None)
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def _getGroupBoardList(self, board_type, page, count, last_id, last_type, groupId):
        params = {
            "params": self._encode({
                "group_id": str(groupId),
                "board_type": board_type,
                "page": page,
                "count": count,
                "last_id": last_id,
                "last_type": last_type,
                "imei": self._imei
            }),
            "zpw_ver": 645,
            "zpw_type": self.apiLogintype
        }
        
        response = self._get("https://groupboard-wpa.chat.zalo.me/api/board/list", params=params)
        data = response.json()
        results = data.get("data") if data.get("error_code") == 0 else None
        if results:
            results = self._decode(results)
            results = Group.fromDict(results.get("data"), None)
            
            return results
            
        error_code = data.get("error_code")
        error_message = data.get("error_message") or data.get("data")
        raise ZaloAPIException(f"Error #{error_code} when sending requests: {error_message}")
    
    def getGroupBoardList(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group board list (pinmsg, note, poll) by ID.
            
        Args:
            groupId (int | str): Group ID to get board list
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 poll, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` board data in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(0, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupPinMsg(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group pinned messages by ID.
            
        Args:
            groupId (int | str): Group ID to get pinned messages
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 message, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` pinned messages in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(2, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupNote(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group notes by ID.
            
        Args:
            groupId (int | str): Group ID to get notes
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 notes, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` notes in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(1, page, count, last_id, last_type, groupId)
        
        return response
    
    def getGroupPoll(self, groupId, page=1, count=20, last_id=0, last_type=0):
        """Get group polls by ID.
            
        Args:
            groupId (int | str): Group ID to get polls
            page (int): Number of pages to retrieve data from
            count (int): Amount of data to retrieve per page (5 poll, ..)
            last_id (int): Default (no description)
            last_type (int): Default (no description)
            
        Returns:
            object: `Group` polls in group
            dict: A dictionary containing error_code, response if failed
            
        Raises:
            ZaloAPIException: If request failed
        """
        response = self._getGroupBoardList(3, page, count, last_id, last_type, groupId)
        
        return response