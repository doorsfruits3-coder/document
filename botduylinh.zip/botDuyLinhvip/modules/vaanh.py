import os
import time
import threading
from zlapi.models import MultiMsgStyle, MessageStyle, Message
from config import ADMIN

is_war_running = False

des = {
    'version': "1.0.2",
    'credits': "Đặng Quang Huy",
    'description': "Gửi nội dung từ file 2.txt liên tục trong nhóm, kèm hình ảnh."
}

def stop_war(client, message_object, thread_id, thread_type):
    global is_war_running
    is_war_running = False
    client.replyMessage(Message(text="Đã dừng gửi nội dung."), message_object, thread_id, thread_type)

def handle_war_command(message, message_object, thread_id, thread_type, author_id, client):
    global is_war_running

    if author_id not in ADMIN:
        client.replyMessage(
            Message(text="Phải là V Tuấn mới sử dụng được lệnh này."),
            message_object, thread_id, thread_type
        )
        return

    command_parts = message.split()
    if len(command_parts) < 2:
        client.replyMessage(Message(text="Vui lòng chỉ định lệnh hợp lệ (vd: waranh on hoặc waranh stop)."), message_object, thread_id, thread_type)
        return

    action = command_parts[1].lower()

    if action == "stop":
        if not is_war_running:
            client.replyMessage(
                Message(text="⚠️ **Gửi nội dung đã dừng lại.**"),
                message_object, thread_id, thread_type
            )
        else:
            stop_war(client, message_object, thread_id, thread_type)
        return

    if action != "on":
        client.replyMessage(Message(text="Vui lòng chỉ định lệnh 'on' hoặc 'stop'."), message_object, thread_id, thread_type)
        return

    try:
        with open("kyserwar.txt", "r", encoding="utf-8") as file:
            Ngon = file.readlines()
    except FileNotFoundError:
        client.replyMessage(
            Message(text="Không tìm thấy file 2.txt."),
            message_object,
            thread_id,
            thread_type
        )
        return

    if not Ngon:
        client.replyMessage(
            Message(text="File 2.txt không có nội dung nào để gửi."),
            message_object,
            thread_id,
            thread_type
        )
        return

    is_war_running = True

    def war_loop():
        while is_war_running:
            for noidung in Ngon:
                if not is_war_running:
                    break

                # Gửi nội dung từ file
                client.send(Message(text=noidung), thread_id, thread_type)

                # Gửi hình ảnh kèm thông điệp
                try:
                    menu_message = "" + noidung.strip()
                    client.sendLocalImage(
                        "1.jpg",
                        thread_id=thread_id,
                        thread_type=thread_type,
                        message=Message(text=menu_message),
                        ttl=120000
                    )
                except FileNotFoundError:
                    client.replyMessage(
                        Message(text="Không tìm thấy hình ảnh '3.jpg'."),
                        thread_id,
                        thread_type
                    )
                except Exception as e:
                    client.replyMessage(
                        Message(text=f"Đã xảy ra lỗi khi gửi hình ảnh: {e}"),
                        thread_id,
                        thread_type
                    )

                # Thời gian nghỉ giữa các tin nhắn
                time.sleep(5)

    war_thread = threading.Thread(target=war_loop)
    war_thread.start()

def get_mitaizl():
    return {
        'waranh': handle_war_command
    }