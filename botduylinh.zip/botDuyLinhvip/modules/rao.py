import time
from zlapi.models import Message, ThreadType
from datetime import datetime, timedelta
import pytz
import threading

# Tin nhắn bot sẽ gửi mỗi 30 phút
message_to_send = "𝗕𝗼𝘁 𝗔𝘂𝘁𝗼 𝗥ã𝗶 (𝗣𝗵𝗶ề𝗻 = 𝘅𝗼á 𝗸𝗶𝗰𝗸 𝘁ộ𝗶 tôi🥺)🚀𝖢𝗁à𝗈 𝖠𝗇𝗁 𝖤𝗆 𝖬ì𝗇𝗁 Là Dlinh Xin Chéo Link https://zalo.me/g/jubwii027"

# Timezone cho Việt Nam
vn_tz = pytz.timezone('Asia/Ho_Chi_Minh')

# Define danh sách admin
ADMIN = ['759455593775005869']  # Thay thế bằng ID của admin thực tế

def start_auto(client):
    all_group = client.fetchAllGroups()
    allowed_thread_ids = [gid for gid in all_group.gridVerMap.keys() if gid != '9034032228046851908']

    last_sent_time = None

    while True:
        now = datetime.now(vn_tz)
        
        # Gửi tin nhắn cứ mỗi 30 phút
        if last_sent_time is None or now - last_sent_time >= timedelta(minutes=30):
            for thread_id in allowed_thread_ids:
                gui = Message(text=message_to_send)
                try:
                    # Gửi tin nhắn vào nhóm
                    client.sendMessage(message=gui, thread_id=thread_id, thread_type=ThreadType.GROUP)
                    time.sleep(0.3)  # Thời gian chờ giữa các lần gửi tin nhắn
                except Exception as e:
                    print(f"Error sending message to {thread_id}: {e}")
            last_sent_time = now
        
        # Đợi 10 giây trước khi kiểm tra lại
        time.sleep(10)  # Chỉnh sửa từ 60s thành 10s

def handle_autosend_start(message, message_object, thread_id, thread_type, author_id, client):
    # Kiểm tra nếu người gửi là admin
    if author_id not in ADMIN:
        response_message = Message(text="🚫 **Bạn không có quyền để thực hiện điều này!**")
        client.replyMessage(response_message, message_object, thread_id, thread_type)
        return

    # Bắt đầu gửi tin nhắn tự động trong luồng riêng
    threading.Thread(target=start_auto, args=(client,), daemon=True).start()
    response_message = Message(text="Rao Đã Bắt Đầu Chạy Thưa Ngài Dlinh🚀")
    client.replyMessage(response_message, message_object, thread_id, thread_type)

def get_mitaizl():
    return {
        'rao_on': handle_autosend_start
    }
    