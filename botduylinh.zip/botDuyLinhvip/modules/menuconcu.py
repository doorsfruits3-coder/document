import os
import importlib
import random
from zlapi.models import Message

# Thông tin bot
description = {
    'version': "2.0.0",
    'admin': "𝐕𝐓𝐮𝐚𝐧",
    'description': "Hệ thống lệnh tối thượng dành riêng cho Kyser."
}

# Danh sách biểu tượng đặc biệt
icons = ['⚡', '🔥', '💎', '🚀', '🧨', '✨', '🎯', '🔱', '🌟', '💡', '🎮', '🛠️', '🔮', '🕹️', '🌌']

def get_all_commands():
    commands = {}
    # Lấy tất cả module từ thư mục 'modules'
    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'get_mitaizl'):
                module_commands = module.get_mitaizl()
                commands.update(module_commands)

    return list(commands.keys())

def handle_menu_command(message, message_object, thread_id, thread_type, author_id, client):
    command_names = get_all_commands()
    total_commands = len(command_names)

    # Tạo danh sách lệnh với biểu tượng
    command_list = [
        f"➤ {random.choice(icons)} **{name.upper()}**"
        for name in command_names
    ]

    # Nội dung menu với thiết kế độc đáo
    menu_message = (
        f"╔══════════════════════════════╗\n"
        f"   🌌 **𝐕𝐓𝐮𝐚𝐧 𝐂𝐎𝐌𝐌𝐀𝐃 𝐂𝐄𝐍𝐓𝐄𝐑** 🌌\n"
        f"╚══════════════════════════════╝\n\n"
        f"🛡️ **𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡:**\n"
        f"   👑 **𝗔𝗗𝗠𝗜𝗡:** {description['admin']}\n"
        f"   ⚙️ **𝗩𝗘𝗥𝗦𝗜𝗢𝗡:** {description['version']}\n"
        f"   📜 **𝗧𝗢𝗧𝗔𝗟 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦:** {total_commands}\n\n"
        f"━━━━━━━━━━━ 🌟 ━━━━━━━━━━━\n"
        f"🚀 **𝗔𝗩𝗔𝗜𝗟𝗔𝗕𝗟𝗘 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦:**\n"
        f"{'━' * 35}\n"
        + "\n".join(command_list) +
        f"\n{'━' * 35}\n"
        f"🎮 **𝗛𝗢𝗪 𝗧𝗢 𝗨𝗦𝗘:**\n"
        f"   ➤ Gõ tên lệnh để sử dụng ngay.\n\n"
        f"🔱 **𝗖𝗥𝗘𝗔𝗧𝗘𝗗 𝗕𝗬 𝐕𝐓𝐮𝐚𝐧** 🔱"
    )

    # Gửi menu
    message_to_send = Message(text=menu_message)
    client.replyMessage(message_to_send, message_object, thread_id, thread_type)

def get_mitaizl():
    return {
        'menu3': handle_menu_command
    }