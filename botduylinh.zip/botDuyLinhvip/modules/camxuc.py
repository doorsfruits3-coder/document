import random
from zlapi.models import Message

# Danh sách cảm xúc (reaction)
reaction_all = [
    "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣", "😊", "😇", "🙂", "🙃", "😉", "😌", "😍", "🥰", "😘", "😗", "😙", "😚", "😋", "😛", "😜", "😝", "🤑", "🤗", "🤭", "🤫", "🤔", "🤐", "🤨", "😐", "😑", "😶", "😏", "😒", "🙄", "😬", "🤥", "😌", "😔", "😪", "🤤", "😴", "😷", "🤒", "🤕", "🤢", "🤮", "🤧", "😵", "🤯", "🤠", "🥳", "😎", "🤓", "🧐", "😕", "😟", "🙁", "😮", "😯", "😲", "😳", "🥺", "😦", "😧", "😨", "😰", "😥", "😢", "😭", "😱", "😖", "😣", "😞", "😓", "😩", "😫", "🥱", "😤", "😡", "😠", "🤬", "😈", "👿", "💀", "☠️", "💩", "🤡", "👹", "👺", "👻", "👽", "👾", "🤖",
    # Thêm cảm xúc khác vào đây
]

# Biến lưu trạng thái của bot
reaction_enabled = False

def handle_reaction_command(message, message_object, thread_id, thread_type, author_id, client):
    """
    Hàm này sẽ tự động thả cảm xúc vào tin nhắn nếu chế độ được bật.
    """
    global reaction_enabled

    # Kiểm tra nếu lệnh là camxucon hoặc camxucoff mà không có tiền tố
    if message['text'].strip().lower() == "camxucon":
        reaction_enabled = True
        client.sendMessage(thread_id, "Chế độ thả icon đã được bật.")
        return
    elif message['text'].strip().lower() == "camxucoff":
        reaction_enabled = False
        client.sendMessage(thread_id, "Chế độ thả icon đã được tắt.")
        return

    # Nếu chế độ thả cảm xúc bật, tự động thả cảm xúc vào tin nhắn
    if reaction_enabled:
        try:
            for _ in range(random.randint(1, 3)):  # Số lần thả cảm xúc (tối đa 3)
                action = random.choice(reaction_all)  # Chọn cảm xúc ngẫu nhiên
                client.sendReaction(message_object, action, thread_id, thread_type, reactionType=75)  # Gửi cảm xúc
        except Exception as e:
            print(f"Không thể gửi cảm xúc: {str(e)}")

def get_mitaizl():
    """
    Hàm trả về các lệnh bot xử lý.
    """
    return {
        'camxucon': handle_reaction_command,  # Xử lý lệnh camxucon và camxucoff
        'camxucoff': handle_reaction_command
    }