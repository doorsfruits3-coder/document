import os
from zlapi.models import Message

# Lệnh autocall
def autocall_zalo(phone_number):
    """
    Gọi đến số điện thoại qua ứng dụng Zalo.
    
    :param phone_number: Số điện thoại cần gọi.
    :return: Thông báo trạng thái.
    """
    zalo_url = f"intent://zalo/{phone_number}#Intent;scheme=zalo;package=com.zing.zalo;end;"
    try:
        os.system(f"am start {zalo_url}")
        return f"Đang gọi đến {phone_number} qua Zalo..."
    except Exception as e:
        return f"Không thể gọi qua Zalo: {str(e)}"


def handle_autocall_command(message, message_object, thread_id, thread_type, author_id, client):
    """
    Hàm xử lý lệnh autocall khi nhận được tin nhắn yêu cầu gọi Zalo.
    
    :param message: Tin nhắn nhận được.
    :param message_object: Đối tượng tin nhắn.
    :param thread_id: ID của cuộc trò chuyện.
    :param thread_type: Loại của cuộc trò chuyện (nhóm, cá nhân,...).
    :param author_id: ID của người gửi tin nhắn.
    :param client: Đối tượng client để gửi tin nhắn lại.
    """
    try:
        # Kiểm tra kiểu của message và xem liệu nó có thuộc tính 'text'
        if isinstance(message, Message) and hasattr(message, 'text'):
            # Lấy số điện thoại từ tin nhắn
            phone_number = message.text.split(' ')[1]  
            response = autocall_zalo(phone_number)
            message_to_send = Message(text=response)
            client.replyMessage(message_to_send, message_object, thread_id, thread_type)
        else:
            raise ValueError("Lỗi: message không phải là đối tượng 'Message' hoặc không có thuộc tính 'text'")
    except Exception as e:
        message_to_send = Message(text=f"Không thể xử lý lệnh: {str(e)}")
        client.replyMessage(message_to_send, message_object, thread_id, thread_type)


def get_mitaizl():
    """
    Hàm mitaizl sẽ trả về các lệnh tương ứng để bot có thể xử lý.
    """
    return {
        'autocall': handle_autocall_command  # Thêm lệnh autocall vào
    }