import os
from zlapi.models import Message
import importlib
import time
from datetime import datetime

des = {
    'version': "1.0.2",
    'credits': "Nguyễn Đức Tài",
    'description': "Xem toàn bộ lệnh hiện có của bot"  # Xuân Bách mod
}

def get_all_mitaizl():
    mitaizl = {}

    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'get_mitaizl'):
                get_mitaizl = module.get_mitaizl()
                mitaizl.update(get_mitaizl)

    command_names = list(mitaizl.keys())
    
    return command_names

def handle_menu_command(message, message_object, thread_id, thread_type, author_id, client):
    # Lấy tất cả các lệnh
    command_names = get_all_mitaizl()

    # Tính tổng số lệnh và tạo danh sách các lệnh
    total_mitaizl = len(command_names)
    numbered_mitaizl = [f"{i+1}. {name}" for i, name in enumerate(command_names)]

    # Tạo nội dung menu
    menu_message = f"MENU ADMIN: DUY LINH\n-----------------\n𝐌𝐞𝐧𝐮 🇻🇳 𝐇𝐢ệ𝐧 𝐭ạ𝐢 𝐜ó: {total_mitaizl} 𝐂𝐡ứ𝐜 𝐧ă𝐧𝐠🌸 \n 𝐔𝐩𝐝𝐚𝐭𝐞 : 𝐯𝟏.𝟎.𝟑📨 /-li \n" + "\n".join(numbered_mitaizl)

    # Gửi ảnh và nội dung menu
    client.sendLocalImage("2.jpg", thread_id=thread_id, thread_type=thread_type, message=Message(text=menu_message), ttl=120000)

def get_mitaizl():
    return {
        'menu': handle_menu_command
    }