import os
from zlapi.models import Message
import importlib

des = {
    'version': "1.0.2",
    'credits': "Đặng Quang Huy",
    'description': "Chào"  # Quang Huy _Dzi mod
}

def get_all_mitaizl():
    mitaizl = {}

    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'get_mitaizl'):
                get_mitaizl = module.get_mitaizl()
                mitaizl.update(get_mitaizl)

    command_names = list(mitaizl.keys())
    
    return command_names

def handle_menu_command(message, message_object, thread_id, thread_type, author_id, client):

    command_names = get_all_mitaizl()

    total_mitaizl = len(command_names)
    numbered_mitaizl = [f"{i+1}. {name}" for i, name in enumerate(command_names)]
    menu_message = f"Xin chào Bạn 😼 Chúc Bạn Một Buổi Sáng Thật Vui Vẻ Nhé 🐽"
    
    client.sendLocalImage("c.jpg", thread_id=thread_id, thread_type=thread_type, message=Message(text=menu_message),width=100,height=100,ttl=0)
def get_mitaizl():
    return {
        'chào': handle_menu_command
    }