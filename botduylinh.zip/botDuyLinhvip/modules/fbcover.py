import os
import requests
from zlapi.models import Message, Mention

des = {
    'version': "1.0.2",
    'credits': "Trung Trí",
    'description': "Tạo ảnh bìa Facebook giả"
}

CACHE_DIR = 'modules/cache'
os.makedirs(CACHE_DIR, exist_ok=True)

def get_fake_fb_cover(name, birthday, love, location, hometown, follow, gender, uid):
    url = f"https://subhatde.id.vn/fbcover/v3?name={name}&birthday={birthday}&love={love}&location={location}&hometown={hometown}&follow={follow}&gender={gender}&uid={uid}"
    
    try:
        response = requests.get(url)
        
        if response.status_code == 200:
            image_path = os.path.join(CACHE_DIR, "fake_fb_cover.png")
            with open(image_path, 'wb') as file:
                file.write(response.content)
            return image_path
        else:
            return None
    except Exception as e:
        print(f"Lỗi khi gọi API: {e}")
        return None

def handle_fake_fb_cover_command(message, message_object, thread_id, thread_type, author_id, client):
    content = message.strip().split('|')

    if len(content) < 8:
        error_message = Message(text="Lỗi! Vui lòng nhập thông tin đầy đủ theo định dạng:\nname|birthday|love|location|hometown|follow|gender|uid")
        client.replyMessage(error_message, message_object, thread_id, thread_type, ttl=60000)
        return

    name = content[0].strip()
    birthday = content[1].strip()
    love = content[2].strip()
    location = content[3].strip()
    hometown = content[4].strip()
    follow = content[5].strip()
    gender = content[6].strip()
    uid = content[7].strip()

    loading_message = Message(text="Đang tạo ảnh bìa Facebook giả...Vui lòng chờ 1-3s tùy theo ảnh.")
    client.replyMessage(loading_message, message_object, thread_id, thread_type, ttl=60000)

    image_path = get_fake_fb_cover(name, birthday, love, location, hometown, follow, gender, uid)

    if image_path:
        success_message = Message(
            text=f"@Member, ảnh bìa Facebook giả của bạn đã được tạo với các thông tin:\nTên: {name}\nNgày sinh: {birthday}\nNgười yêu: {love}\nĐịa chỉ: {location}\nQuê quán: {hometown}\nSố người theo dõi: {follow}\nGiới tính: {gender}\nUID: {uid}",
            mention=Mention(author_id, length=len(f"@Member"), offset=0)
        )
        client.sendLocalImage(
            imagePath=image_path,
            message=success_message,
            thread_id=thread_id,
            thread_type=thread_type,
            width=2553,
            height=945,
            ttl=86400000
        )

        os.remove(image_path)
    else:
        error_message = Message(text="❌ Đã xảy ra lỗi khi tạo ảnh bìa. Vui lòng thử lại.")
        client.replyMessage(error_message, message_object, thread_id, thread_type)

def get_mitaizl():
    return {
        'fbcover': handle_fake_fb_cover_command,
    }