import random
import threading
import time
import json
import re
from zlapi import *
from zlapi.models import *
from config import ADMIN  # Thêm import ADMIN từ config.py

author = (
    "👨‍💻 Tác giả: A Sìn\n"
    "🔄 Cập nhật: 09-10-24\n"
    "🚀 Tính năng: Tính năng đi var\n"
    "📌 Lưu ý:\n"
    "   1️⃣ [Bước 1] Thay imei và cookie\n"
    "   2️⃣ [Bước 2] Có 1 lệnh kickall"
)

def kick_all_member_group(message, message_object, thread_id, thread_type, author_id, bot):
    # Kiểm tra xem người dùng có phải là admin không
    if author_id not in ADMIN:
        return  # Không thông báo khi người dùng không có quyền

    # Lấy thông tin nhóm
    group = bot.fetchGroupInfo(thread_id).gridInfoMap[thread_id]
    
    # Lấy danh sách admin (bao gồm cả creatorId)
    admin_ids = group.adminIds.copy()
    if group.creatorId not in admin_ids:
        admin_ids.append(group.creatorId)
    
    # Lấy danh sách thành viên nhóm
    list_mem_group = set([member.split('_')[0] for member in group["memVerList"]])

    # Loại trừ các admin và creator khỏi danh sách bị kick
    list_mem_group_to_kick = list_mem_group - set(admin_ids)

    # Thực hiện kick các thành viên không phải admin
    for uid in list_mem_group_to_kick:
        bot.blockUsersInGroup(uid, thread_id)
        bot.kickUsersInGroup(uid, thread_id)

def get_mitaizl():
    return {
        'kickallmem': kick_all_member_group
    }