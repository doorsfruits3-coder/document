import discord
from discord.ext import commands
import asyncio
import os
import random

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

active_tasks = {}        
admin_list = []         
music_queues = {}       
loop_modes = {}         
xich_list = {}          
dame_list = {}          
var_status = True       

@bot.event
async def on_ready():
    print("========================================")
    print("Bot khởi động thành công | By Wwe Nguyen")
    print(f"Đăng nhập dưới tên: {bot.user}")
    print("========================================")

def is_bot_admin():
    async def predicate(ctx):
        return ctx.author.id in admin_list or ctx.author.guild_permissions.administrator
    return commands.check(predicate)

@bot.command(name="menu")
async def menu(ctx):
    if os.path.exists("menu.txt"):
        with open("menu.txt", "r", encoding="utf-8") as f:
            content = f.read()
        await ctx.send(f"```md\n{content}\n```")
    else:
        await ctx.send("❌ Thiếu file `menu.txt`. Vui lòng tạo file này để xem menu!")

@bot.command(name="av")
async def avatar(ctx, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(title=f"📸 Avatar của {member.name}", color=discord.Color.blue())
    embed.set_image(url=member.display_avatar.url)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="banner")
async def banner(ctx, member: discord.Member = None):
    member = member or ctx.author
    user = await bot.fetch_user(member.id)
    if user.banner:
        embed = discord.Embed(title=f"🖼️ Banner của {user.name}", color=discord.Color.blue())
        embed.set_image(url=user.banner.url)
        embed.set_footer(text="Bot By Wwe Nguyen")
        await ctx.send(embed=embed)
    else:
        await ctx.send("❌ Người dùng này không cài Banner. | By Wwe Nguyen")

@bot.command(name="profile")
async def profile(ctx, member: discord.Member = None):
    member = member or ctx.author
    embed = discord.Embed(title=f"👤 Thông tin của {member.name}", color=discord.Color.green())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="ID Người dùng", value=member.id, inline=True)
    embed.add_field(name="Biệt danh", value=member.display_name, inline=True)
    embed.add_field(name="Ngày tạo tài khoản", value=member.created_at.strftime("%d/%m/%Y"), inline=False)
    embed.add_field(name="Ngày tham gia Server", value=member.joined_at.strftime("%d/%m/%Y"), inline=False)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="sever")
async def sever(ctx):
    guild = ctx.guild
    embed = discord.Embed(title=f"🏰 Thông tin Server: {guild.name}", color=discord.Color.gold())
    embed.add_field(name="ID Server", value=guild.id, inline=True)
    embed.add_field(name="Chủ Server", value=guild.owner, inline=True)
    embed.add_field(name="Tổng thành viên", value=guild.member_count, inline=True)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="members")
async def members(ctx):
    online_count = sum(1 for m in ctx.guild.members if m.status != discord.Status.offline)
    await ctx.send(f"🟢 Hiện tại đang có **{online_count}** thành viên trực tuyến trong server. | By Wwe Nguyen")

@bot.command(name="roleinfo")
async def roleinfo(ctx, role: discord.Role):
    embed = discord.Embed(title=f"🛡️ Thông tin Role: {role.name}", color=role.color)
    embed.add_field(name="ID Role", value=role.id, inline=True)
    embed.add_field(name="Vị trí hiển thị", value=role.position, inline=True)
    embed.add_field(name="Số thành viên sở hữu", value=len(role.members), inline=True)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="channelinfo")
async def channelinfo(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    embed = discord.Embed(title=f"📺 Thông tin Kênh: #{channel.name}", color=discord.Color.purple())
    embed.add_field(name="ID Kênh", value=channel.id, inline=True)
    embed.add_field(name="Loại kênh", value=str(channel.type), inline=True)
    embed.add_field(name="Ngày tạo", value=channel.created_at.strftime("%d/%m/%Y"), inline=False)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="botinfo")
async def botinfo(ctx):
    embed = discord.Embed(title="🤖 Thông tin hệ thống Bot", color=discord.Color.dark_red())
    embed.add_field(name="Tên Bot", value=bot.user.name, inline=True)
    embed.add_field(name="Nhà phát triển hệ thống", value="Wwe Nguyen", inline=True)
    embed.add_field(name="Thư viện sử dụng", value=f"discord.py v{discord.__version__}", inline=False)
    embed.set_footer(text="Bot By Wwe Nguyen")
    await ctx.send(embed=embed)

@bot.command(name="ping")
async def ping(ctx):
    await ctx.send(f"🏓 Pong! Độ trễ hiện tại: `{round(bot.latency * 1000)}ms` | Bot By Wwe Nguyen")

def play_next(ctx):
    guild_id = ctx.guild.id
    vc = ctx.voice_client
    if vc and music_queues.get(guild_id):
        if loop_modes.get(guild_id, False):
            next_song = music_queues[guild_id][0]
        else:
            next_song = music_queues[guild_id].pop(0)
            
        if os.path.exists(next_song):
            vc.play(discord.FFmpegPCMAudio(next_song), after=lambda e: play_next(ctx))
            bot.loop.create_task(ctx.send(f"🎶 Đang phát: `{os.path.basename(next_song)}` | By Wwe Nguyen"))

@bot.command(name="join")
async def join(ctx):
    if ctx.author.voice:
        channel = ctx.author.voice.channel
        if ctx.voice_client:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()
        await ctx.send(f"🔊 Đã vào kênh thoại: **{channel.name}** | By Wwe Nguyen")
    else:
        await ctx.send("❌ Bạn cần phải vào một kênh voice trước.")

@bot.command(name="leave")
async def leave(ctx):
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
        await ctx.send("🔇 Đã rời kênh voice và xóa hàng đợi nhạc. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Hiện tại bot không ở trong kênh thoại nào.")

@bot.command(name="play")
async def play(ctx, song_num: str):
    if not ctx.voice_client:
        await ctx.invoke(join)
    
    guild_id = ctx.guild.id
    if guild_id not in music_queues:
        music_queues[guild_id] = []

    file_path = f"music/{song_num}.mp3"
    if os.path.exists(file_path):
        music_queues[guild_id].append(file_path)
        await ctx.send(f"📥 Đã thêm `{song_num}.mp3` vào hàng đợi. | By Wwe Nguyen")
        if not ctx.voice_client.is_playing() and not ctx.voice_client.is_paused():
            play_next(ctx)
    else:
        await ctx.send(f"❌ Không tìm thấy file nhạc `{song_num}.mp3` trong thư mục music.")

@bot.command(name="playall")
async def playall(ctx):
    if not ctx.voice_client:
        await ctx.invoke(join)
    
    guild_id = ctx.guild.id
    if guild_id not in music_queues:
        music_queues[guild_id] = []

    if os.path.exists("music"):
        files = [f"music/{f}" for f in os.listdir("music") if f.endswith(".mp3")]
        if files:
            music_queues[guild_id].extend(files)
            await ctx.send(f"🎵 Đã đẩy toàn bộ `{len(files)}` bài hát MP3 vào hàng đợi. | By Wwe Nguyen")
            if not ctx.voice_client.is_playing() and not ctx.voice_client.is_paused():
                play_next(ctx)
        else:
            await ctx.send("❌ Không có file .mp3 nào trong thư mục music.")
    else:
        await ctx.send("❌ Thư mục `music` chưa được tạo.")

@bot.command(name="list")
async def list_mp3(ctx):
    if os.path.exists("music"):
        files = [f for f in os.listdir("music") if f.endswith(".mp3")]
        if files:
            await ctx.send(f"📁 **Danh sách các file MP3 sẵn có:**\n" + "\n".join([f"- {name}" for name in files]) + "\n| By Wwe Nguyen")
        else:
            await ctx.send("❌ Thư mục music đang trống.")
    else:
        await ctx.send("❌ Chưa có thư mục music.")

@bot.command(name="que")
async def queue_info(ctx):
    guild_id = ctx.guild.id
    queue = music_queues.get(guild_id, [])
    if not queue:
        return await ctx.send("📭 Hàng đợi nhạc đang trống. | By Wwe Nguyen")
    
    song_list = "\n".join([f"{idx+1}. {os.path.basename(song)}" for idx, song in enumerate(queue)])
    await ctx.send(f"📋 **Hàng đợi hiện tại:**\n{song_list}\n| By Wwe Nguyen")

@bot.command(name="skip")
async def skip(ctx):
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.stop()
        await ctx.send("⏭️ Đã bỏ qua bài hát hiện tại. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Hiện tại bot không phát bài nhạc nào để bỏ qua.")

@bot.command(name="loop")
async def loop(ctx):
    guild_id = ctx.guild.id
    loop_modes[guild_id] = not loop_modes.get(guild_id, False)
    status = "BẬT" if loop_modes[guild_id] else "TẮT"
    await ctx.send(f"🔄 Đã {status} chế độ lặp bài hát hiện tại. | By Wwe Nguyen")

@bot.command(name="clearqueue")
async def clearqueue(ctx):
    guild_id = ctx.guild.id
    music_queues[guild_id] = []
    await ctx.send("🗑️ Đã xóa sạch danh sách hàng đợi nhạc. | By Wwe Nguyen")

@bot.command(name="pause")
async def pause(ctx):
    if ctx.voice_client and ctx.voice_client.is_playing():
        ctx.voice_client.pause()
        await ctx.send("⏸️ Đã tạm dừng nhạc. | By Wwe Nguyen")

@bot.command(name="resume")
async def resume(ctx):
    if ctx.voice_client and ctx.voice_client.is_paused():
        ctx.voice_client.resume()
        await ctx.send("▶️ Tiếp tục phát nhạc. | By Wwe Nguyen")

@bot.command(name="stop")
async def stop(ctx):
    if ctx.voice_client:
        guild_id = ctx.guild.id
        music_queues[guild_id] = []
        ctx.voice_client.stop()
        await ctx.send("🛑 Đã dừng phát nhạc hoàn toàn và dọn sạch hàng đợi. | By Wwe Nguyen")

@bot.command(name="var")
async def var_cmd(ctx, mode: str, member: discord.Member = None):
    global var_status
    if mode.lower() == "on":
        var_status = True
        return await ctx.send("✅ Lệnh chửi (`!var`) đã được BẬT trên toàn hệ thống bot.")
    if mode.lower() == "off":
        var_status = False
        return await ctx.send("❌ Lệnh chửi (`!var`) đã được TẮT trên toàn hệ thống bot.")
    
    if mode.lower() == "stop":
        if member:
            task_key = f"var_{member.id}"
            if task_key in active_tasks:
                active_tasks[task_key].cancel()
                del active_tasks[task_key]
                await ctx.send(f"🏳️ Đã tha, dừng chửi người dùng {member.mention}.")
            else:
                await ctx.send("❌ Thành viên này hiện tại không bị bot chửi.")
        return

    if not var_status:
        return await ctx.send("❌ Hiện tại lệnh var đang bị tắt hoàn toàn hệ thống.")
        
    try:
        target_member = await commands.MemberConverter().convert(ctx, mode)
    except:
        return await ctx.send("❌ Vui lòng gắn thẻ đúng định dạng người cần chửi.")

    lines = ["Nhóc con ra đây solo!", "Thách cự lại bot luôn đấy?", "Tuổi gì mà đòi đối đầu?", "Gà công nghiệp!"]
    
    async def var_loop():
        try:
            while True:
                await ctx.send(f"{target_member.mention} {random.choice(lines)}")
                await asyncio.sleep(1.2)
        except asyncio.CancelledError:
            pass

    task_key = f"var_{target_member.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()

    active_tasks[task_key] = asyncio.create_task(var_loop())

@bot.command(name="treongon")
async def treongon(ctx, mode: str = None):
    if mode and mode.lower() == "stop":
        if "treongon" in active_tasks:
            active_tasks["treongon"].cancel()
            del active_tasks["treongon"]
            await ctx.send("🛑 Đã tắt chế độ khen ngợi liên tục.")
        return

    khen_lines = ["Bạn thật tuyệt vời!", "Đỉnh cao quá bạn ơi!", "Đẹp trai/xinh gái số 1 luôn!", "Ngưỡng mộ bạn ghê!"]
    async def khen_loop():
        try:
            while True:
                await ctx.send(random.choice(khen_lines))
                await asyncio.sleep(2)
        except asyncio.CancelledError:
            pass

    active_tasks["treongon"] = asyncio.create_task(khen_loop())
    await ctx.send("🌟 Bắt đầu lan tỏa năng lượng tích cực (Treo khen) | By Wwe Nguyen")

@bot.command(name="spam")
async def spam(ctx, target: str, delay: float, *, content: str):
    async def spam_loop(dest):
        try:
            while True:
                await dest.send(content)
                await asyncio.sleep(delay)
        except asyncio.CancelledError:
            pass

    if target.startswith("<#"):
        cid = int(target.strip("<#>"))
        destination = bot.get_channel(cid)
    elif target.startswith("<@"):
        uid = int(target.strip("<@!>"))
        destination = bot.get_user(uid) or await bot.fetch_user(uid)
    else:
        try:
            destination = bot.get_channel(int(target)) or bot.get_user(int(target))
        except:
            return await ctx.send("❌ ID hoặc Đối tượng không hợp lệ.")

    if destination:
        task_id = f"spam_{destination.id}"
        if task_id in active_tasks:
            active_tasks[task_id].cancel()
        active_tasks[task_id] = asyncio.create_task(spam_loop(destination))
        await ctx.send(f"🚀 Bắt đầu spam vào đối tượng đã chọn với delay {delay}s! | By Wwe Nguyen")

@bot.command(name="stopspam")
async def stopspam(ctx):
    stopped = 0
    for key in list(active_tasks.keys()):
        if key.startswith("spam_"):
            active_tasks[key].cancel()
            del active_tasks[key]
            stopped += 1
    await ctx.send(f"🛑 Đã quét và tắt {stopped} tiến trình spam đang chạy. | By Wwe Nguyen")

@bot.command(name="nhaytag")
async def nhaytag(ctx, channel_mention: discord.TextChannel, member: discord.Member, delay: int):
    async def nhay_loop():
        try:
            while True:
                await channel_mention.send(f"⚠️ Dậy đi nhóc! {member.mention}")
                await asyncio.sleep(delay)
        except asyncio.CancelledError:
            pass

    task_key = f"nhay_{member.id}"
    active_tasks[task_key] = asyncio.create_task(nhay_loop())
    await ctx.send(f"🔔 Đã kích hoạt nhảy tag liên tục nhắm vào {member.name}.")

@bot.command(name="stopnhay")
async def stopnhay(ctx):
    stopped = 0
    for key in list(active_tasks.keys()):
        if key.startswith("nhay_"):
            active_tasks[key].cancel()
            del active_tasks[key]
            stopped += 1
    await ctx.send(f"🛑 Đã dừng toàn bộ hành động nhảy tag ({stopped} luồng). | By Wwe Nguyen")

@bot.command(name="treo")
async def treo_voice(ctx):
    if ctx.author.voice:
        channel = ctx.author.voice.channel
        if not ctx.voice_client:
            await channel.connect()
        active_tasks["treovoice"] = True
        await ctx.send(f"🤖 Đã bật chế độ treo giữ phòng voice 24/7 tại **{channel.name}**. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Bạn phải ở trong phòng voice để sử dụng lệnh treo.")

@bot.command(name="stoptreo")
async def stoptreo(ctx):
    if "treovoice" in active_tasks:
        del active_tasks["treovoice"]
    if ctx.voice_client:
        await ctx.voice_client.disconnect()
    await ctx.send("🛑 Đã tắt chế độ treo giữ phòng voice. | By Wwe Nguyen")

@bot.command(name="iu")
async def iu(ctx, member: discord.Member):
    await ctx.send(f"😘 | {ctx.author.mention} đã ôm chầm lấy và hôn {member.mention} thật thắm thiết!")
    
    love_lines = ["Anh yêu em vô bờ bến!", "Thế giới này chỉ cần có em.", "Bên nhau mãi mãi em nhé! 🥰"]
    if os.path.exists("love.txt"):
        with open("love.txt", "r", encoding="utf-8") as f:
            love_lines = [line.strip() for line in f.readlines() if line.strip()]

    async def love_loop():
        try:
            while True:
                await ctx.send(f"{member.mention} {random.choice(love_lines)}")
                await asyncio.sleep(2.5)
        except asyncio.CancelledError:
            pass

    task_key = f"iu_{member.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()

    active_tasks[task_key] = asyncio.create_task(love_loop())

@bot.command(name="stopiu")
async def stopiu(ctx, member: discord.Member):
    task_key = f"iu_{member.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()
        del active_tasks[task_key]
        await ctx.send(f"🛑 Đã dừng phát tán tình cảm với {member.mention}. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Không có tiến trình iu nào đang chạy với user này.")

@bot.command(name="dms")
async def dms(ctx, member: discord.Member):
    lines = ["Alo nhóc?", "Nhìn gì mà nhìn?", "Sợ rồi à?", "Hiện hồn lên đi."]
    if os.path.exists("nhay.txt"):
        with open("nhay.txt", "r", encoding="utf-8") as f:
            lines = [l.strip() for l in f.readlines() if l.strip()]

    async def dm_loop():
        try:
            for line in lines:
                try:
                    await member.send(line)
                except:
                    break
                await asyncio.sleep(1.5)
        except asyncio.CancelledError:
            pass

    task_key = f"dms_{member.id}"
    active_tasks[task_key] = asyncio.create_task(dm_loop())
    await ctx.send(f"📬 Đã gửi gói tấn công tin nhắn riêng tư (DM) đến {member.name}.")

@bot.command(name="stopdms")
async def stopdms(ctx, member: discord.Member):
    task_key = f"dms_{member.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()
        del active_tasks[task_key]
        await ctx.send(f"🛑 Đã ngừng gửi DM cho {member.mention}. | By Wwe Nguyen")

@bot.command(name="dame")
async def dame(ctx, member: discord.Member):
    gid = ctx.guild.id
    if gid not in dame_list:
        dame_list[gid] = {}
    dame_list[gid][member.id] = True
    await ctx.send(f"🔥 Mục tiêu {member.mention} đã lọt vào tầm ngắm dame của Bot. Trả lời auto-chửi kích hoạt!")

@bot.command(name="stopdame")
async def stopdame(ctx):
    gid = ctx.guild.id
    dame_list[gid] = {}
    await ctx.send("🛑 Đã xóa toàn bộ danh sách dame của server này. | By Wwe Nguyen")

@bot.command(name="xich")
@commands.has_permissions(administrator=True)
async def xich(ctx, member: discord.Member):
    gid = ctx.guild.id
    if gid not in xich_list:
        xich_list[gid] = []
    if member.id not in xich_list[gid]:
        xich_list[gid].append(member.id)
        await ctx.send(f"⛓️ Đã xích cổ {member.mention}. Mọi tin nhắn của đối tượng này sẽ bị xóa ngay lập tức!")

@bot.command(name="moxich")
@commands.has_permissions(administrator=True)
async def moxich(ctx, member: discord.Member):
    gid = ctx.guild.id
    if gid in xich_list and member.id in xich_list[gid]:
        xich_list[gid].remove(member.id)
        await ctx.send(f"🔓 Đã tháo xích cho {member.mention}. Bạn đã tự do!")

@bot.event
async def on_message(message):
    if message.author.bot or not message.guild:
        return

    gid = message.guild.id

    if gid in xich_list and message.author.id in xich_list[gid]:
        try:
            await message.delete()
            return
        except:
            pass

    if gid in dame_list and message.author.id in dame_list[gid]:
        is_reply_to_bot = False
        if message.reference:
            ref_msg = await message.channel.fetch_message(message.reference.message_id)
            if ref_msg.author.id == bot.user.id:
                is_reply_to_bot = True

        if bot.user.mentioned_in(message) or is_reply_to_bot:
            dame_replies = ["Bớt sủa lại con trai ơi.", "Nói chuyện với bot mà cũng đòi thể hiện?", "Câm mồm đi nhóc."]
            await message.channel.send(f"{message.author.mention} {random.choice(dame_replies)}")

    await bot.process_commands(message)

@bot.command(name="ban")
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    await member.ban(reason=reason)
    await ctx.send(f"🔨 Đã ban thành viên **{member.name}**. Lý do: {reason} | By Wwe Nguyen")

@bot.command(name="unban")
@commands.has_permissions(ban_members=True)
async def unban(ctx, user_id: int):
    user = await bot.fetch_user(user_id)
    await ctx.guild.unban(user)
    await ctx.send(f"🔓 Đã gỡ ban cho người dùng **{user.name}**. | By Wwe Nguyen")

@bot.command(name="kick")
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    await member.kick(reason=reason)
    await ctx.send(f"👢 Đã trục xuất thành viên **{member.name}**. Lý do: {reason} | By Wwe Nguyen")

@bot.command(name="mute")
@commands.has_permissions(moderate_members=True)
async def mute(ctx, member: discord.Member, minutes: int, *, reason=None):
    duration = asyncio.timedelta(minutes=minutes)
    await member.timeout(duration, reason=reason)
    await ctx.send(f"🔇 Đã cấm ngôn (Timeout) thành viên {member.mention} trong {minutes} phút. | By Wwe Nguyen")

@bot.command(name="unmute")
@commands.has_permissions(moderate_members=True)
async def unmute(ctx, member: discord.Member):
    await member.timeout(None)
    await ctx.send(f"🔊 Đã gỡ cấm ngôn cho {member.mention}.")

@bot.command(name="role")
@commands.has_permissions(manage_roles=True)
async def role_cmd(ctx, member: discord.Member, role: discord.Role):
    if role in member.roles:
        await member.remove_roles(role)
        await ctx.send(f"❌ Đã gỡ bỏ role **{role.name}** khỏi {member.name}. | By Wwe Nguyen")
    else:
        await member.add_roles(role)
        await ctx.send(f"✅ Đã cấp thêm role **{role.name}** cho {member.name}. | By Wwe Nguyen")

@bot.command(name="lock")
@commands.has_permissions(manage_channels=True)
async def lock(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = False
    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send(f"🔒 Kênh {channel.mention} đã bị khóa chat thành công! | By Wwe Nguyen")

@bot.command(name="unlock")
@commands.has_permissions(manage_channels=True)
async def unlock(ctx, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    overwrite = channel.overwrites_for(ctx.guild.default_role)
    overwrite.send_messages = True
    await channel.set_permissions(ctx.guild.default_role, overwrite=overwrite)
    await ctx.send(f"🔓 Kênh {channel.mention} đã được mở khóa chat tự do! | By Wwe Nguyen")

@bot.command(name="addadmin")
@commands.has_permissions(administrator=True)
async def addadmin(ctx, member: discord.Member):
    if member.id not in admin_list:
        admin_list.append(member.id)
        await ctx.send(f"👑 Thêm cấp quyền Admin Bot thành công cho {member.mention}. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Người này đã là Admin của Bot rồi.")

@bot.command(name="xoaadmin")
@commands.has_permissions(administrator=True)
async def xoaadmin(ctx, member: discord.Member):
    if member.id in admin_list:
        admin_list.remove(member.id)
        await ctx.send(f"⚙️ Đã hạ quyền Admin Bot của {member.mention}. | By Wwe Nguyen")
    else:
        await ctx.send("❌ Thành viên này vốn không nằm trong danh sách Admin.")

@bot.command(name="listadmin")
async def listadmin(ctx):
    if not admin_list:
        return await ctx.send("Danh sách Admin độc quyền của Bot đang trống. | By Wwe Nguyen")
    mentions = [f"<@{uid}>" for uid in admin_list]
    await ctx.send(f"👑 **Danh sách Quản trị viên Bot:** {', '.join(mentions)}\nPrefix: ! | Bot By Wwe Nguyen")

# ==================== LỆNH WEBHOOK PHÁT TRIỂN THÊM MỚI TẠI ĐÂY ====================

@bot.command(name="warwebhook")
@commands.has_permissions(manage_webhooks=True)
async def warwebhook(ctx, member: discord.Member):
    if not os.path.exists("nhay1.txt"):
        return await ctx.send("❌ Không tìm thấy file `nhay1.txt`. Vui lòng tạo file này để chạy lệnh!")

    # Đọc nội dung file
    with open("nhay1.txt", "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]
    
    if not lines:
        return await ctx.send("❌ File `nhay1.txt` đang trống.")

    await ctx.send("⚙️ Đang dọn dẹp các webhook cũ và khởi tạo luồng hủy diệt...")

    # Xóa toàn bộ webhook cũ trong kênh hiện tại
    try:
        old_webhooks = await ctx.channel.webhooks()
        for wh in old_webhooks:
            await wh.delete()
    except Exception as e:
        print(f"Lỗi khi xóa webhook cũ: {e}")

    # Lấy thông tin avatar của người sử dụng lệnh
    avatar_bytes = None
    try:
        avatar_bytes = await ctx.author.display_avatar.read()
    except:
        pass

    async def webhook_spam_loop():
        current_webhook = None
        # Biến đếm số lượng webhook đã tạo (Tối đa 100)
        webhook_count = 0 
        
        try:
            while True:
                # Tạo trạng thái Đang Nhập (Typing...) liên tục trong kênh chat
                async with ctx.channel.typing():
                    # Nếu chưa có webhook hoặc webhook cũ bị lỗi/rate limit, tiến hành sinh mới
                    if current_webhook is None:
                        if webhook_count >= 100:
                            # Nếu đã dùng hết 100 cái, dọn dẹp và tạo lại danh sách mới
                            try:
                                old_whs = await ctx.channel.webhooks()
                                for w in old_whs:
                                    await w.delete()
                            except: pass
                            webhook_count = 0
                        
                        try:
                            current_webhook = await ctx.channel.create_webhook(
                                name="Wwe nguyen Kẻ Hủy Diệt Ước Mơ", 
                                avatar=avatar_bytes
                            )
                            webhook_count += 1
                        except discord.HTTPException as e:
                            # Bị dính rate limit tạo webhook cấp hệ thống, đợi 1 xíu rồi thử lại
                            await asyncio.sleep(1)
                            continue

                    # Gửi tin nhắn và kèm tag user ở phía sau
                    content_msg = f"{random.choice(lines)} {member.mention}"
                    try:
                        await current_webhook.send(content=content_msg)
                        await asyncio.sleep(0.4) # Độ trễ cơ bản giúp tránh spam quá nghẽn mạng
                    except discord.HTTPException as e:
                        # Nếu bắt gặp mã lỗi Rate Limit (429) hoặc lỗi webhook bị hỏng
                        if e.code == 429 or e.status == 429:
                            # Thiết lập None để hệ thống tự động nhảy sang khởi tạo Webhook mới ở vòng lặp kế tiếp
                            current_webhook = None
                        else:
                            current_webhook = None
        except asyncio.CancelledError:
            # Khi gọi stopwebhook, dọn dẹp sạch toàn bộ webhook đã tạo
            try:
                final_webhooks = await ctx.channel.webhooks()
                for wh in final_webhooks:
                    await wh.delete()
            except:
                pass

    task_key = f"warwh_{ctx.channel.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()

    active_tasks[task_key] = asyncio.create_task(webhook_spam_loop())
    await ctx.send(f"🚀 Bắt đầu kích hoạt 100 Webhook hủy diệt nhắm vào {member.mention}! Trạng thái 'Đang nhập...' đã bật.")

@bot.command(name="stopwebhook")
@commands.has_permissions(manage_webhooks=True)
async def stopwebhook(ctx):
    task_key = f"warwh_{ctx.channel.id}"
    if task_key in active_tasks:
        active_tasks[task_key].cancel()
        del active_tasks[task_key]
        await ctx.send("🛑 Đã tắt luồng spam Webhook và dọn dẹp rác thành công! | By Wwe Nguyen")
    else:
        await ctx.send("❌ Hiện tại không có tiến trình warwebhook nào đang chạy trên kênh này.")

# ====================================================================================

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ Bạn không có đủ quyền hạn Discord trong Server để dùng lệnh kiểm duyệt này.")
    elif isinstance(error, commands.CheckFailure):
        await ctx.send("❌ Quyền hạn bị từ chối! Bạn không có tên trong cấu hình Admin Bot.")

bot.run("")